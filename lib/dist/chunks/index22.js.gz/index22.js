import { bE as a, a7 as u, x as n, Z as m, bF as C, R as p } from "./lib.js";
import { d as c, m as v, o as h, w as i, l as t, a as M, Q as Z, G as w } from "./vue.js";
var k = {
  class: "mb-1"
}, g = {
  class: "grid-container"
};
const x = /* @__PURE__ */ c({
  __name: "index",
  setup: function(B) {
    var s = a.isShow, e = a.showDialog, d = function() {
      e(!1), a.cancel();
    }, o = function(r) {
      a.confirm(r), e(!1), C(r);
    }, f = [{
      name: "关闭",
      fun: d
    }];
    return function(L, r) {
      return h(), v(m, {
        title: "多线编辑工具",
        modelValue: w(s),
        "onUpdate:modelValue": r[12] || (r[12] = function(l) {
          return Z(s) ? s.value = l : null;
        }),
        "max-width": "340",
        "footer-btn-list": f
      }, {
        default: i(function() {
          return [t("div", k, [r[25] || (r[25] = t("p", {
            class: "mb-1 text-caption"
          }, "要使用工具，请单击图标。必须在选定工具之后执行对象选择。", -1)), M(u, {
            title: "多线编辑工具"
          }, {
            default: i(function() {
              return [t("div", g, [t("div", {
                class: "tool-item",
                onClick: r[0] || (r[0] = function(l) {
                  return o("crossJunction");
                })
              }, n(r[13] || (r[13] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0 0 L54 0",
                stroke: "currentColor",
                "stroke-width": "1.5",
                "stroke-dasharray": "3,2",
                transform: "translate(0,25)"
              }), t("path", {
                d: "M0,0 L2,0 L2,17 L9,17 L9,0 L11,0 L11,17 L33,17 L33,18 L-21,18 L-21,17 L0,17 Z ",
                fill: "currentColor",
                transform: "translate(21,0)"
              }), t("path", {
                d: "M0,0 L54,0 L54,2 L32,2 L32,16 L30,16 L30,2 L23,2 L23,16 L21,16 L21,2 L0,2 Z ",
                fill: "currentColor",
                transform: "translate(0,35)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "十字闭合", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[1] || (r[1] = function(l) {
                  return o("tJunction");
                })
              }, n(r[14] || (r[14] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L48,0 L48,1 L0,1 Z ",
                fill: "currentColor",
                transform: "translate(4,11)"
              }), t("path", {
                d: "M0,0 L12,0 L13,2 L-1,2 Z ",
                fill: "currentColor",
                transform: "translate(5,18)"
              }), t("path", {
                d: "M0,0 L11,0 L11,2 L-1,2 Z ",
                fill: "currentColor",
                transform: "translate(23,18)"
              }), t("path", {
                d: "M0,0 L13,0 L13,2 L0,2 Z ",
                fill: "currentColor",
                transform: "translate(39,18)"
              }), t("path", {
                d: "M0,0 L48,0 L48,1 L29,1 L29,18 L27,18 L27,1 L22,1 L22,18 L20,18 L20,1 L0,1 Z ",
                fill: "currentColor",
                transform: "translate(4,26)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "T 形闭合", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[2] || (r[2] = function(l) {
                  return o("cornerJunction");
                })
              }, n(r[15] || (r[15] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L1,0 L1,32 L33,32 L32,34 L0,34 Z ",
                fill: "currentColor",
                transform: "translate(12,8)"
              }), t("path", {
                d: "M0,0 L1,0 L1,29 L30,29 L29,31 L0,31 Z ",
                fill: "currentColor",
                transform: "translate(15,8)"
              }), t("path", {
                d: "M0,0 L2,0 L2,24 L26,24 L26,26 L0,26 Z ",
                fill: "currentColor",
                transform: "translate(19,9)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "角点结合", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[3] || (r[3] = function(l) {
                  return o("singleCut");
                })
              }, n(r[16] || (r[16] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L2,0 L2,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(3,4)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(11,4)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(17,4)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(44,4)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(50,4)"
              }), t("path", {
                d: "M0,0 L2,0 L2,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(57,4)"
              }), t("path", {
                d: "M0,0 L3,0 L4,3 L0,5 L0,3 L-9,3 L-9,2 L-1,1 Z ",
                fill: "currentColor",
                transform: "translate(32,28)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(44,34)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "单个剪切", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[4] || (r[4] = function(l) {
                  return o("crossOpen");
                })
              }, n(r[17] || (r[17] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L2,0 L2,18 L-21,18 L-20,16 L0,16 Z ",
                fill: "currentColor",
                transform: "translate(21,0)"
              }), t("path", {
                d: "M0,0 L2,0 L2,16 L22,16 L23,18 L0,18 Z ",
                fill: "currentColor",
                transform: "translate(30,0)"
              }), t("path", {
                d: "M0 0 L54 0",
                stroke: "currentColor",
                "stroke-width": "1.5",
                "stroke-dasharray": "3,2",
                transform: "translate(0,25)"
              }), t("path", {
                d: "M0,0 L23,0 L23,15 L21,15 L21,1 L0,1 Z ",
                fill: "currentColor",
                transform: "translate(0,35)"
              }), t("path", {
                d: "M0,0 L23,0 L23,1 L2,1 L2,15 L0,15 Z ",
                fill: "currentColor",
                transform: "translate(30,35)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "十字打开", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[5] || (r[5] = function(l) {
                  return o("tOpen");
                })
              }, n(r[18] || (r[18] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L48,0 L48,2 L0,2 Z ",
                fill: "currentColor",
                transform: "translate(4,9)"
              }), t("path", {
                d: "M0,0 L18,0 L18,2 L0,2 Z ",
                fill: "currentColor",
                transform: "translate(5,16)"
              }), t("path", {
                d: "M0,0 L19,0 L19,2 L0,2 Z ",
                fill: "currentColor",
                transform: "translate(33,16)"
              }), t("path", {
                d: "M0,0 L21,0 L21,18 L19,18 L19,2 L0,2 Z ",
                fill: "currentColor",
                transform: "translate(4,24)"
              }), t("path", {
                d: "M0,0 L21,0 L21,2 L2,2 L2,18 L0,18 Z ",
                fill: "currentColor",
                transform: "translate(31,24)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "T 形打开", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[6] || (r[6] = function(l) {
                  return o("addVertex");
                })
              }, n(r[19] || (r[19] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M10,35 L30,35 L50,35 L60,35",
                stroke: "currentColor",
                "stroke-width": "1.5",
                fill: "none"
              }), t("path", {
                d: "M30,35 L50,35",
                stroke: "currentColor",
                "stroke-width": "2",
                fill: "none"
              }), t("circle", {
                cx: "40",
                cy: "35",
                r: "4",
                fill: "currentColor"
              }), t("path", {
                d: "M35,30 L45,40 M35,40 L45,30",
                stroke: "currentColor",
                "stroke-width": "1.5"
              })])], -1), t("div", {
                class: "tool-label"
              }, "添加顶点", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[7] || (r[7] = function(l) {
                  return o("allCut");
                })
              }, n(r[20] || (r[20] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L2,0 L2,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(3,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(11,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(17,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(44,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(50,5)"
              }), t("path", {
                d: "M0,0 L2,0 L2,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(57,5)"
              }), t("path", {
                d: "M0,0 L3,0 L4,3 L0,5 L0,3 L-9,3 L-9,2 L-1,1 Z ",
                fill: "currentColor",
                transform: "translate(32,29)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(44,35)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(50,35)"
              }), t("path", {
                d: "M0,0 L2,0 L2,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(57,35)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "全部剪切", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[8] || (r[8] = function(l) {
                  return o("crossMerge");
                })
              }, n(r[21] || (r[21] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L2,0 L2,18 L-21,18 L-20,16 L0,16 Z ",
                fill: "currentColor",
                transform: "translate(21,0)"
              }), t("path", {
                d: "M0,0 L2,0 L2,16 L22,16 L23,18 L0,18 Z ",
                fill: "currentColor",
                transform: "translate(30,0)"
              }), t("path", {
                d: "M0 0 L54 0",
                stroke: "currentColor",
                "stroke-width": "1.5",
                "stroke-dasharray": "3,2",
                transform: "translate(0,25)"
              }), t("path", {
                d: "M0 0 L0 54",
                stroke: "currentColor",
                "stroke-width": "1.5",
                "stroke-dasharray": "3,2",
                transform: "translate(27,0)"
              }), t("path", {
                d: "M0,0 L23,0 L23,15 L21,15 L21,1 L0,1 Z ",
                fill: "currentColor",
                transform: "translate(0,35)"
              }), t("path", {
                d: "M0,0 L23,0 L23,1 L2,1 L2,15 L0,15 Z ",
                fill: "currentColor",
                transform: "translate(30,35)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "十字合并", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[9] || (r[9] = function(l) {
                  return o("tMerge");
                })
              }, n(r[22] || (r[22] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L51,0 L52,2 L-1,2 Z ",
                fill: "currentColor",
                transform: "translate(2,14)"
              }), t("path", {
                d: "M0,0 L21,0 L21,1 L0,1 Z ",
                fill: "currentColor",
                transform: "translate(1,22)"
              }), t("path", {
                d: "M0,0 L1,0 L1,27 L0,27 Z ",
                fill: "currentColor",
                transform: "translate(27,22)"
              }), t("path", {
                d: "M0,0 L21,0 L21,1 L0,1 Z ",
                fill: "currentColor",
                transform: "translate(33,22)"
              }), t("path", {
                d: "M0,0 L23,0 L23,18 L21,18 L21,2 L1,2 Z ",
                fill: "currentColor",
                transform: "translate(1,31)"
              }), t("path", {
                d: "M0,0 L24,0 L23,2 L1,2 L1,18 L0,18 Z ",
                fill: "currentColor",
                transform: "translate(30,31)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "T 形合并", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[10] || (r[10] = function(l) {
                  return o("deleteVertex");
                })
              }, n(r[23] || (r[23] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M10,35 L30,35 L50,35 L60,35",
                stroke: "currentColor",
                "stroke-width": "1.5",
                fill: "none"
              }), t("path", {
                d: "M55,30 L60,35 L55,40",
                stroke: "currentColor",
                "stroke-width": "1",
                fill: "none"
              }), t("circle", {
                cx: "40",
                cy: "35",
                r: "4",
                fill: "currentColor"
              }), t("path", {
                d: "M35,30 L45,40 M35,40 L45,30",
                stroke: "currentColor",
                "stroke-width": "1.5"
              })])], -1), t("div", {
                class: "tool-label"
              }, "删除顶点", -1)]))), t("div", {
                class: "tool-item",
                onClick: r[11] || (r[11] = function(l) {
                  return o("allJoin");
                })
              }, n(r[24] || (r[24] = [t("div", {
                class: "tool-icon"
              }, [t("svg", {
                width: "28",
                height: "28",
                viewBox: "0 0 56 56"
              }, [t("path", {
                d: "M0,0 L2,0 L2,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(3,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(11,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(17,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(44,5)"
              }), t("path", {
                d: "M0,0 L1,0 L1,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(50,5)"
              }), t("path", {
                d: "M0,0 L2,0 L2,51 L0,51 Z ",
                fill: "currentColor",
                transform: "translate(57,5)"
              }), t("path", {
                d: "M0,0 L3,0 L4,3 L0,5 L0,3 L-9,3 L-9,2 L-1,1 Z ",
                fill: "currentColor",
                transform: "translate(32,29)"
              }), t("path", {
                d: "M0,0 L2,0 L2,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(3,35)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(11,35)"
              }), t("path", {
                d: "M0,0 L1,0 L1,21 L0,21 Z ",
                fill: "currentColor",
                transform: "translate(17,35)"
              })])], -1), t("div", {
                class: "tool-label"
              }, "全部接合", -1)])))])];
            }),
            _: 1
          })])];
        }),
        _: 1
      }, 8, ["modelValue"]);
    };
  }
}), V = /* @__PURE__ */ p(x, [["__scopeId", "data-v-fdf341a5"]]);
export {
  V as default
};
