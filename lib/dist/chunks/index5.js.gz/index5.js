import { aa as S, j as N, ab as d, ac as te, ad as ae, ae as ne, af as le, a6 as A, a7 as g, x as $, ag as i, Z as re, _ as ue, a as q, ah as T, t as h, h as se } from "./lib.js";
import { d as ie, f as F, h as oe, m as de, o as me, w as n, l as o, a, Q as k, G as u, q as p, t as m } from "./vue.js";
import { a as fe, m as pe, o as H, g as Q, M as ve } from "./mxcad.js";
import { D as ge } from "./mxdraw.js";
import { v as Ve, b as be, D as we, C as X, h as ye, j, i as V, F as ce } from "./vuetify.js";
var Me = {
  class: "px-3"
}, Ce = {
  class: "d-flex algin-center mt-2 w-75"
}, ke = {
  class: ""
}, De = {
  class: ""
}, Pe = {
  class: ""
}, Ue = {
  class: ""
};
const Se = /* @__PURE__ */ ie({
  __name: "index",
  setup: function(Ae) {
    var x = S.isShow, z = S.showDialog, B = F(1), s = oe({
      x: 0,
      y: 0
    }), v = N(!1, "Mx_AttachPictureDialog_isGetPt"), b = N(!1, "Mx_AttachPictureDialog_isGetZoomRatio"), w = N(!1, "Mx_AttachPictureDialog_isGetRotationAngle"), y = F(1), c = F(0), Y = /* @__PURE__ */ function() {
      var r = ue(/* @__PURE__ */ q.mark(function e() {
        var t, G, D, M, f, I, C, E, P, Z, U, R;
        return q.wrap(function(l) {
          for (; ; ) switch (l.prev = l.next) {
            case 0:
              if (d.value) {
                l.next = 1;
                break;
              }
              return l.abrupt("return");
            case 1:
              if (d.value.url !== "") {
                l.next = 2;
                break;
              }
              return l.abrupt("return", se().warning(h("请先选择图片")));
            case 2:
              if (z(!1), t = ve.getCurrentMxCAD(), !v.value) {
                l.next = 5;
                break;
              }
              return G = new Q(), G.setMessage(h("指定插入点")), l.next = 3, G.go();
            case 3:
              if (D = l.sent, D) {
                l.next = 4;
                break;
              }
              return l.abrupt("return");
            case 4:
              s.x = D.x, s.y = D.y;
            case 5:
              if (!b.value) {
                l.next = 8;
                break;
              }
              return M = new Q(), f = new H(s.x, s.y), M.setBasePt(f), M.setMessage(h("指定缩放比例")), M.setUserDraw(function(K, O) {
                var L = K.distanceTo(f) / i.width, W = i.width * L, _ = i.height * L, ee = new THREE.Vector3(f.x + W, f.y + _);
                O.drawRect(f.toVector3(), ee);
              }), l.next = 6, M.go();
            case 6:
              if (I = l.sent, I) {
                l.next = 7;
                break;
              }
              return l.abrupt("return");
            case 7:
              y.value = T(I.distanceTo(f) / i.width, 3);
            case 8:
              if (!w.value) {
                l.next = 11;
                break;
              }
              return C = new pe(), C.setMessage(h("指定旋转角度")), E = new H(s.x, s.y), C.setBasePt(E), l.next = 9, C.go();
            case 9:
              if (P = l.sent, P) {
                l.next = 10;
                break;
              }
              return l.abrupt("return");
            case 10:
              C.getDetailedResult() === ge.kCoordIn ? c.value = T(P, 3) : c.value = T(P / (Math.PI / 180), 3);
            case 11:
              Z = t.drawImage(s.x, s.y, i.width * y.value, i.height * y.value, c.value, d.value.fileName || d.value.url, !0, i.width, i.height), U = Z.getMcDbEntity(), U && (R = U.trueColor, U.trueColor = new fe(R.red, R.green, R.blue, B.value * 255));
            case 12:
            case "end":
              return l.stop();
          }
        }, e);
      }));
      return function() {
        return r.apply(this, arguments);
      };
    }(), J = [{
      name: "确定",
      fun: Y,
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        return z(!1);
      }
    }];
    return function(r, e) {
      return me(), de(re, {
        title: r.t("1922"),
        modelValue: u(x),
        "onUpdate:modelValue": e[13] || (e[13] = function(t) {
          return k(x) ? x.value = t : null;
        }),
        "max-width": "600",
        footerBtnList: J
      }, {
        default: n(function() {
          return [o("div", Me, [o("div", Ce, [a(Ve, {
            class: "mt-1 mr-2",
            "return-object": "",
            "item-title": "fileName",
            "item-value": "url",
            items: u(ae),
            modelValue: u(d),
            "onUpdate:modelValue": [e[0] || (e[0] = function(t) {
              return k(d) ? d.value = t : null;
            }), e[1] || (e[1] = function(t) {
              return u(te)(t);
            })],
            modelModifiers: {
              lazy: !0
            }
          }, {
            prepend: n(function() {
              return [o("span", ke, [p(m(r.t("1923")) + "(", 1), e[14] || (e[14] = o("span", {
                class: "text-decoration-underline"
              }, "N", -1)), e[15] || (e[15] = p(") ", -1))])];
            }),
            _: 1
          }, 8, ["items", "modelValue"]), a(ne, {
            onClick: e[2] || (e[2] = function(t) {
              return u(le)(u(S));
            })
          }, {
            default: n(function() {
              return [a(A, {
                "key-name": "B"
              }, {
                default: n(function() {
                  return [p(m(r.t("1924")), 1)];
                }),
                _: 1
              }), e[16] || (e[16] = p()), a(be, {
                icon: "class:iconfont more"
              })];
            }),
            _: 1
          })]), a(we, {
            "align-stretch": "",
            class: "mt-2"
          }, {
            default: n(function() {
              return [a(X, {
                cols: 8,
                "align-self": "auto"
              }, {
                default: n(function() {
                  return [a(g, {
                    title: r.t("1925"),
                    class: "h-100"
                  }, {
                    default: n(function() {
                      var t;
                      return [a(ye, {
                        src: (t = u(d)) === null || t === void 0 ? void 0 : t.url,
                        crossorigin: "anonymous",
                        height: "425px"
                      }, null, 8, ["src"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              }), a(X, {
                cols: 4,
                "align-self": "auto"
              }, {
                default: n(function() {
                  return [a(g, {
                    title: r.t("209")
                  }, {
                    default: n(function() {
                      return [a(j, {
                        modelValue: u(v),
                        "onUpdate:modelValue": e[3] || (e[3] = function(t) {
                          return k(v) ? v.value = t : null;
                        })
                      }, {
                        label: n(function() {
                          return [a(A, {
                            "key-name": "S"
                          }, {
                            default: n(function() {
                              return [p(m(r.t("1927")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), a(V, {
                        class: "mt-1",
                        modelValue: s.x,
                        "onUpdate:modelValue": e[4] || (e[4] = function(t) {
                          return s.x = t;
                        }),
                        disabled: u(v)
                      }, {
                        prepend: n(function() {
                          return $(e[17] || (e[17] = [o("span", {
                            class: ""
                          }, " X:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"]), a(V, {
                        class: "mt-1",
                        modelValue: s.y,
                        "onUpdate:modelValue": e[5] || (e[5] = function(t) {
                          return s.y = t;
                        }),
                        disabled: u(v)
                      }, {
                        prepend: n(function() {
                          return $(e[18] || (e[18] = [o("span", {
                            class: ""
                          }, " Y:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"])];
                    }),
                    _: 1
                  }, 8, ["title"]), a(g, {
                    title: r.t("1928")
                  }, {
                    default: n(function() {
                      return [a(j, {
                        modelValue: u(b),
                        "onUpdate:modelValue": e[6] || (e[6] = function(t) {
                          return k(b) ? b.value = t : null;
                        })
                      }, {
                        label: n(function() {
                          return [a(A, {
                            "key-name": "S"
                          }, {
                            default: n(function() {
                              return [p(m(r.t("1927")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), a(V, {
                        class: "mt-1 ml-1",
                        type: "number",
                        disabled: u(b),
                        modelValue: y.value,
                        "onUpdate:modelValue": e[7] || (e[7] = function(t) {
                          return y.value = t;
                        })
                      }, null, 8, ["disabled", "modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"]), a(g, {
                    title: r.t("1929")
                  }, {
                    default: n(function() {
                      return [a(V, {
                        class: "mt-1",
                        type: "number",
                        modelValue: u(i).width,
                        "onUpdate:modelValue": e[8] || (e[8] = function(t) {
                          return u(i).width = t;
                        })
                      }, {
                        prepend: n(function() {
                          return [o("span", De, m(r.t("1930")) + ":", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), a(V, {
                        class: "mt-1",
                        type: "number",
                        modelValue: u(i).height,
                        "onUpdate:modelValue": e[9] || (e[9] = function(t) {
                          return u(i).height = t;
                        })
                      }, {
                        prepend: n(function() {
                          return [o("span", Pe, m(r.t("1835")) + ":", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"]), a(g, {
                    title: r.t("1931")
                  }, {
                    default: n(function() {
                      return [a(j, {
                        class: "",
                        modelValue: u(w),
                        "onUpdate:modelValue": e[10] || (e[10] = function(t) {
                          return k(w) ? w.value = t : null;
                        })
                      }, {
                        label: n(function() {
                          return [a(A, {
                            "key-name": "S"
                          }, {
                            default: n(function() {
                              return [p(m(r.t("1927")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), a(V, {
                        class: "mt-1",
                        type: "number",
                        modelValue: c.value,
                        "onUpdate:modelValue": e[11] || (e[11] = function(t) {
                          return c.value = t;
                        }),
                        disabled: u(w)
                      }, {
                        prepend: n(function() {
                          return [o("span", Ue, m(r.t("169")) + ":", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"])];
                    }),
                    _: 1
                  }, 8, ["title"]), a(g, {
                    title: r.t("1932")
                  }, {
                    default: n(function() {
                      return [a(ce, {
                        modelValue: B.value,
                        "onUpdate:modelValue": e[12] || (e[12] = function(t) {
                          return B.value = t;
                        }),
                        max: 1,
                        min: 0,
                        step: 0.2,
                        "thumb-label": ""
                      }, null, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              })];
            }),
            _: 1
          })])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  Se as default
};
