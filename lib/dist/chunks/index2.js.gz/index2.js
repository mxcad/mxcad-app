import { U, V as s, W as P, X as C, t as p, Y as H, Z as J, _ as ee, $ as re, a0 as ae, a as L, h as A, a1 as te, l as ne, R as ie } from "./lib.js";
import { d as oe, f as y, g as h, i as se, m as K, o as j, w as n, l as g, a as i, s as ue, G as O, t as m, ac as I, ad as M, q as w, Q as le } from "./vue.js";
import { a8 as xe, c as D, a9 as _, b as R, d as k, I as z, i as S, V as de, m as B, y as ce } from "./vuetify.js";
function E(c, f) {
  var x = Object.keys(c);
  if (Object.getOwnPropertySymbols) {
    var u = Object.getOwnPropertySymbols(c);
    f && (u = u.filter(function(a) {
      return Object.getOwnPropertyDescriptor(c, a).enumerable;
    })), x.push.apply(x, u);
  }
  return x;
}
function fe(c) {
  for (var f = 1; f < arguments.length; f++) {
    var x = arguments[f] != null ? arguments[f] : {};
    f % 2 ? E(Object(x), !0).forEach(function(u) {
      ne(c, u, x[u]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(c, Object.getOwnPropertyDescriptors(x)) : E(Object(x)).forEach(function(u) {
      Object.defineProperty(c, u, Object.getOwnPropertyDescriptor(x, u));
    });
  }
  return c;
}
var pe = {
  class: "px-4 py-3"
}, ve = {
  class: "d-flex align-center"
}, me = {
  class: "d-flex align-center"
};
const ye = /* @__PURE__ */ oe({
  __name: "index",
  setup: function(f) {
    var x = U.showDialog, u = U.isShow, a = y({
      provider: s.provider,
      apiKey: s.apiKey,
      selectedModel: s.selectedModel,
      baseURL: s.baseURL
    }), v = y(!1), b = y(!1), V = y(!1), T = y(!1), F = h(function() {
      return P.find(function(t) {
        return t.id === a.value.provider;
      });
    }), N = h(function() {
      return C(a.value.provider);
    }), $ = h(function() {
      return [function(t) {
        return !!t || p("请输入 API 密钥");
      }, function(t) {
        return H(t, a.value.provider) || p("API 密钥格式不正确");
      }];
    }), G = [function(t) {
      return !t || /^https?:\/\/.+/.test(t) || p("请输入有效的 URL");
    }];
    se(u, function(t) {
      t && (a.value = {
        provider: s.provider,
        apiKey: s.apiKey,
        selectedModel: s.selectedModel,
        baseURL: s.baseURL
      }, T.value = !1);
    });
    var q = function() {
      var r = F.value;
      if (!r) return p("请输入 API 密钥");
      switch (r.id) {
        case "openrouter":
          return "sk-or-v1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        case "openai":
          return "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        case "anthropic":
          return "sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        case "google":
          return "AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        default:
          return p("请输入 API 密钥");
      }
    }, Q = function(r) {
      var e = P.find(function(d) {
        return d.id === r;
      });
      if (e) {
        a.value.baseURL = e.baseURL;
        var o = C(r);
        o.length > 0 && (a.value.selectedModel = o[0].id);
      }
    }, W = /* @__PURE__ */ function() {
      var t = ee(/* @__PURE__ */ L.mark(function r() {
        var e, o, d;
        return L.wrap(function(l) {
          for (; ; ) switch (l.prev = l.next) {
            case 0:
              if (v.value) {
                l.next = 1;
                break;
              }
              return l.abrupt("return");
            case 1:
              return V.value = !0, l.prev = 2, e = fe({}, s), Object.assign(s, a.value), l.next = 3, te();
            case 3:
              o = l.sent, o ? A().success(p("连接成功")) : A().error(p("连接失败")), Object.assign(s, e), l.next = 5;
              break;
            case 4:
              l.prev = 4, d = l.catch(2), console.error("连接测试失败:", d);
            case 5:
              return l.prev = 5, V.value = !1, l.finish(5);
            case 6:
            case "end":
              return l.stop();
          }
        }, r, null, [[2, 4, 5, 6]]);
      }));
      return function() {
        return t.apply(this, arguments);
      };
    }(), X = function() {
      v.value && (re(a.value), x(!1));
    }, Y = function() {
      ae(), a.value = {
        provider: s.provider,
        apiKey: s.apiKey,
        selectedModel: s.selectedModel,
        baseURL: s.baseURL
      };
    }, Z = [{
      name: "测试连接",
      fun: W,
      disabled: function() {
        return !a.value.apiKey || !v.value || V.value;
      }
    }, {
      name: "重置",
      fun: Y
    }, {
      name: "取消",
      fun: function() {
        return x(!1);
      }
    }, {
      name: "保存",
      fun: X,
      primary: !0,
      disabled: function() {
        return !v.value;
      }
    }];
    return function(t, r) {
      return j(), K(J, {
        title: "AI" + O(p)("配置设置"),
        modelValue: O(u),
        "onUpdate:modelValue": r[6] || (r[6] = function(e) {
          return le(u) ? u.value = e : null;
        }),
        "max-width": "500",
        footerBtnList: Z
      }, {
        default: n(function() {
          return [g("div", pe, [i(xe, {
            modelValue: v.value,
            "onUpdate:modelValue": r[5] || (r[5] = function(e) {
              return v.value = e;
            })
          }, {
            default: n(function() {
              return [i(D, {
                modelValue: a.value.provider,
                "onUpdate:modelValue": [r[0] || (r[0] = function(e) {
                  return a.value.provider = e;
                }), Q],
                items: O(P),
                "item-title": "name",
                "item-value": "id",
                class: "mb-4"
              }, {
                item: n(function(e) {
                  var o = e.props, d = e.item;
                  return [i(k, I(M(o)), {
                    prepend: n(function() {
                      return [i(_, {
                        size: "24",
                        class: "mr-3",
                        color: "primary",
                        variant: "tonal"
                      }, {
                        default: n(function() {
                          return [i(R, {
                            icon: d.raw.icon,
                            size: "16"
                          }, null, 8, ["icon"])];
                        }),
                        _: 2
                      }, 1024)];
                    }),
                    default: n(function() {
                      return [i(z, {
                        class: "text-caption"
                      }, {
                        default: n(function() {
                          return [w(m(d.raw.description), 1)];
                        }),
                        _: 2
                      }, 1024)];
                    }),
                    _: 2
                  }, 1040)];
                }),
                selection: n(function(e) {
                  var o = e.item;
                  return [g("div", ve, [i(_, {
                    size: "20",
                    class: "mr-2",
                    color: "primary",
                    variant: "tonal"
                  }, {
                    default: n(function() {
                      return [i(R, {
                        icon: o.raw.icon,
                        size: "12"
                      }, null, 8, ["icon"])];
                    }),
                    _: 2
                  }, 1024), g("span", null, m(o.raw.name), 1)])];
                }),
                _: 1
              }, 8, ["modelValue", "items"]), i(S, {
                modelValue: a.value.apiKey,
                "onUpdate:modelValue": r[2] || (r[2] = function(e) {
                  return a.value.apiKey = e;
                }),
                placeholder: q(),
                type: b.value ? "text" : "password",
                rules: $.value,
                class: "mb-4"
              }, {
                "append-inner": n(function() {
                  return [i(de, {
                    icon: "",
                    variant: "text",
                    size: "16",
                    onClick: r[1] || (r[1] = function(e) {
                      return b.value = !b.value;
                    })
                  }, {
                    default: n(function() {
                      return [i(R, {
                        icon: b.value ? "$mdi-eye-off" : "$mdi-eye",
                        size: "12"
                      }, null, 8, ["icon"])];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }, 8, ["modelValue", "placeholder", "type", "rules"]), i(D, {
                modelValue: a.value.selectedModel,
                "onUpdate:modelValue": r[3] || (r[3] = function(e) {
                  return a.value.selectedModel = e;
                }),
                items: N.value,
                "item-title": "name",
                "item-value": "id",
                class: "mb-4"
              }, {
                item: n(function(e) {
                  var o = e.props, d = e.item;
                  return [i(k, I(M(o)), {
                    prepend: n(function() {
                      return [i(B, {
                        color: d.raw.free ? "success" : "primary",
                        variant: "outlined",
                        size: "x-small",
                        class: "mr-3"
                      }, {
                        default: n(function() {
                          return [w(m(d.raw.free ? "FREE" : "PAID"), 1)];
                        }),
                        _: 2
                      }, 1032, ["color"])];
                    }),
                    default: n(function() {
                      return [i(z, {
                        class: "text-caption"
                      }, {
                        default: n(function() {
                          return [w(m(d.raw.description), 1)];
                        }),
                        _: 2
                      }, 1024)];
                    }),
                    _: 2
                  }, 1040)];
                }),
                selection: n(function(e) {
                  var o = e.item;
                  return [g("div", me, [i(B, {
                    color: o.raw.free ? "success" : "primary",
                    variant: "outlined",
                    size: "x-small",
                    class: "mr-2"
                  }, {
                    default: n(function() {
                      return [w(m(o.raw.free ? "FREE" : "PAID"), 1)];
                    }),
                    _: 2
                  }, 1032, ["color"]), g("span", null, m(o.raw.name), 1)])];
                }),
                _: 1
              }, 8, ["modelValue", "items"]), i(S, {
                modelValue: a.value.baseURL,
                "onUpdate:modelValue": r[4] || (r[4] = function(e) {
                  return a.value.baseURL = e;
                }),
                rules: G,
                class: "mt-2"
              }, null, 8, ["modelValue"]), V.value ? (j(), K(ce, {
                key: 0,
                indeterminate: "",
                color: "primary",
                class: "mb-4"
              })) : ue("", !0)];
            }),
            _: 1
          }, 8, ["modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), we = /* @__PURE__ */ ie(ye, [["__scopeId", "data-v-98e1ad24"]]);
export {
  we as default
};
