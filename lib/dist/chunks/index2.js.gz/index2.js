import { V as P, W as u, X as g, Y as R, t as x, Z as q, x as G, $ as Q, a0 as W, a1 as X, T as Z } from "./lib.js";
import { d as j, f as c, g as w, i as H, m as U, o as C, w as e, l as v, a as n, s as J, G as d, q as f, t as s, ac as O, ad as ee, x as te, Q as re } from "./vue.js";
import { a7 as ae, c as ne, a8 as h, b as _, d as b, a9 as K, i as A, V as ie, v as oe, l as M, m as I, y as le } from "./vuetify.js";
var ue = {
  class: "px-4 py-3"
}, xe = {
  class: "d-flex align-center"
}, se = {
  class: "d-flex align-center ga-1",
  style: {
    "min-width": "0"
  }
}, de = {
  class: "text-truncate",
  style: {
    "min-width": "0"
  }
};
const fe = /* @__PURE__ */ j({
  __name: "index",
  setup: function(ve) {
    var L = P.showDialog, p = P.isShow, l = c({
      provider: u.provider,
      apiKey: u.apiKey,
      selectedModel: u.selectedModel,
      baseURL: u.baseURL
    }), m = c(!1), V = c(!1), z = c(!1), D = c(!1), k = w(function() {
      return g.find(function(i) {
        return i.id === l.value.provider;
      });
    }), B = w(function() {
      return R(l.value.provider);
    }), S = w(function() {
      return [function(i) {
        return !!i || x("4382");
      }, function(i) {
        return q(i) || x("4383");
      }];
    }), T = [function(i) {
      return !i || /^https?:\/\/.+/.test(i) || x("4384");
    }];
    H(p, function(i) {
      i && (l.value = {
        provider: u.provider,
        apiKey: u.apiKey,
        selectedModel: u.selectedModel,
        baseURL: u.baseURL
      }, D.value = !1);
    });
    var $ = function() {
      var r = k.value;
      if (!r) return x("4382");
      switch (r.id) {
        case "openrouter":
          return "sk-or-v1-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        case "openai":
          return "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        case "anthropic":
          return "sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        case "google":
          return "AIzaSyxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
        default:
          return x("4382");
      }
    }, E = function(r) {
      var t = g.find(function(a) {
        return a.id === r;
      });
      if (t) {
        l.value.baseURL = t.baseURL;
        var o = R(r);
        o.length > 0 && (l.value.selectedModel = o[0].id);
      }
    }, F = function() {
      m.value && (W(l.value), L(!1));
    }, N = function() {
      X(), l.value = {
        provider: u.provider,
        apiKey: u.apiKey,
        selectedModel: u.selectedModel,
        baseURL: u.baseURL
      };
    }, Y = [{
      name: "重置",
      fun: N
    }, {
      name: "取消",
      fun: function() {
        return L(!1);
      }
    }, {
      name: "保存",
      fun: F,
      primary: !0,
      disabled: function() {
        return !m.value;
      }
    }];
    return function(i, r) {
      return C(), U(Q, {
        title: "AI" + d(x)("4387"),
        modelValue: d(p),
        "onUpdate:modelValue": r[6] || (r[6] = function(t) {
          return re(p) ? p.value = t : null;
        }),
        "max-width": "500",
        footerBtnList: Y
      }, {
        default: e(function() {
          return [v("div", ue, [n(ae, {
            modelValue: m.value,
            "onUpdate:modelValue": r[5] || (r[5] = function(t) {
              return m.value = t;
            })
          }, {
            default: e(function() {
              return [n(ne, {
                modelValue: l.value.provider,
                "onUpdate:modelValue": [r[0] || (r[0] = function(t) {
                  return l.value.provider = t;
                }), E],
                items: d(g),
                "item-title": "name",
                "item-value": "id",
                class: "mb-4"
              }, {
                item: e(function(t) {
                  var o = t.props, a = t.item;
                  return [n(b, O(ee(o)), {
                    prepend: e(function() {
                      return [n(h, {
                        size: "24",
                        class: "mr-3",
                        color: "primary",
                        variant: "tonal"
                      }, {
                        default: e(function() {
                          return [n(_, {
                            icon: a.raw.icon,
                            size: "16"
                          }, null, 8, ["icon"])];
                        }),
                        _: 2
                      }, 1024)];
                    }),
                    default: e(function() {
                      return [n(K, {
                        class: "text-caption"
                      }, {
                        default: e(function() {
                          return [f(s(a.raw.description), 1)];
                        }),
                        _: 2
                      }, 1024)];
                    }),
                    _: 2
                  }, 1040)];
                }),
                selection: e(function(t) {
                  var o = t.item;
                  return [v("div", xe, [n(h, {
                    size: "20",
                    class: "mr-2",
                    color: "primary",
                    variant: "tonal"
                  }, {
                    default: e(function() {
                      return [n(_, {
                        icon: o.raw.icon,
                        size: "12"
                      }, null, 8, ["icon"])];
                    }),
                    _: 2
                  }, 1024), v("span", null, s(o.raw.name), 1)])];
                }),
                prepend: e(function() {
                  return [f(s(d(x)("选择供应商")) + ": ", 1)];
                }),
                _: 1
              }, 8, ["modelValue", "items"]), n(A, {
                modelValue: l.value.apiKey,
                "onUpdate:modelValue": r[2] || (r[2] = function(t) {
                  return l.value.apiKey = t;
                }),
                placeholder: $(),
                type: V.value ? "text" : "password",
                rules: S.value,
                class: "mb-4"
              }, {
                "append-inner": e(function() {
                  return [n(ie, {
                    icon: "",
                    variant: "text",
                    size: "16",
                    onClick: r[1] || (r[1] = function(t) {
                      return V.value = !V.value;
                    })
                  }, {
                    default: e(function() {
                      return [n(_, {
                        icon: V.value ? "$mdi-eye-off" : "$mdi-eye",
                        size: "12"
                      }, null, 8, ["icon"])];
                    }),
                    _: 1
                  })];
                }),
                prepend: e(function() {
                  return G(r[7] || (r[7] = [f(" API KEY: ", -1)]));
                }),
                _: 1
              }, 8, ["modelValue", "placeholder", "type", "rules"]), n(oe, {
                modelValue: l.value.selectedModel,
                "onUpdate:modelValue": r[3] || (r[3] = function(t) {
                  return l.value.selectedModel = t;
                }),
                items: B.value,
                "item-title": "name",
                "item-value": "id",
                class: "mb-4",
                hint: d(x)("4453"),
                "persistent-hint": "",
                type: "string"
              }, {
                prepend: e(function() {
                  return [f(s(d(x)("模型选择")) + ": ", 1)];
                }),
                selection: e(function(t) {
                  var o, a = t.item;
                  return [v("div", se, [n(I, {
                    color: (a && typeof a.raw == "string" ? a.raw.includes("free") : !(a == null || (o = a.raw) === null || o === void 0) && o.free) ? "success" : "primary"
                  }, {
                    default: e(function() {
                      var y;
                      return [f(s((a && typeof a.raw == "string" ? a.raw.includes("free") : !(a == null || (y = a.raw) === null || y === void 0) && y.free) ? "FREE" : "PAID"), 1)];
                    }),
                    _: 2
                  }, 1032, ["color"]), v("div", de, s((a == null ? void 0 : a.title) || d(x)("4377")), 1)])];
                }),
                item: e(function(t) {
                  var o = t.item, a = t.props;
                  return [n(b, te(a, {
                    class: {
                      "v-list-item--active": o.raw.id === d(u).selectedModel
                    }
                  }), {
                    prepend: e(function() {
                      return [n(I, {
                        color: o.raw.free ? "success" : "primary",
                        variant: "outlined",
                        size: "x-small",
                        class: "mr-2"
                      }, {
                        default: e(function() {
                          return [f(s(o.raw.free ? "FREE" : "PAID"), 1)];
                        }),
                        _: 2
                      }, 1032, ["color"])];
                    }),
                    default: e(function() {
                      return [n(M, null, {
                        default: e(function() {
                          return [f(s(o.props.name), 1)];
                        }),
                        _: 2
                      }, 1024), n(K, null, {
                        default: e(function() {
                          return [f(s(o.props.description), 1)];
                        }),
                        _: 2
                      }, 1024)];
                    }),
                    _: 2
                  }, 1040, ["class"])];
                }),
                "no-data": e(function() {
                  return [n(b, null, {
                    default: e(function() {
                      return [n(M, null, {
                        default: e(function() {
                          return [f(s(d(x)("4452")), 1)];
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }, 8, ["modelValue", "items", "hint"]), n(A, {
                modelValue: l.value.baseURL,
                "onUpdate:modelValue": r[4] || (r[4] = function(t) {
                  return l.value.baseURL = t;
                }),
                rules: T,
                class: "mt-2"
              }, {
                prepend: e(function() {
                  return [f(s(d(x)("自定义API地址")) + ": ", 1)];
                }),
                _: 1
              }, 8, ["modelValue"]), z.value ? (C(), U(le, {
                key: 0,
                indeterminate: "",
                color: "primary",
                class: "mb-4"
              })) : J("", !0)];
            }),
            _: 1
          }, 8, ["modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), ye = /* @__PURE__ */ Z(fe, [["__scopeId", "data-v-744774d2"]]);
export {
  ye as default
};
