import { l as q, bx as G, _ as j, a as C, bw as ie, aW as pe, ae as ue, x as ee, $ as se, y as me, by as ge, T as he, bK as te, j as ne, a7 as Q, a6 as z, a8 as we, t as E, a9 as be, h as ye } from "./lib.js";
import { f as $, d as oe, m as ae, o as Y, w as i, l as h, A as De, a as n, Q as U, af as _e, G as o, q as P, t as S, c as fe, F as ce, b as Ce, x as ke } from "./vue.js";
import { V as J, a as Se, h as de, D as K, C as N, c as Ve, b as Pe, v as re } from "./vuetify.js";
import { h as Fe, f as le, d as Ie, N as xe, M as Me } from "./mxcad.js";
import { M as Ae } from "./mxdraw.js";
function ve(p) {
  var d = [], a = null, v = p.split(`
`);
  return v.forEach(function(g) {
    if (g.trim() !== "")
      if (g.startsWith("*")) {
        a && (a.value += ")", d.push(a));
        var m = g.substring(1).split(",").map(function(s) {
          return s.trim();
        });
        a = {
          id: m[0],
          name: m[1],
          value: "(",
          imgPath: new URL("imgs/".concat(m[0], ".png"), G()).href
        };
      } else {
        if (!a) {
          console.error("Invalid pattern file format. Missing pattern start marker (*)");
          return;
        }
        var _ = g.trim().split(",").map(function(s) {
          return s.startsWith(".") ? "0" + s : s;
        }).join(), u = (a.value === "(" ? "(" : " (") + _ + ")";
        a.value += u;
      }
  }), a && d.push(a), d;
}
var H = /* @__PURE__ */ function(p) {
  return p.ANSI = "ANSI", p.ISO = "ISO", p.ANY = "ANY", p;
}(H || {}), X = q(q(q({}, "ANSI", new URL("fonts/mx.pat", G()).href), "ISO", new URL("fonts/mxiso.pat", G()).href), "ANY", new URL("fonts/mxuser.pat", G()).href), D = $(), O = $(0), Z = {};
Object.keys(X).forEach(/* @__PURE__ */ function() {
  var p = j(/* @__PURE__ */ C.mark(function d(a) {
    var v, g, m, _;
    return C.wrap(function(u) {
      for (; ; ) switch (u.prev = u.next) {
        case 0:
          return v = X[a], u.next = 1, fetch(v);
        case 1:
          return g = u.sent, u.next = 2, g.blob();
        case 2:
          return m = u.sent, u.next = 3, ie(m);
        case 3:
          _ = u.sent, Z[a] = ve(_), D.value || T(a);
        case 4:
        case "end":
          return u.stop();
      }
    }, d);
  }));
  return function(d) {
    return p.apply(this, arguments);
  };
}());
var L = $(""), T = function(d) {
  L.value = X[d], D.value = Z[d];
  var a = 0;
  R.value && (a = D.value.indexOf(R.value)), R.value = D.value[a];
}, R = $(), Ne = function(d) {
  if (D.value) {
    var a = D.value.indexOf(d);
    a >= 0 && (O.value = a);
  }
  R.value = d;
}, Ue = function() {
  return {
    patContent: D,
    activeIndex: O,
    defaultPatContents: Z,
    switchPath: T,
    filePath: L,
    item: R,
    onchange: Ne
  };
}, $e = {
  class: "px-3"
}, Be = {
  class: "d-flex algin-center mt-3"
}, je = {
  class: "mt-2"
}, Oe = {
  class: "fill_box"
}, Le = ["onClick"], Te = {
  class: "d-inline-block text-truncate"
};
const Re = /* @__PURE__ */ oe({
  __name: "FillSelectDialog",
  emits: ["change"],
  setup: function(d, a) {
    var v = a.expose, g = a.emit, m = pe(!1), _ = m.isShow, u = m.showDialog, s = $(), W = function() {
      s.value && s.value.click();
    }, I = /* @__PURE__ */ function() {
      var b = j(/* @__PURE__ */ C.mark(function r(f) {
        var k, V, M, A, l;
        return C.wrap(function(e) {
          for (; ; ) switch (e.prev = e.next) {
            case 0:
              if (k = f.target, V = k.files, V) {
                e.next = 1;
                break;
              }
              return e.abrupt("return");
            case 1:
              return M = V[0], e.next = 2, ge(M);
            case 2:
              if (A = e.sent, me(A) === "object") {
                e.next = 3;
                break;
              }
              return e.abrupt("return");
            case 3:
              return k.value = "", e.next = 4, ie(A);
            case 4:
              l = e.sent, D.value = ve(l);
            case 5:
            case "end":
              return e.stop();
          }
        }, r);
      }));
      return function(f) {
        return b.apply(this, arguments);
      };
    }(), x = g, w = function() {
      if (D.value) {
        var r = D.value[O.value];
        x("change", r);
      }
      u(!1);
    }, F = [{
      name: "确定",
      fun: w,
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        return u(!1);
      }
    }];
    return v({
      showDialog: u
    }), function(b, r) {
      return Y(), ae(se, {
        title: b.t("2040"),
        "max-width": "400",
        modelValue: o(_),
        "onUpdate:modelValue": r[4] || (r[4] = function(f) {
          return U(_) ? _.value = f : null;
        }),
        footerBtnList: F
      }, {
        default: i(function() {
          return [h("div", $e, [h("div", Be, [De(h("input", {
            class: "form__inset w-100",
            disabled: !0,
            "onUpdate:modelValue": r[0] || (r[0] = function(f) {
              return U(L) ? L.value = f : null;
            })
          }, null, 512), [[_e, o(L)]]), n(ue, {
            onClick: W,
            class: "ml-1"
          }, {
            default: i(function() {
              return [P(S(b.t("219")) + "(F)...", 1)];
            }),
            _: 1
          })]), h("input", {
            type: "file",
            ref_key: "fillFileSelect",
            ref: s,
            onChange: I,
            style: {
              display: "none"
            },
            accept: ".pat"
          }, null, 544), h("div", je, [n(J, {
            density: "compact",
            class: "mr-2",
            onClick: r[1] || (r[1] = function(f) {
              return o(T)(o(H).ANSI);
            })
          }, {
            default: i(function() {
              return ee(r[5] || (r[5] = [P("ANSI", -1)]));
            }),
            _: 1
          }), n(J, {
            density: "compact",
            class: "mr-2",
            onClick: r[2] || (r[2] = function(f) {
              return o(T)(o(H).ISO);
            })
          }, {
            default: i(function() {
              return ee(r[6] || (r[6] = [P("ISO", -1)]));
            }),
            _: 1
          }), n(J, {
            density: "compact",
            onClick: r[3] || (r[3] = function(f) {
              return o(T)(o(H).ANY);
            })
          }, {
            default: i(function() {
              return [P(S(b.t("2041")), 1)];
            }),
            _: 1
          })]), h("div", Oe, [(Y(!0), fe(ce, null, Ce(o(D), function(f, k) {
            return Y(), ae(Se, {
              text: f.id + " " + f.name,
              location: "bottom",
              "open-delay": 800
            }, {
              activator: i(function(V) {
                var M = V.props;
                return [h("div", ke({
                  ref_for: !0
                }, M, {
                  class: ["fill_pattern", o(O) === k ? "fill_pattern_active" : ""],
                  onClick: function(l) {
                    return O.value = k;
                  },
                  onDblclick: w
                }), [n(de, {
                  src: f.imgPath || "",
                  width: "32",
                  height: "32"
                }, null, 8, ["src"]), h("span", Te, S(f.id), 1)], 16, Le)];
              }),
              _: 2
            }, 1032, ["text"]);
          }), 256))])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), Ee = /* @__PURE__ */ he(Re, [["__scopeId", "data-v-0b03bfc9"]]);
var Ge = {
  class: "px-3"
}, Ye = {
  class: "d-flex align-center"
}, He = {
  class: "mr-2"
};
const Ke = /* @__PURE__ */ oe({
  __name: "index",
  setup: function(d) {
    var a = te.isShow, v = te.showDialog, g = $(), m = Ue(), _ = m.patContent, u = m.onchange, s = m.item, W = function(e) {
      var t;
      (t = g.value) === null || t === void 0 || t.showDialog(e);
    }, I = ne(0, "PatternFillingDialog_angle"), x = ne(11, "PatternFillingDialog_proportion"), w, F, b = /* @__PURE__ */ function() {
      var l = j(/* @__PURE__ */ C.mark(function e() {
        var t, y;
        return C.wrap(function(c) {
          for (; ; ) switch (c.prev = c.next) {
            case 0:
              return v(!1), t = new Fe(), t.clearLastInputPoint(), t.setMessage(`
` + E("指定填充区域内部一点") + ":"), t.disableAllTrace(!0), t.setDisableOsnap(!0), c.next = 1, t.go();
            case 1:
              y = c.sent, y && (F = y, w = "point"), v(!0);
            case 2:
            case "end":
              return c.stop();
          }
        }, e);
      }));
      return function() {
        return l.apply(this, arguments);
      };
    }(), r, f = /* @__PURE__ */ function() {
      var l = j(/* @__PURE__ */ C.mark(function e() {
        var t, y, c;
        return C.wrap(function(B) {
          for (; ; ) switch (B.prev = B.next) {
            case 0:
              return v(!1), B.next = 1, le.userSelect(E("选择对象"));
            case 1:
              t = B.sent, t && t.length > 0 && (y = t[0], c = y.getMcDbEntity(), c && (r = c), w = "object"), v(!0);
            case 2:
            case "end":
              return B.stop();
          }
        }, e);
      }));
      return function() {
        return l.apply(this, arguments);
      };
    }(), k = /* @__PURE__ */ function() {
      var l = j(/* @__PURE__ */ C.mark(function e() {
        var t, y;
        return C.wrap(function(c) {
          for (; ; ) switch (c.prev = c.next) {
            case 0:
              if (!(w === "point" && F)) {
                c.next = 2;
                break;
              }
              if (t = le.builderHatchFromPoint(F), t) {
                c.next = 1;
                break;
              }
              return Ae.acutPrintf(E("没有找到闭合区域") + `
`), ye().error(E("没有找到闭合区域")), c.abrupt("return");
            case 1:
              y = Me.getCurrentMxCAD(), s.value && (y.addPatternDefinition(s.value.id, s.value.value), y.drawPatternDefinition = s.value.id), t.patternAngle = I.value, y.drawHatch(t, x.value * 10), v(!1), be(), w = F = void 0;
            case 2:
              w === "object" && r && (r instanceof Ie && new xe(), r = w = void 0, v(!1));
            case 3:
            case "end":
              return c.stop();
          }
        }, e);
      }));
      return function() {
        return l.apply(this, arguments);
      };
    }(), V = function() {
      w = r = F = void 0, v(!1);
    }, M = [{
      name: "确定",
      fun: k,
      primary: !0,
      disabled: function() {
        return typeof w == "undefined";
      }
    }, {
      name: "关闭",
      fun: V
    }], A = {
      enter: function() {
        var e;
        ((e = document.activeElement) === null || e === void 0 ? void 0 : e.tagName) !== "INPUT" && k();
      },
      esc: V,
      k: b,
      b: f
    };
    return function(l, e) {
      return Y(), fe(ce, null, [n(se, {
        title: l.t("2042"),
        "max-width": "360",
        modelValue: o(a),
        "onUpdate:modelValue": e[4] || (e[4] = function(t) {
          return U(a) ? a.value = t : null;
        }),
        footerBtnList: M,
        keys: A
      }, {
        default: i(function() {
          return [h("div", Ge, [n(Q, {
            title: l.t("2043"),
            class: "mt-2"
          }, {
            default: i(function() {
              return [n(K, null, {
                default: i(function() {
                  return [n(N, {
                    cols: "8"
                  }, {
                    default: i(function() {
                      return [n(Ve, {
                        items: o(_),
                        "item-title": "id",
                        modelValue: o(s),
                        "onUpdate:modelValue": [e[0] || (e[0] = function(t) {
                          return U(s) ? s.value = t : null;
                        }), o(u)],
                        "return-object": ""
                      }, {
                        prepend: i(function() {
                          return [P(S(l.t("1624")) + ": ", 1)];
                        }),
                        _: 1
                      }, 8, ["items", "modelValue", "onUpdate:modelValue"])];
                    }),
                    _: 1
                  }), n(N, {
                    cols: "4"
                  }, {
                    default: i(function() {
                      return [n(ue, {
                        style: {
                          "min-width": "60px"
                        },
                        onClick: e[1] || (e[1] = function(t) {
                          return W(!0);
                        })
                      }, {
                        default: i(function() {
                          return [n(Pe, {
                            icon: "class:iconfont more"
                          })];
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }), n(K, null, {
                default: i(function() {
                  return [n(N, {
                    cols: "8"
                  }, {
                    default: i(function() {
                      var t;
                      return [h("div", Ye, [h("span", He, S(l.t("2044")) + ":", 1), n(de, {
                        src: ((t = o(s)) === null || t === void 0 ? void 0 : t.imgPath) || "",
                        width: "32",
                        height: "32",
                        style: {
                          flex: "unset"
                        }
                      }, null, 8, ["src"])])];
                    }),
                    _: 1
                  }), n(N, {
                    cols: "4"
                  })];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["title"]), n(Q, {
            title: l.t("2045"),
            class: "mt-2"
          }, {
            default: i(function() {
              return [n(K, null, {
                default: i(function() {
                  return [n(N, {
                    cols: "6"
                  }, {
                    default: i(function() {
                      return [n(z, {
                        "key-name": "G",
                        colon: ""
                      }, {
                        default: i(function() {
                          return [P(S(l.t("169")), 1)];
                        }),
                        _: 1
                      }), n(re, {
                        modelValue: o(I),
                        "onUpdate:modelValue": e[2] || (e[2] = function(t) {
                          return U(I) ? I.value = t : null;
                        }),
                        items: [0, 5, 10, 15, 20, 30, 45, 60, 90, 95, 100, 120, 135, 150]
                      }, null, 8, ["modelValue"])];
                    }),
                    _: 1
                  }), n(N, {
                    cols: "6"
                  }, {
                    default: i(function() {
                      return [n(z, {
                        "key-name": "S",
                        colon: ""
                      }, {
                        default: i(function() {
                          return [P(S(l.t("1686")), 1)];
                        }),
                        _: 1
                      }), n(re, {
                        modelValue: o(x),
                        "onUpdate:modelValue": e[3] || (e[3] = function(t) {
                          return U(x) ? x.value = t : null;
                        }),
                        items: [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 11]
                      }, null, 8, ["modelValue"])];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["title"]), n(Q, {
            title: l.t("2046"),
            class: "mt-2"
          }, {
            default: i(function() {
              return [h("div", null, [n(we, {
                onClick: b
              }), n(z, {
                "key-name": "K"
              }, {
                default: i(function() {
                  return [P(S(l.t("2047")) + ": " + S(l.t("1965")), 1)];
                }),
                _: 1
              })])];
            }),
            _: 1
          }, 8, ["title"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]), n(Ee, {
        ref_key: "fillSelectDialog",
        ref: g,
        onChange: o(u)
      }, null, 8, ["onChange"])], 64);
    };
  }
});
export {
  Ke as default
};
