import { z as ar, a4 as tr, t as s, ae as me, a7 as be, aR as nr, a8 as Me, x as H, aT as ge, $ as ur, _ as T, a as x, h as g, aU as Z, aV as A, G as sr, T as lr } from "./lib.js";
import { d as ir, f as E, i as De, g as Pe, ah as or, m as Y, o as P, w as m, c as W, s as he, l as N, a as f, G as v, q as M, t as L, A as pr, F as ye, b as Fe, p as Te, n as cr, y as fr, x as _, Q as dr } from "./vue.js";
import { M as ee, p as R, O as Ae, e as vr, q as mr, h as br, A as gr } from "./mxcad.js";
import { r as hr, M as yr, d as kr } from "./mxdraw.js";
import { i as Ee } from "./identificationFrame.js";
import { s as wr } from "./pinia.js";
import { i as Ne, Q as xr, S as ke, j as Ue, v as Be, aa as Sr, f as Cr, b as O, H as Vr, a as re, V as ae } from "./vuetify.js";
function we(k, F) {
  var y = typeof Symbol != "undefined" && k[Symbol.iterator] || k["@@iterator"];
  if (!y) {
    if (Array.isArray(k) || (y = Mr(k)) || F) {
      y && (k = y);
      var C = 0, J = function() {
      };
      return { s: J, n: function() {
        return C >= k.length ? { done: !0 } : { done: !1, value: k[C++] };
      }, e: function(B) {
        throw B;
      }, f: J };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  var V, d = !0, X = !1;
  return { s: function() {
    y = y.call(k);
  }, n: function() {
    var B = y.next();
    return d = B.done, B;
  }, e: function(B) {
    X = !0, V = B;
  }, f: function() {
    try {
      d || y.return == null || y.return();
    } finally {
      if (X) throw V;
    }
  } };
}
function Mr(k, F) {
  if (k) {
    if (typeof k == "string") return ze(k, F);
    var y = {}.toString.call(k).slice(8, -1);
    return y === "Object" && k.constructor && (y = k.constructor.name), y === "Map" || y === "Set" ? Array.from(k) : y === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(y) ? ze(k, F) : void 0;
  }
}
function ze(k, F) {
  (F == null || F > k.length) && (F = k.length);
  for (var y = 0, C = Array(F); y < F; y++) C[y] = k[y];
  return C;
}
var Dr = {
  key: 0,
  class: "d-flex align-center"
}, Pr = {
  class: "d-flex"
}, Fr = {
  class: "position-relative"
}, Tr = {
  class: "d-flex align-center justify-space-between"
}, Ar = {
  class: "ml-2 multi-select-actions"
}, Er = {
  class: "d-flex flex-wrap justify-space-start overflow-y-auto",
  style: {
    "max-height": "340px"
  }
}, Nr = ["onClick"], Ur = {
  class: "cut-box-actions"
}, Br = {
  class: "cut-box-jump"
}, zr = {
  key: 0,
  class: "cut-box-filename"
}, Ir = {
  class: "cut-box-add ma-2"
};
const Lr = /* @__PURE__ */ ir({
  __name: "index",
  setup: function(F) {
    var y = [{
      name: "全部导出",
      primary: !0,
      fun: function() {
        return je();
      },
      disabled: function() {
        return X.value;
      }
    }, {
      name: "关闭",
      fun: function() {
        d.value = [], A(!1);
      }
    }], C = E(!1);
    De(C, function(u) {
      u || d.value.forEach(function(r) {
        r.selected = !1;
      });
    });
    var J = [{
      name: "批量删除",
      icon: "delete",
      color: "error",
      fun: Le
    }, {
      name: "批量导出",
      icon: "lingcunweiDWG",
      color: "primary",
      fun: Re
    }], V = E(!1), d = E([]), X = Pe(function() {
      return d.value.some(function(u) {
        return u.exportStatus === "exporting";
      });
    }), U = function() {
      return d.value.filter(function(r) {
        return r.selected;
      }).length;
    };
    function B(u) {
      if (C.value) {
        var r = d.value[u];
        r.selected = !r.selected, V.value = !1;
      }
    }
    De(C, function() {
      V.value = !1;
    });
    function Ie() {
      var u = d.value.some(function(r) {
        return !r.selected;
      });
      d.value.forEach(function(r) {
        r.selected = u;
      }), V.value = !1;
    }
    function Le() {
      d.value = d.value.filter(function(u) {
        return !u.selected;
      }), V.value = !1;
    }
    function Re() {
      return te.apply(this, arguments);
    }
    function te() {
      return te = T(/* @__PURE__ */ x.mark(function u() {
        var r, a, e, p, t, l, o;
        return x.wrap(function(i) {
          for (; ; ) switch (i.prev = i.next) {
            case 0: {
              i.next = 3;
              break;
            }
            case 1:
              return i.next = 2, Z.hasPath(G.value);
            case 2:
              if (i.sent) {
                i.next = 3;
                break;
              }
              return g().error(s("3717")), i.abrupt("return");
            case 3:
              if (d.value.length !== 0) {
                i.next = 4;
                break;
              }
              return g().error(s("3718")), i.abrupt("return");
            case 4:
              r = d.value.map(function(b, c) {
                return b.selected ? c : -1;
              }).filter(function(b) {
                return b !== -1;
              }), a = [], e = we(r), i.prev = 5, e.s();
            case 6:
              if ((p = e.n()).done) {
                i.next = 10;
                break;
              }
              return t = p.value, d.value[t].exportStatus = "ready", i.next = 7, se(t);
            case 7:
              return l = i.sent, V.value = !1, i.next = 8, new Promise(function(b) {
                return setTimeout(b, 500);
              });
            case 8:
              l && a.push(t);
            case 9:
              i.next = 6;
              break;
            case 10:
              i.next = 12;
              break;
            case 11:
              i.prev = 11, o = i.catch(5), e.e(o);
            case 12:
              return i.prev = 12, e.f(), i.finish(12);
            case 13:
              a.length === 0 ? g().error(s("3719")) : g().success(s("3720")), V.value = !1;
            case 14:
            case "end":
              return i.stop();
          }
        }, u, null, [[5, 11, 12, 13]]);
      })), te.apply(this, arguments);
    }
    function Ge(u) {
      var r = d.value[u];
      if (r) {
        var a = parseFloat(r.param.bd_pt1_x), e = parseFloat(r.param.bd_pt1_y), p = parseFloat(r.param.bd_pt2_x), t = parseFloat(r.param.bd_pt2_y), l = Math.abs(p - a), o = Math.abs(t - e), i = 0.2, b = a - l * i, c = e - o * i, w = p + l * i, n = t + o * i;
        A(!1);
        var S = ee.getCurrentMxCAD();
        S.zoomW(new R(b, c), new R(w, n));
        var D = S.mxdraw.getTempMarkDraw();
        D.clear();
        var j = new THREE.Vector3(a, e, 0), Q = new THREE.Vector3(p, e, 0), h = new THREE.Vector3(p, t, 0), de = new THREE.Vector3(a, t, 0), K = hr.createLines([j, Q, h, de, j], 16711680);
        D.drawEntity(K), S.updateDisplay(), setTimeout(function() {
          g().warning(s("4317")), document.addEventListener("click", function() {
            D.clear(), A(!0);
          }, {
            once: !0
          });
        });
      }
    }
    var z = E("manual"), I = E("");
    function We(u) {
      d.value.splice(u, 1), V.value = !1;
    }
    var q = E(!1), ne = /* @__PURE__ */ function() {
      var u = T(/* @__PURE__ */ x.mark(function r(a, e) {
        return x.wrap(function(p) {
          for (; ; ) switch (p.prev = p.next) {
            case 0:
              return p.abrupt("return", new Promise(function(t, l) {
                var o = ee.getCurrentMxCAD();
                o.setAttribute({
                  ShowCoordinate: !1
                });
                var i = Math.abs(a.x - e.x), b = Math.abs(a.y - e.y);
                if (i < 1 || b < 1) return t(void 0);
                var c = 800, w, n;
                i <= c ? (w = i, n = b) : (w = c, n = c * (b / i)), o.mxdraw.createCanvasImageData(function(S) {
                  t(S), o.setAttribute({
                    ShowCoordinate: !0
                  });
                }, {
                  width: w,
                  // 图片宽
                  height: n,
                  // 图片高
                  range_pt1: a.toVector3(),
                  // 截图范围角点1
                  range_pt2: e.toVector3()
                  // 截图范围角点2
                });
              }));
            case 1:
            case "end":
              return p.stop();
          }
        }, r);
      }));
      return function(a, e) {
        return u.apply(this, arguments);
      };
    }();
    function $e(u) {
      return d.value.some(function(r) {
        var a = 1e-3, e = Math.abs(parseFloat(r.param.bd_pt1_x) - parseFloat(u.bd_pt1_x)) < a, p = Math.abs(parseFloat(r.param.bd_pt1_y) - parseFloat(u.bd_pt1_y)) < a, t = Math.abs(parseFloat(r.param.bd_pt2_x) - parseFloat(u.bd_pt2_x)) < a, l = Math.abs(parseFloat(r.param.bd_pt2_y) - parseFloat(u.bd_pt2_y)) < a;
        return e && p && t && l;
      });
    }
    function ue(u, r) {
      if ($e(r)) {
        g().info(s("3721"));
        return;
      }
      d.value.push({
        imgBase64: u,
        param: r,
        exportStatus: "ready",
        selected: !1
      }), V.value = !0;
    }
    var G = E(""), se = /* @__PURE__ */ function() {
      var u = T(/* @__PURE__ */ x.mark(function r(a) {
        var e, p, t, l, o, i, b, c, w, n, S, D, j, Q;
        return x.wrap(function(h) {
          for (; ; ) switch (h.prev = h.next) {
            case 0:
              if (((e = d.value[a]) === null || e === void 0 ? void 0 : e.exportStatus) !== "exporting") {
                h.next = 1;
                break;
              }
              return h.abrupt("return");
            case 1: {
              h.next = 4;
              break;
            }
            case 2:
              return h.next = 3, Z.hasPath(G.value);
            case 3:
              if (h.sent) {
                h.next = 4;
                break;
              }
              return g().error(s("3717")), h.abrupt("return");
            case 4:
              if (!(a < 0 || a >= d.value.length)) {
                h.next = 5;
                break;
              }
              return h.abrupt("return");
            case 5:
              p = ee.getCurrentMxCAD().mxdraw.getTempMarkDraw(), p.clear(), t = d.value[a], t.exportStatus = "exporting", h.prev = 6;
              {
                h.next = 10;
                break;
              }
            case 7:
              if (o = h.sent, !o) {
                h.next = 8;
                break;
              }
              return t.exportStatus = "success", t.fileName = l, h.abrupt("return", !0);
            case 8:
              t.exportStatus = "error", t.fileName = "";
            case 9:
              h.next = 11;
              break;
            case 10:
              return i = sr() || {}, b = i.baseUrl, c = b === void 0 ? "" : b, w = i.mxfilepath, n = w === void 0 ? "" : w, S = i.cutDwgUrl, D = S === void 0 ? "" : S, j = "".concat((/* @__PURE__ */ new Date()).getTime(), "_").concat(a, ".dwg"), h.next = 11, new Promise(function(de, K) {
                ee.getCurrentMxCAD().saveFileToUrl(D, function(Rr, ve) {
                  try {
                    var Ce = JSON.parse(ve);
                    if (Ce.ret == "ok") {
                      var rr = c + n + Ce.file;
                      gr.downloadFileFromUrl(rr, j), t.exportStatus = "success", t.fileName = j, de();
                    } else
                      console.error("导出DWG失败:", ve), t.exportStatus = "error", K(new Error(ve));
                  } catch (Ve) {
                    console.error("导出DWG错误:", Ve), t.exportStatus = "error", K(Ve);
                  }
                }, void 0, JSON.stringify(t.param));
              });
            case 11:
              h.next = 13;
              break;
            case 12:
              h.prev = 12, Q = h.catch(6), console.error("导出DWG失败:", Q), t.exportStatus = "error";
            case 13:
            case "end":
              return h.stop();
          }
        }, r, null, [[6, 12]]);
      }));
      return function(a) {
        return u.apply(this, arguments);
      };
    }(), je = /* @__PURE__ */ function() {
      var u = T(/* @__PURE__ */ x.mark(function r() {
        var a, e, p;
        return x.wrap(function(t) {
          for (; ; ) switch (t.prev = t.next) {
            case 0:
              if (!X.value) {
                t.next = 1;
                break;
              }
              return t.abrupt("return");
            case 1:
              if (d.value.length !== 0) {
                t.next = 2;
                break;
              }
              return g().error(s("3718")), t.abrupt("return");
            case 2: {
              t.next = 5;
              break;
            }
            case 3:
              return t.next = 4, Z.hasPath(G.value);
            case 4:
              if (t.sent) {
                t.next = 5;
                break;
              }
              return g().error(s("3717")), t.abrupt("return");
            case 5:
              a = [], V.value = !1, t.prev = 6, e = 0;
            case 7:
              if (!(e < d.value.length)) {
                t.next = 11;
                break;
              }
              return d.value[e].exportStatus = "ready", t.next = 8, se(e);
            case 8:
              return p = t.sent, t.next = 9, new Promise(function(l) {
                return setTimeout(l, 500);
              });
            case 9:
              p && a.push(e);
            case 10:
              e++, t.next = 7;
              break;
            case 11:
              a.length === 0 ? g().error(s("3719")) : g().success(s("3722"));
            case 12:
              return t.prev = 12, V.value = !1, t.finish(12);
            case 13:
            case "end":
              return t.stop();
          }
        }, r, null, [[6, , 12, 13]]);
      }));
      return function() {
        return u.apply(this, arguments);
      };
    }();
    function le(u) {
      var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1, a = r, e = r, p = new R(u.minPt.x - a, u.minPt.y - e, u.minPt.z), t = new R(u.maxPt.x + a, u.maxPt.y + e, u.maxPt.z);
      return {
        minPt: p,
        maxPt: t
      };
    }
    var He = /* @__PURE__ */ function() {
      var u = T(/* @__PURE__ */ x.mark(function r() {
        var a, e, p, t, l, o, i, b, c, w;
        return x.wrap(function(n) {
          for (; ; ) switch (n.prev = n.next) {
            case 0:
              return n.next = 1, Ee({
                method: "polyline",
                isSpecifiedRange: !q.value,
                layerName: xe(),
                targetLevel: fe.value
              });
            case 1:
              if (a = n.sent, a.length !== 0) {
                n.next = 2;
                break;
              }
              return g().error(s("3723")), n.abrupt("return");
            case 2:
              e = we(a), n.prev = 3, e.s();
            case 4:
              if ((p = e.n()).done) {
                n.next = 9;
                break;
              }
              if (t = p.value, t) {
                n.next = 5;
                break;
              }
              return n.abrupt("continue", 8);
            case 5:
              return l = le(t), o = l.minPt, i = l.maxPt, n.next = 6, ne(o, i);
            case 6:
              if (b = n.sent, b) {
                n.next = 7;
                break;
              }
              return n.abrupt("continue", 8);
            case 7:
              c = {
                bd_pt1_x: "" + o.x,
                bd_pt1_y: "" + o.y,
                bd_pt2_x: "" + i.x,
                bd_pt2_y: "" + i.y
              }, ue(b, c);
            case 8:
              n.next = 4;
              break;
            case 9:
              n.next = 11;
              break;
            case 10:
              n.prev = 10, w = n.catch(3), e.e(w);
            case 11:
              return n.prev = 11, e.f(), n.finish(11);
            case 12:
            case "end":
              return n.stop();
          }
        }, r, null, [[3, 10, 11, 12]]);
      }));
      return function() {
        return u.apply(this, arguments);
      };
    }(), $ = E(""), xe = function() {
      return $.value !== "" ? $.value : void 0;
    }, Oe = wr(ar()), Xe = Oe.list, Ye = Pe(function() {
      return Xe.value.map(function(u) {
        return u.name;
      });
    });
    function Je() {
      return ie.apply(this, arguments);
    }
    function ie() {
      return ie = T(/* @__PURE__ */ x.mark(function u() {
        var r, a, e, p, t;
        return x.wrap(function(l) {
          for (; ; ) switch (l.prev = l.next) {
            case 0:
              return A(!1), l.prev = 1, r = new Ae(), r.setMessage(s("3724")), l.next = 2, r.go();
            case 2:
              if (a = l.sent, a.isValid()) {
                l.next = 3;
                break;
              }
              return g().warning(s("3725")), l.abrupt("return");
            case 3:
              if (e = a.getMcDbEntity(), e) {
                l.next = 4;
                break;
              }
              return g().warning(s("3726")), l.abrupt("return");
            case 4:
              if (p = e.layer, p) {
                l.next = 5;
                break;
              }
              return g().warning(s("3727")), l.abrupt("return");
            case 5:
              $.value = p, g().success(s("3728") + p), l.next = 7;
              break;
            case 6:
              l.prev = 6, t = l.catch(1), console.error("获取图层名失败:", t), g().error(s("3729"));
            case 7:
              return l.prev = 7, A(!0), l.finish(7);
            case 8:
            case "end":
              return l.stop();
          }
        }, u, null, [[1, 6, 7, 8]]);
      })), ie.apply(this, arguments);
    }
    function qe() {
      return oe.apply(this, arguments);
    }
    function oe() {
      return oe = T(/* @__PURE__ */ x.mark(function u() {
        var r, a, e, p, t, l;
        return x.wrap(function(o) {
          for (; ; ) switch (o.prev = o.next) {
            case 0:
              return A(!1), o.prev = 1, r = new Ae(), r.setMessage(s("3730")), o.next = 2, r.go();
            case 2:
              if (a = o.sent, a.isValid()) {
                o.next = 3;
                break;
              }
              return g().warning(s("3725")), o.abrupt("return");
            case 3:
              if (e = a.getMcDbEntity(), e) {
                o.next = 4;
                break;
              }
              return g().warning(s("3726")), o.abrupt("return");
            case 4:
              if (!(e instanceof vr)) {
                o.next = 6;
                break;
              }
              if (p = e, t = p.blockName, t) {
                o.next = 5;
                break;
              }
              return g().warning(s("3731")), o.abrupt("return");
            case 5:
              I.value = t, g().success(s("3732") + t), o.next = 7;
              break;
            case 6:
              g().warning(s("3733"));
            case 7:
              o.next = 9;
              break;
            case 8:
              o.prev = 8, l = o.catch(1), console.error("获取图块名失败:", l), g().error(s("3734"));
            case 9:
              return o.prev = 9, A(!0), o.finish(9);
            case 10:
            case "end":
              return o.stop();
          }
        }, u, null, [[1, 8, 9, 10]]);
      })), oe.apply(this, arguments);
    }
    var Qe = /* @__PURE__ */ function() {
      var u = T(/* @__PURE__ */ x.mark(function r() {
        var a, e, p, t, l, o, i, b, c, w;
        return x.wrap(function(n) {
          for (; ; ) switch (n.prev = n.next) {
            case 0:
              if (I.value !== "") {
                n.next = 1;
                break;
              }
              return g().error(s("3587")), n.abrupt("return");
            case 1:
              return n.next = 2, Ee({
                method: "block",
                blockName: I.value !== "" ? I.value : void 0,
                isSpecifiedRange: !q.value,
                layerName: xe()
              });
            case 2:
              if (a = n.sent, a.length !== 0) {
                n.next = 3;
                break;
              }
              return g().error(s("3723")), n.abrupt("return");
            case 3:
              e = we(a), n.prev = 4, e.s();
            case 5:
              if ((p = e.n()).done) {
                n.next = 10;
                break;
              }
              if (t = p.value, t) {
                n.next = 6;
                break;
              }
              return n.abrupt("continue", 9);
            case 6:
              return l = le(t), o = l.minPt, i = l.maxPt, n.next = 7, ne(o, i);
            case 7:
              if (b = n.sent, b) {
                n.next = 8;
                break;
              }
              return n.abrupt("continue", 9);
            case 8:
              c = {
                bd_pt1_x: "" + o.x,
                bd_pt1_y: "" + o.y,
                bd_pt2_x: "" + i.x,
                bd_pt2_y: "" + i.y
              }, ue(b, c);
            case 9:
              n.next = 5;
              break;
            case 10:
              n.next = 12;
              break;
            case 11:
              n.prev = 11, w = n.catch(4), e.e(w);
            case 12:
              return n.prev = 12, e.f(), n.finish(12);
            case 13:
            case "end":
              return n.stop();
          }
        }, r, null, [[4, 11, 12, 13]]);
      }));
      return function() {
        return u.apply(this, arguments);
      };
    }();
    function Ke() {
      return pe.apply(this, arguments);
    }
    function pe() {
      return pe = T(/* @__PURE__ */ x.mark(function u() {
        var r;
        return x.wrap(function(a) {
          for (; ; ) switch (a.prev = a.next) {
            case 0:
              if (!(z.value === "block" && I.value === "")) {
                a.next = 1;
                break;
              }
              return g().error(s("3587")), a.abrupt("return");
            case 1:
              A(!1), a.prev = 2, r = z.value, a.next = r === "polyline" ? 3 : r === "block" ? 5 : 7;
              break;
            case 3:
              return a.next = 4, He();
            case 4:
              return a.abrupt("continue", 9);
            case 5:
              return a.next = 6, Qe();
            case 6:
              return a.abrupt("continue", 9);
            case 7:
              return a.next = 8, Ze();
            case 8:
              return a.abrupt("continue", 9);
            case 9:
              return a.prev = 9, A(!0), a.finish(9);
            case 10:
            case "end":
              return a.stop();
          }
        }, u, null, [[2, , 9, 10]]);
      })), pe.apply(this, arguments);
    }
    function Ze() {
      return ce.apply(this, arguments);
    }
    function ce() {
      return ce = T(/* @__PURE__ */ x.mark(function u() {
        var r, a, e, p, t, l, o, i, b;
        return x.wrap(function(c) {
          for (; ; ) switch (c.prev = c.next) {
            case 0:
              return r = new br(), r.clearLastInputPoint(), r.setMessage(s("3589")), c.next = 1, r.go();
            case 1:
              if (a = c.sent, a) {
                c.next = 2;
                break;
              }
              return c.abrupt("return");
            case 2:
              return r.setMessage(s("3590")), r.setUserDraw(function(w, n) {
                n.setColor(16711680);
                var S = new mr();
                S.addVertexAt(a), S.addVertexAt(new R(a.x, w.y)), S.addVertexAt(w), S.addVertexAt(new R(w.x, a.y)), S.constantWidth = yr.screenCoordLong2Doc(2), S.isClosed = !0, n.drawMcDbEntity(S);
                var D = [];
                D.push(a.toVector3()), D.push(new THREE.Vector3(a.x, w.y)), D.push(w.toVector3()), D.push(new THREE.Vector3(w.x, a.y)), n.setColor(12868), n.drawSolid(D, 0.5);
              }), r.setDisableOsnap(!0), r.setDisableOrthoTrace(!0), r.setDynamicInputType(kr.kXYCoordInput), c.next = 3, r.go();
            case 3:
              if (e = c.sent, e) {
                c.next = 4;
                break;
              }
              return c.abrupt("return");
            case 4:
              return p = {
                minPt: new R(Math.min(a.x, e.x), Math.min(a.y, e.y), Math.min(a.z, e.z)),
                maxPt: new R(Math.max(a.x, e.x), Math.max(a.y, e.y), Math.max(a.z, e.z))
              }, t = le(p), l = t.minPt, o = t.maxPt, i = {
                bd_pt1_x: "" + l.x,
                bd_pt1_y: "" + l.y,
                bd_pt2_x: "" + o.x,
                bd_pt2_y: "" + o.y
              }, c.next = 5, ne(l, o);
            case 5:
              if (b = c.sent, b) {
                c.next = 6;
                break;
              }
              return c.abrupt("return");
            case 6:
              ue(b, i);
            case 7:
            case "end":
              return c.stop();
          }
        }, u);
      })), ce.apply(this, arguments);
    }
    var Se = function() {
      I.value = "", $.value = "", d.value = [], A(!1);
    }, _e = {
      esc: Se
    }, er = /* @__PURE__ */ function() {
      var u = T(/* @__PURE__ */ x.mark(function r() {
        var a;
        return x.wrap(function(e) {
          for (; ; ) switch (e.prev = e.next) {
            case 0:
              return e.next = 1, Z.showDirSelectBox(G.value);
            case 1:
              a = e.sent, a && (G.value = a);
            case 2:
            case "end":
              return e.stop();
          }
        }, r);
      }));
      return function() {
        return u.apply(this, arguments);
      };
    }(), fe = E(0);
    return function(u, r) {
      var a = or("scroll-bottom");
      return P(), Y(ur, {
        title: v(s)("1990"),
        modelValue: v(ge),
        "onUpdate:modelValue": r[8] || (r[8] = function(e) {
          return dr(ge) ? ge.value = e : null;
        }),
        "max-width": "610",
        footerBtnList: y,
        keys: _e,
        onClickClose: Se
      }, {
        default: m(function() {
          return [v(tr)() ? (P(), W("div", Dr, [f(Ne, {
            modelValue: G.value,
            "onUpdate:modelValue": r[0] || (r[0] = function(e) {
              return G.value = e;
            }),
            class: "flex-grow-1 mr-2"
          }, {
            prepend: m(function() {
              return [M(L(v(s)("3735")) + ": ", 1)];
            }),
            _: 1
          }, 8, ["modelValue"]), f(me, {
            small: "",
            onClick: er
          }, {
            default: m(function() {
              return [M(L(v(s)("3736")), 1)];
            }),
            _: 1
          })])) : he("", !0), N("div", Pr, [f(be, {
            title: v(s)("3591"),
            class: "mr-2"
          }, {
            default: m(function() {
              return [f(xr, {
                modelValue: z.value,
                "onUpdate:modelValue": r[1] || (r[1] = function(e) {
                  return z.value = e;
                }),
                inline: !1
              }, {
                default: m(function() {
                  return [f(ke, {
                    value: "manual",
                    label: v(s)("3592")
                  }, null, 8, ["label"]), f(ke, {
                    value: "polyline",
                    class: "mt-2",
                    label: v(s)("3593")
                  }, null, 8, ["label"]), f(ke, {
                    value: "block",
                    class: "mt-2",
                    label: v(s)("3594")
                  }, null, 8, ["label"])];
                }),
                _: 1
              }, 8, ["modelValue"])];
            }),
            _: 1
          }, 8, ["title"]), f(be, {
            title: v(s)("3737")
          }, {
            default: m(function() {
              return [f(Ue, {
                modelValue: q.value,
                "onUpdate:modelValue": r[2] || (r[2] = function(e) {
                  return q.value = e;
                }),
                label: v(s)("3738"),
                disabled: z.value === "manual"
              }, null, 8, ["modelValue", "label", "disabled"]), f(Be, {
                modelValue: I.value,
                "onUpdate:modelValue": r[3] || (r[3] = function(e) {
                  return I.value = e;
                }),
                class: "mt-2",
                items: v(nr)(),
                disabled: z.value !== "block",
                clearable: ""
              }, {
                prepend: m(function() {
                  return [M(L(v(s)("3739")) + ": ", 1)];
                }),
                append: m(function() {
                  return [f(Me, {
                    text: v(s)("3740"),
                    onClick: qe
                  }, null, 8, ["text"])];
                }),
                _: 1
              }, 8, ["modelValue", "items", "disabled"]), f(Be, {
                class: "mt-2",
                modelValue: $.value,
                "onUpdate:modelValue": r[4] || (r[4] = function(e) {
                  return $.value = e;
                }),
                items: Ye.value,
                disabled: z.value === "manual",
                clearable: ""
              }, {
                prepend: m(function() {
                  return [M(L(v(s)("3741")) + ": ", 1)];
                }),
                append: m(function() {
                  return [f(Me, {
                    text: v(s)("3742"),
                    onClick: Je
                  }, null, 8, ["text"])];
                }),
                _: 1
              }, 8, ["modelValue", "items", "disabled"]), f(Ne, {
                modelValue: fe.value,
                "onUpdate:modelValue": r[5] || (r[5] = function(e) {
                  return fe.value = e;
                }),
                modelModifiers: {
                  number: !0
                },
                class: "mt-2",
                type: "number",
                min: "0",
                disabled: z.value === "manual"
              }, {
                prepend: m(function() {
                  return [M(L(v(s)("4461")) + ": ", 1)];
                }),
                _: 1
              }, 8, ["modelValue", "disabled"])];
            }),
            _: 1
          }, 8, ["title"])]), f(be, {
            title: v(s)("3597"),
            class: "mt-2",
            style: {
              "min-height": "420px"
            }
          }, {
            default: m(function() {
              return [N("div", Fr, [N("div", Tr, [f(Sr, {
                class: "ml-4",
                modelValue: C.value,
                "onUpdate:modelValue": r[6] || (r[6] = function(e) {
                  return C.value = e;
                }),
                label: C.value ? v(s)("3743") : v(s)("3744"),
                density: "compact",
                color: "primary",
                "hide-details": ""
              }, null, 8, ["modelValue", "label"]), N("div", Ar, [f(me, {
                small: "",
                onClick: Ie,
                disabled: d.value.length === 0 || !C.value
              }, {
                default: m(function() {
                  return [M(L(d.value.some(function(e) {
                    return !e.selected;
                  }) ? v(s)("1871") : v(s)("3745")), 1)];
                }),
                _: 1
              }, 8, ["disabled"]), (P(), W(ye, null, Fe(J, function(e, p) {
                return f(me, {
                  small: "",
                  disabled: !(U() > 0),
                  key: p,
                  class: "ml-1",
                  onClick: e.fun
                }, {
                  default: m(function() {
                    return [M(L(e.name), 1)];
                  }),
                  _: 2
                }, 1032, ["disabled", "onClick"]);
              }), 64))])]), f(Cr, {
                class: "mb-2"
              }), pr((P(), W("div", Er, [(P(!0), W(ye, null, Fe(d.value, function(e, p) {
                return P(), W("div", {
                  key: p,
                  class: Te(["cut-box-container ma-2", {
                    "selected-box": e.selected
                  }])
                }, [N("div", {
                  class: "cut-box bg-black",
                  style: cr({
                    backgroundImage: "url(".concat(e.imgBase64, ")"),
                    backgroundPosition: "center",
                    backgroundRepeat: "no-repeat",
                    backgroundSize: "contain"
                  }),
                  onClick: function(l) {
                    return C.value && B(p);
                  }
                }, [N("div", {
                  class: Te(["cut-box-status", [e.exportStatus === "ready" ? "status-ready" : e.exportStatus === "exporting" ? "status-exporting" : e.exportStatus === "success" ? "status-success" : "status-error"]])
                }, [C.value ? (P(), Y(Ue, {
                  key: 0,
                  style: {
                    "--v-selection-control-size": "24px",
                    "margin-left": "2px",
                    "margin-top": "1.5px"
                  },
                  modelValue: e.selected,
                  "onUpdate:modelValue": function(l) {
                    return e.selected = l;
                  },
                  color: "primary",
                  onClick: r[7] || (r[7] = fr(function() {
                  }, ["stop"]))
                }, null, 8, ["modelValue", "onUpdate:modelValue"])) : (P(), W(ye, {
                  key: 1
                }, [e.exportStatus === "ready" ? (P(), Y(O, {
                  key: 0,
                  size: "small"
                }, {
                  default: m(function() {
                    return H(r[9] || (r[9] = [M("pending", -1)]));
                  }),
                  _: 1
                })) : e.exportStatus === "exporting" ? (P(), Y(Vr, {
                  key: 1,
                  indeterminate: "",
                  size: "16",
                  width: "2",
                  color: "white"
                })) : e.exportStatus === "success" ? (P(), Y(O, {
                  key: 2,
                  color: "success",
                  size: "small"
                }, {
                  default: m(function() {
                    return H(r[10] || (r[10] = [M("class:iconfont gou", -1)]));
                  }),
                  _: 1
                })) : he("", !0)], 64))], 2), N("div", Ur, [f(re, {
                  text: v(s)("205"),
                  location: "top"
                }, {
                  activator: m(function(t) {
                    var l = t.props;
                    return [f(ae, _({
                      ref_for: !0
                    }, l, {
                      icon: "",
                      variant: "outlined",
                      color: "error",
                      class: "delete-btn",
                      onClick: function(i) {
                        return We(p);
                      }
                    }), {
                      default: m(function() {
                        return [f(O, {
                          size: "14"
                        }, {
                          default: m(function() {
                            return H(r[11] || (r[11] = [M("cha", -1)]));
                          }),
                          _: 1
                        })];
                      }),
                      _: 1
                    }, 16, ["onClick"])];
                  }),
                  _: 2
                }, 1032, ["text"]), f(re, {
                  text: e.exportStatus === "ready" ? v(s)("3598") : e.exportStatus === "exporting" ? v(s)("3599") : e.exportStatus === "success" ? v(s)("3600") : v(s)("3601"),
                  location: "top"
                }, {
                  activator: m(function(t) {
                    var l = t.props;
                    return [f(ae, _({
                      ref_for: !0
                    }, l, {
                      icon: "",
                      variant: "outlined",
                      color: e.exportStatus === "success" ? "success" : e.exportStatus === "error" ? "warning" : "primary",
                      class: "export-btn",
                      disabled: e.exportStatus === "exporting",
                      loading: e.exportStatus === "exporting",
                      onClick: function(i) {
                        return se(p);
                      }
                    }), {
                      default: m(function() {
                        return [f(O, {
                          size: "14"
                        }, {
                          default: m(function() {
                            return H(r[12] || (r[12] = [M("lingcunweiDWG", -1)]));
                          }),
                          _: 1
                        })];
                      }),
                      _: 1
                    }, 16, ["color", "disabled", "loading", "onClick"])];
                  }),
                  _: 2
                }, 1032, ["text"])]), N("div", Br, [f(re, {
                  text: v(s)("3746"),
                  location: "top"
                }, {
                  activator: m(function(t) {
                    var l = t.props;
                    return [f(ae, _({
                      ref_for: !0
                    }, l, {
                      icon: "",
                      variant: "outlined",
                      color: "info",
                      class: "jump-btn",
                      onClick: function(i) {
                        return Ge(p);
                      }
                    }), {
                      default: m(function() {
                        return [f(O, {
                          size: "14"
                        }, {
                          default: m(function() {
                            return H(r[13] || (r[13] = [M("chuangkousuofang", -1)]));
                          }),
                          _: 1
                        })];
                      }),
                      _: 1
                    }, 16, ["onClick"])];
                  }),
                  _: 2
                }, 1032, ["text"])])], 12, Nr), e.fileName ? (P(), W("div", zr, L(e.fileName), 1)) : he("", !0)], 2);
              }), 128)), N("div", Ir, [f(re, {
                text: v(s)("3602"),
                location: "top"
              }, {
                activator: m(function(e) {
                  var p = e.props;
                  return [f(ae, _({
                    class: "add-btn"
                  }, p, {
                    variant: "outlined",
                    color: "primary",
                    onClick: Ke
                  }), {
                    default: m(function() {
                      return [f(O, {
                        size: "36"
                      }, {
                        default: m(function() {
                          return H(r[14] || (r[14] = [M("class:iconfont plus", -1)]));
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  }, 16)];
                }),
                _: 1
              }, 8, ["text"])])])), [[a, V.value]])])];
            }),
            _: 1
          }, 8, ["title"])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), Yr = /* @__PURE__ */ lr(Lr, [["__scopeId", "data-v-72e16280"]]);
export {
  Yr as default
};
