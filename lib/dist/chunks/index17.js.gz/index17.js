import { ba as n, $ as x } from "./lib.js";
import { d as g, f as i, m as f, o as l, w as m, q as d, l as w, t as r, c as _, F as B, b as C, Q as k, G as D } from "./vue.js";
import { i as U } from "./vuetify.js";
var b = {
  class: "pa-2 overflow-auto",
  style: {
    "max-height": "200px"
  }
};
const R = /* @__PURE__ */ g({
  __name: "index",
  setup: function(F) {
    var t = n.isShow, c = n.showDialog, o = i([]), u = i("");
    n.onReveal(function(e) {
      e && (o.value = e.texts, u.value = e.name);
    });
    var p = function() {
      n.confirm(o.value), t.value = !1;
    }, v = function() {
      c(!1);
    }, h = [{
      name: "取消",
      fun: v
    }, {
      name: "确认",
      primary: !0,
      fun: p
    }];
    return function(e, s) {
      return l(), f(x, {
        title: e.t("4318"),
        footerBtnList: h,
        modelValue: D(t),
        "onUpdate:modelValue": s[0] || (s[0] = function(a) {
          return k(t) ? t.value = a : null;
        }),
        "max-width": 400
      }, {
        default: m(function() {
          return [d(r(e.t("4465")) + "： " + r(u.value) + " ", 1), w("div", b, [(l(!0), _(B, null, C(o.value, function(a) {
            return l(), f(U, {
              modelValue: a.tag,
              "onUpdate:modelValue": function(V) {
                return a.tag = V;
              },
              class: "mt-2"
            }, {
              prepend: m(function() {
                return [d(r(a.prompt) + ": ", 1)];
              }),
              _: 2
            }, 1032, ["modelValue", "onUpdate:modelValue"]);
          }), 256))])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  R as default
};
