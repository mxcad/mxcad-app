import { I as T, ae as w, $ as D, T as V } from "./lib.js";
import { d as b, g as A, j as H, m as s, o as i, w as f, l as k, c as x, G as r, F as y, q as C, t as g, C as v, s as p, b as S, x as j, Q as E } from "./vue.js";
import { s as M } from "./pinia.js";
var N = {
  class: "d-flex justify-center align-center py-7"
}, R = {
  class: "d-flex justify-space-evenly py-3"
};
const F = /* @__PURE__ */ b({
  __name: "index",
  setup: function(P) {
    var d = T(), m = M(d), n = m.options, c = m.isShow, _ = d.showDialog, u = A(function() {
      if (n.value.buttons && n.value.buttons.length > 0)
        return n.value.buttons;
      var o = [];
      return typeof n.value.defineTitle == "string" && o.push({
        text: n.value.defineTitle,
        props: {
          primary: !0,
          isAction: !0
        },
        onClick: function() {
          var e, a;
          (e = (a = n.value).define) === null || e === void 0 || e.call(a), l();
        }
      }), typeof n.value.cancelTitle == "string" && o.push({
        text: n.value.cancelTitle,
        props: {
          isAction: !0
        },
        onClick: function() {
          var e, a;
          (e = (a = n.value).cancel) === null || e === void 0 || e.call(a), l();
        }
      }), o;
    }), l = function() {
      _(!1);
    }, h = function() {
      var t = u.value.find(function(e) {
        var a;
        return e.role === "confirm" || ((a = e.props) === null || a === void 0 ? void 0 : a.primary);
      });
      return l(), (t == null ? void 0 : t.onClick) && t.onClick();
    }, $ = function() {
      var t = u.value.find(function(e) {
        return e.role === "cancel";
      });
      return l(), (t == null ? void 0 : t.onClick) && t.onClick() || function() {
        return _(!1);
      };
    }, B = {
      Escape: $,
      Enter: h
    };
    return H(function() {
      var o, t;
      (o = (t = n.value).mounted) === null || o === void 0 || o.call(t);
    }), function(o, t) {
      return i(), s(D, {
        title: r(n).title,
        modelValue: r(c),
        "onUpdate:modelValue": t[0] || (t[0] = function(e) {
          return E(c) ? c.value = e : null;
        }),
        "max-width": "max-content",
        keys: B
      }, {
        actions: f(function() {
          return [k("div", R, [r(n).actionsBefore ? (i(), s(v(r(n).actionsBefore), {
            key: 0
          })) : p("", !0), u.value.length > 0 ? (i(!0), x(y, {
            key: 1
          }, S(u.value, function(e, a) {
            return i(), s(w, j({
              key: a
            }, {
              ref_for: !0
            }, e.props || {}, {
              onClick: function() {
                l(), e.onClick && e.onClick();
              },
              class: "mr-2"
            }), {
              default: f(function() {
                return [C(g(e.text), 1)];
              }),
              _: 2
            }, 1040, ["onClick"]);
          }), 128)) : p("", !0), r(n).actionsAfter ? (i(), s(v(r(n).actionsAfter), {
            key: 2
          })) : p("", !0)])];
        }),
        default: f(function() {
          return [k("div", N, [typeof r(n).text == "string" ? (i(), x(y, {
            key: 0
          }, [C(g(r(n).text), 1)], 64)) : (i(), s(v(r(n).text), {
            key: 1
          }))])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), U = /* @__PURE__ */ V(F, [["__scopeId", "data-v-2e27a8d5"]]);
export {
  U as default
};
