import { bO as X, t as D, z as fe, I as de, a6 as y, a8 as ve, aQ as me, a7 as ce, Z as pe, C as ye, x as Ve, bP as ke, bQ as T, R as ge } from "./lib.js";
import { d as be, f as c, i as Y, m as q, o as z, w as a, l as xe, a as e, q as s, t as V, x as Ce, A as we, s as H, B as Be, G as F, Q as Le } from "./vue.js";
import { h as Me, M as Se, a as $ } from "./mxcad.js";
import { s as ee } from "./pinia.js";
import { D as w, C as n, c as B, k as Ie, d as De, S as Te, T as te, j as Ae } from "./vuetify.js";
var Ne = {
  class: "px-2 mt-5"
};
const Re = /* @__PURE__ */ be({
  __name: "index",
  setup: function(Ue) {
    var A, N, L = X.isShow, Z = X.showDialog, p = {}, R = c([]), b = c("所有图元");
    Y(L, function(u) {
      u && ye(function() {
        p = {};
        var t = new Me();
        t.allSelect(), t.forEach(function(l) {
          var r = l.getObjectName();
          p[r] ? p[r].push(l) : p[r] = [l];
        }), R.value = [{
          title: "所有图元",
          value: "all"
        }].concat(Ve(Object.keys(p).map(function(l) {
          return {
            title: ke[l] || l,
            value: l
          };
        }))), b.value = R.value[0].value;
      });
    });
    var _ = [{
      title: "Color",
      value: 1
    }, {
      title: "Layer",
      value: 2
    }, {
      title: "LineType",
      value: 3
    }], d = c(_[0].value), J = [{
      title: "= " + D("等于"),
      value: "="
    }, {
      title: "!= " + D("不等于"),
      value: "!="
    }, {
      title: "> " + D("大于"),
      value: ">"
    }, {
      title: D("全部选择"),
      value: "all"
    }], v = c(J[0].value), M = c(!0), ae = ee(fe()), O = ae.list, k = c((A = O.value[0]) === null || A === void 0 ? void 0 : A.name), le = ee(de()), U = le.lineTypeList, g = c((N = U.value[0]) === null || N === void 0 ? void 0 : N.name), j = c(!0);
    Y(d, function() {
      k.value || (k.value = O.value[0].name), g.value || (g.value = U.value[0].name);
    });
    var S = c(), ue = function() {
      Z(!1);
      var t = Se.getCurrentMxCAD(), l = function(K) {
        var I, f;
        if (d.value === 1 && (f = "trueColor"), d.value === 2 && (f = "layer"), d.value === 3 && (f = "linetype"), !!f) {
          var re = function(i) {
            if (i instanceof $ && f === "trueColor") {
              var m, o, W = new $(), x = (m = S.value) === null || m === void 0 || (m = m.color) === null || m === void 0 ? void 0 : m.method;
              if (x !== T.kByColor) {
                var C;
                if (x === T.kByLayer && i.method === x || x === T.kByBlock && i.method === x || x === T.kByACI && i.colorIndex === ((C = S.value) === null || C === void 0 || (C = C.color) === null || C === void 0 ? void 0 : C.index)) return !0;
              }
              var G = new THREE.Color((o = S.value) === null || o === void 0 || (o = o.color) === null || o === void 0 ? void 0 : o.color), ie = G.r, oe = G.g, se = G.b;
              W.setRGB(ie * 255, oe * 255, se * 255);
              var P = Number(W.getColorValue()), Q = Number(i.getColorValue());
              return v.value === "=" ? P === Q : v.value === "!=" ? P !== Q : v.value === ">" ? P < Q : !1;
            }
            return !1;
          };
          j.value || t.mxdraw.clearMxCurrentSelect();
          var E = [];
          (I = p[K]) === null || I === void 0 || I.forEach(function(h) {
            var i = !1, m = h.getMcDbEntity();
            if (m) {
              if (v.value === "all")
                i = !0;
              else {
                var o = m[f];
                re(o) && (i = !0), v.value === "=" ? (f === "layer" && o === k.value || f === "linetype" && o === g.value) && (i = !0) : v.value === "!=" ? (f === "layer" && o !== k.value || f === "linetype" && o !== g.value) && (i = !0) : v.value === ">" && (f === "layer" && o > k.value || f === "linetype" && o > g.value) && (i = !0), M.value || (i = !i);
              }
              i && E.push(h);
            }
          }), t.addCurrentSelect(E, E.length < 30);
        }
      };
      b.value === "all" ? Object.keys(p).forEach(function(r) {
        l(r);
      }) : M.value ? l(b.value) : Object.keys(p).filter(function(r) {
        return r !== b.value;
      }).forEach(function(r) {
        l(r);
      }), t.updateDisplay();
    }, ne = [{
      name: "确定",
      fun: ue,
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        return Z(!1);
      }
    }];
    return function(u, t) {
      return z(), q(pe, {
        title: u.t("224"),
        "max-width": "320",
        modelValue: F(L),
        "onUpdate:modelValue": t[6] || (t[6] = function(l) {
          return Le(L) ? L.value = l : null;
        }),
        footerBtnList: ne
      }, {
        default: a(function() {
          return [xe("div", Ne, [e(w, null, {
            default: a(function() {
              return [e(n, {
                cols: "4",
                class: "text-right"
              }, {
                default: a(function() {
                  return [e(y, {
                    "key-name": "V"
                  }, {
                    default: a(function() {
                      return [s(V(u.t("2073")), 1)];
                    }),
                    _: 1
                  }), t[7] || (t[7] = s(": ", -1))];
                }),
                _: 1
              }), e(n, {
                cols: "6"
              }, {
                default: a(function() {
                  return [e(B, {
                    class: "mx-1",
                    items: [u.t("2074")],
                    "model-value": u.t("2074")
                  }, null, 8, ["items", "model-value"])];
                }),
                _: 1
              }), e(n, {
                cols: "2"
              }, {
                default: a(function() {
                  return [e(ve, {
                    disabled: ""
                  })];
                }),
                _: 1
              })];
            }),
            _: 1
          }), e(w, null, {
            default: a(function() {
              return [e(n, {
                cols: "4",
                class: "text-right"
              }, {
                default: a(function() {
                  return [e(y, {
                    "key-name": "B"
                  }, {
                    default: a(function() {
                      return [s(V(u.t("2075")), 1)];
                    }),
                    _: 1
                  }), t[8] || (t[8] = s(": ", -1))];
                }),
                _: 1
              }), e(n, {
                cols: "6"
              }, {
                default: a(function() {
                  return [e(B, {
                    class: "mx-1",
                    items: R.value,
                    modelValue: b.value,
                    "onUpdate:modelValue": t[0] || (t[0] = function(l) {
                      return b.value = l;
                    })
                  }, null, 8, ["items", "modelValue"])];
                }),
                _: 1
              }), e(n, {
                cols: "2"
              })];
            }),
            _: 1
          }), e(w, null, {
            default: a(function() {
              return [e(n, {
                cols: "4",
                class: "text-right",
                "align-self": "start"
              }, {
                default: a(function() {
                  return [e(y, {
                    "key-name": "P"
                  }, {
                    default: a(function() {
                      return [s(V(u.t("206")), 1)];
                    }),
                    _: 1
                  }), t[9] || (t[9] = s(": ", -1))];
                }),
                _: 1
              }), e(n, {
                cols: "6"
              }, {
                default: a(function() {
                  return [e(Ie, {
                    items: _,
                    border: "",
                    height: "160",
                    density: "compact",
                    variant: "text"
                  }, {
                    item: a(function(l) {
                      var r = l.props;
                      return [e(De, Ce(r, {
                        onClick: function(I) {
                          return d.value = r.value;
                        },
                        class: d.value === r.value ? "bg-light-blue-darken-2" : ""
                      }), null, 16, ["onClick", "class"])];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }), e(n, {
                cols: "2"
              })];
            }),
            _: 1
          }), e(w, null, {
            default: a(function() {
              return [e(n, {
                cols: "4",
                class: "text-right"
              }, {
                default: a(function() {
                  return [e(y, {
                    "key-name": "O"
                  }, {
                    default: a(function() {
                      return [s(V(u.t("2077")), 1)];
                    }),
                    _: 1
                  }), t[10] || (t[10] = s(": ", -1))];
                }),
                _: 1
              }), e(n, {
                cols: "6"
              }, {
                default: a(function() {
                  return [e(B, {
                    class: "mx-1",
                    items: J,
                    modelValue: v.value,
                    "onUpdate:modelValue": t[1] || (t[1] = function(l) {
                      return v.value = l;
                    })
                  }, null, 8, ["modelValue"])];
                }),
                _: 1
              }), e(n, {
                cols: "2"
              })];
            }),
            _: 1
          }), e(w, null, {
            default: a(function() {
              return [e(n, {
                cols: "4",
                class: "text-right"
              }, {
                default: a(function() {
                  return [e(y, {
                    "key-name": "V"
                  }, {
                    default: a(function() {
                      return [s(V(u.t("2078")), 1)];
                    }),
                    _: 1
                  }), t[11] || (t[11] = s(": ", -1))];
                }),
                _: 1
              }), e(n, {
                cols: "6"
              }, {
                default: a(function() {
                  return [we(e(me, {
                    ref_key: "selectColor",
                    ref: S
                  }, null, 512), [[Be, d.value === 1]]), d.value === 2 ? (z(), q(B, {
                    key: 0,
                    modelValue: k.value,
                    "onUpdate:modelValue": t[2] || (t[2] = function(l) {
                      return k.value = l;
                    }),
                    items: F(O),
                    "item-title": "name",
                    "item-value": "name"
                  }, null, 8, ["modelValue", "items"])) : H("", !0), d.value === 3 ? (z(), q(B, {
                    key: 1,
                    modelValue: g.value,
                    "onUpdate:modelValue": t[3] || (t[3] = function(l) {
                      return g.value = l;
                    }),
                    items: F(U),
                    "item-title": "name",
                    "item-value": "name"
                  }, null, 8, ["modelValue", "items"])) : H("", !0)];
                }),
                _: 1
              }), e(n, {
                cols: "2"
              })];
            }),
            _: 1
          }), e(ce, {
            title: u.t("2073")
          }, {
            default: a(function() {
              return [e(Te, {
                class: "",
                inline: !1,
                modelValue: M.value,
                "onUpdate:modelValue": t[4] || (t[4] = function(l) {
                  return M.value = l;
                })
              }, {
                default: a(function() {
                  return [e(te, {
                    value: !0
                  }, {
                    label: a(function() {
                      return [e(y, {
                        "key-name": "I"
                      }, {
                        default: a(function() {
                          return [s(V(u.t("2079")), 1)];
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  }), e(te, {
                    value: !1,
                    class: "mt-1"
                  }, {
                    label: a(function() {
                      return [e(y, {
                        "key-name": "E"
                      }, {
                        default: a(function() {
                          return [s(V(u.t("2080")), 1)];
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }, 8, ["modelValue"])];
            }),
            _: 1
          }, 8, ["title"]), e(Ae, {
            class: "mt-2",
            modelValue: j.value,
            "onUpdate:modelValue": t[5] || (t[5] = function(l) {
              return j.value = l;
            })
          }, {
            label: a(function() {
              return [e(y, {
                "key-name": "A"
              }, {
                default: a(function() {
                  return [s(V(u.t("2081")), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), Qe = /* @__PURE__ */ ge(Re, [["__scopeId", "data-v-8cfd1a49"]]);
export {
  Qe as default
};
