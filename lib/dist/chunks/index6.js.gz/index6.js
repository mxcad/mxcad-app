import { x as J, a6 as w, T as E, ai as K, t as n, l as G, z as Q, J as X, u as Y, aj as Z, ak as ee, al as te, am as I, a8 as ne, an as oe, ao as A, $ as ae } from "./lib.js";
import { d as B, c as C, o as P, a, l as o, w as b, t as i, F as re, b as le, p as ie, q as x, f as U, i as S, G as r, g as D, m as ue, Q as se } from "./vue.js";
import { _ as de, i as L, c as R } from "./vuetify.js";
import { s as H } from "./pinia.js";
import { k as V } from "./mxcad.js";
var pe = {
  class: "h-full flex flex-col"
}, ce = {
  class: "bg-gray-100"
}, me = ["onClick"], fe = {
  class: "p-2 font-medium"
}, ve = {
  class: "p-2"
}, be = {
  class: "p-2 truncate"
}, xe = {
  class: "d-flex align-center mt-3"
};
const ye = /* @__PURE__ */ B({
  __name: "AttributeTab",
  props: {
    attributes: {},
    selectedRowIndex: {}
  },
  emits: ["selectRow", "updateValue"],
  setup: function(s, e) {
    var t = e.emit, m = t, $ = function(y) {
      m("selectRow", y);
    }, l = function(y) {
      m("updateValue", y);
    };
    return function(c, y) {
      var O;
      return P(), C("div", pe, [a(de, {
        class: "w-full",
        height: "240"
      }, {
        default: b(function() {
          return [o("thead", ce, [o("tr", null, [o("th", null, i(c.t("2277")), 1), o("th", null, i(c.t("1909")), 1), o("th", null, i(c.t("2078")), 1)])]), o("tbody", null, [(P(!0), C(re, null, le(c.attributes, function(h, j) {
            return P(), C("tr", {
              key: h.tag,
              onClick: function(k) {
                return $(j);
              },
              class: ie({
                active: c.selectedRowIndex === j
              })
            }, [o("td", fe, i(h.tag), 1), o("td", ve, i(h.prompt), 1), o("td", be, i(h.value), 1)], 10, me);
          }), 128))])];
        }),
        _: 1
      }), o("div", xe, [a(w, {
        "key-name": "V",
        colon: "",
        class: "mr-2"
      }, {
        default: b(function() {
          return J(y[0] || (y[0] = [x("值", -1)]));
        }),
        _: 1
      }), a(L, {
        "model-value": c.selectedRowIndex >= 0 ? (O = c.attributes[c.selectedRowIndex]) === null || O === void 0 ? void 0 : O.value : "",
        disabled: c.selectedRowIndex < 0,
        "onUpdate:modelValue": l
      }, null, 8, ["model-value", "disabled"])])]);
    };
  }
}), _e = /* @__PURE__ */ E(ye, [["__scopeId", "data-v-f36e6f11"]]);
function W(u, s) {
  var e = Object.keys(u);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(u);
    s && (t = t.filter(function(m) {
      return Object.getOwnPropertyDescriptor(u, m).enumerable;
    })), e.push.apply(e, t);
  }
  return e;
}
function F(u) {
  for (var s = 1; s < arguments.length; s++) {
    var e = arguments[s] != null ? arguments[s] : {};
    s % 2 ? W(Object(e), !0).forEach(function(t) {
      G(u, t, e[t]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(u, Object.getOwnPropertyDescriptors(e)) : W(Object(e)).forEach(function(t) {
      Object.defineProperty(u, t, Object.getOwnPropertyDescriptor(e, t));
    });
  }
  return u;
}
var ge = {
  class: "px-2 py-1 text-sm"
}, Ve = {
  class: "grid grid-cols-2 gap-x-4 gap-y-3"
}, we = {
  class: "d-flex align-center justify-space-between mb-2"
}, Te = {
  class: "d-flex align-center justify-space-between mb-2"
}, Oe = {
  class: "d-flex align-center justify-space-between mb-2"
}, he = {
  class: "d-flex align-center justify-space-between mb-2"
}, ke = {
  class: "d-flex align-center justify-space-between mb-2"
}, je = {
  class: "d-flex align-center justify-space-between mb-2"
}, Me = {
  class: "d-flex align-center justify-space-between mb-2"
};
const $e = /* @__PURE__ */ B({
  __name: "TextOptionTab",
  props: {
    textOptions: {}
  },
  emits: ["updateTextOptions"],
  setup: function(s, e) {
    var t = e.emit, m = s, $ = t, l = U(F({
      style: "",
      textHorzMode: V.TextHorzMode.kTextLeft,
      textVertMode: V.TextVertMode.kTextBase,
      height: 0,
      widthFactor: 0,
      rotation: 0,
      obliqueAngle: 0
    }, m.textOptions));
    S(function() {
      return m.textOptions;
    }, function(k) {
      k && Object.assign(l.value, k);
    }, {
      deep: !0
    }), S(l, function(k) {
      $("updateTextOptions", F({}, k));
    }, {
      deep: !0
    });
    var c = K(), y = c.initList, O = H(c), h = O.textStyles, j = [{
      title: n("1719"),
      value: V.TextHorzMode.kTextLeft
    }, {
      title: n("1720"),
      value: V.TextHorzMode.kTextCenter
    }, {
      title: n("1721"),
      value: V.TextHorzMode.kTextRight
    }, {
      title: n("1718"),
      value: V.TextHorzMode.kTextAlign
    }, {
      title: n("4458"),
      value: V.TextHorzMode.kTextMid
    }, {
      title: n("4459"),
      value: V.TextHorzMode.kTextFit
    }], M = [{
      title: n("4460"),
      value: V.TextVertMode.kTextBase
    }, {
      title: n("1725"),
      value: V.TextVertMode.kTextBottom
    }, {
      title: n("4458"),
      value: V.TextVertMode.kTextVertMid
    }, {
      title: n("1723"),
      value: V.TextVertMode.kTextTop
    }];
    return function(k, d) {
      return P(), C("div", ge, [o("div", Ve, [o("div", we, [a(w, {
        "key-name": "S",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("230")), 1)];
        }),
        _: 1
      }), a(R, {
        class: "",
        "onUpdate:menu": d[0] || (d[0] = function(p) {
          return p && r(y)();
        }),
        items: r(h),
        "max-width": "340px",
        modelValue: l.value.style,
        "onUpdate:modelValue": d[1] || (d[1] = function(p) {
          return l.value.style = p;
        })
      }, null, 8, ["items", "modelValue"])]), o("div", Te, [a(w, {
        "key-name": "J",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("1718")), 1)];
        }),
        _: 1
      }), a(R, {
        modelValue: l.value.textHorzMode,
        "onUpdate:modelValue": d[2] || (d[2] = function(p) {
          return l.value.textHorzMode = p;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px",
        items: j
      }, null, 8, ["modelValue"])]), o("div", Oe, [a(w, {
        "key-name": "J",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("1722")), 1)];
        }),
        _: 1
      }), a(R, {
        modelValue: l.value.textVertMode,
        "onUpdate:modelValue": d[3] || (d[3] = function(p) {
          return l.value.textVertMode = p;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px",
        items: M
      }, null, 8, ["modelValue"])]), o("div", he, [a(w, {
        "key-name": "E",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("1835")), 1)];
        }),
        _: 1
      }), a(L, {
        modelValue: l.value.height,
        "onUpdate:modelValue": d[4] || (d[4] = function(p) {
          return l.value.height = p;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px",
        type: "number"
      }, null, 8, ["modelValue"])]), o("div", ke, [a(w, {
        "key-name": "W",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("2143")), 1)];
        }),
        _: 1
      }), a(L, {
        modelValue: l.value.widthFactor,
        "onUpdate:modelValue": d[5] || (d[5] = function(p) {
          return l.value.widthFactor = p;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px",
        type: "number",
        step: "0.1"
      }, null, 8, ["modelValue"])]), o("div", je, [a(w, {
        "key-name": "R",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("176")), 1)];
        }),
        _: 1
      }), a(L, {
        class: "",
        modelValue: l.value.rotation,
        "onUpdate:modelValue": d[6] || (d[6] = function(p) {
          return l.value.rotation = p;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px",
        type: "number",
        step: "1"
      }, null, 8, ["modelValue"])]), o("div", Me, [a(w, {
        "key-name": "O",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("2144")), 1)];
        }),
        _: 1
      }), a(L, {
        modelValue: l.value.obliqueAngle,
        "onUpdate:modelValue": d[7] || (d[7] = function(p) {
          return l.value.obliqueAngle = p;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px",
        type: "number",
        step: "1"
      }, null, 8, ["modelValue"])])])]);
    };
  }
}), Pe = /* @__PURE__ */ E($e, [["__scopeId", "data-v-be24df37"]]);
function N(u, s) {
  var e = Object.keys(u);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(u);
    s && (t = t.filter(function(m) {
      return Object.getOwnPropertyDescriptor(u, m).enumerable;
    })), e.push.apply(e, t);
  }
  return e;
}
function q(u) {
  for (var s = 1; s < arguments.length; s++) {
    var e = arguments[s] != null ? arguments[s] : {};
    s % 2 ? N(Object(e), !0).forEach(function(t) {
      G(u, t, e[t]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(u, Object.getOwnPropertyDescriptors(e)) : N(Object(e)).forEach(function(t) {
      Object.defineProperty(u, t, Object.getOwnPropertyDescriptor(e, t));
    });
  }
  return u;
}
var Re = {
  class: "px-2 py-1 text-sm"
}, Le = {
  class: "grid grid-cols-2 gap-x-4 gap-y-3"
}, Ce = {
  class: "d-flex align-center justify-space-between mb-2"
}, Ue = {
  class: "d-flex align-center justify-space-between mb-2"
}, Se = {
  class: "d-flex align-center justify-space-between mb-2"
}, Be = {
  class: "d-flex align-center justify-space-between mb-2"
};
const ze = /* @__PURE__ */ B({
  __name: "PropertiesTab",
  props: {
    properties: {}
  },
  emits: ["updateProperties"],
  setup: function(s, e) {
    var t = e.emit, m = Q(), $ = m.initLayerList, l = H(m), c = l.list, y = D(function() {
      return c.value.map(function(g) {
        return g.name;
      });
    }), O = X(), h = O.initLineTypeList, j = H(O), M = j.lineTypeList, k = Y(), d = k.createColor, p = s, z = t, _ = U(q({
      layer: "0",
      color: d(),
      lineType: "Continuous",
      lineWeight: 0
    }, p.properties));
    S(function() {
      return p.properties;
    }, function(g) {
      g && Object.assign(_.value, g);
    }, {
      deep: !0
    }), S(_, function(g) {
      z("updateProperties", q({}, g));
    }, {
      deep: !0
    });
    var v = ee();
    return function(g, f) {
      return P(), C("div", Re, [o("div", Le, [o("div", Ce, [a(w, {
        "key-name": "L",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("196")), 1)];
        }),
        _: 1
      }), a(R, {
        items: y.value,
        modelValue: _.value.layer,
        "onUpdate:modelValue": f[0] || (f[0] = function(T) {
          return _.value.layer = T;
        }),
        "max-width": "340px",
        "onUpdate:menu": f[1] || (f[1] = function(T) {
          return T && r($)();
        })
      }, null, 8, ["items", "modelValue"])]), o("div", Ue, [a(w, {
        "key-name": "C",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("210")), 1)];
        }),
        _: 1
      }), a(Z, {
        modelValue: _.value.color,
        "onUpdate:modelValue": f[2] || (f[2] = function(T) {
          return _.value.color = T;
        }),
        "is-store-color": !1,
        "max-width": "340px"
      }, null, 8, ["modelValue"])]), o("div", Se, [a(w, {
        "key-name": "T",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("218")), 1)];
        }),
        _: 1
      }), a(R, {
        items: r(M),
        "item-title": "name",
        modelValue: _.value.lineType,
        "onUpdate:modelValue": f[3] || (f[3] = function(T) {
          return _.value.lineType = T;
        }),
        "max-width": "340px",
        "onUpdate:menu": f[4] || (f[4] = function(T) {
          return T && r(h)();
        })
      }, null, 8, ["items", "modelValue"])]), o("div", Be, [a(w, {
        "key-name": "W",
        colon: ""
      }, {
        default: b(function() {
          return [x(i(r(n)("1810")), 1)];
        }),
        _: 1
      }), a(R, {
        "item-title": "name",
        items: r(v),
        modelValue: _.value.lineWeight,
        "onUpdate:modelValue": f[5] || (f[5] = function(T) {
          return _.value.lineWeight = T;
        }),
        modelModifiers: {
          number: !0
        },
        "max-width": "340px"
      }, null, 8, ["items", "modelValue"])])])]);
    };
  }
}), Ie = /* @__PURE__ */ E(ze, [["__scopeId", "data-v-cb93a876"]]);
var Ae = {
  class: "px-3 py-2"
}, De = {
  class: "d-flex align-center justify-space-between"
}, He = {
  class: "mb-2"
}, Ee = {
  class: "flex justify-end mb-3"
};
const Ge = /* @__PURE__ */ B({
  __name: "index",
  setup: function(s) {
    var e = te(), t = e.attributes, m = e.selectedRowIndex, $ = e.textOptions, l = e.properties, c = e.selectRow, y = e.updateAttributeValue, O = e.updateTextOptions, h = e.updateProperties, j = e.selectBlock, M = U(""), k = D(function() {
      var v;
      return m.value >= 0 ? (v = t.value[m.value]) === null || v === void 0 ? void 0 : v.tag : "";
    });
    I.onReveal(function(v) {
      v && (M.value = v.blockName, t.value = J(v.attributes), m.value = 0);
    });
    var d = U(0), p = D(function() {
      return [{
        tab: n("2387"),
        component: _e,
        props: function() {
          return {
            attributes: t.value,
            selectedRowIndex: m.value,
            onSelectRow: c,
            onUpdateValue: y
          };
        }
      }, {
        tab: n("文字选项"),
        component: Pe,
        props: function() {
          return {
            textOptions: $.value,
            onUpdateTextOptions: O
          };
        }
      }, {
        tab: n("206"),
        component: Ie,
        props: function() {
          return {
            properties: l.value,
            onUpdateProperties: h
          };
        }
      }];
    }), z = function() {
      I.confirm({
        blockName: M.value,
        attributes: t.value
      });
    };
    c(0);
    var _ = [{
      name: "确定",
      fun: z,
      primary: !0
    }, {
      name: "取消",
      fun: function() {
        I.showDialog(!1);
      }
    }];
    return function(v, g) {
      return P(), ue(ae, {
        title: r(n)("4455"),
        modelValue: r(A),
        "onUpdate:modelValue": g[1] || (g[1] = function(f) {
          return se(A) ? A.value = f : null;
        }),
        footerBtnList: _,
        "max-width": "600"
      }, {
        default: b(function() {
          return [o("div", Ae, [o("div", De, [o("div", null, [o("div", He, i(r(n)("4077")) + ": " + i(M.value), 1), o("div", null, i(r(n)("2277")) + ": " + i(k.value), 1)]), o("div", Ee, [x(i(r(n)("4456")) + "(B) ", 1), a(ne, {
            text: r(n)("4457"),
            onClick: r(j)
          }, null, 8, ["text", "onClick"])])]), a(oe, {
            items: p.value,
            modelValue: d.value,
            "onUpdate:modelValue": g[0] || (g[0] = function(f) {
              return d.value = f;
            }),
            height: 280,
            tabsProps: {
              grow: !0
            }
          }, null, 8, ["items", "modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  Ge as default
};
