import { bU as k, ai as q, t as l, a7 as M, a8 as S, $ as I, _ as O, a as g, l as J, T as K } from "./lib.js";
import { d as Q, f as W, m as X, o as Y, w as a, a as r, G as u, l as f, t as v, Q as Z } from "./vue.js";
import { s as $ } from "./pinia.js";
import { k as p, s as _, n as ee, M as te, p as ne, J as le, h as re } from "./mxcad.js";
import { D as oe, C as z, j as y, i as b, c as D } from "./vuetify.js";
function H(V, c) {
  var i = Object.keys(V);
  if (Object.getOwnPropertySymbols) {
    var d = Object.getOwnPropertySymbols(V);
    c && (d = d.filter(function(T) {
      return Object.getOwnPropertyDescriptor(V, T).enumerable;
    })), i.push.apply(i, d);
  }
  return i;
}
function C(V) {
  for (var c = 1; c < arguments.length; c++) {
    var i = arguments[c] != null ? arguments[c] : {};
    c % 2 ? H(Object(i), !0).forEach(function(d) {
      J(V, d, i[d]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(V, Object.getOwnPropertyDescriptors(i)) : H(Object(i)).forEach(function(d) {
      Object.defineProperty(V, d, Object.getOwnPropertyDescriptor(i, d));
    });
  }
  return V;
}
const ae = /* @__PURE__ */ Q({
  __name: "index",
  setup: function(c) {
    var i = k.isShow, d = k.showDialog, T = $(q()), A = T.textStyles, U = {
      tag: "",
      // 标记(T)
      prompt: "",
      // 提示(M)
      defaultValue: "",
      // 默认(L)
      mode: {
        invisible: !1,
        constant: !1,
        verify: !1,
        preset: !1,
        lockPosition: !0,
        multiLine: !1
      },
      insertPoint: {
        onScreen: !0,
        x: 0,
        y: 0,
        z: 0
      },
      textOptions: {
        textHorzMode: p.TextHorzMode.kTextLeft,
        textVertMode: p.TextVertMode.kTextBase,
        styleName: "Standard",
        annotative: !1,
        height: 0.2,
        rotation: 0,
        widthFactor: 1,
        obliqueAngle: 0,
        boundaryWidth: 0
      }
    }, n = W(C({}, U)), j = function() {
      n.value = C({}, U);
    };
    k.onReveal(j);
    var R = [{
      title: l("1719"),
      value: p.TextHorzMode.kTextLeft
    }, {
      title: l("1720"),
      value: p.TextHorzMode.kTextCenter
    }, {
      title: l("1721"),
      value: p.TextHorzMode.kTextRight
    }, {
      title: l("1718"),
      value: p.TextHorzMode.kTextAlign
    }, {
      title: l("4458"),
      value: p.TextHorzMode.kTextMid
    }, {
      title: l("4459"),
      value: p.TextHorzMode.kTextFit
    }], E = [{
      title: l("4460"),
      value: p.TextVertMode.kTextBase
    }, {
      title: l("1725"),
      value: p.TextVertMode.kTextBottom
    }, {
      title: l("4458"),
      value: p.TextVertMode.kTextVertMid
    }, {
      title: l("1723"),
      value: p.TextVertMode.kTextTop
    }];
    function F() {
      return w.apply(this, arguments);
    }
    function w() {
      return w = O(/* @__PURE__ */ g.mark(function m() {
        var e, t, s, o, P;
        return g.wrap(function(x) {
          for (; ; ) switch (x.prev = x.next) {
            case 0:
              if (e = new le(), t = n.value, e.tag = t.tag, e.prompt = t.prompt, e.textString = t.defaultValue, e.isVerifiable = t.mode.verify, e.isConstant = t.mode.constant, e.isPreset = t.mode.preset, e.isInvisible = t.mode.invisible, e.textStyle = t.textOptions.styleName, e.height = t.textOptions.height, e.widthFactor = t.textOptions.widthFactor, e.rotation = THREE.MathUtils.degToRad(t.textOptions.rotation), e.oblique = THREE.MathUtils.degToRad(t.textOptions.obliqueAngle), e.horizontalMode = t.textOptions.textHorzMode, e.verticalMode = t.textOptions.textVertMode, e.widthFactor = t.textOptions.widthFactor, !t.insertPoint.onScreen) {
                x.next = 3;
                break;
              }
              return s = new re(), s.setMessage(l("1618")), s.setUserDraw(function(h, G) {
                e.position = h, e.alignmentPoint = h, G.drawMcDbEntity(e);
              }), x.next = 1, s.go();
            case 1:
              if (o = x.sent, o) {
                x.next = 2;
                break;
              }
              return x.abrupt("return");
            case 2:
              e.position = o, e.alignmentPoint = o, x.next = 4;
              break;
            case 3:
              P = new ne(t.insertPoint.x, t.insertPoint.y, t.insertPoint.z), e.position = P, e.alignmentPoint = P;
            case 4:
              return x.abrupt("return", e);
            case 5:
            case "end":
              return x.stop();
          }
        }, m);
      })), w.apply(this, arguments);
    }
    var B = /* @__PURE__ */ function() {
      var m = O(/* @__PURE__ */ g.mark(function e() {
        var t, s;
        return g.wrap(function(o) {
          for (; ; ) switch (o.prev = o.next) {
            case 0:
              return i.value = !1, t = new _(), t.setMessage(l("1835")), o.next = 1, t.go();
            case 1:
              s = o.sent, typeof s == "number" && (n.value.textOptions.height = s), i.value = !0;
            case 2:
            case "end":
              return o.stop();
          }
        }, e);
      }));
      return function() {
        return m.apply(this, arguments);
      };
    }(), L = /* @__PURE__ */ function() {
      var m = O(/* @__PURE__ */ g.mark(function e() {
        var t, s;
        return g.wrap(function(o) {
          for (; ; ) switch (o.prev = o.next) {
            case 0:
              return i.value = !1, t = new ee(), t.setMessage(l("169")), o.next = 1, t.go();
            case 1:
              s = o.sent, typeof s == "number" && (n.value.textOptions.rotation = THREE.MathUtils.radToDeg(s)), i.value = !0;
            case 2:
            case "end":
              return o.stop();
          }
        }, e);
      }));
      return function() {
        return m.apply(this, arguments);
      };
    }(), N = [{
      name: "确定",
      fun: function() {
        var m = O(/* @__PURE__ */ g.mark(function t() {
          var s;
          return g.wrap(function(o) {
            for (; ; ) switch (o.prev = o.next) {
              case 0:
                return d(!1), o.next = 1, F();
              case 1:
                s = o.sent, s && te.getCurrentMxCAD().drawEntity(s);
              case 2:
              case "end":
                return o.stop();
            }
          }, t);
        }));
        function e() {
          return m.apply(this, arguments);
        }
        return e;
      }(),
      primary: !0
    }, {
      name: "取消",
      fun: function() {
        return d(!1);
      }
    }, {
      name: "帮助",
      fun: function() {
        return alert("帮助文档");
      }
    }];
    return function(m, e) {
      return Y(), X(I, {
        title: u(l)("4526"),
        "max-width": "500",
        modelValue: u(i),
        "onUpdate:modelValue": e[17] || (e[17] = function(t) {
          return Z(i) ? i.value = t : null;
        }),
        footerBtnList: N
      }, {
        default: a(function() {
          return [r(oe, null, {
            default: a(function() {
              return [r(z, {
                cols: "4",
                "align-self": "stretch",
                class: "h-100"
              }, {
                default: a(function() {
                  return [r(M, {
                    title: u(l)("193")
                  }, {
                    default: a(function() {
                      return [r(y, {
                        modelValue: n.value.mode.invisible,
                        "onUpdate:modelValue": e[0] || (e[0] = function(t) {
                          return n.value.mode.invisible = t;
                        }),
                        label: "不可见(I)"
                      }, null, 8, ["modelValue"]), r(y, {
                        modelValue: n.value.mode.constant,
                        "onUpdate:modelValue": e[1] || (e[1] = function(t) {
                          return n.value.mode.constant = t;
                        }),
                        label: "固定(C)"
                      }, null, 8, ["modelValue"]), r(y, {
                        modelValue: n.value.mode.verify,
                        "onUpdate:modelValue": e[2] || (e[2] = function(t) {
                          return n.value.mode.verify = t;
                        }),
                        label: "验证(V)"
                      }, null, 8, ["modelValue"]), r(y, {
                        modelValue: n.value.mode.preset,
                        "onUpdate:modelValue": e[3] || (e[3] = function(t) {
                          return n.value.mode.preset = t;
                        }),
                        label: "预设(P)"
                      }, null, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"]), r(M, {
                    title: u(l)("209")
                  }, {
                    default: a(function() {
                      return [r(y, {
                        modelValue: n.value.insertPoint.onScreen,
                        "onUpdate:modelValue": e[4] || (e[4] = function(t) {
                          return n.value.insertPoint.onScreen = t;
                        }),
                        label: "在屏幕上指定(O)"
                      }, null, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.insertPoint.x,
                        "onUpdate:modelValue": e[5] || (e[5] = function(t) {
                          return n.value.insertPoint.x = t;
                        }),
                        modelModifiers: {
                          number: !0
                        },
                        type: "number",
                        step: "0.001",
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("209")) + "X:", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.insertPoint.y,
                        "onUpdate:modelValue": e[6] || (e[6] = function(t) {
                          return n.value.insertPoint.y = t;
                        }),
                        modelModifiers: {
                          number: !0
                        },
                        type: "number",
                        step: "0.001",
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("209")) + "Y:", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.insertPoint.z,
                        "onUpdate:modelValue": e[7] || (e[7] = function(t) {
                          return n.value.insertPoint.z = t;
                        }),
                        modelModifiers: {
                          number: !0
                        },
                        type: "number",
                        step: "0.001"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("209")) + "Z:", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              }), r(z, {
                cols: "8",
                "align-self": "stretch",
                class: "h-100"
              }, {
                default: a(function() {
                  return [r(M, {
                    title: u(l)("2387")
                  }, {
                    default: a(function() {
                      return [r(b, {
                        modelValue: n.value.tag,
                        "onUpdate:modelValue": e[8] || (e[8] = function(t) {
                          return n.value.tag = t;
                        }),
                        type: "text",
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("2277")) + "(T):", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.prompt,
                        "onUpdate:modelValue": e[9] || (e[9] = function(t) {
                          return n.value.prompt = t;
                        }),
                        type: "text",
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("1909")) + "(M):", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.defaultValue,
                        "onUpdate:modelValue": e[10] || (e[10] = function(t) {
                          return n.value.defaultValue = t;
                        }),
                        type: "text"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("4464")) + "(L):", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"]), r(M, {
                    title: u(l)("4527")
                  }, {
                    default: a(function() {
                      return [r(D, {
                        modelValue: n.value.textOptions.textHorzMode,
                        "onUpdate:modelValue": e[11] || (e[11] = function(t) {
                          return n.value.textOptions.textHorzMode = t;
                        }),
                        items: R,
                        "item-title": "title",
                        class: "mb-1",
                        "item-value": "value"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("1718")) + "(J):", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(D, {
                        modelValue: n.value.textOptions.textVertMode,
                        "onUpdate:modelValue": e[12] || (e[12] = function(t) {
                          return n.value.textOptions.textVertMode = t;
                        }),
                        items: E,
                        "item-title": "title",
                        class: "mb-1",
                        "item-value": "value"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("1722")) + "(J):", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(D, {
                        modelValue: n.value.textOptions.styleName,
                        "onUpdate:modelValue": e[13] || (e[13] = function(t) {
                          return n.value.textOptions.styleName = t;
                        }),
                        items: u(A),
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("230")) + "(S):", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue", "items"]), r(y, {
                        modelValue: n.value.textOptions.annotative,
                        "onUpdate:modelValue": e[14] || (e[14] = function(t) {
                          return n.value.textOptions.annotative = t;
                        }),
                        label: "注释性(N)"
                      }, null, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.textOptions.height,
                        "onUpdate:modelValue": e[15] || (e[15] = function(t) {
                          return n.value.textOptions.height = t;
                        }),
                        modelModifiers: {
                          number: !0
                        },
                        type: "number",
                        step: "0.001",
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("2283")) + "(E):", 1)];
                        }),
                        append: a(function() {
                          return [r(S, {
                            text: u(l)("4528"),
                            onClick: B
                          }, null, 8, ["text"])];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), r(b, {
                        modelValue: n.value.textOptions.rotation,
                        "onUpdate:modelValue": e[16] || (e[16] = function(t) {
                          return n.value.textOptions.rotation = t;
                        }),
                        modelModifiers: {
                          number: !0
                        },
                        type: "number",
                        step: "0.001",
                        class: "mb-1"
                      }, {
                        prepend: a(function() {
                          return [f("span", null, v(u(l)("1931")) + "(R):", 1)];
                        }),
                        append: a(function() {
                          return [r(S, {
                            text: u(l)("4529"),
                            onClick: L
                          }, null, 8, ["text"])];
                        }),
                        _: 1
                      }, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              })];
            }),
            _: 1
          })];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), me = /* @__PURE__ */ K(ae, [["__scopeId", "data-v-72138061"]]);
export {
  me as default
};
