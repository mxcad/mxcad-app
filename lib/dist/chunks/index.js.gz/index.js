import { t as y, x as de, R as fe, T as ve, U as pe, l as he } from "./lib.js";
import { f as S, g as te, d as ge, i as ae, ah as me, m as xe, o as z, A as be, s as ne, G as t, c as Z, l as x, a as b, t as C, w as D, q, Q as re, ai as we, T as ye, v as G } from "./vue.js";
import "./es.regexp.constructor.js";
import { M as _e } from "./mxcad.js";
import { b as Se } from "./@vueuse/core.js";
import { h as Ce, b as De, V as L, i as le, j as M } from "./vuetify.js";
function Fe(n, e) {
  var a = typeof Symbol != "undefined" && n[Symbol.iterator] || n["@@iterator"];
  if (!a) {
    if (Array.isArray(n) || (a = Ve(n)) || e) {
      a && (n = a);
      var o = 0, u = function() {
      };
      return { s: u, n: function() {
        return o >= n.length ? { done: !0 } : { done: !1, value: n[o++] };
      }, e: function(r) {
        throw r;
      }, f: u };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  var c, F = !0, m = !1;
  return { s: function() {
    a = a.call(n);
  }, n: function() {
    var r = a.next();
    return F = r.done, r;
  }, e: function(r) {
    m = !0, c = r;
  }, f: function() {
    try {
      F || a.return == null || a.return();
    } finally {
      if (m) throw c;
    }
  } };
}
function Ve(n, e) {
  if (n) {
    if (typeof n == "string") return ie(n, e);
    var a = {}.toString.call(n).slice(8, -1);
    return a === "Object" && n.constructor && (a = n.constructor.name), a === "Map" || a === "Set" ? Array.from(n) : a === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? ie(n, e) : void 0;
  }
}
function ie(n, e) {
  (e == null || e > n.length) && (e = n.length);
  for (var a = 0, o = Array(e); a < e; a++) o[a] = n[a];
  return o;
}
var ee = function(e, a) {
  var o = S(!1), u = S(""), c = S(""), F = S(!1), m = S({
    matchCase: !1,
    matchWholeWord: !1,
    useWildcards: !1,
    matchDiacritics: !1,
    matchHalfFullWidth: !1
  }), v = S({
    current: 0,
    total: 0
  }), r = S([]), d = S(-1), Q = te(function() {
    return !u.value;
  }), E = te(function() {
    return !u.value || v.value.total === 0;
  }), I = function() {
    if (!u.value) return [];
    var i = [], s = e.mText.textString;
    if (!s) return [];
    var h = s, p = u.value;
    if (m.value.matchCase || (h = s.toLowerCase(), p = u.value.toLowerCase()), m.value.matchHalfFullWidth || (h = O(h), p = O(p)), m.value.matchDiacritics || (h = N(h), p = N(p)), m.value.useWildcards)
      return $(h, p);
    for (var _ = 0, g; (g = h.indexOf(p, _)) !== -1; ) {
      if (m.value.matchWholeWord) {
        var R = g > 0 ? h[g - 1] : null, W = g + p.length < h.length ? h[g + p.length] : null, Y = !R || !/\w/.test(R), ce = !W || !/\w/.test(W);
        if (!(Y && ce)) {
          _ = g + 1;
          continue;
        }
      }
      i.push({
        index: g,
        length: p.length
      }), _ = g + 1;
    }
    return i;
  }, O = function(i) {
    return i.replace(/[\uFF01-\uFF5E]/g, function(s) {
      return String.fromCharCode(s.charCodeAt(0) - 65248);
    });
  }, N = function(i) {
    return i.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }, $ = function(i, s) {
    for (var h = [], p = s.replace(/\*/g, ".*").replace(/\?/g, ".").replace(/\./g, "\\."), _ = new RegExp(p, "g"), g; (g = _.exec(i)) !== null; )
      h.push({
        index: g.index,
        length: g[0].length
      }), g.index === _.lastIndex && _.lastIndex++;
    return h;
  }, H = function(i) {
    console.log(121), e.selectionStart = i.index, e.selectionEnd = i.index + i.length, e.isSelecting = !0, e.cursorPosition = i.index + i.length, e.updateCursorPosition(), e.updateSelectionHighlight(), e.draw(), e.cursor.focus();
  }, U = function() {
    u.value && (V(), r.value.length !== 0 && (d.value === -1 || d.value >= r.value.length - 1 ? d.value = 0 : d.value++, v.value.current = d.value + 1, H(r.value[d.value])));
  }, T = function() {
    u.value && (V(), r.value.length !== 0 && (d.value === -1 || d.value <= 0 ? d.value = r.value.length - 1 : d.value--, v.value.current = d.value + 1));
  }, B = function(i) {
    if (!u.value || i.length === 0) return 0;
    var s = e.mText.textString, h = de(i).sort(function(W, Y) {
      return Y.index - W.index;
    });
    e.saveToHistory();
    var p = s, _ = Fe(h), g;
    try {
      for (_.s(); !(g = _.n()).done; ) {
        var R = g.value;
        p = p.substring(0, R.index) + c.value + p.substring(R.index + R.length);
      }
    } catch (W) {
      _.e(W);
    } finally {
      _.f();
    }
    return e.mText.textString = p, e.updateBox(), e.clearSelection(), e.draw(), d.value = -1, r.value = [], V(), _e.getCurrentMxCAD().updateDisplay(), h.length;
  }, J = function() {
    if (!(d.value === -1 || r.value.length === 0)) {
      var i = r.value[d.value];
      B([i]), r.value.length > 0 && U();
    }
  }, A = function() {
    if (r.value.length !== 0) {
      var i = B(r.value);
      i > 0 && console.log(y("已替换 ".concat(i, " 处文本")));
    }
  }, K = function() {
    d.value = -1, r.value = [], v.value = {
      current: 0,
      total: 0
    }, e.clearSelection();
  }, V = Se(function() {
    u.value && (r.value = I(), v.value.total = r.value.length, F.value = !0, r.value.length > 0 && d.value < 0 && (d.value = 0, v.value.current = 1, H(r.value[0])));
  }, 300), X = function() {
    if (e.hasSelection()) {
      var i = e.getSelectedText();
      i && (u.value = i);
    }
    o.value = !0, setTimeout(function() {
      V();
    }, 100);
  }, P = function() {
    o.value = !1, e.clearSelection(), K(), a != null && a.onClose && a.onClose();
  }, k = function() {
    var i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
    i ? X() : P();
  };
  return {
    isShow: o,
    findText: u,
    replaceText: c,
    optionsRef: m,
    resultStats: v,
    hasSearched: F,
    disableFind: Q,
    disableReplace: E,
    findNext: U,
    findPrevious: T,
    replaceCurrent: J,
    replaceAll: A,
    refreshSearch: V,
    showDialog: k,
    closeDialog: P
  };
}, Te = {
  class: "find-replace-header",
  id: "single_line_text_find_replace_dialog_header"
}, ke = {
  class: "dialog-title"
}, Re = {
  class: "find-replace-content"
}, We = {
  class: "input-row find-row"
}, Oe = {
  class: "label"
}, Ae = {
  class: "input-row replace-row"
}, Pe = {
  class: "label"
}, Le = {
  class: "options-area"
}, Me = {
  class: "option-row"
}, je = {
  class: "option-row"
}, Ee = {
  class: "option-row"
}, Ie = {
  class: "option-row"
}, Ne = {
  class: "option-row"
}, He = {
  class: "right-buttons"
}, Ue = {
  key: 0,
  class: "search-stats mt-2"
}, Be = {
  key: 1,
  class: "search-stats mt-2 error-text"
};
const Ke = /* @__PURE__ */ ge({
  __name: "index",
  props: {
    editor: {},
    onClose: {
      type: Function
    }
  },
  setup: function(e, a) {
    var o = a.expose, u = e, c = ee(u.editor, {
      onClose: u.onClose
    }), F = c.isShow, m = c.findText, v = c.replaceText, r = c.optionsRef, d = c.resultStats, Q = c.hasSearched, E = c.disableFind, I = c.disableReplace, O = c.findNext, N = c.findPrevious, $ = c.replaceCurrent, H = c.replaceAll, U = c.showDialog, T = c.closeDialog, B = c.refreshSearch, J = S(null), A = S(null), K = function(l) {
      l.key === "Escape" ? T() : l.key === "Enter" && l.ctrlKey && O();
    }, V = S(0), X = S(0), P = function() {
      setTimeout(function() {
        A.value && A.value.focus({
          preventScroll: !0
        });
      });
    };
    return ae([m, function() {
      return r.value;
    }], function() {
      B(), P();
    }, {
      deep: !0
    }), ae(F, function(k) {
      k ? (document.addEventListener("keydown", K), P()) : document.removeEventListener("keydown", K);
    }), o({
      showDialog: U
    }), function(k, l) {
      var i = me("draggable");
      return z(), xe(ye, {
        to: "body"
      }, [t(F) ? be((z(), Z("div", {
        key: 0,
        ref_key: "dialogRef",
        ref: J,
        class: "find-replace-dialog",
        onKeydown: l[7] || (l[7] = we(
          //@ts-ignore
          function() {
            return t(T) && t(T).apply(void 0, arguments);
          },
          ["esc"]
        ))
      }, [x("div", Te, [x("div", ke, [b(Ce, {
        src: t(fe)(),
        alt: "logo",
        width: "24",
        height: "24",
        class: "mr-2"
      }, null, 8, ["src"]), x("span", null, C(t(y)("1823")), 1)]), b(L, {
        icon: "",
        size: "x-small",
        variant: "text",
        onClick: t(T),
        class: "close-btn"
      }, {
        default: D(function() {
          return [b(De, {
            icon: "cha",
            size: "small"
          })];
        }),
        _: 1
      }, 8, ["onClick"])]), x("div", Re, [x("div", We, [b(t(le), {
        modelValue: t(m),
        "onUpdate:modelValue": l[0] || (l[0] = function(s) {
          return re(m) ? m.value = s : null;
        }),
        modelModifiers: {
          lazy: !0
        },
        ref_key: "findInputRef",
        ref: A
      }, {
        prepend: D(function() {
          return [x("label", Oe, C(t(y)("2167")) + ":", 1)];
        }),
        append: D(function() {
          return [b(L, {
            onClick: t(O),
            width: "80",
            height: "21",
            disabled: t(E)
          }, {
            default: D(function() {
              return [q(C(t(y)("2168")), 1)];
            }),
            _: 1
          }, 8, ["onClick", "disabled"])];
        }),
        _: 1
      }, 8, ["modelValue"])]), x("div", Ae, [b(t(le), {
        modelValue: t(v),
        "onUpdate:modelValue": l[1] || (l[1] = function(s) {
          return re(v) ? v.value = s : null;
        })
      }, {
        prepend: D(function() {
          return [x("label", Pe, C(t(y)("2169")) + ":", 1)];
        }),
        append: D(function() {
          return [b(L, {
            onClick: t($),
            width: "80",
            height: "21",
            disabled: t(I)
          }, {
            default: D(function() {
              return [q(C(t(y)("2170")), 1)];
            }),
            _: 1
          }, 8, ["onClick", "disabled"])];
        }),
        _: 1
      }, 8, ["modelValue"])]), x("div", Le, [x("div", Me, [b(M, {
        modelValue: t(r).matchCase,
        "onUpdate:modelValue": l[2] || (l[2] = function(s) {
          return t(r).matchCase = s;
        }),
        label: t(y)("2171")
      }, null, 8, ["modelValue", "label"])]), x("div", je, [b(M, {
        modelValue: t(r).matchWholeWord,
        "onUpdate:modelValue": l[3] || (l[3] = function(s) {
          return t(r).matchWholeWord = s;
        }),
        label: t(y)("2172")
      }, null, 8, ["modelValue", "label"])]), x("div", Ee, [b(M, {
        modelValue: t(r).useWildcards,
        "onUpdate:modelValue": l[4] || (l[4] = function(s) {
          return t(r).useWildcards = s;
        }),
        label: t(y)("2173")
      }, null, 8, ["modelValue", "label"])]), x("div", Ie, [b(M, {
        modelValue: t(r).matchDiacritics,
        "onUpdate:modelValue": l[5] || (l[5] = function(s) {
          return t(r).matchDiacritics = s;
        }),
        label: t(y)("2174")
      }, null, 8, ["modelValue", "label"])]), x("div", Ne, [b(M, {
        modelValue: t(r).matchHalfFullWidth,
        "onUpdate:modelValue": l[6] || (l[6] = function(s) {
          return t(r).matchHalfFullWidth = s;
        }),
        label: t(y)("2175")
      }, null, 8, ["modelValue", "label"])])]), x("div", He, [b(L, {
        onClick: t(N),
        width: "80",
        height: "21",
        disabled: t(E),
        class: "mb-2"
      }, {
        default: D(function() {
          return [q(C(t(y)("184")), 1)];
        }),
        _: 1
      }, 8, ["onClick", "disabled"]), b(L, {
        onClick: t(H),
        width: "80",
        height: "21",
        disabled: t(I)
      }, {
        default: D(function() {
          return [q(C(t(y)("2176")), 1)];
        }),
        _: 1
      }, 8, ["onClick", "disabled"]), t(d).total > 0 ? (z(), Z("div", Ue, C(t(d).current) + " / " + C(t(d).total), 1)) : t(m) && t(Q) ? (z(), Z("div", Be, C(t(y)("2177")), 1)) : ne("", !0)])])], 32)), [[i, {
        downEl: "#single_line_text_find_replace_dialog_header",
        x: V.value,
        y: X.value
      }]]) : ne("", !0)]);
    };
  }
}), ue = /* @__PURE__ */ ve(Ke, [["__scopeId", "data-v-1cf661dd"]]);
function oe(n, e) {
  var a = Object.keys(n);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(n);
    e && (o = o.filter(function(u) {
      return Object.getOwnPropertyDescriptor(n, u).enumerable;
    })), a.push.apply(a, o);
  }
  return a;
}
function ze(n) {
  for (var e = 1; e < arguments.length; e++) {
    var a = arguments[e] != null ? arguments[e] : {};
    e % 2 ? oe(Object(a), !0).forEach(function(o) {
      he(n, o, a[o]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(a)) : oe(Object(a)).forEach(function(o) {
      Object.defineProperty(n, o, Object.getOwnPropertyDescriptor(a, o));
    });
  }
  return n;
}
var f, w, j = !1;
function qe() {
  try {
    var n = pe();
    return n || null;
  } catch (e) {
    return console.error("获取应用实例失败:", e), null;
  }
}
var Ge = function(e) {
  try {
    if (j && f && f.component) {
      var a = f.component;
      a && a.exposed && a.exposed.showDialog(!0);
      return;
    }
    se();
    var o = qe();
    w || (w = document.createElement("div"), document.body.appendChild(w)), f = b(ue, ze({}, e)), o && o._context && (f.appContext = o._context), w && (G(f, w), j = !0, setTimeout(function() {
      if (f && f.component) {
        var u = f.component;
        u && u.exposed && u.exposed.showDialog(!0);
      }
    }, 0));
  } catch (u) {
    console.error("显示单行文本查找替换对话框时出错:", u);
  }
}, se = function() {
  try {
    if (f && f.component) {
      var e = f.component;
      e && e.exposed && e.exposed.showDialog(!1), e.props && typeof e.props.onClose == "function" && e.props.onClose(), setTimeout(function() {
        w && (G(null, w), j = !1);
      }, 300);
    }
  } catch (a) {
    if (console.error("隐藏单行文本查找替换对话框时出错:", a), w) {
      try {
        G(null, w);
      } catch (o) {
      }
      j = !1;
    }
  }
}, Qe = function() {
  try {
    w && (f && f.component && (f.component.exposed && f.component.exposed.showDialog(!1), f.component.props && typeof f.component.props.onClose == "function" && f.component.props.onClose()), G(null, w), w.parentNode && w.parentNode.removeChild(w), w = void 0, f = void 0, j = !1);
  } catch (e) {
    console.error("清理单行文本查找替换对话框资源时出错:", e);
  }
};
const tt = {
  SingleLineFindReplaceDialog: ue,
  useSingleLineFindReplace: ee,
  // 创建并返回hook实例
  create: function(e) {
    return ee(e);
  },
  // 显示和隐藏对话框
  show: Ge,
  hide: se,
  cleanup: Qe
};
export {
  ue as SingleLineFindReplaceDialog,
  Qe as cleanup,
  tt as default,
  se as hideSingleLineFindReplaceDialog,
  Ge as showSingleLineFindReplaceDialog,
  ee as useSingleLineFindReplace
};
