import { b2 as J, a6 as s, ae as K, a7 as G, x as C, $ as _ } from "./lib.js";
import { d as h, f as ee, g as j, m as A, o as E, w as l, l as d, a as u, G as t, Q as c, q as m, t as i, x as te } from "./vue.js";
import { D as M, C as P, ab as ne, v as le, b as ue, a as oe, j as y, i as k } from "./vuetify.js";
var ae = {
  class: "px-3"
}, re = {
  class: "d-flex"
}, ie = {
  class: ""
};
const ve = /* @__PURE__ */ h({
  __name: "index",
  setup: function(de) {
    var a = J(), N = a.isShow, X = a.showDialog, O = a.insertBlock, I = a.list, r = a.currentItem, R = a.openFile, f = a.isGetInsertionPoint, U = a.insertionPoint, p = a.isGetProportion, g = a.proportion, V = a.isUniformProportion, B = a.isGetRotation, w = a.rotation, x = a.isDecomposition, S = a.isAutoComputeOrigin, D = a.isBlockLibrary, $ = a.isBlockLibraryDecomposition, z = a.isBlockLibraryAutoComputeOrigin, L = a.isExtractBlock, F = ee(), Y = [{
      name: "确定",
      fun: O,
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        return X(!1);
      }
    }], v = !1, Z = {
      n: function() {
        var e;
        if (!v) {
          var n = (e = F.value) === null || e === void 0 ? void 0 : e.$el, b = n.getElementsByTagName("input")[0];
          b == null || b.focus({
            preventScroll: !0
          });
        }
      },
      b: function() {
        v || R();
      },
      s: function() {
        v || (f.value = !f.value);
      },
      e: function() {
        v || (p.value = !p.value);
      },
      c: function() {
        v || (B.value = !B.value);
      },
      u: function() {
        v || (V.value = !V.value);
      },
      d: function() {
        v || (x.value = !x.value);
      },
      enter: function() {
        O();
      }
    }, q = j(function() {
      var o;
      if (!((o = r.value) !== null && o !== void 0 && o.filePath)) return "";
      var e = new URL(r.value.filePath), n = e.pathname, b = n.split("/").pop();
      return b;
    }), T = function(e) {
      v = e;
    }, Q = j(function() {
      return I.value.map(function(o) {
        return o.name;
      });
    }), W = function(e) {
      var n = Q.value.indexOf(e.name);
      n !== -1 && (r.value = I.value[n]);
    }, H = function(e) {
      if (r.value && r.value.filePath) {
        r.value.name = e;
        return;
      }
    };
    return function(o, e) {
      return E(), A(_, {
        title: o.t("1993"),
        modelValue: t(N),
        "onUpdate:modelValue": e[15] || (e[15] = function(n) {
          return c(N) ? N.value = n : null;
        }),
        "max-width": "470",
        footerBtnList: Y,
        keys: Z
      }, {
        default: l(function() {
          return [d("div", ae, [u(M, null, {
            default: l(function() {
              return [u(P, {
                class: "mt-1"
              }, {
                default: l(function() {
                  return [d("div", re, [t(D) || t(r) && !t(r).filePath ? (E(), A(t(ne), {
                    key: 0,
                    class: "mt-1",
                    ref_key: "autocomplete",
                    ref: F,
                    "onUpdate:focused": T,
                    items: t(I),
                    "item-title": "name",
                    "return-object": "",
                    modelValue: t(r),
                    "onUpdate:modelValue": e[0] || (e[0] = function(n) {
                      return c(r) ? r.value = n : null;
                    })
                  }, {
                    prepend: l(function() {
                      return [u(s, {
                        class: "",
                        "key-name": "N"
                      }, {
                        default: l(function() {
                          return [m(i(o.t("1923")), 1)];
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  }, 8, ["items", "modelValue"])) : (E(), A(le, {
                    key: 1,
                    class: "mt-1",
                    ref_key: "autocomplete",
                    ref: F,
                    "onUpdate:focused": T,
                    items: t(I),
                    "item-title": "name",
                    "return-object": "",
                    "model-value": t(r),
                    "onUpdate:search": H,
                    "onUpdate:modelValue": W
                  }, {
                    prepend: l(function() {
                      return [u(s, {
                        class: "",
                        "key-name": "N"
                      }, {
                        default: l(function() {
                          return [m(i(o.t("1923")), 1)];
                        }),
                        _: 1
                      })];
                    }),
                    _: 1
                  }, 8, ["items", "model-value"])), u(K, {
                    onClick: t(R),
                    class: "ml-1"
                  }, {
                    default: l(function() {
                      return [u(s, {
                        "key-name": "B"
                      }, {
                        default: l(function() {
                          return [m(i(o.t("1924")), 1)];
                        }),
                        _: 1
                      }), u(ue, {
                        icon: "class:iconfont more"
                      })];
                    }),
                    _: 1
                  }, 8, ["onClick"])]), u(oe, {
                    text: t(r) && t(r).filePath || o.t("1994")
                  }, {
                    activator: l(function(n) {
                      var b = n.props;
                      return [d("p", te({
                        class: "mt-1 text-truncate"
                      }, b), i(o.t("1994")) + ": " + i(q.value), 17)];
                    }),
                    _: 1
                  }, 8, ["text"])];
                }),
                _: 1
              }), u(P, {
                cols: 3,
                class: "h-100"
              })];
            }),
            _: 1
          }), u(M, {
            "align-stretch": ""
          }, {
            default: l(function() {
              return [u(P, {
                cols: "4",
                "align-self": "stretch"
              }, {
                default: l(function() {
                  return [u(G, {
                    title: o.t("209"),
                    class: "h-100"
                  }, {
                    default: l(function() {
                      return [u(y, {
                        class: "",
                        modelValue: t(f),
                        "onUpdate:modelValue": e[1] || (e[1] = function(n) {
                          return c(f) ? f.value = n : null;
                        })
                      }, {
                        label: l(function() {
                          return [u(s, {
                            "key-name": "S"
                          }, {
                            default: l(function() {
                              return [m(i(o.t("1927")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        modelValue: t(U).x,
                        "onUpdate:modelValue": e[2] || (e[2] = function(n) {
                          return t(U).x = n;
                        }),
                        disabled: t(f)
                      }, {
                        prepend: l(function() {
                          return C(e[16] || (e[16] = [d("span", {
                            class: ""
                          }, " X:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        modelValue: t(U).y,
                        "onUpdate:modelValue": e[3] || (e[3] = function(n) {
                          return t(U).y = n;
                        }),
                        disabled: t(f)
                      }, {
                        prepend: l(function() {
                          return C(e[17] || (e[17] = [d("span", {
                            class: ""
                          }, " Y:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        modelValue: t(U).z,
                        "onUpdate:modelValue": e[4] || (e[4] = function(n) {
                          return t(U).z = n;
                        }),
                        disabled: t(f)
                      }, {
                        prepend: l(function() {
                          return C(e[18] || (e[18] = [d("span", {
                            class: ""
                          }, " Z:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              }), u(P, {
                cols: "4",
                "align-self": "stretch"
              }, {
                default: l(function() {
                  return [u(G, {
                    title: o.t("1686"),
                    class: "h-100"
                  }, {
                    default: l(function() {
                      return [u(y, {
                        class: "",
                        modelValue: t(p),
                        "onUpdate:modelValue": e[5] || (e[5] = function(n) {
                          return c(p) ? p.value = n : null;
                        })
                      }, {
                        label: l(function() {
                          return [u(s, {
                            "key-name": "E"
                          }, {
                            default: l(function() {
                              return [m(i(o.t("1927")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        step: "0.001",
                        modelValue: t(g).x,
                        "onUpdate:modelValue": e[6] || (e[6] = function(n) {
                          return t(g).x = n;
                        }),
                        disabled: t(p)
                      }, {
                        prepend: l(function() {
                          return C(e[19] || (e[19] = [d("span", {
                            class: ""
                          }, " X:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        modelValue: t(g).y,
                        "onUpdate:modelValue": e[7] || (e[7] = function(n) {
                          return t(g).y = n;
                        }),
                        step: "0.001",
                        disabled: t(p) || t(V)
                      }, {
                        prepend: l(function() {
                          return C(e[20] || (e[20] = [d("span", {
                            class: ""
                          }, " Y:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        modelValue: t(g).z,
                        "onUpdate:modelValue": e[8] || (e[8] = function(n) {
                          return t(g).z = n;
                        }),
                        step: "0.001",
                        disabled: t(p) || t(V)
                      }, {
                        prepend: l(function() {
                          return C(e[21] || (e[21] = [d("span", {
                            class: ""
                          }, " Z:", -1)]));
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"]), u(y, {
                        class: "ml-4 mt-1",
                        modelValue: t(V),
                        "onUpdate:modelValue": e[9] || (e[9] = function(n) {
                          return c(V) ? V.value = n : null;
                        })
                      }, {
                        label: l(function() {
                          return [u(s, {
                            "key-name": "U"
                          }, {
                            default: l(function() {
                              return [m(i(o.t("1995")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              }), u(P, {
                cols: "4",
                "align-self": "stretch"
              }, {
                default: l(function() {
                  return [u(G, {
                    title: o.t("176"),
                    class: "h-100"
                  }, {
                    default: l(function() {
                      return [u(y, {
                        class: "",
                        modelValue: t(B),
                        "onUpdate:modelValue": e[10] || (e[10] = function(n) {
                          return c(B) ? B.value = n : null;
                        })
                      }, {
                        label: l(function() {
                          return [u(s, {
                            "key-name": "C"
                          }, {
                            default: l(function() {
                              return [m(i(o.t("1927")), 1)];
                            }),
                            _: 1
                          })];
                        }),
                        _: 1
                      }, 8, ["modelValue"]), u(k, {
                        class: "mt-1",
                        type: "number",
                        modelValue: t(w),
                        "onUpdate:modelValue": e[11] || (e[11] = function(n) {
                          return c(w) ? w.value = n : null;
                        }),
                        disabled: t(B)
                      }, {
                        prepend: l(function() {
                          return [d("span", ie, i(o.t("169")) + ":", 1)];
                        }),
                        _: 1
                      }, 8, ["modelValue", "disabled"])];
                    }),
                    _: 1
                  }, 8, ["title"])];
                }),
                _: 1
              })];
            }),
            _: 1
          }), u(y, {
            class: "mt-2",
            "model-value": t(D) ? t($) : t(x),
            "onUpdate:modelValue": e[12] || (e[12] = function(n) {
              t(D) ? $.value = !!n : x.value = !!n;
            })
          }, {
            label: l(function() {
              return [u(s, {
                "key-name": "D"
              }, {
                default: l(function() {
                  return [m(i(o.t("216")), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["model-value"]), u(y, {
            class: "mt-2",
            modelValue: t(L),
            "onUpdate:modelValue": e[13] || (e[13] = function(n) {
              return c(L) ? L.value = n : null;
            })
          }, {
            label: l(function() {
              return [u(s, {
                "key-name": "D"
              }, {
                default: l(function() {
                  return [m(i(o.t("1997")), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["modelValue"]), u(y, {
            class: "mt-2",
            "model-value": t(D) ? t(z) : t(S),
            "onUpdate:modelValue": e[14] || (e[14] = function(n) {
              t(D) ? z.value = !!n : S.value = !!n;
            })
          }, {
            label: l(function() {
              return [u(s, {
                "key-name": "D"
              }, {
                default: l(function() {
                  return [m(i(o.t("1999")), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["model-value"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  ve as default
};
