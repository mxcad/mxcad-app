import { _ as C, a as w, t as L, h as W, d as Y, x as J } from "./lib.js";
import { q as F, e as T, i as I, ac as $, F as j, f as G, p as O } from "./mxcad.js";
function E(a, n) {
  var e = typeof Symbol != "undefined" && a[Symbol.iterator] || a["@@iterator"];
  if (!e) {
    if (Array.isArray(a) || (e = K(a)) || n) {
      e && (a = e);
      var t = 0, l = function() {
      };
      return { s: l, n: function() {
        return t >= a.length ? { done: !0 } : { done: !1, value: a[t++] };
      }, e: function(s) {
        throw s;
      }, f: l };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  var y, f = !0, u = !1;
  return { s: function() {
    e = e.call(a);
  }, n: function() {
    var s = e.next();
    return f = s.done, s;
  }, e: function(s) {
    u = !0, y = s;
  }, f: function() {
    try {
      f || e.return == null || e.return();
    } finally {
      if (u) throw y;
    }
  } };
}
function K(a, n) {
  if (a) {
    if (typeof a == "string") return z(a, n);
    var e = {}.toString.call(a).slice(8, -1);
    return e === "Object" && a.constructor && (e = a.constructor.name), e === "Map" || e === "Set" ? Array.from(a) : e === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? z(a, n) : void 0;
  }
}
function z(a, n) {
  (n == null || n > a.length) && (n = a.length);
  for (var e = 0, t = Array(n); e < n; e++) t[e] = a[e];
  return t;
}
function Q(a) {
  return J(a).sort(function(n, e) {
    var t = (n.maxPt.x - n.minPt.x) * (n.maxPt.y - n.minPt.y), l = (e.maxPt.x - e.minPt.x) * (e.maxPt.y - e.minPt.y);
    return l - t;
  });
}
function U(a) {
  var n = Q(a), e = /* @__PURE__ */ new Map(), t = E(n), l;
  try {
    for (t.s(); !(l = t.n()).done; ) {
      var y = l.value, f = 0, u = E(e.entries()), i;
      try {
        for (u.s(); !(i = u.n()).done; ) {
          var s = Y(i.value, 2), o = s[0], b = s[1];
          y.minPt.x >= o.minPt.x && y.minPt.y >= o.minPt.y && y.maxPt.x <= o.maxPt.x && y.maxPt.y <= o.maxPt.y && (f = Math.max(f, b + 1));
        }
      } catch (g) {
        u.e(g);
      } finally {
        u.f();
      }
      e.set(y, f);
    }
  } catch (g) {
    t.e(g);
  } finally {
    t.f();
  }
  return e;
}
function q(a) {
  if (a.length <= 1) return a;
  var n = [], e = E(a), t;
  try {
    for (e.s(); !(t = e.n()).done; ) {
      var l = t.value, y = !1, f = E(a), u;
      try {
        for (f.s(); !(u = f.n()).done; ) {
          var i = u.value;
          if (i !== l && l.minPt.x >= i.minPt.x && l.minPt.y >= i.minPt.y && l.maxPt.x <= i.maxPt.x && l.maxPt.y <= i.maxPt.y) {
            y = !0;
            break;
          }
        }
      } catch (s) {
        f.e(s);
      } finally {
        f.f();
      }
      y || n.push(l);
    }
  } catch (s) {
    e.e(s);
  } finally {
    e.f();
  }
  return n;
}
var X = /* @__PURE__ */ function() {
  var a = C(/* @__PURE__ */ w.mark(function n(e) {
    var t, l, y, f, u, i, s, o, b, g, A, R, M, P, S, B, D, p, d;
    return w.wrap(function(r) {
      for (; ; ) switch (r.prev = r.next) {
        case 0:
          if (t = e || {}, l = t.blockName, y = t.isSpecifiedRange, f = y === void 0 ? !1 : y, u = t.layerName, i = t.targetLevel, s = i === void 0 ? 0 : i, o = [], b = l, b) {
            r.next = 5;
            break;
          }
          return r.next = 1, G.userSelect(L("3603"));
        case 1:
          if (g = r.sent, g.length !== 0) {
            r.next = 2;
            break;
          }
          return r.abrupt("return", o);
        case 2:
          if (A = g[0].getMcDbEntity(), A instanceof T) {
            r.next = 3;
            break;
          }
          return W().error(L("3604")), r.abrupt("return", o);
        case 3:
          if (R = A, M = R.blockTableRecordId.getMcDbBlockTableRecord(), M) {
            r.next = 4;
            break;
          }
          return r.abrupt("return", o);
        case 4:
          b = M.name;
        case 5:
          if (P = new I(), S = new j(), S.AddMcDbEntityTypes("INSERT"), !f) {
            r.next = 7;
            break;
          }
          return r.next = 6, P.userSelect(L("2322"), S);
        case 6:
          r.next = 8;
          break;
        case 7:
          P.allSelect(S);
        case 8:
          return P.forEach(function(c) {
            var v = c.getMcDbEntity();
            if (v instanceof T) {
              var m = v, x = m.blockTableRecordId.getMcDbBlockTableRecord();
              if (u && m.layer !== u) return;
              if (x && x.name === b) {
                var N = m.getBoundingBox(), h = N.minPt, k = N.maxPt, H = new O(Math.min(h.x, k.x), Math.min(h.y, k.y), Math.min(h.z, k.z)), V = new O(Math.max(h.x, k.x), Math.max(h.y, k.y), Math.max(h.z, k.z));
                o.push({
                  minPt: H,
                  maxPt: V
                });
              }
            }
          }), B = U(o), D = o.filter(function(c) {
            return B.get(c) === s;
          }), p = q(D), d = p.filter(function(c) {
            var v = c.minPt, m = c.maxPt, x = new I();
            return x.imp.userSelect(v.x, v.y, m.x, m.y, $(), !1), x.count() > 0;
          }), r.abrupt("return", d);
        case 9:
        case "end":
          return r.stop();
      }
    }, n);
  }));
  return function(e) {
    return a.apply(this, arguments);
  };
}(), Z = /* @__PURE__ */ function() {
  var a = C(/* @__PURE__ */ w.mark(function n(e) {
    var t, l, y, f, u, i, s, o, b, g, A, R, M, P, S, B, D;
    return w.wrap(function(p) {
      for (; ; ) switch (p.prev = p.next) {
        case 0:
          if (t = e || {}, l = t.isSpecifiedRange, y = l === void 0 ? !0 : l, f = t.layerName, u = t.targetLevel, i = u === void 0 ? 0 : u, s = [], !y) {
            p.next = 2;
            break;
          }
          return p.next = 1, G.userSelect(L("3754"));
        case 1:
          s = p.sent, p.next = 3;
          break;
        case 2:
          o = new I(), b = new j(), b.AddMcDbEntityTypes("LWPOLYLINE"), o.allSelect(b), s = o.getIds();
        case 3:
          return g = [], A = function(r, c, v) {
            return (c.x - r.x) * (c.x - v.x) + (c.y - r.y) * (c.y - v.y) == 0;
          }, R = function(r, c, v, m) {
            return A(r, c, v);
          }, M = function(r) {
            if (r instanceof F) {
              if (f && r.layer !== f)
                return;
              var c = r.numVerts();
              if (c === 0 || (r.isClosed ? c > 4 : c > 5)) return;
              for (var v = 0; v < c; v++) {
                var m = r.getBulgeAt(v);
                if (m > 1e-3) return;
              }
              var x = r.getPointAt(0).val;
              if (R(x, r.getPointAt(1).val, r.getPointAt(2).val, r.isClosed ? x : r.getPointAt(3).val)) {
                var N = r.getBoundingBox(), h = N.minPt, k = N.maxPt;
                g.push({
                  minPt: h,
                  maxPt: k
                });
              }
            }
          }, P = function(r) {
            var c = r.blockTableRecordId.getMcDbBlockTableRecord();
            c && c.getAllEntityId().forEach(function(v) {
              var m = v.getMcDbEntity();
              m && (m instanceof F && M(m), m instanceof T && P(m));
            });
          }, s.forEach(function(d) {
            var r = d.getMcDbEntity();
            if (r instanceof F)
              M(r);
            else if (r instanceof T) {
              if (f && r.layer !== f)
                return;
              P(r);
            }
          }), S = U(g), B = g.filter(function(d) {
            return S.get(d) === i;
          }), D = q(B), p.abrupt("return", D.filter(function(d) {
            var r = d.minPt, c = d.maxPt, v = new I();
            return v.imp.userSelect(r.x, r.y, c.x, c.y, $(), !1), v.count() > 0;
          }));
        case 4:
        case "end":
          return p.stop();
      }
    }, n);
  }));
  return function(e) {
    return a.apply(this, arguments);
  };
}(), re = /* @__PURE__ */ function() {
  var a = C(/* @__PURE__ */ w.mark(function n(e) {
    var t, l, y, f, u, i, s;
    return w.wrap(function(o) {
      for (; ; ) switch (o.prev = o.next) {
        case 0:
          if (t = e || {}, l = t.method, y = l === void 0 ? "polyline" : l, f = t.blockName, u = t.isSpecifiedRange, i = t.layerName, s = t.targetLevel, y !== "block") {
            o.next = 1;
            break;
          }
          return o.abrupt("return", X({
            blockName: f,
            isSpecifiedRange: u,
            layerName: i,
            targetLevel: s
          }));
        case 1:
          return o.abrupt("return", Z({
            isSpecifiedRange: u,
            layerName: i,
            targetLevel: s
          }));
        case 2:
        case "end":
          return o.stop();
      }
    }, n);
  }));
  return function(e) {
    return a.apply(this, arguments);
  };
}();
export {
  re as i
};
