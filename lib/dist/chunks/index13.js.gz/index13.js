import { d, m as p, o as c, w as g, l as V, a as _, Q as u, G as o } from "./vue.js";
import { aZ as v, an as w, a_ as s, a$ as t, $ as x, b0 as r } from "./lib.js";
var D = {
  class: "px-3"
};
const k = /* @__PURE__ */ d({
  __name: "index",
  setup: function(b) {
    var i = v(t), l = i.items, f = i.define, m = [{
      name: "确定",
      fun: function() {
        f.value(), r(!1);
      },
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        return r(!1);
      }
    }];
    return function(a, e) {
      return c(), p(x, {
        title: a.t("1985"),
        modelValue: o(t),
        "onUpdate:modelValue": e[1] || (e[1] = function(n) {
          return u(t) ? t.value = n : null;
        }),
        footerBtnList: m,
        "max-width": "600"
      }, {
        default: g(function() {
          return [V("div", D, [_(w, {
            items: o(l),
            modelValue: o(s),
            "onUpdate:modelValue": e[0] || (e[0] = function(n) {
              return u(s) ? s.value = n : null;
            }),
            height: 312,
            tabsProps: {
              grow: !0
            }
          }, null, 8, ["items", "modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  k as default
};
