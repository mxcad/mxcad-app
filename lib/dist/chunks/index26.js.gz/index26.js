import { bL as v, bM as V, bN as u, a6 as l, bO as r, $ as b, bP as k, bQ as D, T as S } from "./lib.js";
import { d as w, i as z, m as P, o as f, w as t, l as c, a as o, c as h, F as B, b as C, G as s, p as E, q as d, t as m, Q as _ } from "./vue.js";
import { b as M, i as R, Q as I, S as x } from "./vuetify.js";
var L = {
  class: "px-3"
}, N = {
  class: "d-flex flex-wrap justify-center"
}, F = ["onClick"], O = {
  class: "d-flex flex-column"
};
const Q = /* @__PURE__ */ w({
  __name: "index",
  setup: function(U) {
    var i = v.isShow, p = v.showDialog, y = [{
      name: "确定",
      fun: function() {
        D(), p(!1);
      },
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        p(!1);
      }
    }], g = ["xiaodian", "", "shizi", "cha", "daunshuxian", "yuanshangyidian", "yuan", "yuanzhonshizi", "yuanzhoncha", "yuanzhonbanshuxian", "fangkuangdain", "fangkuang", "shizikuang1", "fangkuangchaocha", "fangkuangyishangshuxian", "a-1", "a-2", "a-3", "a-4", "a-5"].map(function(a, e) {
      return {
        icon: a,
        value: k[e]
      };
    });
    return z(i, function(a) {
      a && V();
    }), function(a, e) {
      return f(), P(b, {
        title: a.t("222"),
        "max-width": "240",
        modelValue: s(i),
        "onUpdate:modelValue": e[2] || (e[2] = function(n) {
          return _(i) ? i.value = n : null;
        }),
        footerBtnList: y
      }, {
        default: t(function() {
          return [c("div", L, [c("div", N, [(f(!0), h(B, null, C(s(g), function(n) {
            return f(), h("div", {
              class: E(["mx-1 mt-2 box-point-style", n.value === s(u).PDMODE ? "active" : ""]),
              onClick: function(G) {
                return s(u).PDMODE = n.value;
              }
            }, [o(M, {
              size: "20px",
              icon: "class:iconfont " + n.icon
            }, null, 8, ["icon"])], 10, F);
          }), 256))]), o(R, {
            class: "mt-2 ml-1 w-75",
            type: "number",
            modelValue: s(u).PDSIZE,
            "onUpdate:modelValue": e[0] || (e[0] = function(n) {
              return s(u).PDSIZE = n;
            })
          }, {
            prepend: t(function() {
              return [o(l, {
                class: "",
                "key-name": "S"
              }, {
                default: t(function() {
                  return [d(m(a.t("2049")), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["modelValue"]), o(I, {
            column: "",
            class: "mt-2",
            modelValue: s(r),
            "onUpdate:modelValue": e[1] || (e[1] = function(n) {
              return _(r) ? r.value = n : null;
            })
          }, {
            default: t(function() {
              return [c("div", O, [o(x, {
                value: !0,
                class: "mt-1"
              }, {
                label: t(function() {
                  return [o(l, {
                    class: "",
                    "key-name": "R"
                  }, {
                    default: t(function() {
                      return [d(m(a.t("2050")), 1)];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }), o(x, {
                value: !1,
                class: "mt-1"
              }, {
                label: t(function() {
                  return [o(l, {
                    class: "",
                    "key-name": "A"
                  }, {
                    default: t(function() {
                      return [d(m(a.t("2051")), 1)];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              })])];
            }),
            _: 1
          }, 8, ["modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), A = /* @__PURE__ */ S(Q, [["__scopeId", "data-v-0cb1d074"]]);
export {
  A as default
};
