import { b1 as i, $ as O, l as b } from "./lib.js";
import { d as y, f as w, m as j, o as D, w as s, l as P, a as f, q as p, t as d, Q as h, G as C } from "./vue.js";
import { i as m } from "./vuetify.js";
function c(r, o) {
  var e = Object.keys(r);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(r);
    o && (t = t.filter(function(n) {
      return Object.getOwnPropertyDescriptor(r, n).enumerable;
    })), e.push.apply(e, t);
  }
  return e;
}
function S(r) {
  for (var o = 1; o < arguments.length; o++) {
    var e = arguments[o] != null ? arguments[o] : {};
    o % 2 ? c(Object(e), !0).forEach(function(t) {
      b(r, t, e[t]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(e)) : c(Object(e)).forEach(function(t) {
      Object.defineProperty(r, t, Object.getOwnPropertyDescriptor(e, t));
    });
  }
  return r;
}
var B = {
  class: "pa-4"
};
const k = /* @__PURE__ */ y({
  __name: "index",
  setup: function(o) {
    var e = i.isShow, t = i.showDialog, n = w({
      tag: "",
      prompt: "",
      defaultValue: ""
    });
    i.onReveal(function(a) {
      a && (n.value = S({}, a));
    });
    var v = function() {
      i.confirm(n.value), e.value = !1;
    }, V = function() {
      t(!1);
    }, g = [{
      name: "取消",
      fun: V
    }, {
      name: "确认",
      primary: !0,
      fun: v
    }];
    return function(a, l) {
      return D(), j(O, {
        title: a.t("4462"),
        footerBtnList: g,
        modelValue: C(e),
        "onUpdate:modelValue": l[3] || (l[3] = function(u) {
          return h(e) ? e.value = u : null;
        }),
        "max-width": 400
      }, {
        default: s(function() {
          return [P("div", B, [f(m, {
            modelValue: n.value.tag,
            "onUpdate:modelValue": l[0] || (l[0] = function(u) {
              return n.value.tag = u;
            }),
            class: "mt-4"
          }, {
            prepend: s(function() {
              return [p(d(a.t("4463")) + ": ", 1)];
            }),
            _: 1
          }, 8, ["modelValue"]), f(m, {
            modelValue: n.value.prompt,
            "onUpdate:modelValue": l[1] || (l[1] = function(u) {
              return n.value.prompt = u;
            }),
            class: "mt-4"
          }, {
            prepend: s(function() {
              return [p(d(a.t("1909")) + ": ", 1)];
            }),
            _: 1
          }, 8, ["modelValue"]), f(m, {
            modelValue: n.value.defaultValue,
            "onUpdate:modelValue": l[2] || (l[2] = function(u) {
              return n.value.defaultValue = u;
            }),
            class: "mt-4"
          }, {
            prepend: s(function() {
              return [p(d(a.t("4464")) + ": ", 1)];
            }),
            _: 1
          }, 8, ["modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  k as default
};
