import { d as tn, g as pe, V as en, G as V, f as nn, h as on, D as rn, H as ue, i as an, j as ln, k as Ne, u as sn, Q as Gt } from "./vue.js";
var un = Object.defineProperty, Ft = Object.getOwnPropertySymbols, Pe = Object.prototype.hasOwnProperty, ke = Object.prototype.propertyIsEnumerable, ge = (t, n, e) => n in t ? un(t, n, { enumerable: !0, configurable: !0, writable: !0, value: e }) : t[n] = e, vt = (t, n) => {
  for (var e in n || (n = {}))
    Pe.call(n, e) && ge(t, e, n[e]);
  if (Ft)
    for (var e of Ft(n))
      ke.call(n, e) && ge(t, e, n[e]);
  return t;
}, Re = (t, n) => {
  var e = {};
  for (var o in t)
    Pe.call(t, o) && n.indexOf(o) < 0 && (e[o] = t[o]);
  if (t != null && Ft)
    for (var o of Ft(t))
      n.indexOf(o) < 0 && ke.call(t, o) && (e[o] = t[o]);
  return e;
};
const Ye = "[vue-draggable-plus]: ";
function cn(t) {
  console.warn(Ye + t);
}
function dn(t) {
  console.error(Ye + t);
}
function ve(t, n, e) {
  return e >= 0 && e < t.length && t.splice(e, 0, t.splice(n, 1)[0]), t;
}
function fn(t) {
  return t.replace(/-(\w)/g, (n, e) => e ? e.toUpperCase() : "");
}
function hn(t) {
  return Object.keys(t).reduce((n, e) => (typeof t[e] != "undefined" && (n[fn(e)] = t[e]), n), {});
}
function me(t, n) {
  return Array.isArray(t) && t.splice(n, 1), t;
}
function be(t, n, e) {
  return Array.isArray(t) && t.splice(n, 0, e), t;
}
function pn(t) {
  return typeof t == "undefined";
}
function gn(t) {
  return typeof t == "string";
}
function ye(t, n, e) {
  const o = t.children[e];
  t.insertBefore(n, o);
}
function qt(t) {
  t.parentNode && t.parentNode.removeChild(t);
}
function vn(t, n = document) {
  var e;
  let o = null;
  return typeof (n == null ? void 0 : n.querySelector) == "function" ? o = (e = n == null ? void 0 : n.querySelector) == null ? void 0 : e.call(n, t) : o = document.querySelector(t), o || cn(`Element not found: ${t}`), o;
}
function mn(t, n, e = null) {
  return function(...o) {
    return t.apply(e, o), n.apply(e, o);
  };
}
function bn(t, n) {
  const e = vt({}, t);
  return Object.keys(n).forEach((o) => {
    e[o] ? e[o] = mn(t[o], n[o]) : e[o] = n[o];
  }), e;
}
function yn(t) {
  return t instanceof HTMLElement;
}
function we(t, n) {
  Object.keys(t).forEach((e) => {
    n(e, t[e]);
  });
}
function wn(t) {
  return t.charCodeAt(0) === 111 && t.charCodeAt(1) === 110 && // uppercase letter
  (t.charCodeAt(2) > 122 || t.charCodeAt(2) < 97);
}
const Sn = Object.assign;
/**!
 * Sortable 1.15.2
 * @author	RubaXa   <trash@rubaxa.org>
 * @author	owenm    <owen23355@gmail.com>
 * @license MIT
 */
function Se(t, n) {
  var e = Object.keys(t);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(t);
    n && (o = o.filter(function(r) {
      return Object.getOwnPropertyDescriptor(t, r).enumerable;
    })), e.push.apply(e, o);
  }
  return e;
}
function tt(t) {
  for (var n = 1; n < arguments.length; n++) {
    var e = arguments[n] != null ? arguments[n] : {};
    n % 2 ? Se(Object(e), !0).forEach(function(o) {
      Dn(t, o, e[o]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : Se(Object(e)).forEach(function(o) {
      Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(e, o));
    });
  }
  return t;
}
function kt(t) {
  "@babel/helpers - typeof";
  return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? kt = function(n) {
    return typeof n;
  } : kt = function(n) {
    return n && typeof Symbol == "function" && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
  }, kt(t);
}
function Dn(t, n, e) {
  return n in t ? Object.defineProperty(t, n, {
    value: e,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : t[n] = e, t;
}
function rt() {
  return rt = Object.assign || function(t) {
    for (var n = 1; n < arguments.length; n++) {
      var e = arguments[n];
      for (var o in e)
        Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
    }
    return t;
  }, rt.apply(this, arguments);
}
function En(t, n) {
  if (t == null)
    return {};
  var e = {}, o = Object.keys(t), r, i;
  for (i = 0; i < o.length; i++)
    r = o[i], !(n.indexOf(r) >= 0) && (e[r] = t[r]);
  return e;
}
function _n(t, n) {
  if (t == null)
    return {};
  var e = En(t, n), o, r;
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(t);
    for (r = 0; r < i.length; r++)
      o = i[r], !(n.indexOf(o) >= 0) && Object.prototype.propertyIsEnumerable.call(t, o) && (e[o] = t[o]);
  }
  return e;
}
var Cn = "1.15.2";
function ot(t) {
  if (typeof window != "undefined" && window.navigator)
    return !!/* @__PURE__ */ navigator.userAgent.match(t);
}
var it = ot(/(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i), Ot = ot(/Edge/i), De = ot(/firefox/i), Et = ot(/safari/i) && !ot(/chrome/i) && !ot(/android/i), Xe = ot(/iP(ad|od|hone)/i), Be = ot(/chrome/i) && ot(/android/i), Fe = {
  capture: !1,
  passive: !1
};
function S(t, n, e) {
  t.addEventListener(n, e, !it && Fe);
}
function y(t, n, e) {
  t.removeEventListener(n, e, !it && Fe);
}
function jt(t, n) {
  if (n) {
    if (n[0] === ">" && (n = n.substring(1)), t)
      try {
        if (t.matches)
          return t.matches(n);
        if (t.msMatchesSelector)
          return t.msMatchesSelector(n);
        if (t.webkitMatchesSelector)
          return t.webkitMatchesSelector(n);
      } catch (e) {
        return !1;
      }
    return !1;
  }
}
function Tn(t) {
  return t.host && t !== document && t.host.nodeType ? t.host : t.parentNode;
}
function Z(t, n, e, o) {
  if (t) {
    e = e || document;
    do {
      if (n != null && (n[0] === ">" ? t.parentNode === e && jt(t, n) : jt(t, n)) || o && t === e)
        return t;
      if (t === e)
        break;
    } while (t = Tn(t));
  }
  return null;
}
var Ee = /\s+/g;
function U(t, n, e) {
  if (t && n)
    if (t.classList)
      t.classList[e ? "add" : "remove"](n);
    else {
      var o = (" " + t.className + " ").replace(Ee, " ").replace(" " + n + " ", " ");
      t.className = (o + (e ? " " + n : "")).replace(Ee, " ");
    }
}
function p(t, n, e) {
  var o = t && t.style;
  if (o) {
    if (e === void 0)
      return document.defaultView && document.defaultView.getComputedStyle ? e = document.defaultView.getComputedStyle(t, "") : t.currentStyle && (e = t.currentStyle), n === void 0 ? e : e[n];
    !(n in o) && n.indexOf("webkit") === -1 && (n = "-webkit-" + n), o[n] = e + (typeof e == "string" ? "" : "px");
  }
}
function bt(t, n) {
  var e = "";
  if (typeof t == "string")
    e = t;
  else
    do {
      var o = p(t, "transform");
      o && o !== "none" && (e = o + " " + e);
    } while (!n && (t = t.parentNode));
  var r = window.DOMMatrix || window.WebKitCSSMatrix || window.CSSMatrix || window.MSCSSMatrix;
  return r && new r(e);
}
function je(t, n, e) {
  if (t) {
    var o = t.getElementsByTagName(n), r = 0, i = o.length;
    if (e)
      for (; r < i; r++)
        e(o[r], r);
    return o;
  }
  return [];
}
function Q() {
  var t = document.scrollingElement;
  return t || document.documentElement;
}
function N(t, n, e, o, r) {
  if (!(!t.getBoundingClientRect && t !== window)) {
    var i, a, s, l, d, c, f;
    if (t !== window && t.parentNode && t !== Q() ? (i = t.getBoundingClientRect(), a = i.top, s = i.left, l = i.bottom, d = i.right, c = i.height, f = i.width) : (a = 0, s = 0, l = window.innerHeight, d = window.innerWidth, c = window.innerHeight, f = window.innerWidth), (n || e) && t !== window && (r = r || t.parentNode, !it))
      do
        if (r && r.getBoundingClientRect && (p(r, "transform") !== "none" || e && p(r, "position") !== "static")) {
          var D = r.getBoundingClientRect();
          a -= D.top + parseInt(p(r, "border-top-width")), s -= D.left + parseInt(p(r, "border-left-width")), l = a + i.height, d = s + i.width;
          break;
        }
      while (r = r.parentNode);
    if (o && t !== window) {
      var h = bt(r || t), _ = h && h.a, w = h && h.d;
      h && (a /= w, s /= _, f /= _, c /= w, l = a + c, d = s + f);
    }
    return {
      top: a,
      left: s,
      bottom: l,
      right: d,
      width: f,
      height: c
    };
  }
}
function _e(t, n, e) {
  for (var o = st(t, !0), r = N(t)[n]; o; ) {
    var i = N(o)[e], a = void 0;
    if (a = r >= i, !a)
      return o;
    if (o === Q())
      break;
    o = st(o, !1);
  }
  return !1;
}
function yt(t, n, e, o) {
  for (var r = 0, i = 0, a = t.children; i < a.length; ) {
    if (a[i].style.display !== "none" && a[i] !== g.ghost && (o || a[i] !== g.dragged) && Z(a[i], e.draggable, t, !1)) {
      if (r === n)
        return a[i];
      r++;
    }
    i++;
  }
  return null;
}
function ce(t, n) {
  for (var e = t.lastElementChild; e && (e === g.ghost || p(e, "display") === "none" || n && !jt(e, n)); )
    e = e.previousElementSibling;
  return e || null;
}
function q(t, n) {
  var e = 0;
  if (!t || !t.parentNode)
    return -1;
  for (; t = t.previousElementSibling; )
    t.nodeName.toUpperCase() !== "TEMPLATE" && t !== g.clone && (!n || jt(t, n)) && e++;
  return e;
}
function Ce(t) {
  var n = 0, e = 0, o = Q();
  if (t)
    do {
      var r = bt(t), i = r.a, a = r.d;
      n += t.scrollLeft * i, e += t.scrollTop * a;
    } while (t !== o && (t = t.parentNode));
  return [n, e];
}
function xn(t, n) {
  for (var e in t)
    if (t.hasOwnProperty(e)) {
      for (var o in n)
        if (n.hasOwnProperty(o) && n[o] === t[e][o])
          return Number(e);
    }
  return -1;
}
function st(t, n) {
  if (!t || !t.getBoundingClientRect)
    return Q();
  var e = t, o = !1;
  do
    if (e.clientWidth < e.scrollWidth || e.clientHeight < e.scrollHeight) {
      var r = p(e);
      if (e.clientWidth < e.scrollWidth && (r.overflowX == "auto" || r.overflowX == "scroll") || e.clientHeight < e.scrollHeight && (r.overflowY == "auto" || r.overflowY == "scroll")) {
        if (!e.getBoundingClientRect || e === document.body)
          return Q();
        if (o || n)
          return e;
        o = !0;
      }
    }
  while (e = e.parentNode);
  return Q();
}
function On(t, n) {
  if (t && n)
    for (var e in n)
      n.hasOwnProperty(e) && (t[e] = n[e]);
  return t;
}
function $t(t, n) {
  return Math.round(t.top) === Math.round(n.top) && Math.round(t.left) === Math.round(n.left) && Math.round(t.height) === Math.round(n.height) && Math.round(t.width) === Math.round(n.width);
}
var _t;
function He(t, n) {
  return function() {
    if (!_t) {
      var e = arguments, o = this;
      e.length === 1 ? t.call(o, e[0]) : t.apply(o, e), _t = setTimeout(function() {
        _t = void 0;
      }, n);
    }
  };
}
function An() {
  clearTimeout(_t), _t = void 0;
}
function We(t, n, e) {
  t.scrollLeft += n, t.scrollTop += e;
}
function Ve(t) {
  var n = window.Polymer, e = window.jQuery || window.Zepto;
  return n && n.dom ? n.dom(t).cloneNode(!0) : e ? e(t).clone(!0)[0] : t.cloneNode(!0);
}
function Ue(t, n, e) {
  var o = {};
  return Array.from(t.children).forEach(function(r) {
    var i, a, s, l;
    if (!(!Z(r, n.draggable, t, !1) || r.animated || r === e)) {
      var d = N(r);
      o.left = Math.min((i = o.left) !== null && i !== void 0 ? i : 1 / 0, d.left), o.top = Math.min((a = o.top) !== null && a !== void 0 ? a : 1 / 0, d.top), o.right = Math.max((s = o.right) !== null && s !== void 0 ? s : -1 / 0, d.right), o.bottom = Math.max((l = o.bottom) !== null && l !== void 0 ? l : -1 / 0, d.bottom);
    }
  }), o.width = o.right - o.left, o.height = o.bottom - o.top, o.x = o.left, o.y = o.top, o;
}
var z = "Sortable" + (/* @__PURE__ */ new Date()).getTime();
function In() {
  var t = [], n;
  return {
    captureAnimationState: function() {
      if (t = [], !!this.options.animation) {
        var e = [].slice.call(this.el.children);
        e.forEach(function(o) {
          if (!(p(o, "display") === "none" || o === g.ghost)) {
            t.push({
              target: o,
              rect: N(o)
            });
            var r = tt({}, t[t.length - 1].rect);
            if (o.thisAnimationDuration) {
              var i = bt(o, !0);
              i && (r.top -= i.f, r.left -= i.e);
            }
            o.fromRect = r;
          }
        });
      }
    },
    addAnimationState: function(e) {
      t.push(e);
    },
    removeAnimationState: function(e) {
      t.splice(xn(t, {
        target: e
      }), 1);
    },
    animateAll: function(e) {
      var o = this;
      if (!this.options.animation) {
        clearTimeout(n), typeof e == "function" && e();
        return;
      }
      var r = !1, i = 0;
      t.forEach(function(a) {
        var s = 0, l = a.target, d = l.fromRect, c = N(l), f = l.prevFromRect, D = l.prevToRect, h = a.rect, _ = bt(l, !0);
        _ && (c.top -= _.f, c.left -= _.e), l.toRect = c, l.thisAnimationDuration && $t(f, c) && !$t(d, c) && // Make sure animatingRect is on line between toRect & fromRect
        (h.top - c.top) / (h.left - c.left) === (d.top - c.top) / (d.left - c.left) && (s = Nn(h, f, D, o.options)), $t(c, d) || (l.prevFromRect = d, l.prevToRect = c, s || (s = o.options.animation), o.animate(l, h, c, s)), s && (r = !0, i = Math.max(i, s), clearTimeout(l.animationResetTimer), l.animationResetTimer = setTimeout(function() {
          l.animationTime = 0, l.prevFromRect = null, l.fromRect = null, l.prevToRect = null, l.thisAnimationDuration = null;
        }, s), l.thisAnimationDuration = s);
      }), clearTimeout(n), r ? n = setTimeout(function() {
        typeof e == "function" && e();
      }, i) : typeof e == "function" && e(), t = [];
    },
    animate: function(e, o, r, i) {
      if (i) {
        p(e, "transition", ""), p(e, "transform", "");
        var a = bt(this.el), s = a && a.a, l = a && a.d, d = (o.left - r.left) / (s || 1), c = (o.top - r.top) / (l || 1);
        e.animatingX = !!d, e.animatingY = !!c, p(e, "transform", "translate3d(" + d + "px," + c + "px,0)"), this.forRepaintDummy = Mn(e), p(e, "transition", "transform " + i + "ms" + (this.options.easing ? " " + this.options.easing : "")), p(e, "transform", "translate3d(0,0,0)"), typeof e.animated == "number" && clearTimeout(e.animated), e.animated = setTimeout(function() {
          p(e, "transition", ""), p(e, "transform", ""), e.animated = !1, e.animatingX = !1, e.animatingY = !1;
        }, i);
      }
    }
  };
}
function Mn(t) {
  return t.offsetWidth;
}
function Nn(t, n, e, o) {
  return Math.sqrt(Math.pow(n.top - t.top, 2) + Math.pow(n.left - t.left, 2)) / Math.sqrt(Math.pow(n.top - e.top, 2) + Math.pow(n.left - e.left, 2)) * o.animation;
}
var ht = [], Jt = {
  initializeByDefault: !0
}, At = {
  mount: function(t) {
    for (var n in Jt)
      Jt.hasOwnProperty(n) && !(n in t) && (t[n] = Jt[n]);
    ht.forEach(function(e) {
      if (e.pluginName === t.pluginName)
        throw "Sortable: Cannot mount plugin ".concat(t.pluginName, " more than once");
    }), ht.push(t);
  },
  pluginEvent: function(t, n, e) {
    var o = this;
    this.eventCanceled = !1, e.cancel = function() {
      o.eventCanceled = !0;
    };
    var r = t + "Global";
    ht.forEach(function(i) {
      n[i.pluginName] && (n[i.pluginName][r] && n[i.pluginName][r](tt({
        sortable: n
      }, e)), n.options[i.pluginName] && n[i.pluginName][t] && n[i.pluginName][t](tt({
        sortable: n
      }, e)));
    });
  },
  initializePlugins: function(t, n, e, o) {
    ht.forEach(function(a) {
      var s = a.pluginName;
      if (!(!t.options[s] && !a.initializeByDefault)) {
        var l = new a(t, n, t.options);
        l.sortable = t, l.options = t.options, t[s] = l, rt(e, l.defaults);
      }
    });
    for (var r in t.options)
      if (t.options.hasOwnProperty(r)) {
        var i = this.modifyOption(t, r, t.options[r]);
        typeof i != "undefined" && (t.options[r] = i);
      }
  },
  getEventProperties: function(t, n) {
    var e = {};
    return ht.forEach(function(o) {
      typeof o.eventProperties == "function" && rt(e, o.eventProperties.call(n[o.pluginName], t));
    }), e;
  },
  modifyOption: function(t, n, e) {
    var o;
    return ht.forEach(function(r) {
      t[r.pluginName] && r.optionListeners && typeof r.optionListeners[n] == "function" && (o = r.optionListeners[n].call(t[r.pluginName], e));
    }), o;
  }
};
function Pn(t) {
  var n = t.sortable, e = t.rootEl, o = t.name, r = t.targetEl, i = t.cloneEl, a = t.toEl, s = t.fromEl, l = t.oldIndex, d = t.newIndex, c = t.oldDraggableIndex, f = t.newDraggableIndex, D = t.originalEvent, h = t.putSortable, _ = t.extraEventProperties;
  if (n = n || e && e[z], !!n) {
    var w, W = n.options, A = "on" + o.charAt(0).toUpperCase() + o.substr(1);
    window.CustomEvent && !it && !Ot ? w = new CustomEvent(o, {
      bubbles: !0,
      cancelable: !0
    }) : (w = document.createEvent("Event"), w.initEvent(o, !0, !0)), w.to = a || e, w.from = s || e, w.item = r || e, w.clone = i, w.oldIndex = l, w.newIndex = d, w.oldDraggableIndex = c, w.newDraggableIndex = f, w.originalEvent = D, w.pullMode = h ? h.lastPutMode : void 0;
    var $ = tt(tt({}, _), At.getEventProperties(o, n));
    for (var P in $)
      w[P] = $[P];
    e && e.dispatchEvent(w), W[A] && W[A].call(n, w);
  }
}
var kn = ["evt"], H = function(t, n) {
  var e = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, o = e.evt, r = _n(e, kn);
  At.pluginEvent.bind(g)(t, n, tt({
    dragEl: u,
    parentEl: x,
    ghostEl: v,
    rootEl: C,
    nextEl: ft,
    lastDownEl: Rt,
    cloneEl: T,
    cloneHidden: lt,
    dragStarted: wt,
    putSortable: X,
    activeSortable: g.active,
    originalEvent: o,
    oldIndex: mt,
    oldDraggableIndex: Ct,
    newIndex: L,
    newDraggableIndex: at,
    hideGhostForTarget: qe,
    unhideGhostForTarget: $e,
    cloneNowHidden: function() {
      lt = !0;
    },
    cloneNowShown: function() {
      lt = !1;
    },
    dispatchSortableEvent: function(i) {
      F({
        sortable: n,
        name: i,
        originalEvent: o
      });
    }
  }, r));
};
function F(t) {
  Pn(tt({
    putSortable: X,
    cloneEl: T,
    targetEl: u,
    rootEl: C,
    oldIndex: mt,
    oldDraggableIndex: Ct,
    newIndex: L,
    newDraggableIndex: at
  }, t));
}
var u, x, v, C, ft, Rt, T, lt, mt, L, Ct, at, It, X, gt = !1, Ht = !1, Wt = [], ct, J, Zt, Kt, Te, xe, wt, pt, Tt, xt = !1, Mt = !1, Yt, B, Qt = [], re = !1, Vt = [], Lt = typeof document != "undefined", Nt = Xe, Oe = Ot || it ? "cssFloat" : "float", Rn = Lt && !Be && !Xe && "draggable" in document.createElement("div"), Le = function() {
  if (Lt) {
    if (it)
      return !1;
    var t = document.createElement("x");
    return t.style.cssText = "pointer-events:auto", t.style.pointerEvents === "auto";
  }
}(), ze = function(t, n) {
  var e = p(t), o = parseInt(e.width) - parseInt(e.paddingLeft) - parseInt(e.paddingRight) - parseInt(e.borderLeftWidth) - parseInt(e.borderRightWidth), r = yt(t, 0, n), i = yt(t, 1, n), a = r && p(r), s = i && p(i), l = a && parseInt(a.marginLeft) + parseInt(a.marginRight) + N(r).width, d = s && parseInt(s.marginLeft) + parseInt(s.marginRight) + N(i).width;
  if (e.display === "flex")
    return e.flexDirection === "column" || e.flexDirection === "column-reverse" ? "vertical" : "horizontal";
  if (e.display === "grid")
    return e.gridTemplateColumns.split(" ").length <= 1 ? "vertical" : "horizontal";
  if (r && a.float && a.float !== "none") {
    var c = a.float === "left" ? "left" : "right";
    return i && (s.clear === "both" || s.clear === c) ? "vertical" : "horizontal";
  }
  return r && (a.display === "block" || a.display === "flex" || a.display === "table" || a.display === "grid" || l >= o && e[Oe] === "none" || i && e[Oe] === "none" && l + d > o) ? "vertical" : "horizontal";
}, Yn = function(t, n, e) {
  var o = e ? t.left : t.top, r = e ? t.right : t.bottom, i = e ? t.width : t.height, a = e ? n.left : n.top, s = e ? n.right : n.bottom, l = e ? n.width : n.height;
  return o === a || r === s || o + i / 2 === a + l / 2;
}, Xn = function(t, n) {
  var e;
  return Wt.some(function(o) {
    var r = o[z].options.emptyInsertThreshold;
    if (!(!r || ce(o))) {
      var i = N(o), a = t >= i.left - r && t <= i.right + r, s = n >= i.top - r && n <= i.bottom + r;
      if (a && s)
        return e = o;
    }
  }), e;
}, Ge = function(t) {
  function n(r, i) {
    return function(a, s, l, d) {
      var c = a.options.group.name && s.options.group.name && a.options.group.name === s.options.group.name;
      if (r == null && (i || c))
        return !0;
      if (r == null || r === !1)
        return !1;
      if (i && r === "clone")
        return r;
      if (typeof r == "function")
        return n(r(a, s, l, d), i)(a, s, l, d);
      var f = (i ? a : s).options.group.name;
      return r === !0 || typeof r == "string" && r === f || r.join && r.indexOf(f) > -1;
    };
  }
  var e = {}, o = t.group;
  (!o || kt(o) != "object") && (o = {
    name: o
  }), e.name = o.name, e.checkPull = n(o.pull, !0), e.checkPut = n(o.put), e.revertClone = o.revertClone, t.group = e;
}, qe = function() {
  !Le && v && p(v, "display", "none");
}, $e = function() {
  !Le && v && p(v, "display", "");
};
Lt && !Be && document.addEventListener("click", function(t) {
  if (Ht)
    return t.preventDefault(), t.stopPropagation && t.stopPropagation(), t.stopImmediatePropagation && t.stopImmediatePropagation(), Ht = !1, !1;
}, !0);
var dt = function(t) {
  if (u) {
    t = t.touches ? t.touches[0] : t;
    var n = Xn(t.clientX, t.clientY);
    if (n) {
      var e = {};
      for (var o in t)
        t.hasOwnProperty(o) && (e[o] = t[o]);
      e.target = e.rootEl = n, e.preventDefault = void 0, e.stopPropagation = void 0, n[z]._onDragOver(e);
    }
  }
}, Bn = function(t) {
  u && u.parentNode[z]._isOutsideThisEl(t.target);
};
function g(t, n) {
  if (!(t && t.nodeType && t.nodeType === 1))
    throw "Sortable: `el` must be an HTMLElement, not ".concat({}.toString.call(t));
  this.el = t, this.options = n = rt({}, n), t[z] = this;
  var e = {
    group: null,
    sort: !0,
    disabled: !1,
    store: null,
    handle: null,
    draggable: /^[uo]l$/i.test(t.nodeName) ? ">li" : ">*",
    swapThreshold: 1,
    // percentage; 0 <= x <= 1
    invertSwap: !1,
    // invert always
    invertedSwapThreshold: null,
    // will be set to same as swapThreshold if default
    removeCloneOnHide: !0,
    direction: function() {
      return ze(t, this.options);
    },
    ghostClass: "sortable-ghost",
    chosenClass: "sortable-chosen",
    dragClass: "sortable-drag",
    ignore: "a, img",
    filter: null,
    preventOnFilter: !0,
    animation: 0,
    easing: null,
    setData: function(i, a) {
      i.setData("Text", a.textContent);
    },
    dropBubble: !1,
    dragoverBubble: !1,
    dataIdAttr: "data-id",
    delay: 0,
    delayOnTouchOnly: !1,
    touchStartThreshold: (Number.parseInt ? Number : window).parseInt(window.devicePixelRatio, 10) || 1,
    forceFallback: !1,
    fallbackClass: "sortable-fallback",
    fallbackOnBody: !1,
    fallbackTolerance: 0,
    fallbackOffset: {
      x: 0,
      y: 0
    },
    supportPointer: g.supportPointer !== !1 && "PointerEvent" in window && !Et,
    emptyInsertThreshold: 5
  };
  At.initializePlugins(this, t, e);
  for (var o in e)
    !(o in n) && (n[o] = e[o]);
  Ge(n);
  for (var r in this)
    r.charAt(0) === "_" && typeof this[r] == "function" && (this[r] = this[r].bind(this));
  this.nativeDraggable = n.forceFallback ? !1 : Rn, this.nativeDraggable && (this.options.touchStartThreshold = 1), n.supportPointer ? S(t, "pointerdown", this._onTapStart) : (S(t, "mousedown", this._onTapStart), S(t, "touchstart", this._onTapStart)), this.nativeDraggable && (S(t, "dragover", this), S(t, "dragenter", this)), Wt.push(this.el), n.store && n.store.get && this.sort(n.store.get(this) || []), rt(this, In());
}
g.prototype = /** @lends Sortable.prototype */
{
  constructor: g,
  _isOutsideThisEl: function(t) {
    !this.el.contains(t) && t !== this.el && (pt = null);
  },
  _getDirection: function(t, n) {
    return typeof this.options.direction == "function" ? this.options.direction.call(this, t, n, u) : this.options.direction;
  },
  _onTapStart: function(t) {
    if (t.cancelable) {
      var n = this, e = this.el, o = this.options, r = o.preventOnFilter, i = t.type, a = t.touches && t.touches[0] || t.pointerType && t.pointerType === "touch" && t, s = (a || t).target, l = t.target.shadowRoot && (t.path && t.path[0] || t.composedPath && t.composedPath()[0]) || s, d = o.filter;
      if (zn(e), !u && !(/mousedown|pointerdown/.test(i) && t.button !== 0 || o.disabled) && !l.isContentEditable && !(!this.nativeDraggable && Et && s && s.tagName.toUpperCase() === "SELECT") && (s = Z(s, o.draggable, e, !1), !(s && s.animated) && Rt !== s)) {
        if (mt = q(s), Ct = q(s, o.draggable), typeof d == "function") {
          if (d.call(this, t, s, this)) {
            F({
              sortable: n,
              rootEl: l,
              name: "filter",
              targetEl: s,
              toEl: e,
              fromEl: e
            }), H("filter", n, {
              evt: t
            }), r && t.cancelable && t.preventDefault();
            return;
          }
        } else if (d && (d = d.split(",").some(function(c) {
          if (c = Z(l, c.trim(), e, !1), c)
            return F({
              sortable: n,
              rootEl: c,
              name: "filter",
              targetEl: s,
              fromEl: e,
              toEl: e
            }), H("filter", n, {
              evt: t
            }), !0;
        }), d)) {
          r && t.cancelable && t.preventDefault();
          return;
        }
        o.handle && !Z(l, o.handle, e, !1) || this._prepareDragStart(t, a, s);
      }
    }
  },
  _prepareDragStart: function(t, n, e) {
    var o = this, r = o.el, i = o.options, a = r.ownerDocument, s;
    if (e && !u && e.parentNode === r) {
      var l = N(e);
      if (C = r, u = e, x = u.parentNode, ft = u.nextSibling, Rt = e, It = i.group, g.dragged = u, ct = {
        target: u,
        clientX: (n || t).clientX,
        clientY: (n || t).clientY
      }, Te = ct.clientX - l.left, xe = ct.clientY - l.top, this._lastX = (n || t).clientX, this._lastY = (n || t).clientY, u.style["will-change"] = "all", s = function() {
        if (H("delayEnded", o, {
          evt: t
        }), g.eventCanceled) {
          o._onDrop();
          return;
        }
        o._disableDelayedDragEvents(), !De && o.nativeDraggable && (u.draggable = !0), o._triggerDragStart(t, n), F({
          sortable: o,
          name: "choose",
          originalEvent: t
        }), U(u, i.chosenClass, !0);
      }, i.ignore.split(",").forEach(function(d) {
        je(u, d.trim(), te);
      }), S(a, "dragover", dt), S(a, "mousemove", dt), S(a, "touchmove", dt), S(a, "mouseup", o._onDrop), S(a, "touchend", o._onDrop), S(a, "touchcancel", o._onDrop), De && this.nativeDraggable && (this.options.touchStartThreshold = 4, u.draggable = !0), H("delayStart", this, {
        evt: t
      }), i.delay && (!i.delayOnTouchOnly || n) && (!this.nativeDraggable || !(Ot || it))) {
        if (g.eventCanceled) {
          this._onDrop();
          return;
        }
        S(a, "mouseup", o._disableDelayedDrag), S(a, "touchend", o._disableDelayedDrag), S(a, "touchcancel", o._disableDelayedDrag), S(a, "mousemove", o._delayedDragTouchMoveHandler), S(a, "touchmove", o._delayedDragTouchMoveHandler), i.supportPointer && S(a, "pointermove", o._delayedDragTouchMoveHandler), o._dragStartTimer = setTimeout(s, i.delay);
      } else
        s();
    }
  },
  _delayedDragTouchMoveHandler: function(t) {
    var n = t.touches ? t.touches[0] : t;
    Math.max(Math.abs(n.clientX - this._lastX), Math.abs(n.clientY - this._lastY)) >= Math.floor(this.options.touchStartThreshold / (this.nativeDraggable && window.devicePixelRatio || 1)) && this._disableDelayedDrag();
  },
  _disableDelayedDrag: function() {
    u && te(u), clearTimeout(this._dragStartTimer), this._disableDelayedDragEvents();
  },
  _disableDelayedDragEvents: function() {
    var t = this.el.ownerDocument;
    y(t, "mouseup", this._disableDelayedDrag), y(t, "touchend", this._disableDelayedDrag), y(t, "touchcancel", this._disableDelayedDrag), y(t, "mousemove", this._delayedDragTouchMoveHandler), y(t, "touchmove", this._delayedDragTouchMoveHandler), y(t, "pointermove", this._delayedDragTouchMoveHandler);
  },
  _triggerDragStart: function(t, n) {
    n = n || t.pointerType == "touch" && t, !this.nativeDraggable || n ? this.options.supportPointer ? S(document, "pointermove", this._onTouchMove) : n ? S(document, "touchmove", this._onTouchMove) : S(document, "mousemove", this._onTouchMove) : (S(u, "dragend", this), S(C, "dragstart", this._onDragStart));
    try {
      document.selection ? Xt(function() {
        document.selection.empty();
      }) : window.getSelection().removeAllRanges();
    } catch (e) {
    }
  },
  _dragStarted: function(t, n) {
    if (gt = !1, C && u) {
      H("dragStarted", this, {
        evt: n
      }), this.nativeDraggable && S(document, "dragover", Bn);
      var e = this.options;
      !t && U(u, e.dragClass, !1), U(u, e.ghostClass, !0), g.active = this, t && this._appendGhost(), F({
        sortable: this,
        name: "start",
        originalEvent: n
      });
    } else
      this._nulling();
  },
  _emulateDragOver: function() {
    if (J) {
      this._lastX = J.clientX, this._lastY = J.clientY, qe();
      for (var t = document.elementFromPoint(J.clientX, J.clientY), n = t; t && t.shadowRoot && (t = t.shadowRoot.elementFromPoint(J.clientX, J.clientY), t !== n); )
        n = t;
      if (u.parentNode[z]._isOutsideThisEl(t), n)
        do {
          if (n[z]) {
            var e = void 0;
            if (e = n[z]._onDragOver({
              clientX: J.clientX,
              clientY: J.clientY,
              target: t,
              rootEl: n
            }), e && !this.options.dragoverBubble)
              break;
          }
          t = n;
        } while (n = n.parentNode);
      $e();
    }
  },
  _onTouchMove: function(t) {
    if (ct) {
      var n = this.options, e = n.fallbackTolerance, o = n.fallbackOffset, r = t.touches ? t.touches[0] : t, i = v && bt(v, !0), a = v && i && i.a, s = v && i && i.d, l = Nt && B && Ce(B), d = (r.clientX - ct.clientX + o.x) / (a || 1) + (l ? l[0] - Qt[0] : 0) / (a || 1), c = (r.clientY - ct.clientY + o.y) / (s || 1) + (l ? l[1] - Qt[1] : 0) / (s || 1);
      if (!g.active && !gt) {
        if (e && Math.max(Math.abs(r.clientX - this._lastX), Math.abs(r.clientY - this._lastY)) < e)
          return;
        this._onDragStart(t, !0);
      }
      if (v) {
        i ? (i.e += d - (Zt || 0), i.f += c - (Kt || 0)) : i = {
          a: 1,
          b: 0,
          c: 0,
          d: 1,
          e: d,
          f: c
        };
        var f = "matrix(".concat(i.a, ",").concat(i.b, ",").concat(i.c, ",").concat(i.d, ",").concat(i.e, ",").concat(i.f, ")");
        p(v, "webkitTransform", f), p(v, "mozTransform", f), p(v, "msTransform", f), p(v, "transform", f), Zt = d, Kt = c, J = r;
      }
      t.cancelable && t.preventDefault();
    }
  },
  _appendGhost: function() {
    if (!v) {
      var t = this.options.fallbackOnBody ? document.body : C, n = N(u, !0, Nt, !0, t), e = this.options;
      if (Nt) {
        for (B = t; p(B, "position") === "static" && p(B, "transform") === "none" && B !== document; )
          B = B.parentNode;
        B !== document.body && B !== document.documentElement ? (B === document && (B = Q()), n.top += B.scrollTop, n.left += B.scrollLeft) : B = Q(), Qt = Ce(B);
      }
      v = u.cloneNode(!0), U(v, e.ghostClass, !1), U(v, e.fallbackClass, !0), U(v, e.dragClass, !0), p(v, "transition", ""), p(v, "transform", ""), p(v, "box-sizing", "border-box"), p(v, "margin", 0), p(v, "top", n.top), p(v, "left", n.left), p(v, "width", n.width), p(v, "height", n.height), p(v, "opacity", "0.8"), p(v, "position", Nt ? "absolute" : "fixed"), p(v, "zIndex", "100000"), p(v, "pointerEvents", "none"), g.ghost = v, t.appendChild(v), p(v, "transform-origin", Te / parseInt(v.style.width) * 100 + "% " + xe / parseInt(v.style.height) * 100 + "%");
    }
  },
  _onDragStart: function(t, n) {
    var e = this, o = t.dataTransfer, r = e.options;
    if (H("dragStart", this, {
      evt: t
    }), g.eventCanceled) {
      this._onDrop();
      return;
    }
    H("setupClone", this), g.eventCanceled || (T = Ve(u), T.removeAttribute("id"), T.draggable = !1, T.style["will-change"] = "", this._hideClone(), U(T, this.options.chosenClass, !1), g.clone = T), e.cloneId = Xt(function() {
      H("clone", e), !g.eventCanceled && (e.options.removeCloneOnHide || C.insertBefore(T, u), e._hideClone(), F({
        sortable: e,
        name: "clone"
      }));
    }), !n && U(u, r.dragClass, !0), n ? (Ht = !0, e._loopId = setInterval(e._emulateDragOver, 50)) : (y(document, "mouseup", e._onDrop), y(document, "touchend", e._onDrop), y(document, "touchcancel", e._onDrop), o && (o.effectAllowed = "move", r.setData && r.setData.call(e, o, u)), S(document, "drop", e), p(u, "transform", "translateZ(0)")), gt = !0, e._dragStartId = Xt(e._dragStarted.bind(e, n, t)), S(document, "selectstart", e), wt = !0, Et && p(document.body, "user-select", "none");
  },
  // Returns true - if no further action is needed (either inserted or another condition)
  _onDragOver: function(t) {
    var n = this.el, e = t.target, o, r, i, a = this.options, s = a.group, l = g.active, d = It === s, c = a.sort, f = X || l, D, h = this, _ = !1;
    if (re)
      return;
    function w(nt, zt) {
      H(nt, h, tt({
        evt: t,
        isOwner: d,
        axis: D ? "vertical" : "horizontal",
        revert: i,
        dragRect: o,
        targetRect: r,
        canSort: c,
        fromSortable: f,
        target: e,
        completed: A,
        onMove: function(he, Qe) {
          return Pt(C, n, u, o, he, N(he), t, Qe);
        },
        changed: $
      }, zt));
    }
    function W() {
      w("dragOverAnimationCapture"), h.captureAnimationState(), h !== f && f.captureAnimationState();
    }
    function A(nt) {
      return w("dragOverCompleted", {
        insertion: nt
      }), nt && (d ? l._hideClone() : l._showClone(h), h !== f && (U(u, X ? X.options.ghostClass : l.options.ghostClass, !1), U(u, a.ghostClass, !0)), X !== h && h !== g.active ? X = h : h === g.active && X && (X = null), f === h && (h._ignoreWhileAnimating = e), h.animateAll(function() {
        w("dragOverAnimationComplete"), h._ignoreWhileAnimating = null;
      }), h !== f && (f.animateAll(), f._ignoreWhileAnimating = null)), (e === u && !u.animated || e === n && !e.animated) && (pt = null), !a.dragoverBubble && !t.rootEl && e !== document && (u.parentNode[z]._isOutsideThisEl(t.target), !nt && dt(t)), !a.dragoverBubble && t.stopPropagation && t.stopPropagation(), _ = !0;
    }
    function $() {
      L = q(u), at = q(u, a.draggable), F({
        sortable: h,
        name: "change",
        toEl: n,
        newIndex: L,
        newDraggableIndex: at,
        originalEvent: t
      });
    }
    if (t.preventDefault !== void 0 && t.cancelable && t.preventDefault(), e = Z(e, a.draggable, n, !0), w("dragOver"), g.eventCanceled)
      return _;
    if (u.contains(t.target) || e.animated && e.animatingX && e.animatingY || h._ignoreWhileAnimating === e)
      return A(!1);
    if (Ht = !1, l && !a.disabled && (d ? c || (i = x !== C) : X === this || (this.lastPutMode = It.checkPull(this, l, u, t)) && s.checkPut(this, l, u, t))) {
      if (D = this._getDirection(t, e) === "vertical", o = N(u), w("dragOverValid"), g.eventCanceled)
        return _;
      if (i)
        return x = C, W(), this._hideClone(), w("revert"), g.eventCanceled || (ft ? C.insertBefore(u, ft) : C.appendChild(u)), A(!0);
      var P = ce(n, a.draggable);
      if (!P || Wn(t, D, this) && !P.animated) {
        if (P === u)
          return A(!1);
        if (P && n === t.target && (e = P), e && (r = N(e)), Pt(C, n, u, o, e, r, t, !!e) !== !1)
          return W(), P && P.nextSibling ? n.insertBefore(u, P.nextSibling) : n.appendChild(u), x = n, $(), A(!0);
      } else if (P && Hn(t, D, this)) {
        var K = yt(n, 0, a, !0);
        if (K === u)
          return A(!1);
        if (e = K, r = N(e), Pt(C, n, u, o, e, r, t, !1) !== !1)
          return W(), n.insertBefore(u, K), x = n, $(), A(!0);
      } else if (e.parentNode === n) {
        r = N(e);
        var R = 0, et, ut = u.parentNode !== n, m = !Yn(u.animated && u.toRect || o, e.animated && e.toRect || r, D), b = D ? "top" : "left", I = _e(e, "top", "top") || _e(u, "top", "top"), j = I ? I.scrollTop : void 0;
        pt !== e && (et = r[b], xt = !1, Mt = !m && a.invertSwap || ut), R = Vn(t, e, r, D, m ? 1 : a.swapThreshold, a.invertedSwapThreshold == null ? a.swapThreshold : a.invertedSwapThreshold, Mt, pt === e);
        var E;
        if (R !== 0) {
          var O = q(u);
          do
            O -= R, E = x.children[O];
          while (E && (p(E, "display") === "none" || E === v));
        }
        if (R === 0 || E === e)
          return A(!1);
        pt = e, Tt = R;
        var Y = e.nextElementSibling, k = !1;
        k = R === 1;
        var G = Pt(C, n, u, o, e, r, t, k);
        if (G !== !1)
          return (G === 1 || G === -1) && (k = G === 1), re = !0, setTimeout(jn, 30), W(), k && !Y ? n.appendChild(u) : e.parentNode.insertBefore(u, k ? Y : e), I && We(I, 0, j - I.scrollTop), x = u.parentNode, et !== void 0 && !Mt && (Yt = Math.abs(et - N(e)[b])), $(), A(!0);
      }
      if (n.contains(u))
        return A(!1);
    }
    return !1;
  },
  _ignoreWhileAnimating: null,
  _offMoveEvents: function() {
    y(document, "mousemove", this._onTouchMove), y(document, "touchmove", this._onTouchMove), y(document, "pointermove", this._onTouchMove), y(document, "dragover", dt), y(document, "mousemove", dt), y(document, "touchmove", dt);
  },
  _offUpEvents: function() {
    var t = this.el.ownerDocument;
    y(t, "mouseup", this._onDrop), y(t, "touchend", this._onDrop), y(t, "pointerup", this._onDrop), y(t, "touchcancel", this._onDrop), y(document, "selectstart", this);
  },
  _onDrop: function(t) {
    var n = this.el, e = this.options;
    if (L = q(u), at = q(u, e.draggable), H("drop", this, {
      evt: t
    }), x = u && u.parentNode, L = q(u), at = q(u, e.draggable), g.eventCanceled) {
      this._nulling();
      return;
    }
    gt = !1, Mt = !1, xt = !1, clearInterval(this._loopId), clearTimeout(this._dragStartTimer), ie(this.cloneId), ie(this._dragStartId), this.nativeDraggable && (y(document, "drop", this), y(n, "dragstart", this._onDragStart)), this._offMoveEvents(), this._offUpEvents(), Et && p(document.body, "user-select", ""), p(u, "transform", ""), t && (wt && (t.cancelable && t.preventDefault(), !e.dropBubble && t.stopPropagation()), v && v.parentNode && v.parentNode.removeChild(v), (C === x || X && X.lastPutMode !== "clone") && T && T.parentNode && T.parentNode.removeChild(T), u && (this.nativeDraggable && y(u, "dragend", this), te(u), u.style["will-change"] = "", wt && !gt && U(u, X ? X.options.ghostClass : this.options.ghostClass, !1), U(u, this.options.chosenClass, !1), F({
      sortable: this,
      name: "unchoose",
      toEl: x,
      newIndex: null,
      newDraggableIndex: null,
      originalEvent: t
    }), C !== x ? (L >= 0 && (F({
      rootEl: x,
      name: "add",
      toEl: x,
      fromEl: C,
      originalEvent: t
    }), F({
      sortable: this,
      name: "remove",
      toEl: x,
      originalEvent: t
    }), F({
      rootEl: x,
      name: "sort",
      toEl: x,
      fromEl: C,
      originalEvent: t
    }), F({
      sortable: this,
      name: "sort",
      toEl: x,
      originalEvent: t
    })), X && X.save()) : L !== mt && L >= 0 && (F({
      sortable: this,
      name: "update",
      toEl: x,
      originalEvent: t
    }), F({
      sortable: this,
      name: "sort",
      toEl: x,
      originalEvent: t
    })), g.active && ((L == null || L === -1) && (L = mt, at = Ct), F({
      sortable: this,
      name: "end",
      toEl: x,
      originalEvent: t
    }), this.save()))), this._nulling();
  },
  _nulling: function() {
    H("nulling", this), C = u = x = v = ft = T = Rt = lt = ct = J = wt = L = at = mt = Ct = pt = Tt = X = It = g.dragged = g.ghost = g.clone = g.active = null, Vt.forEach(function(t) {
      t.checked = !0;
    }), Vt.length = Zt = Kt = 0;
  },
  handleEvent: function(t) {
    switch (t.type) {
      case "drop":
      case "dragend":
        this._onDrop(t);
        break;
      case "dragenter":
      case "dragover":
        u && (this._onDragOver(t), Fn(t));
        break;
      case "selectstart":
        t.preventDefault();
        break;
    }
  },
  /**
   * Serializes the item into an array of string.
   * @returns {String[]}
   */
  toArray: function() {
    for (var t = [], n, e = this.el.children, o = 0, r = e.length, i = this.options; o < r; o++)
      n = e[o], Z(n, i.draggable, this.el, !1) && t.push(n.getAttribute(i.dataIdAttr) || Ln(n));
    return t;
  },
  /**
   * Sorts the elements according to the array.
   * @param  {String[]}  order  order of the items
   */
  sort: function(t, n) {
    var e = {}, o = this.el;
    this.toArray().forEach(function(r, i) {
      var a = o.children[i];
      Z(a, this.options.draggable, o, !1) && (e[r] = a);
    }, this), n && this.captureAnimationState(), t.forEach(function(r) {
      e[r] && (o.removeChild(e[r]), o.appendChild(e[r]));
    }), n && this.animateAll();
  },
  /**
   * Save the current sorting
   */
  save: function() {
    var t = this.options.store;
    t && t.set && t.set(this);
  },
  /**
   * For each element in the set, get the first element that matches the selector by testing the element itself and traversing up through its ancestors in the DOM tree.
   * @param   {HTMLElement}  el
   * @param   {String}       [selector]  default: `options.draggable`
   * @returns {HTMLElement|null}
   */
  closest: function(t, n) {
    return Z(t, n || this.options.draggable, this.el, !1);
  },
  /**
   * Set/get option
   * @param   {string} name
   * @param   {*}      [value]
   * @returns {*}
   */
  option: function(t, n) {
    var e = this.options;
    if (n === void 0)
      return e[t];
    var o = At.modifyOption(this, t, n);
    typeof o != "undefined" ? e[t] = o : e[t] = n, t === "group" && Ge(e);
  },
  /**
   * Destroy
   */
  destroy: function() {
    H("destroy", this);
    var t = this.el;
    t[z] = null, y(t, "mousedown", this._onTapStart), y(t, "touchstart", this._onTapStart), y(t, "pointerdown", this._onTapStart), this.nativeDraggable && (y(t, "dragover", this), y(t, "dragenter", this)), Array.prototype.forEach.call(t.querySelectorAll("[draggable]"), function(n) {
      n.removeAttribute("draggable");
    }), this._onDrop(), this._disableDelayedDragEvents(), Wt.splice(Wt.indexOf(this.el), 1), this.el = t = null;
  },
  _hideClone: function() {
    if (!lt) {
      if (H("hideClone", this), g.eventCanceled)
        return;
      p(T, "display", "none"), this.options.removeCloneOnHide && T.parentNode && T.parentNode.removeChild(T), lt = !0;
    }
  },
  _showClone: function(t) {
    if (t.lastPutMode !== "clone") {
      this._hideClone();
      return;
    }
    if (lt) {
      if (H("showClone", this), g.eventCanceled)
        return;
      u.parentNode == C && !this.options.group.revertClone ? C.insertBefore(T, u) : ft ? C.insertBefore(T, ft) : C.appendChild(T), this.options.group.revertClone && this.animate(u, T), p(T, "display", ""), lt = !1;
    }
  }
};
function Fn(t) {
  t.dataTransfer && (t.dataTransfer.dropEffect = "move"), t.cancelable && t.preventDefault();
}
function Pt(t, n, e, o, r, i, a, s) {
  var l, d = t[z], c = d.options.onMove, f;
  return window.CustomEvent && !it && !Ot ? l = new CustomEvent("move", {
    bubbles: !0,
    cancelable: !0
  }) : (l = document.createEvent("Event"), l.initEvent("move", !0, !0)), l.to = n, l.from = t, l.dragged = e, l.draggedRect = o, l.related = r || n, l.relatedRect = i || N(n), l.willInsertAfter = s, l.originalEvent = a, t.dispatchEvent(l), c && (f = c.call(d, l, a)), f;
}
function te(t) {
  t.draggable = !1;
}
function jn() {
  re = !1;
}
function Hn(t, n, e) {
  var o = N(yt(e.el, 0, e.options, !0)), r = Ue(e.el, e.options, v), i = 10;
  return n ? t.clientX < r.left - i || t.clientY < o.top && t.clientX < o.right : t.clientY < r.top - i || t.clientY < o.bottom && t.clientX < o.left;
}
function Wn(t, n, e) {
  var o = N(ce(e.el, e.options.draggable)), r = Ue(e.el, e.options, v), i = 10;
  return n ? t.clientX > r.right + i || t.clientY > o.bottom && t.clientX > o.left : t.clientY > r.bottom + i || t.clientX > o.right && t.clientY > o.top;
}
function Vn(t, n, e, o, r, i, a, s) {
  var l = o ? t.clientY : t.clientX, d = o ? e.height : e.width, c = o ? e.top : e.left, f = o ? e.bottom : e.right, D = !1;
  if (!a) {
    if (s && Yt < d * r) {
      if (!xt && (Tt === 1 ? l > c + d * i / 2 : l < f - d * i / 2) && (xt = !0), xt)
        D = !0;
      else if (Tt === 1 ? l < c + Yt : l > f - Yt)
        return -Tt;
    } else if (l > c + d * (1 - r) / 2 && l < f - d * (1 - r) / 2)
      return Un(n);
  }
  return D = D || a, D && (l < c + d * i / 2 || l > f - d * i / 2) ? l > c + d / 2 ? 1 : -1 : 0;
}
function Un(t) {
  return q(u) < q(t) ? 1 : -1;
}
function Ln(t) {
  for (var n = t.tagName + t.className + t.src + t.href + t.textContent, e = n.length, o = 0; e--; )
    o += n.charCodeAt(e);
  return o.toString(36);
}
function zn(t) {
  Vt.length = 0;
  for (var n = t.getElementsByTagName("input"), e = n.length; e--; ) {
    var o = n[e];
    o.checked && Vt.push(o);
  }
}
function Xt(t) {
  return setTimeout(t, 0);
}
function ie(t) {
  return clearTimeout(t);
}
Lt && S(document, "touchmove", function(t) {
  (g.active || gt) && t.cancelable && t.preventDefault();
});
g.utils = {
  on: S,
  off: y,
  css: p,
  find: je,
  is: function(t, n) {
    return !!Z(t, n, t, !1);
  },
  extend: On,
  throttle: He,
  closest: Z,
  toggleClass: U,
  clone: Ve,
  index: q,
  nextTick: Xt,
  cancelNextTick: ie,
  detectDirection: ze,
  getChild: yt
};
g.get = function(t) {
  return t[z];
};
g.mount = function() {
  for (var t = arguments.length, n = new Array(t), e = 0; e < t; e++)
    n[e] = arguments[e];
  n[0].constructor === Array && (n = n[0]), n.forEach(function(o) {
    if (!o.prototype || !o.prototype.constructor)
      throw "Sortable: Mounted plugin must be a constructor function, not ".concat({}.toString.call(o));
    o.utils && (g.utils = tt(tt({}, g.utils), o.utils)), At.mount(o);
  });
};
g.create = function(t, n) {
  return new g(t, n);
};
g.version = Cn;
var M = [], St, ae, le = !1, ee, ne, Ut, Dt;
function Gn() {
  function t() {
    this.defaults = {
      scroll: !0,
      forceAutoScrollFallback: !1,
      scrollSensitivity: 30,
      scrollSpeed: 10,
      bubbleScroll: !0
    };
    for (var n in this)
      n.charAt(0) === "_" && typeof this[n] == "function" && (this[n] = this[n].bind(this));
  }
  return t.prototype = {
    dragStarted: function(n) {
      var e = n.originalEvent;
      this.sortable.nativeDraggable ? S(document, "dragover", this._handleAutoScroll) : this.options.supportPointer ? S(document, "pointermove", this._handleFallbackAutoScroll) : e.touches ? S(document, "touchmove", this._handleFallbackAutoScroll) : S(document, "mousemove", this._handleFallbackAutoScroll);
    },
    dragOverCompleted: function(n) {
      var e = n.originalEvent;
      !this.options.dragOverBubble && !e.rootEl && this._handleAutoScroll(e);
    },
    drop: function() {
      this.sortable.nativeDraggable ? y(document, "dragover", this._handleAutoScroll) : (y(document, "pointermove", this._handleFallbackAutoScroll), y(document, "touchmove", this._handleFallbackAutoScroll), y(document, "mousemove", this._handleFallbackAutoScroll)), Ae(), Bt(), An();
    },
    nulling: function() {
      Ut = ae = St = le = Dt = ee = ne = null, M.length = 0;
    },
    _handleFallbackAutoScroll: function(n) {
      this._handleAutoScroll(n, !0);
    },
    _handleAutoScroll: function(n, e) {
      var o = this, r = (n.touches ? n.touches[0] : n).clientX, i = (n.touches ? n.touches[0] : n).clientY, a = document.elementFromPoint(r, i);
      if (Ut = n, e || this.options.forceAutoScrollFallback || Ot || it || Et) {
        oe(n, this.options, a, e);
        var s = st(a, !0);
        le && (!Dt || r !== ee || i !== ne) && (Dt && Ae(), Dt = setInterval(function() {
          var l = st(document.elementFromPoint(r, i), !0);
          l !== s && (s = l, Bt()), oe(n, o.options, l, e);
        }, 10), ee = r, ne = i);
      } else {
        if (!this.options.bubbleScroll || st(a, !0) === Q()) {
          Bt();
          return;
        }
        oe(n, this.options, st(a, !1), !1);
      }
    }
  }, rt(t, {
    pluginName: "scroll",
    initializeByDefault: !0
  });
}
function Bt() {
  M.forEach(function(t) {
    clearInterval(t.pid);
  }), M = [];
}
function Ae() {
  clearInterval(Dt);
}
var oe = He(function(t, n, e, o) {
  if (n.scroll) {
    var r = (t.touches ? t.touches[0] : t).clientX, i = (t.touches ? t.touches[0] : t).clientY, a = n.scrollSensitivity, s = n.scrollSpeed, l = Q(), d = !1, c;
    ae !== e && (ae = e, Bt(), St = n.scroll, c = n.scrollFn, St === !0 && (St = st(e, !0)));
    var f = 0, D = St;
    do {
      var h = D, _ = N(h), w = _.top, W = _.bottom, A = _.left, $ = _.right, P = _.width, K = _.height, R = void 0, et = void 0, ut = h.scrollWidth, m = h.scrollHeight, b = p(h), I = h.scrollLeft, j = h.scrollTop;
      h === l ? (R = P < ut && (b.overflowX === "auto" || b.overflowX === "scroll" || b.overflowX === "visible"), et = K < m && (b.overflowY === "auto" || b.overflowY === "scroll" || b.overflowY === "visible")) : (R = P < ut && (b.overflowX === "auto" || b.overflowX === "scroll"), et = K < m && (b.overflowY === "auto" || b.overflowY === "scroll"));
      var E = R && (Math.abs($ - r) <= a && I + P < ut) - (Math.abs(A - r) <= a && !!I), O = et && (Math.abs(W - i) <= a && j + K < m) - (Math.abs(w - i) <= a && !!j);
      if (!M[f])
        for (var Y = 0; Y <= f; Y++)
          M[Y] || (M[Y] = {});
      (M[f].vx != E || M[f].vy != O || M[f].el !== h) && (M[f].el = h, M[f].vx = E, M[f].vy = O, clearInterval(M[f].pid), (E != 0 || O != 0) && (d = !0, M[f].pid = setInterval(function() {
        o && this.layer === 0 && g.active._onTouchMove(Ut);
        var k = M[this.layer].vy ? M[this.layer].vy * s : 0, G = M[this.layer].vx ? M[this.layer].vx * s : 0;
        typeof c == "function" && c.call(g.dragged.parentNode[z], G, k, t, Ut, M[this.layer].el) !== "continue" || We(M[this.layer].el, G, k);
      }.bind({
        layer: f
      }), 24))), f++;
    } while (n.bubbleScroll && D !== l && (D = st(D, !1)));
    le = d;
  }
}, 30), Je = function(t) {
  var n = t.originalEvent, e = t.putSortable, o = t.dragEl, r = t.activeSortable, i = t.dispatchSortableEvent, a = t.hideGhostForTarget, s = t.unhideGhostForTarget;
  if (n) {
    var l = e || r;
    a();
    var d = n.changedTouches && n.changedTouches.length ? n.changedTouches[0] : n, c = document.elementFromPoint(d.clientX, d.clientY);
    s(), l && !l.el.contains(c) && (i("spill"), this.onSpill({
      dragEl: o,
      putSortable: e
    }));
  }
};
function de() {
}
de.prototype = {
  startIndex: null,
  dragStart: function(t) {
    var n = t.oldDraggableIndex;
    this.startIndex = n;
  },
  onSpill: function(t) {
    var n = t.dragEl, e = t.putSortable;
    this.sortable.captureAnimationState(), e && e.captureAnimationState();
    var o = yt(this.sortable.el, this.startIndex, this.options);
    o ? this.sortable.el.insertBefore(n, o) : this.sortable.el.appendChild(n), this.sortable.animateAll(), e && e.animateAll();
  },
  drop: Je
};
rt(de, {
  pluginName: "revertOnSpill"
});
function fe() {
}
fe.prototype = {
  onSpill: function(t) {
    var n = t.dragEl, e = t.putSortable, o = e || this.sortable;
    o.captureAnimationState(), n.parentNode && n.parentNode.removeChild(n), o.animateAll();
  },
  drop: Je
};
rt(fe, {
  pluginName: "removeOnSpill"
});
g.mount(new Gn());
g.mount(fe, de);
function qn(t) {
  return t == null ? t : JSON.parse(JSON.stringify(t));
}
function $n(t) {
  ue() && sn(t);
}
function Jn(t) {
  ue() ? ln(t) : Ne(t);
}
let Ze = null, Ke = null;
function Ie(t = null, n = null) {
  Ze = t, Ke = n;
}
function Zn() {
  return {
    data: Ze,
    clonedData: Ke
  };
}
const Me = Symbol("cloneElement");
function Kn(...t) {
  var n, e;
  const o = (n = ue()) == null ? void 0 : n.proxy;
  let r = null;
  const i = t[0];
  let [, a, s] = t;
  Array.isArray(V(a)) || (s = a, a = null);
  let l = null;
  const {
    immediate: d = !0,
    clone: c = qn,
    customUpdate: f
  } = (e = V(s)) != null ? e : {};
  function D(m) {
    var b;
    const { from: I, oldIndex: j, item: E } = m;
    r = Array.from(I.childNodes);
    const O = V((b = V(a)) == null ? void 0 : b[j]), Y = c(O);
    Ie(O, Y), E[Me] = Y;
  }
  function h(m) {
    const b = m.item[Me];
    if (!pn(b)) {
      if (qt(m.item), Gt(a)) {
        const I = [...V(a)];
        a.value = be(I, m.newDraggableIndex, b);
        return;
      }
      be(V(a), m.newDraggableIndex, b);
    }
  }
  function _(m) {
    const { from: b, item: I, oldIndex: j, oldDraggableIndex: E, pullMode: O, clone: Y } = m;
    if (ye(b, I, j), O === "clone") {
      qt(Y);
      return;
    }
    if (Gt(a)) {
      const k = [...V(a)];
      a.value = me(k, E);
      return;
    }
    me(V(a), E);
  }
  function w(m) {
    if (f) {
      f(m);
      return;
    }
    const { from: b, item: I, oldIndex: j, oldDraggableIndex: E, newDraggableIndex: O } = m;
    if (qt(I), ye(b, I, j), Gt(a)) {
      const Y = [...V(a)];
      a.value = ve(
        Y,
        E,
        O
      );
      return;
    }
    ve(V(a), E, O);
  }
  function W(m) {
    const { newIndex: b, oldIndex: I, from: j, to: E } = m;
    let O = null;
    const Y = b === I && j === E;
    try {
      if (Y) {
        let k = null;
        r == null || r.some((G, nt) => {
          if (k && (r == null ? void 0 : r.length) !== E.childNodes.length)
            return j.insertBefore(k, G.nextSibling), !0;
          const zt = E.childNodes[nt];
          k = E == null ? void 0 : E.replaceChild(G, zt);
        });
      }
    } catch (k) {
      O = k;
    } finally {
      r = null;
    }
    Ne(() => {
      if (Ie(), O)
        throw O;
    });
  }
  const A = {
    onUpdate: w,
    onStart: D,
    onAdd: h,
    onRemove: _,
    onEnd: W
  };
  function $(m) {
    const b = V(i);
    return m || (m = gn(b) ? vn(b, o == null ? void 0 : o.$el) : b), m && !yn(m) && (m = m.$el), m || dn("Root element not found"), m;
  }
  function P() {
    var m;
    const b = (m = V(s)) != null ? m : {}, { immediate: I, clone: j } = b, E = Re(b, ["immediate", "clone"]);
    return we(E, (O, Y) => {
      wn(O) && (E[O] = (k, ...G) => {
        const nt = Zn();
        return Sn(k, nt), Y(k, ...G);
      });
    }), bn(
      a === null ? {} : A,
      E
    );
  }
  const K = (m) => {
    m = $(m), l && R.destroy(), l = new g(m, P());
  };
  an(
    () => s,
    () => {
      l && we(P(), (m, b) => {
        l == null || l.option(m, b);
      });
    },
    { deep: !0 }
  );
  const R = {
    option: (m, b) => l == null ? void 0 : l.option(m, b),
    destroy: () => {
      l == null || l.destroy(), l = null;
    },
    save: () => l == null ? void 0 : l.save(),
    toArray: () => l == null ? void 0 : l.toArray(),
    closest: (...m) => l == null ? void 0 : l.closest(...m)
  }, et = () => R == null ? void 0 : R.option("disabled", !0), ut = () => R == null ? void 0 : R.option("disabled", !1);
  return Jn(() => {
    d && K();
  }), $n(R.destroy), vt({ start: K, pause: et, resume: ut }, R);
}
const se = [
  "update",
  "start",
  "add",
  "remove",
  "choose",
  "unchoose",
  "end",
  "sort",
  "filter",
  "clone",
  "move",
  "change"
], Qn = [
  "clone",
  "animation",
  "ghostClass",
  "group",
  "sort",
  "disabled",
  "store",
  "handle",
  "draggable",
  "swapThreshold",
  "invertSwap",
  "invertedSwapThreshold",
  "removeCloneOnHide",
  "direction",
  "chosenClass",
  "dragClass",
  "ignore",
  "filter",
  "preventOnFilter",
  "easing",
  "setData",
  "dropBubble",
  "dragoverBubble",
  "dataIdAttr",
  "delay",
  "delayOnTouchOnly",
  "touchStartThreshold",
  "forceFallback",
  "fallbackClass",
  "fallbackOnBody",
  "fallbackTolerance",
  "fallbackOffset",
  "supportPointer",
  "emptyInsertThreshold",
  "scroll",
  "forceAutoScrollFallback",
  "scrollSensitivity",
  "scrollSpeed",
  "bubbleScroll",
  "modelValue",
  "tag",
  "target",
  "customUpdate",
  ...se.map((t) => `on${t.replace(/^\S/, (n) => n.toUpperCase())}`)
], eo = tn({
  name: "VueDraggable",
  model: {
    prop: "modelValue",
    event: "update:modelValue"
  },
  props: Qn,
  emits: ["update:modelValue", ...se],
  setup(t, { slots: n, emit: e, expose: o, attrs: r }) {
    const i = se.reduce((c, f) => {
      const D = `on${f.replace(/^\S/, (h) => h.toUpperCase())}`;
      return c[D] = (...h) => e(f, ...h), c;
    }, {}), a = pe(() => {
      const c = en(t), { modelValue: f } = c, D = Re(c, ["modelValue"]), h = Object.entries(D).reduce((_, [w, W]) => {
        const A = V(W);
        return A !== void 0 && (_[w] = A), _;
      }, {});
      return vt(vt({}, i), hn(vt(vt({}, r), h)));
    }), s = pe({
      get: () => t.modelValue,
      set: (c) => e("update:modelValue", c)
    }), l = nn(), d = on(
      Kn(t.target || l, s, a)
    );
    return o(d), () => {
      var c;
      return rn(t.tag || "div", { ref: l }, (c = n == null ? void 0 : n.default) == null ? void 0 : c.call(n, d));
    };
  }
});
export {
  eo as l
};
