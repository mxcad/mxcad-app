import { av as C, aw as U, ax as $, ay as F, az as G, aA as K, aB as j, aC as k, aD as B, aE as H, aF as M, aG as Y, aH as L, aI as q, aJ as z, aK as J, aL as Q, aM as V, aN as X, aO as Z, aP as W, aQ as ee } from "./lib.js";
var re = C.f, ae = function(t, r, e) {
  e in t || re(t, e, {
    configurable: !0,
    get: function() {
      return r[e];
    },
    set: function(i) {
      r[e] = i;
    }
  });
}, te = H, p = G, y = K, ie = B, ne = X, se = Z, oe = W, ve = U.f, I = z, ce = J, O = V, ue = Q, m = j, le = ae, fe = L, de = k, he = ee, Se = $.enforce, ye = q, ge = F, D = M, T = Y, Ee = ge("match"), u = p.RegExp, d = u.prototype, Pe = p.SyntaxError, xe = y(d.exec), E = y("".charAt), R = y("".replace), w = y("".indexOf), N = y("".slice), pe = /^\?<[^\s\d!#%&*+<=>@^][^\s!#%&*+<=>@^]*>/, f = /a/g, x = /a/g, Ie = new u(f) !== f, _ = m.MISSED_STICKY, Oe = m.UNSUPPORTED_Y, Re = te && (!Ie || _ || D || T || de(function() {
  return x[Ee] = !1, u(f) !== f || u(x) === x || String(u(f, "i")) !== "/a/i";
})), we = function(t) {
  for (var r = t.length, e = 0, i = "", o = !1, n; e <= r; e++) {
    if (n = E(t, e), n === "\\") {
      i += n + E(t, ++e);
      continue;
    }
    !o && n === "." ? i += "[\\s\\S]" : (n === "[" ? o = !0 : n === "]" && (o = !1), i += n);
  }
  return i;
}, Ne = function(t) {
  for (var r = t.length, e = 0, i = "", o = [], n = oe(null), c = !1, v = !1, h = 0, s = "", a; e <= r; e++) {
    if (a = E(t, e), a === "\\")
      a += E(t, ++e);
    else if (a === "]")
      c = !1;
    else if (!c) switch (!0) {
      case a === "[":
        c = !0;
        break;
      case a === "(":
        if (i += a, N(t, e + 1, e + 3) === "?:")
          continue;
        xe(pe, N(t, e + 1)) && (e += 2, v = !0), h++;
        continue;
      case (a === ">" && v):
        if (s === "" || he(n, s))
          throw new Pe("Invalid capture group name");
        n[s] = !0, o[o.length] = [s, h], v = !1, s = "";
        continue;
    }
    v ? s += a : i += a;
  }
  return [i, o];
};
if (ie("RegExp", Re)) {
  for (var l = function(r, e) {
    var i = I(d, this), o = ce(r), n = e === void 0, c = [], v = r, h, s, a, P, g, S;
    if (!i && o && n && r.constructor === l)
      return r;
    if ((o || I(d, r)) && (r = r.source, n && (e = ue(v))), r = r === void 0 ? "" : O(r), e = e === void 0 ? "" : O(e), v = r, D && "dotAll" in f && (s = !!e && w(e, "s") > -1, s && (e = R(e, /s/g, ""))), h = e, _ && "sticky" in f && (a = !!e && w(e, "y") > -1, a && Oe && (e = R(e, /y/g, ""))), T && (P = Ne(r), r = P[0], c = P[1]), g = ne(u(r, e), i ? this : d, l), (s || a || c.length) && (S = Se(g), s && (S.dotAll = !0, S.raw = l(we(r), h)), a && (S.sticky = !0), c.length && (S.groups = c)), r !== v) try {
      se(g, "source", v === "" ? "(?:)" : v);
    } catch (be) {
    }
    return g;
  }, b = ve(u), A = 0; b.length > A; )
    le(l, u, b[A++]);
  d.constructor = l, l.prototype = d, fe(p, "RegExp", l, { constructor: !0 });
}
ye("RegExp");
