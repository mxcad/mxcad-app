import { ap as C, aq as U, ar as $, as as F, at as G, au as K, av as j, aw as k, ax as B, ay as H, az as Y, aA as q, aB as M, aC as L, aD as z, aE as J, aF as Q, aG as V, aH as X, aI as Z, aJ as W, aK as rr } from "./lib.js";
var er = C.f, ar = function(t, e, r) {
  r in t || er(t, r, {
    configurable: !0,
    get: function() {
      return e[r];
    },
    set: function(i) {
      e[r] = i;
    }
  });
}, tr = H, p = G, y = K, ir = B, nr = X, sr = Z, or = W, vr = U.f, I = z, cr = J, R = V, ur = Q, m = j, lr = ar, fr = M, dr = k, hr = rr, Sr = $.enforce, yr = L, gr = F, D = Y, T = q, Er = gr("match"), u = p.RegExp, d = u.prototype, xr = p.SyntaxError, Pr = y(d.exec), E = y("".charAt), w = y("".replace), O = y("".indexOf), b = y("".slice), pr = /^\?<[^\s\d!#%&*+<=>@^][^\s!#%&*+<=>@^]*>/, f = /a/g, P = /a/g, Ir = new u(f) !== f, _ = m.MISSED_STICKY, Rr = m.UNSUPPORTED_Y, wr = tr && (!Ir || _ || D || T || dr(function() {
  return P[Er] = !1, u(f) !== f || u(P) === P || String(u(f, "i")) !== "/a/i";
})), Or = function(t) {
  for (var e = t.length, r = 0, i = "", o = !1, n; r <= e; r++) {
    if (n = E(t, r), n === "\\") {
      i += n + E(t, ++r);
      continue;
    }
    !o && n === "." ? i += "[\\s\\S]" : (n === "[" ? o = !0 : n === "]" && (o = !1), i += n);
  }
  return i;
}, br = function(t) {
  for (var e = t.length, r = 0, i = "", o = [], n = or(null), c = !1, v = !1, h = 0, s = "", a; r <= e; r++) {
    if (a = E(t, r), a === "\\")
      a += E(t, ++r);
    else if (a === "]")
      c = !1;
    else if (!c) switch (!0) {
      case a === "[":
        c = !0;
        break;
      case a === "(":
        if (i += a, b(t, r + 1, r + 3) === "?:")
          continue;
        Pr(pr, b(t, r + 1)) && (r += 2, v = !0), h++;
        continue;
      case (a === ">" && v):
        if (s === "" || hr(n, s))
          throw new xr("Invalid capture group name");
        n[s] = !0, o[o.length] = [s, h], v = !1, s = "";
        continue;
    }
    v ? s += a : i += a;
  }
  return [i, o];
};
if (ir("RegExp", wr)) {
  for (var l = function(e, r) {
    var i = I(d, this), o = cr(e), n = r === void 0, c = [], v = e, h, s, a, x, g, S;
    if (!i && o && n && e.constructor === l)
      return e;
    if ((o || I(d, e)) && (e = e.source, n && (r = ur(v))), e = e === void 0 ? "" : R(e), r = r === void 0 ? "" : R(r), v = e, D && "dotAll" in f && (s = !!r && O(r, "s") > -1, s && (r = w(r, /s/g, ""))), h = r, _ && "sticky" in f && (a = !!r && O(r, "y") > -1, a && Rr && (r = w(r, /y/g, ""))), T && (x = br(e), e = x[0], c = x[1]), g = nr(u(e, r), i ? this : d, l), (s || a || c.length) && (S = Sr(g), s && (S.dotAll = !0, S.raw = l(Or(e), h)), a && (S.sticky = !0), c.length && (S.groups = c)), e !== v) try {
      sr(g, "source", v === "" ? "(?:)" : v);
    } catch (Ar) {
    }
    return g;
  }, A = vr(u), N = 0; A.length > N; )
    lr(l, u, A[N++]);
  d.constructor = l, l.prototype = d, fr(p, "RegExp", l, { constructor: !0 });
}
yr("RegExp");
