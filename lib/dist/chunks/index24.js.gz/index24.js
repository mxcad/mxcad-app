import { bH as v, bI as V, bJ as u, a6 as l, bK as r, Z as b, bL as k, bM as D, R as S } from "./lib.js";
import { d as w, i as z, m as P, o as f, w as t, l as c, a as o, c as h, F as B, b as C, G as s, p as R, q as d, t as m, Q as _ } from "./vue.js";
import { b as E, i as I, S as M, T as x } from "./vuetify.js";
var L = {
  class: "px-3"
}, F = {
  class: "d-flex flex-wrap justify-center"
}, N = ["onClick"], T = {
  class: "d-flex flex-column"
};
const U = /* @__PURE__ */ w({
  __name: "index",
  setup: function(G) {
    var i = v.isShow, p = v.showDialog, y = [{
      name: "确定",
      fun: function() {
        D(), p(!1);
      },
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        p(!1);
      }
    }], g = ["xiaodian", "", "shizi", "cha", "daunshuxian", "yuanshangyidian", "yuan", "yuanzhonshizi", "yuanzhoncha", "yuanzhonbanshuxian", "fangkuangdain", "fangkuang", "shizikuang1", "fangkuangchaocha", "fangkuangyishangshuxian", "a-1", "a-2", "a-3", "a-4", "a-5"].map(function(a, e) {
      return {
        icon: a,
        value: k[e]
      };
    });
    return z(i, function(a) {
      a && V();
    }), function(a, e) {
      return f(), P(b, {
        title: a.t("222"),
        "max-width": "240",
        modelValue: s(i),
        "onUpdate:modelValue": e[2] || (e[2] = function(n) {
          return _(i) ? i.value = n : null;
        }),
        footerBtnList: y
      }, {
        default: t(function() {
          return [c("div", L, [c("div", F, [(f(!0), h(B, null, C(s(g), function(n) {
            return f(), h("div", {
              class: R(["mx-1 mt-2 box-point-style", n.value === s(u).PDMODE ? "active" : ""]),
              onClick: function($) {
                return s(u).PDMODE = n.value;
              }
            }, [o(E, {
              size: "20px",
              icon: "class:iconfont " + n.icon
            }, null, 8, ["icon"])], 10, N);
          }), 256))]), o(I, {
            class: "mt-2 ml-1 w-75",
            type: "number",
            modelValue: s(u).PDSIZE,
            "onUpdate:modelValue": e[0] || (e[0] = function(n) {
              return s(u).PDSIZE = n;
            })
          }, {
            prepend: t(function() {
              return [o(l, {
                class: "",
                "key-name": "S"
              }, {
                default: t(function() {
                  return [d(m(a.t("2049")), 1)];
                }),
                _: 1
              })];
            }),
            _: 1
          }, 8, ["modelValue"]), o(M, {
            column: "",
            class: "mt-2",
            modelValue: s(r),
            "onUpdate:modelValue": e[1] || (e[1] = function(n) {
              return _(r) ? r.value = n : null;
            })
          }, {
            default: t(function() {
              return [c("div", T, [o(x, {
                value: !0,
                class: "mt-1"
              }, {
                label: t(function() {
                  return [o(l, {
                    class: "",
                    "key-name": "R"
                  }, {
                    default: t(function() {
                      return [d(m(a.t("2050")), 1)];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              }), o(x, {
                value: !1,
                class: "mt-1"
              }, {
                label: t(function() {
                  return [o(l, {
                    class: "",
                    "key-name": "A"
                  }, {
                    default: t(function() {
                      return [d(m(a.t("2051")), 1)];
                    }),
                    _: 1
                  })];
                }),
                _: 1
              })])];
            }),
            _: 1
          }, 8, ["modelValue"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), H = /* @__PURE__ */ S(U, [["__scopeId", "data-v-0cb1d074"]]);
export {
  H as default
};
