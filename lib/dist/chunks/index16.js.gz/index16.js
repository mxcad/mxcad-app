import { J as ue, aW as ce, $ as Y, T as Z, b3 as B, ae as N, b4 as de, ak as ve, b5 as K, x as me } from "./lib.js";
import { d as I, f as R, m as W, o as s, w as _, l as e, a as c, t as o, c as r, F as A, b as O, G as a, p as ee, Q as te, i as pe, g as fe, ah as P, A as f, q as w, y as X, s as _e, af as he, n as ge, k as ke } from "./vue.js";
import { s as Ce } from "./pinia.js";
import { _ as ne, i as Le, b as M, R as C, c as ye, f as be } from "./vuetify.js";
import { u as we } from "./hooks2.js";
import { b as xe } from "./@vueuse/core.js";
var De = function() {
  var x = ue(), k = x.createLineType;
  x.initLineTypeList;
  var l = Ce(x), D = l.lineTypeList;
  return {
    lineTypeList: D,
    createLineType: k
  };
}, Te = {
  class: "mt-2"
}, Ve = {
  class: "text-center"
}, Se = {
  class: "text-center"
}, $e = {
  class: "text-center"
}, Me = ["onClick"];
const Re = /* @__PURE__ */ I({
  __name: "index",
  emits: ["change"],
  setup: function(x, k) {
    var l = k.expose, D = k.emit, L = De(), T = L.lineTypeList, y = R(0), V = ce(!1), S = V.isShow, $ = V.showDialog, j = V.onReveal, F = D, z = [{
      name: "确定",
      fun: function() {
        F("change", T.value[y.value]), $(!1);
      },
      primary: !0
    }, {
      name: "取消",
      fun: function() {
        return $(!1);
      }
    }];
    return j(function(d) {
      y.value = T.value.findIndex(function(b) {
        return b.name === d.name;
      });
    }), l({
      showDialog: $
    }), function(d, b) {
      return s(), W(Y, {
        title: d.t("2300"),
        "max-width": "500",
        modelValue: a(S),
        "onUpdate:modelValue": b[0] || (b[0] = function(h) {
          return te(S) ? S.value = h : null;
        }),
        footerBtnList: z
      }, {
        default: _(function() {
          return [e("div", Te, [e("p", null, o(d.t("2301")), 1), c(ne, {
            height: "300"
          }, {
            default: _(function() {
              return [e("thead", null, [e("tr", null, [e("th", Ve, o(d.t("218")), 1), e("th", Se, o(d.t("2302")), 1), e("th", $e, o(d.t("1970")), 1)])]), e("tbody", null, [(s(!0), r(A, null, O(a(T), function(h, U) {
                return s(), r("tr", {
                  key: h.id,
                  class: ee(y.value === U ? "active" : ""),
                  onClick: function(G) {
                    return y.value = U;
                  }
                }, [e("td", null, o(h.name), 1), e("td", null, o(h.explain), 1), e("td", null, o(h.appearance), 1)], 10, Me);
              }), 128))])];
            }),
            _: 1
          })])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
}), Ue = /* @__PURE__ */ Z(Re, [["__scopeId", "data-v-964f83a9"]]);
var Be = {
  class: "d-flex align-center"
}, Ne = {
  class: "d-flex align-center my-2"
}, We = {
  class: "w-100"
}, Ae = {
  class: "w-100"
}, je = {
  class: "w-20"
}, Fe = {
  class: ""
}, ze = {
  class: ""
}, Ee = {
  class: ""
}, Oe = {
  class: "w-20"
}, qe = {
  class: "w-20"
}, He = {
  class: "w-20"
}, Ge = {
  class: "w-100",
  ref: "tbody"
}, Je = ["id", "onClick", "onContextmenu"], Qe = {
  class: "text-no-wrap"
}, Ke = {
  style: {
    width: "18px"
  },
  class: "d-inline-block"
}, Pe = ["for"], Xe = ["disabled", "id", "onClick", "onUpdate:modelValue"], Ye = ["onClick"], Ze = ["onClick"], Ie = ["onClick"], et = ["onClick"], tt = ["onClick"], nt = {
  class: "w-20 text-truncate"
}, it = {
  class: "w-100 my-3",
  cellpadding: "20"
}, at = {
  class: "w-100"
}, lt = {
  class: "w-100"
}, ot = {
  class: "w-auto px-6"
}, st = {
  class: "d-flex justify-end w-auto"
};
const rt = /* @__PURE__ */ I({
  __name: "index",
  setup: function(x) {
    var k = R(), l = we({
      onAddLayer: function() {
        var n, v = (n = k.value) === null || n === void 0 ? void 0 : n.$el, g = v.getElementsByClassName("v-table__wrapper")[0];
        ke(function() {
          g.scrollTo({
            top: g.scrollHeight - g.clientHeight,
            behavior: "smooth"
          });
        });
      }
    }), D = l.onClickLayer, L = l.onClickStopTD, T = l.onClickLayerName, y = l.resumeIndex, V = l.reverseSelection, S = l.selectColor, $ = l.selectLineType, j = l.setIndex, F = l.onRightClickLayer, z = l.initLayerList, d = l.setLayerList, b = l.list, h = l.bodyRightClickMenuOptions, U = l.btnList, H = l.rootId, G = l.clearAllSelect;
    pe(B, function(i) {
      !i && G();
    }), z();
    var J = R([]), ie = function(n) {
      var v = n(J.value, function(t, m) {
        return m;
      }), g = v.map;
      g.length > 0 && j(g);
    }, Q = R(), ae = function(n) {
      var v;
      (v = Q.value) === null || v === void 0 || v.showDialog(!0, n);
    }, E = R(""), le = xe(function(i) {
      i === null && (i = ""), E.value = i;
    }, 500), oe = fe(function() {
      return b.value.filter(function(i) {
        return i.name.toLowerCase().includes(E.value.toLowerCase());
      });
    }), se = ve(), re = function(n, v) {
      L(new MouseEvent("click"), n, "lineWeight", v);
    };
    return function(i, n) {
      var v = P("box-selection"), g = P("right-click-menu");
      return s(), r(A, null, [c(Y, {
        maxWidth: "900",
        ref: "layerDialog",
        modelValue: a(B),
        "onUpdate:modelValue": n[4] || (n[4] = function(t) {
          return te(B) ? B.value = t : null;
        }),
        title: i.t("2000")
      }, {
        actions: _(function() {
          return me(n[9] || (n[9] = [e("div", {
            class: "mt-1"
          }, null, -1)]));
        }),
        default: _(function() {
          return [e("div", Be, [e("div", Ne, [(s(!0), r(A, null, O(a(U), function(t, m) {
            return s(), W(N, {
              onClick: t.fun,
              class: "mx-2 px-2",
              key: t.name + m
            }, {
              default: _(function() {
                return [w(o(i.t(t.name)), 1)];
              }),
              _: 2
            }, 1032, ["onClick"]);
          }), 128))]), c(Le, {
            "model-values": E.value,
            "onUpdate:modelValue": a(le),
            class: "pa-1",
            clearable: "",
            density: "compact",
            label: i.t("2001"),
            variant: "solo",
            "hide-details": "",
            "single-line": ""
          }, {
            "append-inner": _(function() {
              return [c(M, {
                icon: "$mdi-magnify",
                class: "v-icon--clickable"
              })];
            }),
            _: 1
          }, 8, ["model-values", "onUpdate:modelValue", "label"])]), f((s(), W(a(ne), {
            class: "w-100 layer-table",
            height: "300",
            ref_key: "boxRef",
            ref: k,
            onClick: n[0] || (n[0] = function(t) {
              return a(y)();
            })
          }, {
            default: _(function() {
              return [e("thead", We, [e("tr", Ae, [e("th", je, [n[5] || (n[5] = e("div", {
                style: {
                  width: "10px"
                },
                class: "d-inline-block"
              }, null, -1)), n[6] || (n[6] = w()), e("span", null, o(i.t("196") + i.t("1923")), 1)]), e("th", Fe, o(i.t("2002")), 1), e("th", ze, o(i.t("2003")), 1), e("th", Ee, o(i.t("203")), 1), e("th", Oe, o(i.t("210")), 1), e("th", qe, o(i.t("217")), 1), e("th", He, o(i.t("1810")), 1)])]), f((s(), r("tbody", Ge, [(s(!0), r(A, null, O(oe.value, function(t, m) {
                return s(), r("tr", {
                  class: ee(["text-center layer-info", t.isSelect ? "active" : ""]),
                  ref_for: !0,
                  ref_key: "refItems",
                  ref: J,
                  key: t.id,
                  id: t.id.toString(),
                  onClick: X(function(p) {
                    return a(D)(m);
                  }, ["prevent"]),
                  onContextmenu: X(function(p) {
                    return a(F)(m, p);
                  }, ["prevent"])
                }, [f((s(), r("td", Qe, [e("div", Ke, [t.status ? (s(), W(M, {
                  key: 0,
                  icon: "class:iconfont gou",
                  size: "x-small",
                  color: "#16FD21"
                })) : _e("", !0)]), e("label", {
                  class: "d-inline-block",
                  for: t.id.toString()
                }, [f(e("input", {
                  disabled: t.id === a(H),
                  id: t.id.toString(),
                  class: "text-truncate text-center",
                  type: "text",
                  onClick: function(u) {
                    return a(T)(u, m);
                  },
                  "onUpdate:modelValue": function(u) {
                    return t.name = u;
                  }
                }, null, 8, Xe), [[he, t.name]])], 8, Pe)])), [[C]]), f((s(), r("td", {
                  class: "text-orange",
                  onClick: function(u) {
                    return a(L)(u, t, "visible", !t.visible, m);
                  }
                }, [c(M, {
                  icon: t.visible ? "yanjing1" : "yanjing"
                }, null, 8, ["icon"])], 8, Ye)), [[C, void 0, void 0, {
                  prevent: !0
                }]]), f((s(), r("td", {
                  class: "text-orange",
                  onClick: function(u) {
                    return a(L)(u, t, "lock", !t.lock, m);
                  }
                }, [c(M, {
                  icon: t.lock ? "suo" : "jiesuo1"
                }, null, 8, ["icon"])], 8, Ze)), [[C]]), f((s(), r("td", {
                  onClick: function(u) {
                    return a(L)(u, t, "print", !t.print, m);
                  }
                }, [c(M, {
                  icon: t.print ? "dayin" : "budayinbiaoqian"
                }, null, 8, ["icon"])], 8, Ie)), [[C]]), f((s(), r("td", {
                  class: "d-flex align-center justify-center",
                  onClick: function(u) {
                    return a(S)(t.color);
                  }
                }, [e("div", {
                  class: "colorBox mr-2",
                  style: ge({
                    background: "".concat(t.color.color)
                  })
                }, null, 4), e("span", null, o(a(de)(t.color.name)), 1)], 8, et)), [[C]]), f((s(), r("td", {
                  class: "w-20 text-truncate",
                  onClick: function(u) {
                    return ae(t.lineType);
                  }
                }, [w(o(t.lineType.name), 1)], 8, tt)), [[C]]), f((s(), r("td", nt, [c(ye, {
                  items: a(se),
                  "item-title": "name",
                  "bg-color": "transparent",
                  "model-value": t.lineWeight,
                  "onUpdate:modelValue": function(u) {
                    return re(t, u);
                  }
                }, null, 8, ["items", "model-value", "onUpdate:modelValue"])])), [[C]])], 42, Je);
              }), 128))])), [[v, ie]])];
            }),
            _: 1
          })), [[g, a(h)]]), c(be, {
            color: "#576375",
            class: "border-opacity-75"
          }), e("table", it, [e("thead", at, [e("tr", lt, [n[7] || (n[7] = e("th", {
            class: "w-20"
          }, null, -1)), e("th", ot, [c(N, {
            onClick: n[1] || (n[1] = function(t) {
              return a(V)();
            })
          }, {
            default: _(function() {
              return [w(o(i.t("2005")), 1)];
            }),
            _: 1
          })]), n[8] || (n[8] = e("th", {
            class: "w-50"
          }, null, -1)), e("th", st, [c(N, {
            isAction: "",
            primary: "",
            onClick: n[2] || (n[2] = function(t) {
              return a(d)(), a(K)(!1);
            })
          }, {
            default: _(function() {
              return [w(o(i.t("1829")), 1)];
            }),
            _: 1
          }), c(N, {
            class: "ml-10 mr-6",
            onClick: n[3] || (n[3] = function(t) {
              return a(K)();
            })
          }, {
            default: _(function() {
              return [w(o(i.t("2006")), 1)];
            }),
            _: 1
          })])])])])];
        }),
        _: 1
      }, 8, ["modelValue", "title"]), c(Ue, {
        ref_key: "linearManager",
        ref: Q,
        onChange: a($)
      }, null, 8, ["onChange"])], 64);
    };
  }
}), ft = /* @__PURE__ */ Z(rt, [["__scopeId", "data-v-53e30ecd"]]);
export {
  ft as default
};
