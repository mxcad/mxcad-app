import { f as E, d as S, i as U, m as R, o as B, w as c, l as g, a as T, Q as w, G as C, t as h } from "./vue.js";
import { c7 as m, w as F, b as k, _ as V, a as v, c8 as G, t as D, a7 as H, $ as L } from "./lib.js";
import { f as N } from "./mxdraw.js";
import { j as O, x as X, l as A, M as y, F as _, O as j, p as z, s as I, h as Q } from "./mxcad.js";
import { ac as Y, i as $ } from "./vuetify.js";
var l = E(""), d = E(0), x = m.isShow, M = m.showDialog, q = m.confirm, J = m.onReveal, P = m.onConfirm;
J(function() {
  var o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  typeof o.text == "string" && (l.value = o.text), typeof o.angle == "number" && (d.value = F(THREE.MathUtils.radToDeg(o.angle), 2));
});
var K = /* @__PURE__ */ function() {
  var o = V(/* @__PURE__ */ v.mark(function f() {
    var s, i, u, e, r, a;
    return v.wrap(function(n) {
      for (; ; ) switch (n.prev = n.next) {
        case 0:
          return s = new Q(), s.setMessage(D("2105") + ":"), s.setCursorType(N.kCross), n.next = 1, s.go();
        case 1:
          if (i = n.sent, i) {
            n.next = 2;
            break;
          }
          return n.abrupt("return");
        case 2:
          return u = new I(), u.setMessage(D("2106") + ":"), n.next = 3, u.go();
        case 3:
          if (e = n.sent, e !== null) {
            n.next = 4;
            break;
          }
          return n.abrupt("return");
        case 4:
          return r = P(function(p) {
            var t = new A();
            t.textString = p.text, t.position = new z(i), t.alignmentPoint = t.position, t.height = e, t.rotation = p.angle, y.getCurrentMxCAD().drawEntity(t), y.getCurrentMxCAD().updateDisplay(), a();
          }), a = r.off, n.next = 5, M(!0, {
            text: "测试"
          });
        case 5:
          a();
        case 6:
        case "end":
          return n.stop();
      }
    }, f);
  }));
  return function() {
    return o.apply(this, arguments);
  };
}(), W = /* @__PURE__ */ function() {
  var o = V(/* @__PURE__ */ v.mark(function f() {
    var s, i, u, e, r, a, n, p;
    return v.wrap(function(t) {
      for (; ; ) switch (t.prev = t.next) {
        case 0:
          return s = new _(), s.AddMcDbEntityTypes("TEXT,MTEXT,CUSTOMENTITY"), i = new j(), i.setFilter(s), i.setMessage(D("2107")), t.next = 1, i.go();
        case 1:
          if (u = t.sent, u.isValid()) {
            t.next = 2;
            break;
          }
          return t.abrupt("return");
        case 2:
          if (e = u.getMcDbEntity(), e) {
            t.next = 3;
            break;
          }
          return t.abrupt("return");
        case 3:
          if (!(e instanceof A)) {
            t.next = 5;
            break;
          }
          return r = e.textString, a = e.rotation, n = P(function(b) {
            e.textString = b.text, e.rotation = b.angle, y.getCurrentMxCAD().updateDisplay(), p();
          }), p = n.off, t.next = 4, M(!0, {
            text: r,
            angle: a
          });
        case 4:
          p(), t.next = 6;
          break;
        case 5:
          (e instanceof O || e instanceof X) && G(u, i.pickPoint());
        case 6:
        case "end":
          return t.stop();
      }
    }, f);
  }));
  return function() {
    return o.apply(this, arguments);
  };
}();
k("Mx_EditText", W);
k("_DrawText", function() {
  K();
});
var Z = {
  class: "px-3"
}, ee = {
  class: "px-2"
}, te = {
  class: ""
}, ne = {
  class: ""
};
const oe = /* @__PURE__ */ S({
  __name: "index",
  setup: function(f) {
    U(x, function(e) {
      e || (l.value = "", d.value = 0);
    });
    var s = function() {
      q({
        text: l.value,
        angle: THREE.MathUtils.degToRad(d.value)
      }), l.value = "";
    }, i = [{
      name: "确定",
      fun: function() {
        s();
      },
      primary: !0
    }, {
      name: "关闭",
      fun: function() {
        return M(!1);
      }
    }], u = {
      esc: function() {
        return M(!1);
      },
      enter: function() {
        s();
      }
    };
    return function(e, r) {
      return B(), R(L, {
        title: e.t("227"),
        "max-width": "480",
        modelValue: C(x),
        "onUpdate:modelValue": r[2] || (r[2] = function(a) {
          return w(x) ? x.value = a : null;
        }),
        footerBtnList: i,
        persistent: "",
        keys: u
      }, {
        default: c(function() {
          return [g("div", Z, [T(H, {
            title: e.t("2109")
          }, {
            default: c(function() {
              return [g("div", ee, [T(Y, {
                class: "mt-1",
                modelValue: C(l),
                "onUpdate:modelValue": r[0] || (r[0] = function(a) {
                  return w(l) ? l.value = a : null;
                }),
                autofocus: "",
                rows: "3",
                "no-resize": ""
              }, {
                prepend: c(function() {
                  return [g("span", te, h(e.t("2039")) + ":", 1)];
                }),
                _: 1
              }, 8, ["modelValue"]), T($, {
                class: "mt-1 w-50",
                modelValue: C(d),
                "onUpdate:modelValue": r[1] || (r[1] = function(a) {
                  return w(d) ? d.value = a : null;
                }),
                type: "number"
              }, {
                prepend: c(function() {
                  return [g("span", ne, h(e.t("1931")) + ":", 1)];
                }),
                _: 1
              }, 8, ["modelValue"])])];
            }),
            _: 1
          }, 8, ["title"])])];
        }),
        _: 1
      }, 8, ["title", "modelValue"]);
    };
  }
});
export {
  oe as default
};
