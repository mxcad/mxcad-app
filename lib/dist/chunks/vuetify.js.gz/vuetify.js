var _d = Object.defineProperty, Ad = Object.defineProperties;
var Ld = Object.getOwnPropertyDescriptors;
var Wa = Object.getOwnPropertySymbols;
var Go = Object.prototype.hasOwnProperty, Uo = Object.prototype.propertyIsEnumerable;
var Le = Math.pow, Yo = (e, n, t) => n in e ? _d(e, n, { enumerable: !0, configurable: !0, writable: !0, value: t }) : e[n] = t, v = (e, n) => {
  for (var t in n || (n = {}))
    Go.call(n, t) && Yo(e, t, n[t]);
  if (Wa)
    for (var t of Wa(n))
      Uo.call(n, t) && Yo(e, t, n[t]);
  return e;
}, le = (e, n) => Ad(e, Ld(n));
var Ge = (e, n) => {
  var t = {};
  for (var a in e)
    Go.call(e, a) && n.indexOf(a) < 0 && (t[a] = e[a]);
  if (e != null && Wa)
    for (var a of Wa(e))
      n.indexOf(a) < 0 && Uo.call(e, a) && (t[a] = e[a]);
  return t;
};
var He = (e, n, t) => new Promise((a, l) => {
  var i = (u) => {
    try {
      r(t.next(u));
    } catch (c) {
      l(c);
    }
  }, o = (u) => {
    try {
      r(t.throw(u));
    } catch (c) {
      l(c);
    }
  }, r = (u) => u.done ? a(u.value) : Promise.resolve(u.value).then(i, o);
  r((t = t.apply(e, n)).next());
});
import { i as oe, N as tt, U as Hn, h as yt, E as We, S as M, Y as qn, F as he, Z as Td, _ as Bd, J as te, G as Tt, $ as ji, a0 as dl, H as Dd, W as Pe, g as C, a1 as Oe, f as Q, d as Md, D as Vn, P as Ue, V as Xn, a2 as st, a as k, l as w, x as G, p as X, M as pd, I as dt, O as vl, j as gt, a3 as St, a4 as nu, a5 as Ed, k as Ve, n as ie, a6 as Yi, a7 as en, Q as Jl, a8 as _a, A as Re, B as $t, a9 as $d, aa as Fd, C as Od, t as hn, K as Nd, T as Rd, ab as Hd, q as Nt, ac as zd, ad as Wd, u as jd, ae as Yd, y as ja, af as Gd } from "./vue.js";
function mt(e, n) {
  let t;
  function a() {
    t = Hn(), t.run(() => n.length ? n(() => {
      t == null || t.stop(), a();
    }) : n());
  }
  oe(e, (l) => {
    l && !t ? a() : l || (t == null || t.stop(), t = void 0);
  }, {
    immediate: !0
  }), tt(() => {
    t == null || t.stop();
  });
}
const Te = typeof window != "undefined", Gi = Te && "IntersectionObserver" in window, Ud = Te && ("ontouchstart" in window || window.navigator.maxTouchPoints > 0), Ko = Te && "EyeDropper" in window, Kd = Te && "matchMedia" in window && typeof window.matchMedia == "function";
function qo(e, n, t) {
  qd(e, n), n.set(e, t);
}
function qd(e, n) {
  if (n.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
}
function Xo(e, n, t) {
  return e.set(au(e, n), t), t;
}
function Gt(e, n) {
  return e.get(au(e, n));
}
function au(e, n, t) {
  if (typeof e == "function" ? e === n : e.has(n)) return arguments.length < 3 ? n : t;
  throw new TypeError("Private element is not present on this object");
}
function lu(e, n, t) {
  const a = n.length - 1;
  if (a < 0) return e === void 0 ? t : e;
  for (let l = 0; l < a; l++) {
    if (e == null)
      return t;
    e = e[n[l]];
  }
  return e == null || e[n[a]] === void 0 ? t : e[n[a]];
}
function at(e, n) {
  if (e === n) return !0;
  if (e instanceof Date && n instanceof Date && e.getTime() !== n.getTime() || e !== Object(e) || n !== Object(n))
    return !1;
  const t = Object.keys(e);
  return t.length !== Object.keys(n).length ? !1 : t.every((a) => at(e[a], n[a]));
}
function yn(e, n, t) {
  return e == null || !n || typeof n != "string" ? t : e[n] !== void 0 ? e[n] : (n = n.replace(/\[(\w+)\]/g, ".$1"), n = n.replace(/^\./, ""), lu(e, n.split("."), t));
}
function qe(e, n, t) {
  if (n === !0) return e === void 0 ? t : e;
  if (n == null || typeof n == "boolean") return t;
  if (e !== Object(e)) {
    if (typeof n != "function") return t;
    const l = n(e, t);
    return typeof l == "undefined" ? t : l;
  }
  if (typeof n == "string") return yn(e, n, t);
  if (Array.isArray(n)) return lu(e, n, t);
  if (typeof n != "function") return t;
  const a = n(e, t);
  return typeof a == "undefined" ? t : a;
}
function Vt(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  return Array.from({
    length: e
  }, (t, a) => n + a);
}
function ce(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "px";
  if (e == null || e === "")
    return;
  const t = Number(e);
  return isNaN(t) ? String(e) : isFinite(t) ? `${t}${n}` : void 0;
}
function Ja(e) {
  return e !== null && typeof e == "object" && !Array.isArray(e);
}
function Zo(e) {
  let n;
  return e !== null && typeof e == "object" && ((n = Object.getPrototypeOf(e)) === Object.prototype || n === null);
}
function Ui(e) {
  if (e && "$el" in e) {
    const n = e.$el;
    return (n == null ? void 0 : n.nodeType) === Node.TEXT_NODE ? n.nextElementSibling : n;
  }
  return e;
}
const ei = Object.freeze({
  enter: "Enter",
  tab: "Tab",
  delete: "Delete",
  esc: "Escape",
  space: "Space",
  up: "ArrowUp",
  down: "ArrowDown",
  left: "ArrowLeft",
  right: "ArrowRight",
  end: "End",
  home: "Home",
  del: "Delete",
  backspace: "Backspace",
  insert: "Insert",
  pageup: "PageUp",
  pagedown: "PageDown",
  shift: "Shift"
});
function iu(e) {
  return Object.keys(e);
}
function cn(e, n) {
  return n.every((t) => e.hasOwnProperty(t));
}
function qt(e, n) {
  const t = {};
  for (const a of n)
    Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
  return t;
}
function ti(e, n, t) {
  const a = /* @__PURE__ */ Object.create(null), l = /* @__PURE__ */ Object.create(null);
  for (const i in e)
    n.some((o) => o instanceof RegExp ? o.test(i) : o === i) ? a[i] = e[i] : l[i] = e[i];
  return [a, l];
}
function $e(e, n) {
  const t = v({}, e);
  return n.forEach((a) => delete t[a]), t;
}
const ou = /^on[^a-z]/, Ki = (e) => ou.test(e), Xd = ["onAfterscriptexecute", "onAnimationcancel", "onAnimationend", "onAnimationiteration", "onAnimationstart", "onAuxclick", "onBeforeinput", "onBeforescriptexecute", "onChange", "onClick", "onCompositionend", "onCompositionstart", "onCompositionupdate", "onContextmenu", "onCopy", "onCut", "onDblclick", "onFocusin", "onFocusout", "onFullscreenchange", "onFullscreenerror", "onGesturechange", "onGestureend", "onGesturestart", "onGotpointercapture", "onInput", "onKeydown", "onKeypress", "onKeyup", "onLostpointercapture", "onMousedown", "onMousemove", "onMouseout", "onMouseover", "onMouseup", "onMousewheel", "onPaste", "onPointercancel", "onPointerdown", "onPointerenter", "onPointerleave", "onPointermove", "onPointerout", "onPointerover", "onPointerup", "onReset", "onSelect", "onSubmit", "onTouchcancel", "onTouchend", "onTouchmove", "onTouchstart", "onTransitioncancel", "onTransitionend", "onTransitionrun", "onTransitionstart", "onWheel"], Zd = ["ArrowUp", "ArrowDown", "ArrowRight", "ArrowLeft", "Enter", "Escape", "Tab", " "];
function Qd(e) {
  return e.isComposing && Zd.includes(e.key);
}
function an(e) {
  const [n, t] = ti(e, [ou]), a = $e(n, Xd), [l, i] = ti(t, ["class", "style", "id", /^data-/]);
  return Object.assign(l, n), Object.assign(i, a), [l, i];
}
function ze(e) {
  return e == null ? [] : Array.isArray(e) ? e : [e];
}
function ru(e, n) {
  let t = 0;
  const a = function() {
    for (var l = arguments.length, i = new Array(l), o = 0; o < l; o++)
      i[o] = arguments[o];
    clearTimeout(t), t = setTimeout(() => e(...i), Tt(n));
  };
  return a.clear = () => {
    clearTimeout(t);
  }, a.immediate = e, a;
}
function Fe(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1;
  return Math.max(n, Math.min(t, e));
}
function Qo(e) {
  const n = e.toString().trim();
  return n.includes(".") ? n.length - n.indexOf(".") - 1 : 0;
}
function Jo(e, n) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "0";
  return e + t.repeat(Math.max(0, n - e.length));
}
function er(e, n) {
  return (arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "0").repeat(Math.max(0, n - e.length)) + e;
}
function Jd(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1;
  const t = [];
  let a = 0;
  for (; a < e.length; )
    t.push(e.substr(a, n)), a += n;
  return t;
}
function tr(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1e3;
  if (e < n)
    return `${e} B`;
  const t = n === 1024 ? ["Ki", "Mi", "Gi"] : ["k", "M", "G"];
  let a = -1;
  for (; Math.abs(e) >= n && a < t.length - 1; )
    e /= n, ++a;
  return `${e.toFixed(1)} ${t[a]}B`;
}
function vt() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, t = arguments.length > 2 ? arguments[2] : void 0;
  const a = {};
  for (const l in e)
    a[l] = e[l];
  for (const l in n) {
    const i = e[l], o = n[l];
    if (Zo(i) && Zo(o)) {
      a[l] = vt(i, o, t);
      continue;
    }
    if (t && Array.isArray(i) && Array.isArray(o)) {
      a[l] = t(i, o);
      continue;
    }
    a[l] = o;
  }
  return a;
}
function uu(e) {
  return e.map((n) => n.type === he ? uu(n.children) : n).flat();
}
function fn() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
  if (fn.cache.has(e)) return fn.cache.get(e);
  const n = e.replace(/[^a-z]/gi, "-").replace(/\B([A-Z])/g, "-$1").toLowerCase();
  return fn.cache.set(e, n), n;
}
fn.cache = /* @__PURE__ */ new Map();
function Nn(e, n) {
  if (!n || typeof n != "object") return [];
  if (Array.isArray(n))
    return n.map((t) => Nn(e, t)).flat(1);
  if (n.suspense)
    return Nn(e, n.ssContent);
  if (Array.isArray(n.children))
    return n.children.map((t) => Nn(e, t)).flat(1);
  if (n.component) {
    if (Object.getOwnPropertySymbols(n.component.provides).includes(e))
      return [n.component];
    if (n.component.subTree)
      return Nn(e, n.component.subTree).flat(1);
  }
  return [];
}
var En = /* @__PURE__ */ new WeakMap(), un = /* @__PURE__ */ new WeakMap();
class su {
  constructor(n) {
    qo(this, En, []), qo(this, un, 0), this.size = n;
  }
  get isFull() {
    return Gt(En, this).length === this.size;
  }
  push(n) {
    Gt(En, this)[Gt(un, this)] = n, Xo(un, this, (Gt(un, this) + 1) % this.size);
  }
  values() {
    return Gt(En, this).slice(Gt(un, this)).concat(Gt(En, this).slice(0, Gt(un, this)));
  }
  clear() {
    Gt(En, this).length = 0, Xo(un, this, 0);
  }
}
function ev(e) {
  return "touches" in e ? {
    clientX: e.touches[0].clientX,
    clientY: e.touches[0].clientY
  } : {
    clientX: e.clientX,
    clientY: e.clientY
  };
}
function qi(e) {
  const n = yt({});
  We(() => {
    const a = e();
    for (const l in a)
      n[l] = a[l];
  }, {
    flush: "sync"
  });
  const t = {};
  for (const a in n)
    t[a] = M(() => n[a]);
  return t;
}
function el(e, n) {
  return e.includes(n);
}
function cu(e) {
  return e[2].toLowerCase() + e.slice(3);
}
const ot = () => [Function, Array];
function nr(e, n) {
  return n = "on" + qn(n), !!(e[n] || e[`${n}Once`] || e[`${n}Capture`] || e[`${n}OnceCapture`] || e[`${n}CaptureOnce`]);
}
function fl(e) {
  for (var n = arguments.length, t = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++)
    t[a - 1] = arguments[a];
  if (Array.isArray(e))
    for (const l of e)
      l(...t);
  else typeof e == "function" && e(...t);
}
function va(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
  const t = ["button", "[href]", 'input:not([type="hidden"])', "select", "textarea", "[tabindex]"].map((a) => `${a}${n ? ':not([tabindex="-1"])' : ""}:not([disabled])`).join(", ");
  return [...e.querySelectorAll(t)];
}
function du(e, n, t) {
  var o;
  let a, l = e.indexOf(document.activeElement);
  const i = n === "next" ? 1 : -1;
  do
    l += i, a = e[l];
  while ((!a || a.offsetParent == null || !((o = t == null ? void 0 : t(a)) == null || o)) && l < e.length && l >= 0);
  return a;
}
function mn(e, n) {
  var a, l, i, o;
  const t = va(e);
  if (n == null)
    (e === document.activeElement || !e.contains(document.activeElement)) && ((a = t[0]) == null || a.focus());
  else if (n === "first")
    (l = t[0]) == null || l.focus();
  else if (n === "last")
    (i = t.at(-1)) == null || i.focus();
  else if (typeof n == "number")
    (o = t[n]) == null || o.focus();
  else {
    const r = du(t, n);
    r ? r.focus() : mn(e, n === "next" ? "first" : "last");
  }
}
function Ya(e) {
  return e == null || typeof e == "string" && e.trim() === "";
}
function vu() {
}
function zn(e, n) {
  if (!(Te && typeof CSS != "undefined" && typeof CSS.supports != "undefined" && CSS.supports(`selector(${n})`))) return null;
  try {
    return !!e && e.matches(n);
  } catch (a) {
    return null;
  }
}
function ml(e) {
  return e.some((n) => Td(n) ? n.type === Bd ? !1 : n.type !== he || ml(n.children) : !0) ? e : null;
}
function Rl(e, n, t) {
  var a;
  return (a = e == null ? void 0 : e(n)) != null ? a : t == null ? void 0 : t(n);
}
function tv(e, n) {
  if (!Te || e === 0)
    return n(), () => {
    };
  const t = window.setTimeout(n, e);
  return () => window.clearTimeout(t);
}
function nv(e, n) {
  const t = e.clientX, a = e.clientY, l = n.getBoundingClientRect(), i = l.left, o = l.top, r = l.right, u = l.bottom;
  return t >= i && t <= r && a >= o && a <= u;
}
function tl() {
  const e = te(), n = (t) => {
    e.value = t;
  };
  return Object.defineProperty(n, "value", {
    enumerable: !0,
    get: () => e.value,
    set: (t) => e.value = t
  }), Object.defineProperty(n, "el", {
    enumerable: !0,
    get: () => Ui(e.value)
  }), n;
}
function Wn(e) {
  const n = e.key.length === 1, t = !e.ctrlKey && !e.metaKey && !e.altKey;
  return n && t;
}
function ni(e) {
  return typeof e == "string" || typeof e == "number" || typeof e == "boolean" || typeof e == "bigint";
}
function nl(e) {
  return "\\^$*+?.()|{}[]".includes(e) ? `\\${e}` : e;
}
function av(e, n, t) {
  const a = new RegExp(`[\\d\\-${nl(t)}]`), l = e.split("").filter((o) => a.test(o)).filter((o, r, u) => r === 0 && /[-]/.test(o) || // sign allowed at the start
  o === t && r === u.indexOf(o) || // decimal separator allowed only once
  /\d/.test(o)).join("");
  if (n === 0)
    return l.split(t)[0];
  const i = new RegExp(`${nl(t)}\\d`);
  if (n !== null && i.test(l)) {
    const o = l.split(t);
    return [o[0], o[1].substring(0, n)].join(t);
  }
  return l;
}
function lv(e) {
  const n = {};
  for (const t in e)
    n[ji(t)] = e[t];
  return n;
}
function iv(e) {
  const n = ["checked", "disabled"];
  return Object.fromEntries(Object.entries(e).filter((t) => {
    let [a, l] = t;
    return n.includes(a) ? !!l : l !== void 0;
  }));
}
const fu = ["top", "bottom"], ov = ["start", "end", "left", "right"];
function ai(e, n) {
  let [t, a] = e.split(" ");
  return a || (a = el(fu, t) ? "start" : el(ov, t) ? "top" : "center"), {
    side: li(t, n),
    align: li(a, n)
  };
}
function li(e, n) {
  return e === "start" ? n ? "right" : "left" : e === "end" ? n ? "left" : "right" : e;
}
function Hl(e) {
  return {
    side: {
      center: "center",
      top: "bottom",
      bottom: "top",
      left: "right",
      right: "left"
    }[e.side],
    align: e.align
  };
}
function zl(e) {
  return {
    side: e.side,
    align: {
      center: "center",
      top: "bottom",
      bottom: "top",
      left: "right",
      right: "left"
    }[e.align]
  };
}
function ar(e) {
  return {
    side: e.align,
    align: e.side
  };
}
function lr(e) {
  return el(fu, e.side) ? "y" : "x";
}
class Ot {
  constructor(n) {
    let {
      x: t,
      y: a,
      width: l,
      height: i
    } = n;
    this.x = t, this.y = a, this.width = l, this.height = i;
  }
  get top() {
    return this.y;
  }
  get bottom() {
    return this.y + this.height;
  }
  get left() {
    return this.x;
  }
  get right() {
    return this.x + this.width;
  }
}
function ir(e, n) {
  return {
    x: {
      before: Math.max(0, n.left - e.left),
      after: Math.max(0, e.right - n.right)
    },
    y: {
      before: Math.max(0, n.top - e.top),
      after: Math.max(0, e.bottom - n.bottom)
    }
  };
}
function mu(e) {
  return Array.isArray(e) ? new Ot({
    x: e[0],
    y: e[1],
    width: 0,
    height: 0
  }) : e.getBoundingClientRect();
}
function rv(e) {
  if (e === document.documentElement)
    return visualViewport ? new Ot({
      x: visualViewport.scale > 1 ? 0 : visualViewport.offsetLeft,
      y: visualViewport.scale > 1 ? 0 : visualViewport.offsetTop,
      width: visualViewport.width * visualViewport.scale,
      height: visualViewport.height * visualViewport.scale
    }) : new Ot({
      x: 0,
      y: 0,
      width: document.documentElement.clientWidth,
      height: document.documentElement.clientHeight
    });
  {
    const n = e.getBoundingClientRect();
    return new Ot({
      x: n.x,
      y: n.y,
      width: e.clientWidth,
      height: e.clientHeight
    });
  }
}
function Xi(e) {
  const n = e.getBoundingClientRect(), t = getComputedStyle(e), a = t.transform;
  if (a) {
    let l, i, o, r, u;
    if (a.startsWith("matrix3d("))
      l = a.slice(9, -1).split(/, /), i = Number(l[0]), o = Number(l[5]), r = Number(l[12]), u = Number(l[13]);
    else if (a.startsWith("matrix("))
      l = a.slice(7, -1).split(/, /), i = Number(l[0]), o = Number(l[3]), r = Number(l[4]), u = Number(l[5]);
    else
      return new Ot(n);
    const c = t.transformOrigin, s = n.x - r - (1 - i) * parseFloat(c), d = n.y - u - (1 - o) * parseFloat(c.slice(c.indexOf(" ") + 1)), f = i ? n.width / i : e.offsetWidth + 1, m = o ? n.height / o : e.offsetHeight + 1;
    return new Ot({
      x: s,
      y: d,
      width: f,
      height: m
    });
  } else
    return new Ot(n);
}
function dn(e, n, t) {
  if (typeof e.animate == "undefined") return {
    finished: Promise.resolve()
  };
  let a;
  try {
    a = e.animate(n, t);
  } catch (l) {
    return {
      finished: Promise.resolve()
    };
  }
  return typeof a.finished == "undefined" && (a.finished = new Promise((l) => {
    a.onfinish = () => {
      l(a);
    };
  })), a;
}
const Xa = /* @__PURE__ */ new WeakMap();
function uv(e, n) {
  Object.keys(n).forEach((t) => {
    if (Ki(t)) {
      const a = cu(t), l = Xa.get(e);
      if (n[t] == null)
        l == null || l.forEach((i) => {
          const [o, r] = i;
          o === a && (e.removeEventListener(a, r), l.delete(i));
        });
      else if (!l || ![...l].some((i) => i[0] === a && i[1] === n[t])) {
        e.addEventListener(a, n[t]);
        const i = l || /* @__PURE__ */ new Set();
        i.add([a, n[t]]), Xa.has(e) || Xa.set(e, i);
      }
    } else
      n[t] == null ? e.removeAttribute(t) : e.setAttribute(t, n[t]);
  });
}
function sv(e, n) {
  Object.keys(n).forEach((t) => {
    if (Ki(t)) {
      const a = cu(t), l = Xa.get(e);
      l == null || l.forEach((i) => {
        const [o, r] = i;
        o === a && (e.removeEventListener(a, r), l.delete(i));
      });
    } else
      e.removeAttribute(t);
  });
}
const $n = 2.4, or = 0.2126729, rr = 0.7151522, ur = 0.072175, cv = 0.55, dv = 0.58, vv = 0.57, fv = 0.62, Ga = 0.03, sr = 1.45, mv = 5e-4, gv = 1.25, hv = 1.25, cr = 0.078, dr = 12.82051282051282, Ua = 0.06, vr = 1e-3;
function fr(e, n) {
  const t = Le(e.r / 255, $n), a = Le(e.g / 255, $n), l = Le(e.b / 255, $n), i = Le(n.r / 255, $n), o = Le(n.g / 255, $n), r = Le(n.b / 255, $n);
  let u = t * or + a * rr + l * ur, c = i * or + o * rr + r * ur;
  if (u <= Ga && (u += Le(Ga - u, sr)), c <= Ga && (c += Le(Ga - c, sr)), Math.abs(c - u) < mv) return 0;
  let s;
  if (c > u) {
    const d = (Le(c, cv) - Le(u, dv)) * gv;
    s = d < vr ? 0 : d < cr ? d - d * dr * Ua : d - Ua;
  } else {
    const d = (Le(c, fv) - Le(u, vv)) * hv;
    s = d > -vr ? 0 : d > -cr ? d - d * dr * Ua : d + Ua;
  }
  return s * 100;
}
function et(e) {
  dl(`Vuetify: ${e}`);
}
function fa(e) {
  dl(`Vuetify error: ${e}`);
}
function gu(e, n) {
  n = Array.isArray(n) ? n.slice(0, -1).map((t) => `'${t}'`).join(", ") + ` or '${n.at(-1)}'` : `'${n}'`, dl(`[Vuetify UPGRADE] '${e}' is deprecated, use ${n} instead.`);
}
const al = 0.20689655172413793, yv = (e) => e > Le(al, 3) ? Math.cbrt(e) : e / (3 * Le(al, 2)) + 4 / 29, bv = (e) => e > al ? Le(e, 3) : 3 * Le(al, 2) * (e - 4 / 29);
function hu(e) {
  const n = yv, t = n(e[1]);
  return [116 * t - 16, 500 * (n(e[0] / 0.95047) - t), 200 * (t - n(e[2] / 1.08883))];
}
function yu(e) {
  const n = bv, t = (e[0] + 16) / 116;
  return [n(t + e[1] / 500) * 0.95047, n(t), n(t - e[2] / 200) * 1.08883];
}
const Sv = [[3.2406, -1.5372, -0.4986], [-0.9689, 1.8758, 0.0415], [0.0557, -0.204, 1.057]], kv = (e) => e <= 31308e-7 ? e * 12.92 : 1.055 * Le(e, 1 / 2.4) - 0.055, wv = [[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]], Cv = (e) => e <= 0.04045 ? e / 12.92 : Le((e + 0.055) / 1.055, 2.4);
function bu(e) {
  const n = Array(3), t = kv, a = Sv;
  for (let l = 0; l < 3; ++l)
    n[l] = Math.round(Fe(t(a[l][0] * e[0] + a[l][1] * e[1] + a[l][2] * e[2])) * 255);
  return {
    r: n[0],
    g: n[1],
    b: n[2]
  };
}
function Zi(e) {
  let {
    r: n,
    g: t,
    b: a
  } = e;
  const l = [0, 0, 0], i = Cv, o = wv;
  n = i(n / 255), t = i(t / 255), a = i(a / 255);
  for (let r = 0; r < 3; ++r)
    l[r] = o[r][0] * n + o[r][1] * t + o[r][2] * a;
  return l;
}
function ii(e) {
  return !!e && /^(#|var\(--|(rgb|hsl)a?\()/.test(e);
}
function xv(e) {
  return ii(e) && !/^((rgb|hsl)a?\()?var\(--/.test(e);
}
const mr = new RegExp("^(?<fn>(?:rgb|hsl)a?)\\((?<values>.+)\\)"), Vv = {
  rgb: (e, n, t, a) => ({
    r: e,
    g: n,
    b: t,
    a
  }),
  rgba: (e, n, t, a) => ({
    r: e,
    g: n,
    b: t,
    a
  }),
  hsl: (e, n, t, a) => gr({
    h: e,
    s: n,
    l: t,
    a
  }),
  hsla: (e, n, t, a) => gr({
    h: e,
    s: n,
    l: t,
    a
  }),
  hsv: (e, n, t, a) => Rt({
    h: e,
    s: n,
    v: t,
    a
  }),
  hsva: (e, n, t, a) => Rt({
    h: e,
    s: n,
    v: t,
    a
  })
};
function Pt(e) {
  if (typeof e == "number")
    return (isNaN(e) || e < 0 || e > 16777215) && et(`'${e}' is not a valid hex color`), {
      r: (e & 16711680) >> 16,
      g: (e & 65280) >> 8,
      b: e & 255
    };
  if (typeof e == "string" && mr.test(e)) {
    const {
      groups: n
    } = e.match(mr), {
      fn: t,
      values: a
    } = n, l = a.split(/,\s*|\s*\/\s*|\s+/).map((i, o) => i.endsWith("%") || // unitless slv are %
    o > 0 && o < 3 && ["hsl", "hsla", "hsv", "hsva"].includes(t) ? parseFloat(i) / 100 : parseFloat(i));
    return Vv[t](...l);
  } else if (typeof e == "string") {
    let n = e.startsWith("#") ? e.slice(1) : e;
    [3, 4].includes(n.length) ? n = n.split("").map((a) => a + a).join("") : [6, 8].includes(n.length) || et(`'${e}' is not a valid hex(a) color`);
    const t = parseInt(n, 16);
    return (isNaN(t) || t < 0 || t > 4294967295) && et(`'${e}' is not a valid hex(a) color`), Cu(n);
  } else if (typeof e == "object") {
    if (cn(e, ["r", "g", "b"]))
      return e;
    if (cn(e, ["h", "s", "l"]))
      return Rt(Qi(e));
    if (cn(e, ["h", "s", "v"]))
      return Rt(e);
  }
  throw new TypeError(`Invalid color: ${e == null ? e : String(e) || e.constructor.name}
Expected #hex, #hexa, rgb(), rgba(), hsl(), hsla(), object or number`);
}
function Rt(e) {
  const {
    h: n,
    s: t,
    v: a,
    a: l
  } = e, i = (r) => {
    const u = (r + n / 60) % 6;
    return a - a * t * Math.max(Math.min(u, 4 - u, 1), 0);
  }, o = [i(5), i(3), i(1)].map((r) => Math.round(r * 255));
  return {
    r: o[0],
    g: o[1],
    b: o[2],
    a: l
  };
}
function gr(e) {
  return Rt(Qi(e));
}
function Aa(e) {
  if (!e) return {
    h: 0,
    s: 1,
    v: 1,
    a: 1
  };
  const n = e.r / 255, t = e.g / 255, a = e.b / 255, l = Math.max(n, t, a), i = Math.min(n, t, a);
  let o = 0;
  l !== i && (l === n ? o = 60 * (0 + (t - a) / (l - i)) : l === t ? o = 60 * (2 + (a - n) / (l - i)) : l === a && (o = 60 * (4 + (n - t) / (l - i)))), o < 0 && (o = o + 360);
  const r = l === 0 ? 0 : (l - i) / l, u = [o, r, l];
  return {
    h: u[0],
    s: u[1],
    v: u[2],
    a: e.a
  };
}
function oi(e) {
  const {
    h: n,
    s: t,
    v: a,
    a: l
  } = e, i = a - a * t / 2, o = i === 1 || i === 0 ? 0 : (a - i) / Math.min(i, 1 - i);
  return {
    h: n,
    s: o,
    l: i,
    a: l
  };
}
function Qi(e) {
  const {
    h: n,
    s: t,
    l: a,
    a: l
  } = e, i = a + t * Math.min(a, 1 - a), o = i === 0 ? 0 : 2 - 2 * a / i;
  return {
    h: n,
    s: o,
    v: i,
    a: l
  };
}
function Su(e) {
  let {
    r: n,
    g: t,
    b: a,
    a: l
  } = e;
  return l === void 0 ? `rgb(${n}, ${t}, ${a})` : `rgba(${n}, ${t}, ${a}, ${l})`;
}
function ku(e) {
  return Su(Rt(e));
}
function Ka(e) {
  const n = Math.round(e).toString(16);
  return ("00".substr(0, 2 - n.length) + n).toUpperCase();
}
function wu(e) {
  let {
    r: n,
    g: t,
    b: a,
    a: l
  } = e;
  return `#${[Ka(n), Ka(t), Ka(a), l !== void 0 ? Ka(Math.round(l * 255)) : ""].join("")}`;
}
function Cu(e) {
  e = Iv(e);
  let [n, t, a, l] = Jd(e, 2).map((i) => parseInt(i, 16));
  return l = l === void 0 ? l : l / 255, {
    r: n,
    g: t,
    b: a,
    a: l
  };
}
function Pv(e) {
  const n = Cu(e);
  return Aa(n);
}
function xu(e) {
  return wu(Rt(e));
}
function Iv(e) {
  return e.startsWith("#") && (e = e.slice(1)), e = e.replace(/([^0-9a-f])/gi, "F"), (e.length === 3 || e.length === 4) && (e = e.split("").map((n) => n + n).join("")), e.length !== 6 && (e = Jo(Jo(e, 6), 8, "F")), e;
}
function _v(e, n) {
  const t = hu(Zi(e));
  return t[0] = t[0] + n * 10, bu(yu(t));
}
function Av(e, n) {
  const t = hu(Zi(e));
  return t[0] = t[0] - n * 10, bu(yu(t));
}
function ri(e) {
  const n = Pt(e);
  return Zi(n)[1];
}
function Lv(e, n) {
  const t = ri(e), a = ri(n), l = Math.max(t, a), i = Math.min(t, a);
  return (l + 0.05) / (i + 0.05);
}
function Vu(e) {
  const n = Math.abs(fr(Pt(0), Pt(e)));
  return Math.abs(fr(Pt(16777215), Pt(e))) > Math.min(n, 50) ? "#fff" : "#000";
}
function N(e, n) {
  return (t) => Object.keys(e).reduce((a, l) => {
    const o = typeof e[l] == "object" && e[l] != null && !Array.isArray(e[l]) ? e[l] : {
      type: e[l]
    };
    return t && l in t ? a[l] = le(v({}, o), {
      default: t[l]
    }) : a[l] = o, n && !a[l].source && (a[l].source = n), a;
  }, {});
}
const de = N({
  class: [String, Array, Object],
  style: {
    type: [String, Array, Object],
    default: null
  }
}, "component");
function Ke(e, n) {
  const t = Dd();
  if (!t)
    throw new Error(`[Vuetify] ${e} must be called from inside a setup function`);
  return t;
}
function jt() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "composables";
  const n = Ke(e).type;
  return fn((n == null ? void 0 : n.aliasName) || (n == null ? void 0 : n.name));
}
function Tv(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : Ke("injectSelf");
  const {
    provides: t
  } = n;
  if (t && e in t)
    return t[e];
}
const jn = Symbol.for("vuetify:defaults");
function Bv(e) {
  return Q(e);
}
function Ji() {
  const e = Pe(jn);
  if (!e) throw new Error("[Vuetify] Could not find defaults instance");
  return e;
}
function je(e, n) {
  const t = Ji(), a = Q(e), l = C(() => {
    if (Tt(n == null ? void 0 : n.disabled)) return t.value;
    const o = Tt(n == null ? void 0 : n.scoped), r = Tt(n == null ? void 0 : n.reset), u = Tt(n == null ? void 0 : n.root);
    if (a.value == null && !(o || r || u)) return t.value;
    let c = vt(a.value, {
      prev: t.value
    });
    if (o) return c;
    if (r || u) {
      const s = Number(r || 1 / 0);
      for (let d = 0; d <= s && !(!c || !("prev" in c)); d++)
        c = c.prev;
      return c && typeof u == "string" && u in c && (c = vt(vt(c, {
        prev: c
      }), c[u])), c;
    }
    return c.prev ? vt(c.prev, c) : c;
  });
  return Oe(jn, l), l;
}
function Dv(e, n) {
  return e.props && (typeof e.props[n] != "undefined" || typeof e.props[fn(n)] != "undefined");
}
function Pu() {
  var u;
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = arguments.length > 1 ? arguments[1] : void 0, t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Ji();
  const a = Ke("useDefaults");
  if (n = (u = n != null ? n : a.type.name) != null ? u : a.type.__name, !n)
    throw new Error("[Vuetify] Could not determine component name");
  const l = C(() => {
    var c, s;
    return (s = t.value) == null ? void 0 : s[(c = e._as) != null ? c : n];
  }), i = new Proxy(e, {
    get(c, s) {
      var h, b, g, S;
      const d = Reflect.get(c, s);
      if (s === "class" || s === "style")
        return [(h = l.value) == null ? void 0 : h[s], d].filter((y) => y != null);
      if (Dv(a.vnode, s)) return d;
      const f = (b = l.value) == null ? void 0 : b[s];
      if (f !== void 0) return f;
      const m = (S = (g = t.value) == null ? void 0 : g.global) == null ? void 0 : S[s];
      return m !== void 0 ? m : d;
    }
  }), o = te();
  We(() => {
    if (l.value) {
      const c = Object.entries(l.value).filter((s) => {
        let [d] = s;
        return d.startsWith(d[0].toUpperCase());
      });
      o.value = c.length ? Object.fromEntries(c) : void 0;
    } else
      o.value = void 0;
  });
  function r() {
    const c = Tv(jn, a);
    Oe(jn, C(() => {
      var s;
      return o.value ? vt((s = c == null ? void 0 : c.value) != null ? s : {}, o.value) : c == null ? void 0 : c.value;
    }));
  }
  return {
    props: i,
    provideSubDefaults: r
  };
}
function Mv() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = arguments.length > 1 ? arguments[1] : void 0;
  const {
    props: t,
    provideSubDefaults: a
  } = Pu(e, n);
  return a(), t;
}
function _t(e) {
  var n, t;
  if (e._setup = (n = e._setup) != null ? n : e.setup, !e.name)
    return et("The component is missing an explicit name, unable to generate default prop value"), e;
  if (e._setup) {
    e.props = N((t = e.props) != null ? t : {}, e.name)();
    const a = Object.keys(e.props).filter((l) => l !== "class" && l !== "style");
    e.filterProps = function(i) {
      return qt(i, a);
    }, e.props._as = String, e.setup = function(i, o) {
      var d;
      const r = Ji();
      if (!r.value) return e._setup(i, o);
      const {
        props: u,
        provideSubDefaults: c
      } = Pu(i, (d = i._as) != null ? d : e.name, r), s = e._setup(u, o);
      return c(), s;
    };
  }
  return e;
}
function Y() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
  return (n) => (e ? _t : Md)(n);
}
function pv(e, n) {
  return n.props = e, n;
}
function Xt(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "div", t = arguments.length > 2 ? arguments[2] : void 0;
  return Y()({
    name: t != null ? t : qn(ji(e.replace(/__/g, "-"))),
    props: v({
      tag: {
        type: String,
        default: n
      }
    }, de()),
    setup(a, l) {
      let {
        slots: i
      } = l;
      return () => {
        var o;
        return Vn(a.tag, {
          class: [e, a.class],
          style: a.style
        }, (o = i.default) == null ? void 0 : o.call(i));
      };
    }
  });
}
function Iu(e) {
  if (typeof e.getRootNode != "function") {
    for (; e.parentNode; ) e = e.parentNode;
    return e !== document ? null : document;
  }
  const n = e.getRootNode();
  return n !== document && n.getRootNode({
    composed: !0
  }) !== document ? null : n;
}
const ma = "cubic-bezier(0.4, 0, 0.2, 1)", Ev = "cubic-bezier(0.0, 0, 0.2, 1)", $v = "cubic-bezier(0.4, 0, 1, 1)", Fv = {
  linear: (e) => e,
  easeInQuad: (e) => Le(e, 2),
  easeOutQuad: (e) => e * (2 - e),
  easeInOutQuad: (e) => e < 0.5 ? 2 * Le(e, 2) : -1 + (4 - 2 * e) * e,
  easeInCubic: (e) => Le(e, 3),
  easeOutCubic: (e) => Le(--e, 3) + 1,
  easeInOutCubic: (e) => e < 0.5 ? 4 * Le(e, 3) : (e - 1) * (2 * e - 2) * (2 * e - 2) + 1,
  easeInQuart: (e) => Le(e, 4),
  easeOutQuart: (e) => 1 - Le(--e, 4),
  easeInOutQuart: (e) => e < 0.5 ? 8 * Le(e, 4) : 1 - 8 * Le(--e, 4),
  easeInQuint: (e) => Le(e, 5),
  easeOutQuint: (e) => 1 + Le(--e, 5),
  easeInOutQuint: (e) => e < 0.5 ? 16 * Le(e, 5) : 1 + 16 * Le(--e, 5)
};
function hr(e, n, t) {
  return Object.keys(e).filter((a) => Ki(a) && a.endsWith(n)).reduce((a, l) => (a[l.slice(0, -n.length)] = (i) => e[l](i, t(i)), a), {});
}
function eo(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
  for (; e; ) {
    if (n ? Ov(e) : to(e)) return e;
    e = e.parentElement;
  }
  return document.scrollingElement;
}
function ll(e, n) {
  const t = [];
  if (n && e && !n.contains(e)) return t;
  for (; e && (to(e) && t.push(e), e !== n); )
    e = e.parentElement;
  return t;
}
function to(e) {
  if (!e || e.nodeType !== Node.ELEMENT_NODE) return !1;
  const n = window.getComputedStyle(e), t = n.overflowY === "scroll" || n.overflowY === "auto" && e.scrollHeight > e.clientHeight, a = n.overflowX === "scroll" || n.overflowX === "auto" && e.scrollWidth > e.clientWidth;
  return t || a;
}
function Ov(e) {
  if (!e || e.nodeType !== Node.ELEMENT_NODE) return !1;
  const n = window.getComputedStyle(e);
  return ["scroll", "auto"].includes(n.overflowY);
}
function Nv(e) {
  let {
    depth: n,
    isLast: t,
    isLastGroup: a,
    leafLinks: l,
    separateRoots: i,
    parentIndentLines: o,
    variant: r
  } = e;
  if (!o || !n)
    return {
      leaf: void 0,
      node: void 0,
      children: o
    };
  if (r === "simple")
    return {
      leaf: [...o, "line"],
      node: [...o, "line"],
      children: [...o, "line"]
    };
  const u = t && (!a || i || n > 1);
  return {
    leaf: [...o, u ? "last-leaf" : "leaf", ...l ? ["leaf-link"] : []],
    node: [...o, u ? "last-leaf" : "leaf"],
    children: [...o, u ? "none" : "line"]
  };
}
function Rv(e) {
  for (; e; ) {
    if (window.getComputedStyle(e).position === "fixed")
      return !0;
    e = e.offsetParent;
  }
  return !1;
}
function Z(e) {
  const n = Ke("useRender");
  n.render = e;
}
function ve(e, n, t) {
  let a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : (d) => d, l = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : (d) => d;
  const i = Ke("useProxiedModel"), o = Q(e[n] !== void 0 ? e[n] : t), r = fn(n), c = r !== n ? C(() => {
    var d, f, m, h;
    return e[n], !!(((d = i.vnode.props) != null && d.hasOwnProperty(n) || (f = i.vnode.props) != null && f.hasOwnProperty(r)) && ((m = i.vnode.props) != null && m.hasOwnProperty(`onUpdate:${n}`) || (h = i.vnode.props) != null && h.hasOwnProperty(`onUpdate:${r}`)));
  }) : C(() => {
    var d, f;
    return e[n], !!((d = i.vnode.props) != null && d.hasOwnProperty(n) && ((f = i.vnode.props) != null && f.hasOwnProperty(`onUpdate:${n}`)));
  });
  mt(() => !c.value, () => {
    oe(() => e[n], (d) => {
      o.value = d;
    });
  });
  const s = C({
    get() {
      const d = e[n];
      return a(c.value ? d : o.value);
    },
    set(d) {
      const f = l(d), m = Ue(c.value ? e[n] : o.value);
      m === f || a(m) === d || (o.value = f, i == null || i.emit(`update:${n}`, f));
    }
  });
  return Object.defineProperty(s, "externalValue", {
    get: () => c.value ? e[n] : o.value
  }), s;
}
const Hv = {
  badge: "Badge",
  open: "Open",
  close: "Close",
  dismiss: "Dismiss",
  confirmEdit: {
    ok: "OK",
    cancel: "Cancel"
  },
  dataIterator: {
    noResultsText: "No matching records found",
    loadingText: "Loading items..."
  },
  dataTable: {
    itemsPerPageText: "Rows per page:",
    ariaLabel: {
      sortDescending: "Sorted descending.",
      sortAscending: "Sorted ascending.",
      sortNone: "Not sorted.",
      activateNone: "Activate to remove sorting.",
      activateDescending: "Activate to sort descending.",
      activateAscending: "Activate to sort ascending."
    },
    sortBy: "Sort by"
  },
  dataFooter: {
    itemsPerPageText: "Items per page:",
    itemsPerPageAll: "All",
    nextPage: "Next page",
    prevPage: "Previous page",
    firstPage: "First page",
    lastPage: "Last page",
    pageText: "{0}-{1} of {2}"
  },
  dateRangeInput: {
    divider: "to"
  },
  datePicker: {
    itemsSelected: "{0} selected",
    range: {
      title: "Select dates",
      header: "Enter dates"
    },
    title: "Select date",
    header: "Enter date",
    input: {
      placeholder: "Enter date"
    },
    ariaLabel: {
      previousMonth: "Previous month",
      nextMonth: "Next month",
      selectYear: "Select year",
      selectDate: "{0}",
      // Full date format
      currentDate: "Today, {0}"
    }
  },
  noDataText: "No data available",
  carousel: {
    prev: "Previous visual",
    next: "Next visual",
    ariaLabel: {
      delimiter: "Carousel slide {0} of {1}"
    }
  },
  calendar: {
    moreEvents: "{0} more",
    today: "Today"
  },
  input: {
    clear: "Clear {0}",
    prependAction: "{0} prepended action",
    appendAction: "{0} appended action",
    otp: "Please enter OTP character {0}"
  },
  fileInput: {
    counter: "{0} files",
    counterSize: "{0} files ({1} in total)"
  },
  fileUpload: {
    title: "Drag and drop files here",
    divider: "or",
    browse: "Browse Files"
  },
  timePicker: {
    am: "AM",
    pm: "PM",
    title: "Select Time"
  },
  pagination: {
    ariaLabel: {
      root: "Pagination Navigation",
      next: "Next page",
      previous: "Previous page",
      page: "Go to page {0}",
      currentPage: "Page {0}, Current page",
      first: "First page",
      last: "Last page"
    }
  },
  stepper: {
    next: "Next",
    prev: "Previous"
  },
  rating: {
    ariaLabel: {
      item: "Rating {0} of {1}"
    }
  },
  loading: "Loading...",
  infiniteScroll: {
    loadMore: "Load more",
    empty: "No more"
  },
  rules: {
    required: "This field is required",
    email: "Please enter a valid email",
    number: "This field can only contain numbers",
    integer: "This field can only contain integer values",
    capital: "This field can only contain uppercase letters",
    maxLength: "You must enter a maximum of {0} characters",
    minLength: "You must enter a minimum of {0} characters",
    strictLength: "The length of the entered field is invalid",
    exclude: "The {0} character is not allowed",
    notEmpty: "Please choose at least one value",
    pattern: "Invalid format"
  },
  hotkey: {
    then: "then",
    ctrl: "Ctrl",
    command: "Command",
    space: "Space",
    shift: "Shift",
    alt: "Alt",
    enter: "Enter",
    escape: "Escape",
    upArrow: "Up Arrow",
    downArrow: "Down Arrow",
    leftArrow: "Left Arrow",
    rightArrow: "Right Arrow",
    backspace: "Backspace",
    option: "Option",
    plus: "plus",
    shortcut: "Keyboard shortcut: {0}"
  },
  video: {
    play: "Play",
    pause: "Pause",
    seek: "Seek",
    volume: "Volume",
    showVolume: "Show volume control",
    mute: "Mute",
    unmute: "Unmute",
    enterFullscreen: "Full screen",
    exitFullscreen: "Exit full screen"
  },
  colorPicker: {
    ariaLabel: {
      eyedropper: "Select color with eyedropper",
      hueSlider: "Hue",
      alphaSlider: "Alpha",
      redInput: "Red value",
      greenInput: "Green value",
      blueInput: "Blue value",
      alphaInput: "Alpha value",
      hueInput: "Hue value",
      saturationInput: "Saturation value",
      lightnessInput: "Lightness value",
      hexInput: "HEX value",
      hexaInput: "HEX with alpha value",
      changeFormat: "Change color format"
    }
  }
}, yr = "$vuetify.", br = (e, n) => e.replace(/\{(\d+)\}/g, (t, a) => String(n[Number(a)])), _u = (e, n, t) => function(a) {
  for (var l = arguments.length, i = new Array(l > 1 ? l - 1 : 0), o = 1; o < l; o++)
    i[o - 1] = arguments[o];
  if (!a.startsWith(yr))
    return br(a, i);
  const r = a.replace(yr, ""), u = e.value && t.value[e.value], c = n.value && t.value[n.value];
  let s = yn(u, r, null);
  return s || (et(`Translation key "${a}" not found in "${e.value}", trying fallback locale`), s = yn(c, r, null)), s || (fa(`Translation key "${a}" not found in fallback`), s = a), typeof s != "string" && (fa(`Translation key "${a}" has a non-string value`), s = a), br(s, i);
};
function no(e, n) {
  return (t, a) => new Intl.NumberFormat([e.value, n.value], a).format(t);
}
function Au(e, n) {
  return no(e, n)(0.1).includes(",") ? "," : ".";
}
function Wl(e, n, t) {
  var l, i;
  const a = ve(e, n, (l = e[n]) != null ? l : t.value);
  return a.value = (i = e[n]) != null ? i : t.value, oe(t, (o) => {
    e[n] == null && (a.value = t.value);
  }), a;
}
function Lu(e) {
  return (n) => {
    const t = Wl(n, "locale", e.current), a = Wl(n, "fallback", e.fallback), l = Wl(n, "messages", e.messages);
    return {
      name: "vuetify",
      current: t,
      fallback: a,
      messages: l,
      decimalSeparator: M(() => Au(t, a)),
      t: _u(t, a, l),
      n: no(t, a),
      provide: Lu({
        current: t,
        fallback: a,
        messages: l
      })
    };
  };
}
function zv(e) {
  var l, i;
  const n = te((l = e == null ? void 0 : e.locale) != null ? l : "en"), t = te((i = e == null ? void 0 : e.fallback) != null ? i : "en"), a = Q(v({
    en: Hv
  }, e == null ? void 0 : e.messages));
  return {
    name: "vuetify",
    current: n,
    fallback: t,
    messages: a,
    decimalSeparator: M(() => {
      var o;
      return (o = e == null ? void 0 : e.decimalSeparator) != null ? o : Au(n, t);
    }),
    t: _u(n, t, a),
    n: no(n, t),
    provide: Lu({
      current: n,
      fallback: t,
      messages: a
    })
  };
}
const Yn = Symbol.for("vuetify:locale");
function Wv(e) {
  return e.name != null;
}
function jv(e) {
  const n = e != null && e.adapter && Wv(e == null ? void 0 : e.adapter) ? e == null ? void 0 : e.adapter : zv(e), t = Uv(n, e);
  return v(v({}, n), t);
}
function Ee() {
  const e = Pe(Yn);
  if (!e) throw new Error("[Vuetify] Could not find injected locale instance");
  return e;
}
function Yv(e) {
  const n = Pe(Yn);
  if (!n) throw new Error("[Vuetify] Could not find injected locale instance");
  const t = n.provide(e), a = Kv(t, n.rtl, e), l = v(v({}, t), a);
  return Oe(Yn, l), l;
}
function Gv() {
  return {
    af: !1,
    ar: !0,
    bg: !1,
    ca: !1,
    ckb: !1,
    cs: !1,
    de: !1,
    el: !1,
    en: !1,
    es: !1,
    et: !1,
    fa: !0,
    fi: !1,
    fr: !1,
    hr: !1,
    hu: !1,
    he: !0,
    id: !1,
    it: !1,
    ja: !1,
    km: !1,
    ko: !1,
    lv: !1,
    lt: !1,
    nl: !1,
    no: !1,
    pl: !1,
    pt: !1,
    ro: !1,
    ru: !1,
    sk: !1,
    sl: !1,
    srCyrl: !1,
    srLatn: !1,
    sv: !1,
    th: !1,
    tr: !1,
    az: !1,
    uk: !1,
    vi: !1,
    zhHans: !1,
    zhHant: !1
  };
}
function Uv(e, n) {
  var l;
  const t = Q((l = n == null ? void 0 : n.rtl) != null ? l : Gv()), a = C(() => {
    var i;
    return (i = t.value[e.current.value]) != null ? i : !1;
  });
  return {
    isRtl: a,
    rtl: t,
    rtlClasses: M(() => `v-locale--is-${a.value ? "rtl" : "ltr"}`)
  };
}
function Kv(e, n, t) {
  const a = C(() => {
    var l, i;
    return (i = (l = t.rtl) != null ? l : n.value[e.current.value]) != null ? i : !1;
  });
  return {
    isRtl: a,
    rtl: n,
    rtlClasses: M(() => `v-locale--is-${a.value ? "rtl" : "ltr"}`)
  };
}
function Xe() {
  const e = Pe(Yn);
  if (!e) throw new Error("[Vuetify] Could not find injected rtl instance");
  return {
    isRtl: e.isRtl,
    rtlClasses: e.rtlClasses
  };
}
function La(e) {
  const n = e.slice(-2).toUpperCase();
  switch (!0) {
    case e === "GB-alt-variant":
      return {
        firstDay: 0,
        firstWeekSize: 4
      };
    case e === "001":
      return {
        firstDay: 1,
        firstWeekSize: 1
      };
    case `AG AS BD BR BS BT BW BZ CA CO DM DO ET GT GU HK HN ID IL IN JM JP KE
    KH KR LA MH MM MO MT MX MZ NI NP PA PE PH PK PR PY SA SG SV TH TT TW UM US
    VE VI WS YE ZA ZW`.includes(n):
      return {
        firstDay: 0,
        firstWeekSize: 1
      };
    case `AI AL AM AR AU AZ BA BM BN BY CL CM CN CR CY EC GE HR KG KZ LB LK LV
    MD ME MK MN MY NZ RO RS SI TJ TM TR UA UY UZ VN XK`.includes(n):
      return {
        firstDay: 1,
        firstWeekSize: 1
      };
    case `AD AN AT AX BE BG CH CZ DE DK EE ES FI FJ FO FR GB GF GP GR HU IE IS
    IT LI LT LU MC MQ NL NO PL RE RU SE SK SM VA`.includes(n):
      return {
        firstDay: 1,
        firstWeekSize: 4
      };
    case "AE AF BH DJ DZ EG IQ IR JO KW LY OM QA SD SY".includes(n):
      return {
        firstDay: 6,
        firstWeekSize: 1
      };
    case n === "MV":
      return {
        firstDay: 5,
        firstWeekSize: 1
      };
    case n === "PT":
      return {
        firstDay: 0,
        firstWeekSize: 4
      };
    default:
      return null;
  }
}
function qv(e, n, t) {
  var s, d;
  const a = [];
  let l = [];
  const i = Tu(e), o = Bu(e), r = (d = t != null ? t : (s = La(n)) == null ? void 0 : s.firstDay) != null ? d : 0, u = (i.getDay() - r + 7) % 7, c = (o.getDay() - r + 7) % 7;
  for (let f = 0; f < u; f++) {
    const m = new Date(i);
    m.setDate(m.getDate() - (u - f)), l.push(m);
  }
  for (let f = 1; f <= o.getDate(); f++) {
    const m = new Date(e.getFullYear(), e.getMonth(), f);
    l.push(m), l.length === 7 && (a.push(l), l = []);
  }
  for (let f = 1; f < 7 - c; f++) {
    const m = new Date(o);
    m.setDate(m.getDate() + f), l.push(m);
  }
  return l.length > 0 && a.push(l), a;
}
function ui(e, n, t) {
  var i, o;
  let a = ((o = t != null ? t : (i = La(n)) == null ? void 0 : i.firstDay) != null ? o : 0) % 7;
  [0, 1, 2, 3, 4, 5, 6].includes(a) || (et("Invalid firstDayOfWeek, expected discrete number in range [0-6]"), a = 0);
  const l = new Date(e);
  for (; l.getDay() !== a; )
    l.setDate(l.getDate() - 1);
  return l;
}
function Xv(e, n) {
  var l, i;
  const t = new Date(e), a = (((i = (l = La(n)) == null ? void 0 : l.firstDay) != null ? i : 0) + 6) % 7;
  for (; t.getDay() !== a; )
    t.setDate(t.getDate() + 1);
  return t;
}
function Tu(e) {
  return new Date(e.getFullYear(), e.getMonth(), 1);
}
function Bu(e) {
  return new Date(e.getFullYear(), e.getMonth() + 1, 0);
}
function Zv(e) {
  const n = e.split("-").map(Number);
  return new Date(n[0], n[1] - 1, n[2]);
}
const Qv = /^([12]\d{3}-([1-9]|0[1-9]|1[0-2])-([1-9]|0[1-9]|[12]\d|3[01]))$/;
function Du(e) {
  if (e == null) return /* @__PURE__ */ new Date();
  if (e instanceof Date) return e;
  if (typeof e == "string") {
    let n;
    if (Qv.test(e))
      return Zv(e);
    if (n = Date.parse(e), !isNaN(n)) return new Date(n);
  }
  return null;
}
const Sr = new Date(2e3, 0, 2);
function Jv(e, n, t) {
  var l, i;
  const a = (i = n != null ? n : (l = La(e)) == null ? void 0 : l.firstDay) != null ? i : 0;
  return Vt(7).map((o) => {
    const r = new Date(Sr);
    return r.setDate(Sr.getDate() + a + o), new Intl.DateTimeFormat(e, {
      weekday: t != null ? t : "narrow"
    }).format(r);
  });
}
function ef(e, n, t, a) {
  var r;
  const l = (r = Du(e)) != null ? r : /* @__PURE__ */ new Date(), i = a == null ? void 0 : a[n];
  if (typeof i == "function")
    return i(l, n, t);
  let o = {};
  switch (n) {
    case "fullDate":
      o = {
        year: "numeric",
        month: "short",
        day: "numeric"
      };
      break;
    case "fullDateWithWeekday":
      o = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
      };
      break;
    case "normalDate":
      const u = l.getDate(), c = new Intl.DateTimeFormat(t, {
        month: "long"
      }).format(l);
      return `${u} ${c}`;
    case "normalDateWithWeekday":
      o = {
        weekday: "short",
        day: "numeric",
        month: "short"
      };
      break;
    case "shortDate":
      o = {
        month: "short",
        day: "numeric"
      };
      break;
    case "year":
      o = {
        year: "numeric"
      };
      break;
    case "month":
      o = {
        month: "long"
      };
      break;
    case "monthShort":
      o = {
        month: "short"
      };
      break;
    case "monthAndYear":
      o = {
        month: "long",
        year: "numeric"
      };
      break;
    case "monthAndDate":
      o = {
        month: "long",
        day: "numeric"
      };
      break;
    case "weekday":
      o = {
        weekday: "long"
      };
      break;
    case "weekdayShort":
      o = {
        weekday: "short"
      };
      break;
    case "dayOfMonth":
      return new Intl.NumberFormat(t).format(l.getDate());
    case "hours12h":
      o = {
        hour: "numeric",
        hour12: !0
      };
      break;
    case "hours24h":
      o = {
        hour: "numeric",
        hour12: !1
      };
      break;
    case "minutes":
      o = {
        minute: "numeric"
      };
      break;
    case "seconds":
      o = {
        second: "numeric"
      };
      break;
    case "fullTime":
      o = {
        hour: "numeric",
        minute: "numeric"
      };
      break;
    case "fullTime12h":
      o = {
        hour: "numeric",
        minute: "numeric",
        hour12: !0
      };
      break;
    case "fullTime24h":
      o = {
        hour: "numeric",
        minute: "numeric",
        hour12: !1
      };
      break;
    case "fullDateTime":
      o = {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "numeric"
      };
      break;
    case "fullDateTime12h":
      o = {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        hour12: !0
      };
      break;
    case "fullDateTime24h":
      o = {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        hour12: !1
      };
      break;
    case "keyboardDate":
      o = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      };
      break;
    case "keyboardDateTime":
      return o = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "numeric",
        minute: "numeric"
      }, new Intl.DateTimeFormat(t, o).format(l).replace(/, /g, " ");
    case "keyboardDateTime12h":
      return o = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "numeric",
        minute: "numeric",
        hour12: !0
      }, new Intl.DateTimeFormat(t, o).format(l).replace(/, /g, " ");
    case "keyboardDateTime24h":
      return o = {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "numeric",
        minute: "numeric",
        hour12: !1
      }, new Intl.DateTimeFormat(t, o).format(l).replace(/, /g, " ");
    default:
      o = i != null ? i : {
        timeZone: "UTC",
        timeZoneName: "short"
      };
  }
  return new Intl.DateTimeFormat(t, o).format(l);
}
function tf(e, n) {
  const t = e.toJsDate(n), a = t.getFullYear(), l = er(String(t.getMonth() + 1), 2, "0"), i = er(String(t.getDate()), 2, "0");
  return `${a}-${l}-${i}`;
}
function nf(e) {
  const [n, t, a] = e.split("-").map(Number);
  return new Date(n, t - 1, a);
}
function af(e, n) {
  const t = new Date(e);
  return t.setMinutes(t.getMinutes() + n), t;
}
function lf(e, n) {
  const t = new Date(e);
  return t.setHours(t.getHours() + n), t;
}
function Za(e, n) {
  const t = new Date(e);
  return t.setDate(t.getDate() + n), t;
}
function of(e, n) {
  const t = new Date(e);
  return t.setDate(t.getDate() + n * 7), t;
}
function rf(e, n) {
  const t = new Date(e);
  return t.setDate(1), t.setMonth(t.getMonth() + n), t;
}
function si(e) {
  return e.getFullYear();
}
function uf(e) {
  return e.getMonth();
}
function sf(e, n, t, a) {
  var m, h;
  const l = La(n), i = (m = t != null ? t : l == null ? void 0 : l.firstDay) != null ? m : 0, o = (h = a != null ? a : l == null ? void 0 : l.firstWeekSize) != null ? h : 1;
  function r(b) {
    const g = new Date(b, 0, 1);
    return 7 - ci(g, ui(g, n, i), "days");
  }
  let u = si(e);
  const c = Za(ui(e, n, i), 6);
  u < si(c) && r(u + 1) >= o && u++;
  const s = new Date(u, 0, 1), d = r(u), f = d >= o ? Za(s, d - 7) : Za(s, d);
  return 1 + ci(Mu(e), ol(f), "weeks");
}
function cf(e) {
  return e.getDate();
}
function df(e) {
  return new Date(e.getFullYear(), e.getMonth() + 1, 1);
}
function vf(e) {
  return new Date(e.getFullYear(), e.getMonth() - 1, 1);
}
function ff(e) {
  return e.getHours();
}
function mf(e) {
  return e.getMinutes();
}
function gf(e) {
  return new Date(e.getFullYear(), 0, 1);
}
function hf(e) {
  return new Date(e.getFullYear(), 11, 31);
}
function yf(e, n) {
  return il(e, n[0]) && kf(e, n[1]);
}
function bf(e) {
  const n = new Date(e);
  return n instanceof Date && !isNaN(n.getTime());
}
function il(e, n) {
  return e.getTime() > n.getTime();
}
function Sf(e, n) {
  return il(ol(e), ol(n));
}
function kf(e, n) {
  return e.getTime() < n.getTime();
}
function kr(e, n) {
  return e.getTime() === n.getTime();
}
function wf(e, n) {
  return e.getDate() === n.getDate() && e.getMonth() === n.getMonth() && e.getFullYear() === n.getFullYear();
}
function Cf(e, n) {
  return e.getMonth() === n.getMonth() && e.getFullYear() === n.getFullYear();
}
function xf(e, n) {
  return e.getFullYear() === n.getFullYear();
}
function ci(e, n, t) {
  const a = new Date(e), l = new Date(n);
  switch (t) {
    case "years":
      return a.getFullYear() - l.getFullYear();
    case "quarters":
      return Math.floor((a.getMonth() - l.getMonth() + (a.getFullYear() - l.getFullYear()) * 12) / 4);
    case "months":
      return a.getMonth() - l.getMonth() + (a.getFullYear() - l.getFullYear()) * 12;
    case "weeks":
      return Math.floor((a.getTime() - l.getTime()) / (1e3 * 60 * 60 * 24 * 7));
    case "days":
      return Math.floor((a.getTime() - l.getTime()) / (1e3 * 60 * 60 * 24));
    case "hours":
      return Math.floor((a.getTime() - l.getTime()) / (1e3 * 60 * 60));
    case "minutes":
      return Math.floor((a.getTime() - l.getTime()) / (1e3 * 60));
    case "seconds":
      return Math.floor((a.getTime() - l.getTime()) / 1e3);
    default:
      return a.getTime() - l.getTime();
  }
}
function Vf(e, n) {
  const t = new Date(e);
  return t.setHours(n), t;
}
function Pf(e, n) {
  const t = new Date(e);
  return t.setMinutes(n), t;
}
function If(e, n) {
  const t = new Date(e);
  return t.setMonth(n), t;
}
function _f(e, n) {
  const t = new Date(e);
  return t.setDate(n), t;
}
function Af(e, n) {
  const t = new Date(e);
  return t.setFullYear(n), t;
}
function ol(e) {
  return new Date(e.getFullYear(), e.getMonth(), e.getDate(), 0, 0, 0, 0);
}
function Mu(e) {
  return new Date(e.getFullYear(), e.getMonth(), e.getDate(), 23, 59, 59, 999);
}
class Lf {
  constructor(n) {
    this.locale = n.locale, this.formats = n.formats;
  }
  date(n) {
    return Du(n);
  }
  toJsDate(n) {
    return n;
  }
  toISO(n) {
    return tf(this, n);
  }
  parseISO(n) {
    return nf(n);
  }
  addMinutes(n, t) {
    return af(n, t);
  }
  addHours(n, t) {
    return lf(n, t);
  }
  addDays(n, t) {
    return Za(n, t);
  }
  addWeeks(n, t) {
    return of(n, t);
  }
  addMonths(n, t) {
    return rf(n, t);
  }
  getWeekArray(n, t) {
    const a = t !== void 0 ? Number(t) : void 0;
    return qv(n, this.locale, a);
  }
  startOfWeek(n, t) {
    const a = t !== void 0 ? Number(t) : void 0;
    return ui(n, this.locale, a);
  }
  endOfWeek(n) {
    return Xv(n, this.locale);
  }
  startOfMonth(n) {
    return Tu(n);
  }
  endOfMonth(n) {
    return Bu(n);
  }
  format(n, t) {
    return ef(n, t, this.locale, this.formats);
  }
  isEqual(n, t) {
    return kr(n, t);
  }
  isValid(n) {
    return bf(n);
  }
  isWithinRange(n, t) {
    return yf(n, t);
  }
  isAfter(n, t) {
    return il(n, t);
  }
  isAfterDay(n, t) {
    return Sf(n, t);
  }
  isBefore(n, t) {
    return !il(n, t) && !kr(n, t);
  }
  isSameDay(n, t) {
    return wf(n, t);
  }
  isSameMonth(n, t) {
    return Cf(n, t);
  }
  isSameYear(n, t) {
    return xf(n, t);
  }
  setMinutes(n, t) {
    return Pf(n, t);
  }
  setHours(n, t) {
    return Vf(n, t);
  }
  setMonth(n, t) {
    return If(n, t);
  }
  setDate(n, t) {
    return _f(n, t);
  }
  setYear(n, t) {
    return Af(n, t);
  }
  getDiff(n, t, a) {
    return ci(n, t, a);
  }
  getWeekdays(n, t) {
    const a = n !== void 0 ? Number(n) : void 0;
    return Jv(this.locale, a, t);
  }
  getYear(n) {
    return si(n);
  }
  getMonth(n) {
    return uf(n);
  }
  getWeek(n, t, a) {
    const l = t !== void 0 ? Number(t) : void 0;
    return sf(n, this.locale, l, a);
  }
  getDate(n) {
    return cf(n);
  }
  getNextMonth(n) {
    return df(n);
  }
  getPreviousMonth(n) {
    return vf(n);
  }
  getHours(n) {
    return ff(n);
  }
  getMinutes(n) {
    return mf(n);
  }
  startOfDay(n) {
    return ol(n);
  }
  endOfDay(n) {
    return Mu(n);
  }
  startOfYear(n) {
    return gf(n);
  }
  endOfYear(n) {
    return hf(n);
  }
}
const pu = Symbol.for("vuetify:date-options"), wr = Symbol.for("vuetify:date-adapter");
function Tf(e, n) {
  const t = vt({
    adapter: Lf,
    locale: {
      af: "af-ZA",
      // ar: '', # not the same value for all variants
      bg: "bg-BG",
      ca: "ca-ES",
      ckb: "",
      cs: "cs-CZ",
      de: "de-DE",
      el: "el-GR",
      en: "en-US",
      // es: '', # not the same value for all variants
      et: "et-EE",
      fa: "fa-IR",
      fi: "fi-FI",
      // fr: '', #not the same value for all variants
      hr: "hr-HR",
      hu: "hu-HU",
      he: "he-IL",
      id: "id-ID",
      it: "it-IT",
      ja: "ja-JP",
      ko: "ko-KR",
      lv: "lv-LV",
      lt: "lt-LT",
      nl: "nl-NL",
      no: "no-NO",
      pl: "pl-PL",
      pt: "pt-PT",
      ro: "ro-RO",
      ru: "ru-RU",
      sk: "sk-SK",
      sl: "sl-SI",
      srCyrl: "sr-SP",
      srLatn: "sr-SP",
      sv: "sv-SE",
      th: "th-TH",
      tr: "tr-TR",
      az: "az-AZ",
      uk: "uk-UA",
      vi: "vi-VN",
      zhHans: "zh-CN",
      zhHant: "zh-TW"
    }
  }, e);
  return {
    options: t,
    instance: Eu(t, n)
  };
}
function Bf(e, n, t) {
  const a = e.getDiff(e.endOfDay(t != null ? t : n), e.startOfDay(n), "days"), l = [n];
  for (let i = 1; i < a; i++) {
    const o = e.addDays(n, i);
    l.push(o);
  }
  return t && l.push(e.endOfDay(t)), l;
}
function Eu(e, n) {
  var a;
  const t = yt(typeof e.adapter == "function" ? new e.adapter({
    locale: (a = e.locale[n.current.value]) != null ? a : n.current.value,
    formats: e.formats
  }) : e.adapter);
  return oe(n.current, (l) => {
    var i, o;
    t.locale = (o = (i = e.locale[l]) != null ? i : l) != null ? o : t.locale;
  }), t;
}
function Zn() {
  const e = Pe(pu);
  if (!e) throw new Error("[Vuetify] Could not find injected date options");
  const n = Ee();
  return Eu(e, n);
}
const gl = ["sm", "md", "lg", "xl", "xxl"], di = Symbol.for("vuetify:display"), Cr = {
  mobileBreakpoint: "lg",
  thresholds: {
    xs: 0,
    sm: 600,
    md: 960,
    lg: 1280,
    xl: 1920,
    xxl: 2560
  }
}, Df = function() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Cr;
  return vt(Cr, e);
};
function xr(e) {
  return Te && !e ? window.innerWidth : typeof e == "object" && e.clientWidth || 0;
}
function Vr(e) {
  return Te && !e ? window.innerHeight : typeof e == "object" && e.clientHeight || 0;
}
function Pr(e) {
  const n = Te && !e ? window.navigator.userAgent : "ssr";
  function t(h) {
    return !!n.match(h);
  }
  const a = t(/android/i), l = t(/iphone|ipad|ipod/i), i = t(/cordova/i), o = t(/electron/i), r = t(/chrome/i), u = t(/edge/i), c = t(/firefox/i), s = t(/opera/i), d = t(/win/i), f = t(/mac/i), m = t(/linux/i);
  return {
    android: a,
    ios: l,
    cordova: i,
    electron: o,
    chrome: r,
    edge: u,
    firefox: c,
    opera: s,
    win: d,
    mac: f,
    linux: m,
    touch: Ud,
    ssr: n === "ssr"
  };
}
function Mf(e, n) {
  const {
    thresholds: t,
    mobileBreakpoint: a
  } = Df(e), l = te(Vr(n)), i = te(Pr(n)), o = yt({}), r = te(xr(n));
  function u() {
    l.value = Vr(), r.value = xr();
  }
  function c() {
    u(), i.value = Pr();
  }
  return We(() => {
    const s = r.value < t.sm, d = r.value < t.md && !s, f = r.value < t.lg && !(d || s), m = r.value < t.xl && !(f || d || s), h = r.value < t.xxl && !(m || f || d || s), b = r.value >= t.xxl, g = s ? "xs" : d ? "sm" : f ? "md" : m ? "lg" : h ? "xl" : "xxl", S = typeof a == "number" ? a : t[a], y = r.value < S;
    o.xs = s, o.sm = d, o.md = f, o.lg = m, o.xl = h, o.xxl = b, o.smAndUp = !s, o.mdAndUp = !(s || d), o.lgAndUp = !(s || d || f), o.xlAndUp = !(s || d || f || m), o.smAndDown = !(f || m || h || b), o.mdAndDown = !(m || h || b), o.lgAndDown = !(h || b), o.xlAndDown = !b, o.name = g, o.height = l.value, o.width = r.value, o.mobile = y, o.mobileBreakpoint = a, o.platform = i.value, o.thresholds = t;
  }), Te && (window.addEventListener("resize", u, {
    passive: !0
  }), tt(() => {
    window.removeEventListener("resize", u);
  }, !0)), le(v({}, Xn(o)), {
    update: c,
    ssr: !!n
  });
}
const Pn = N({
  mobile: {
    type: Boolean,
    default: !1
  },
  mobileBreakpoint: [Number, String]
}, "display");
function At() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
    mobile: null
  }, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  const t = Pe(di);
  if (!t) throw new Error("Could not find Vuetify display injection");
  const a = C(() => e.mobile ? !0 : typeof e.mobileBreakpoint == "number" ? t.width.value < e.mobileBreakpoint : e.mobileBreakpoint ? t.width.value < t.thresholds.value[e.mobileBreakpoint] : e.mobile === null ? t.mobile.value : !1), l = M(() => n ? {
    [`${n}--mobile`]: a.value
  } : {});
  return le(v({}, t), {
    displayClasses: l,
    mobile: a
  });
}
const $u = Symbol.for("vuetify:goto");
function Fu() {
  return {
    container: void 0,
    duration: 300,
    layout: !1,
    offset: 0,
    easing: "easeInOutCubic",
    patterns: Fv
  };
}
function pf(e) {
  var n;
  return (n = ao(e)) != null ? n : document.scrollingElement || document.body;
}
function ao(e) {
  return typeof e == "string" ? document.querySelector(e) : Ui(e);
}
function jl(e, n, t) {
  if (typeof e == "number") return n && t ? -e : e;
  let a = ao(e), l = 0;
  for (; a; )
    l += n ? a.offsetLeft : a.offsetTop, a = a.offsetParent;
  return l;
}
function Ef(e, n) {
  return {
    rtl: n.isRtl,
    options: vt(Fu(), e)
  };
}
function Ir(e, n, t, a) {
  return He(this, null, function* () {
    var m, h, b;
    const l = t ? "scrollLeft" : "scrollTop", i = vt((m = a == null ? void 0 : a.options) != null ? m : Fu(), n), o = a == null ? void 0 : a.rtl.value, r = (h = typeof e == "number" ? e : ao(e)) != null ? h : 0, u = i.container === "parent" && r instanceof HTMLElement ? r.parentElement : pf(i.container), c = typeof i.easing == "function" ? i.easing : i.patterns[i.easing];
    if (!c) throw new TypeError(`Easing function "${i.easing}" not found.`);
    let s;
    if (typeof r == "number")
      s = jl(r, t, o);
    else if (s = jl(r, t, o) - jl(u, t, o), i.layout) {
      const S = window.getComputedStyle(r).getPropertyValue("--v-layout-top");
      S && (s -= parseInt(S, 10));
    }
    s += i.offset, s = $f(u, s, !!o, !!t);
    const d = (b = u[l]) != null ? b : 0;
    if (s === d) return Promise.resolve(s);
    const f = performance.now();
    return new Promise((g) => requestAnimationFrame(function S(y) {
      const V = (y - f) / i.duration, x = Math.floor(d + (s - d) * c(Fe(V, 0, 1)));
      if (u[l] = x, V >= 1 && Math.abs(x - u[l]) < 10)
        return g(s);
      if (V > 2)
        return et("Scroll target is not reachable"), g(u[l]);
      requestAnimationFrame(S);
    }));
  });
}
function Ou() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  const n = Pe($u), {
    isRtl: t
  } = Xe();
  if (!n) throw new Error("[Vuetify] Could not find injected goto instance");
  const a = le(v({}, n), {
    // can be set via VLocaleProvider
    rtl: M(() => n.rtl.value || t.value)
  });
  function l(i, o) {
    return He(this, null, function* () {
      return Ir(i, vt(e, o), !1, a);
    });
  }
  return l.horizontal = (i, o) => He(this, null, function* () {
    return Ir(i, vt(e, o), !0, a);
  }), l;
}
function $f(e, n, t, a) {
  const {
    scrollWidth: l,
    scrollHeight: i
  } = e, [o, r] = e === document.scrollingElement ? [window.innerWidth, window.innerHeight] : [e.offsetWidth, e.offsetHeight];
  let u, c;
  return a ? t ? (u = -(l - o), c = 0) : (u = 0, c = l - o) : (u = 0, c = i + -r), Fe(n, u, c);
}
const Ff = {
  collapse: "mdi-chevron-up",
  complete: "mdi-check",
  cancel: "mdi-close-circle",
  close: "mdi-close",
  delete: "mdi-close-circle",
  // delete (e.g. v-chip close)
  clear: "mdi-close-circle",
  success: "mdi-check-circle",
  info: "mdi-information",
  warning: "mdi-alert-circle",
  error: "mdi-close-circle",
  prev: "mdi-chevron-left",
  next: "mdi-chevron-right",
  checkboxOn: "mdi-checkbox-marked",
  checkboxOff: "mdi-checkbox-blank-outline",
  checkboxIndeterminate: "mdi-minus-box",
  delimiter: "mdi-circle",
  // for carousel
  sortAsc: "mdi-arrow-up",
  sortDesc: "mdi-arrow-down",
  expand: "mdi-chevron-down",
  menu: "mdi-menu",
  subgroup: "mdi-menu-down",
  dropdown: "mdi-menu-down",
  radioOn: "mdi-radiobox-marked",
  radioOff: "mdi-radiobox-blank",
  edit: "mdi-pencil",
  ratingEmpty: "mdi-star-outline",
  ratingFull: "mdi-star",
  ratingHalf: "mdi-star-half-full",
  loading: "mdi-cached",
  first: "mdi-page-first",
  last: "mdi-page-last",
  unfold: "mdi-unfold-more-horizontal",
  file: "mdi-paperclip",
  plus: "mdi-plus",
  minus: "mdi-minus",
  calendar: "mdi-calendar",
  treeviewCollapse: "mdi-menu-down",
  treeviewExpand: "mdi-menu-right",
  eyeDropper: "mdi-eyedropper",
  upload: "mdi-cloud-upload",
  color: "mdi-palette",
  command: "mdi-apple-keyboard-command",
  ctrl: "mdi-apple-keyboard-control",
  space: "mdi-keyboard-space",
  shift: "mdi-apple-keyboard-shift",
  alt: "mdi-apple-keyboard-option",
  enter: "mdi-keyboard-return",
  arrowup: "mdi-arrow-up",
  arrowdown: "mdi-arrow-down",
  arrowleft: "mdi-arrow-left",
  arrowright: "mdi-arrow-right",
  backspace: "mdi-backspace",
  play: "mdi-play",
  pause: "mdi-pause",
  fullscreen: "mdi-fullscreen",
  fullscreenExit: "mdi-fullscreen-exit",
  volumeHigh: "mdi-volume-high",
  volumeMedium: "mdi-volume-medium",
  volumeLow: "mdi-volume-low",
  volumeOff: "mdi-volume-variant-off"
}, Of = {
  // Not using mergeProps here, functional components merge props by default (?)
  component: (e) => Vn(lo, le(v({}, e), {
    class: "mdi"
  }))
}, me = [String, Function, Object, Array], vi = Symbol.for("vuetify:icons"), hl = N({
  icon: {
    type: me
  },
  // Could not remove this and use makeTagProps, types complained because it is not required
  tag: {
    type: [String, Object, Function],
    required: !0
  }
}, "icon"), fi = Y()({
  name: "VComponentIcon",
  props: hl(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return () => {
      const a = e.icon;
      return k(e.tag, null, {
        default: () => {
          var l;
          return [e.icon ? k(a, null, null) : (l = t.default) == null ? void 0 : l.call(t)];
        }
      });
    };
  }
}), yl = _t({
  name: "VSvgIcon",
  inheritAttrs: !1,
  props: hl(),
  setup(e, n) {
    let {
      attrs: t
    } = n;
    return () => k(e.tag, G(t, {
      style: null
    }), {
      default: () => [w("svg", {
        class: "v-icon__svg",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 24 24",
        role: "img",
        "aria-hidden": "true"
      }, [Array.isArray(e.icon) ? e.icon.map((a) => Array.isArray(a) ? w("path", {
        d: a[0],
        "fill-opacity": a[1]
      }, null) : w("path", {
        d: a
      }, null)) : w("path", {
        d: e.icon
      }, null)])]
    });
  }
}), Nf = _t({
  name: "VLigatureIcon",
  props: hl(),
  setup(e) {
    return () => k(e.tag, null, {
      default: () => [e.icon]
    });
  }
}), lo = _t({
  name: "VClassIcon",
  props: hl(),
  setup(e) {
    return () => k(e.tag, {
      class: X(e.icon)
    }, null);
  }
});
function Rf() {
  return {
    svg: {
      component: yl
    },
    class: {
      component: lo
    }
  };
}
function Hf(e) {
  var a;
  const n = Rf(), t = (a = e == null ? void 0 : e.defaultSet) != null ? a : "mdi";
  return t === "mdi" && !n.mdi && (n.mdi = Of), vt({
    defaultSet: t,
    sets: n,
    aliases: le(v({}, Ff), {
      /* eslint-disable max-len */
      vuetify: ["M8.2241 14.2009L12 21L22 3H14.4459L8.2241 14.2009Z", ["M7.26303 12.4733L7.00113 12L2 3H12.5261C12.5261 3 12.5261 3 12.5261 3L7.26303 12.4733Z", 0.6]],
      "vuetify-outline": "svg:M7.26 12.47 12.53 3H2L7.26 12.47ZM14.45 3 8.22 14.2 12 21 22 3H14.45ZM18.6 5 12 16.88 10.51 14.2 15.62 5ZM7.26 8.35 5.4 5H9.13L7.26 8.35Z",
      "vuetify-play": ["m6.376 13.184-4.11-7.192C1.505 4.66 2.467 3 4.003 3h8.532l-.953 1.576-.006.01-.396.677c-.429.732-.214 1.507.194 2.015.404.503 1.092.878 1.869.806a3.72 3.72 0 0 1 1.005.022c.276.053.434.143.523.237.138.146.38.635-.25 2.09-.893 1.63-1.553 1.722-1.847 1.677-.213-.033-.468-.158-.756-.406a4.95 4.95 0 0 1-.8-.927c-.39-.564-1.04-.84-1.66-.846-.625-.006-1.316.27-1.693.921l-.478.826-.911 1.506Z", ["M9.093 11.552c.046-.079.144-.15.32-.148a.53.53 0 0 1 .43.207c.285.414.636.847 1.046 1.2.405.35.914.662 1.516.754 1.334.205 2.502-.698 3.48-2.495l.014-.028.013-.03c.687-1.574.774-2.852-.005-3.675-.37-.391-.861-.586-1.333-.676a5.243 5.243 0 0 0-1.447-.044c-.173.016-.393-.073-.54-.257-.145-.18-.127-.316-.082-.392l.393-.672L14.287 3h5.71c1.536 0 2.499 1.659 1.737 2.992l-7.997 13.996c-.768 1.344-2.706 1.344-3.473 0l-3.037-5.314 1.377-2.278.004-.006.004-.007.481-.831Z", 0.6]]
      /* eslint-enable max-len */
    })
  }, e);
}
const zf = (e) => {
  const n = Pe(vi);
  if (!n) throw new Error("Missing Vuetify Icons provide!");
  return {
    iconData: C(() => {
      var u;
      const a = st(e);
      if (!a) return {
        component: fi
      };
      let l = a;
      if (typeof l == "string" && (l = l.trim(), l.startsWith("$") && (l = (u = n.aliases) == null ? void 0 : u[l.slice(1)])), l || et(`Could not find aliased icon "${a}"`), Array.isArray(l))
        return {
          component: yl,
          icon: l
        };
      if (typeof l != "string")
        return {
          component: fi,
          icon: l
        };
      const i = Object.keys(n.sets).find((c) => typeof l == "string" && l.startsWith(`${c}:`)), o = i ? l.slice(i.length + 1) : l;
      return {
        component: n.sets[i != null ? i : n.defaultSet].component,
        icon: o
      };
    })
  };
}, ga = Symbol.for("vuetify:theme"), Ie = N({
  theme: String
}, "theme");
function _r() {
  return {
    defaultTheme: "light",
    prefix: "v-",
    variations: {
      colors: [],
      lighten: 0,
      darken: 0
    },
    themes: {
      light: {
        dark: !1,
        colors: {
          background: "#FFFFFF",
          surface: "#FFFFFF",
          "surface-bright": "#FFFFFF",
          "surface-light": "#EEEEEE",
          "surface-variant": "#424242",
          "on-surface-variant": "#EEEEEE",
          primary: "#1867C0",
          "primary-darken-1": "#1F5592",
          secondary: "#48A9A6",
          "secondary-darken-1": "#018786",
          error: "#B00020",
          info: "#2196F3",
          success: "#4CAF50",
          warning: "#FB8C00"
        },
        variables: {
          "border-color": "#000000",
          "border-opacity": 0.12,
          "high-emphasis-opacity": 0.87,
          "medium-emphasis-opacity": 0.6,
          "disabled-opacity": 0.38,
          "idle-opacity": 0.04,
          "hover-opacity": 0.04,
          "focus-opacity": 0.12,
          "selected-opacity": 0.08,
          "activated-opacity": 0.12,
          "pressed-opacity": 0.12,
          "dragged-opacity": 0.08,
          "theme-kbd": "#EEEEEE",
          "theme-on-kbd": "#000000",
          "theme-code": "#F5F5F5",
          "theme-on-code": "#000000"
        }
      },
      dark: {
        dark: !0,
        colors: {
          background: "#121212",
          surface: "#212121",
          "surface-bright": "#ccbfd6",
          "surface-light": "#424242",
          "surface-variant": "#c8c8c8",
          "on-surface-variant": "#000000",
          primary: "#2196F3",
          "primary-darken-1": "#277CC1",
          secondary: "#54B6B2",
          "secondary-darken-1": "#48A9A6",
          error: "#CF6679",
          info: "#2196F3",
          success: "#4CAF50",
          warning: "#FB8C00"
        },
        variables: {
          "border-color": "#FFFFFF",
          "border-opacity": 0.12,
          "high-emphasis-opacity": 1,
          "medium-emphasis-opacity": 0.7,
          "disabled-opacity": 0.5,
          "idle-opacity": 0.1,
          "hover-opacity": 0.04,
          "focus-opacity": 0.12,
          "selected-opacity": 0.08,
          "activated-opacity": 0.12,
          "pressed-opacity": 0.16,
          "dragged-opacity": 0.08,
          "theme-kbd": "#424242",
          "theme-on-kbd": "#FFFFFF",
          "theme-code": "#343434",
          "theme-on-code": "#CCCCCC"
        }
      }
    },
    stylesheetId: "vuetify-theme-stylesheet",
    scoped: !1,
    unimportant: !1,
    utilities: !0
  };
}
function Wf() {
  var a, l, i;
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : _r();
  const n = _r();
  if (!e) return le(v({}, n), {
    isDisabled: !0
  });
  const t = {};
  for (const [o, r] of Object.entries((a = e.themes) != null ? a : {})) {
    const u = r.dark || o === "dark" ? (l = n.themes) == null ? void 0 : l.dark : (i = n.themes) == null ? void 0 : i.light;
    t[o] = vt(u, r);
  }
  return vt(n, le(v({}, e), {
    themes: t
  }));
}
function sn(e, n, t, a) {
  e.push(`${Uf(n, a)} {
`, ...t.map((l) => `  ${l};
`), `}
`);
}
function Ar(e, n) {
  const t = e.dark ? 2 : 1, a = e.dark ? 1 : 2, l = [];
  for (const [i, o] of Object.entries(e.colors)) {
    const r = Pt(o);
    l.push(`--${n}theme-${i}: ${r.r},${r.g},${r.b}`), i.startsWith("on-") || l.push(`--${n}theme-${i}-overlay-multiplier: ${ri(o) > 0.18 ? t : a}`);
  }
  for (const [i, o] of Object.entries(e.variables)) {
    const r = typeof o == "string" && o.startsWith("#") ? Pt(o) : void 0, u = r ? `${r.r}, ${r.g}, ${r.b}` : void 0;
    l.push(`--${n}${i}: ${u != null ? u : o}`);
  }
  return l;
}
function jf(e, n, t) {
  const a = {};
  if (t)
    for (const l of ["lighten", "darken"]) {
      const i = l === "lighten" ? _v : Av;
      for (const o of Vt(t[l], 1))
        a[`${e}-${l}-${o}`] = wu(i(Pt(n), o));
    }
  return a;
}
function Yf(e, n) {
  if (!n) return {};
  let t = {};
  for (const a of n.colors) {
    const l = e[a];
    l && (t = v(v({}, t), jf(a, l, n)));
  }
  return t;
}
function Gf(e) {
  const n = {};
  for (const t of Object.keys(e)) {
    if (t.startsWith("on-") || e[`on-${t}`]) continue;
    const a = `on-${t}`, l = Pt(e[t]);
    n[a] = Vu(l);
  }
  return n;
}
function Uf(e, n) {
  if (!n) return e;
  const t = `:where(${n})`;
  return e === ":root" ? t : `${t} ${e}`;
}
function Kf(e, n, t) {
  const a = qf(e, n);
  a && (a.innerHTML = t);
}
function qf(e, n) {
  if (!Te) return null;
  let t = document.getElementById(e);
  return t || (t = document.createElement("style"), t.id = e, t.type = "text/css", n && t.setAttribute("nonce", n), document.head.appendChild(t)), t;
}
function Xf(e) {
  const n = Wf(e), t = te(n.defaultTheme), a = Q(n.themes), l = te("light"), i = C({
    get() {
      return t.value === "system" ? l.value : t.value;
    },
    set(S) {
      t.value = S;
    }
  }), o = C(() => {
    const S = {};
    for (const [y, P] of Object.entries(a.value)) {
      const V = v(v({}, P.colors), Yf(P.colors, n.variations));
      S[y] = le(v({}, P), {
        colors: v(v({}, V), Gf(V))
      });
    }
    return S;
  }), r = M(() => o.value[i.value]), u = M(() => t.value === "system"), c = C(() => {
    var V;
    const S = [], y = n.unimportant ? "" : " !important", P = n.scoped ? n.prefix : "";
    (V = r.value) != null && V.dark && sn(S, ":root", ["color-scheme: dark"], n.scope), sn(S, ":root", Ar(r.value, n.prefix), n.scope);
    for (const [x, I] of Object.entries(o.value))
      sn(S, `.${n.prefix}theme--${x}`, [`color-scheme: ${I.dark ? "dark" : "normal"}`, ...Ar(I, n.prefix)], n.scope);
    if (n.utilities) {
      const x = [], I = [], T = new Set(Object.values(o.value).flatMap((_) => Object.keys(_.colors)));
      for (const _ of T)
        _.startsWith("on-") ? sn(I, `.${_}`, [`color: rgb(var(--${n.prefix}theme-${_}))${y}`], n.scope) : (sn(x, `.${P}bg-${_}`, [`--${n.prefix}theme-overlay-multiplier: var(--${n.prefix}theme-${_}-overlay-multiplier)`, `background-color: rgb(var(--${n.prefix}theme-${_}))${y}`, `color: rgb(var(--${n.prefix}theme-on-${_}))${y}`], n.scope), sn(I, `.${P}text-${_}`, [`color: rgb(var(--${n.prefix}theme-${_}))${y}`], n.scope), sn(I, `.${P}border-${_}`, [`--${n.prefix}border-color: var(--${n.prefix}theme-${_})`], n.scope));
      S.push(...x, ...I);
    }
    return S.map((x, I) => I === 0 ? x : `    ${x}`).join("");
  }), s = M(() => n.isDisabled ? void 0 : `${n.prefix}theme--${i.value}`), d = M(() => Object.keys(o.value));
  if (Kd) {
    let y = function() {
      l.value = S.matches ? "dark" : "light";
    };
    const S = window.matchMedia("(prefers-color-scheme: dark)");
    y(), S.addEventListener("change", y, {
      passive: !0
    }), pd() && tt(() => {
      S.removeEventListener("change", y);
    });
  }
  function f(S) {
    if (n.isDisabled) return;
    const y = S._context.provides.usehead;
    if (y) {
      let P = function() {
        return {
          style: [{
            textContent: c.value,
            id: n.stylesheetId,
            nonce: n.cspNonce || !1
          }]
        };
      };
      if (y.push) {
        const V = y.push(P);
        Te && oe(c, () => {
          V.patch(P);
        });
      } else
        Te ? (y.addHeadObjs(M(P)), We(() => y.updateDOM())) : y.addHeadObjs(P());
    } else {
      let P = function() {
        Kf(n.stylesheetId, n.cspNonce, c.value);
      };
      Te ? oe(c, P, {
        immediate: !0
      }) : P();
    }
  }
  function m(S) {
    if (S !== "system" && !d.value.includes(S)) {
      et(`Theme "${S}" not found on the Vuetify theme instance`);
      return;
    }
    i.value = S;
  }
  function h() {
    let S = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : d.value;
    const y = S.indexOf(i.value), P = y === -1 ? 0 : (y + 1) % S.length;
    m(S[P]);
  }
  function b() {
    let S = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : ["light", "dark"];
    h(S);
  }
  const g = new Proxy(i, {
    get(S, y) {
      return Reflect.get(S, y);
    },
    set(S, y, P) {
      return y === "value" && gu(`theme.global.name.value = ${P}`, `theme.change('${P}')`), Reflect.set(S, y, P);
    }
  });
  return {
    install: f,
    change: m,
    cycle: h,
    toggle: b,
    isDisabled: n.isDisabled,
    isSystem: u,
    name: i,
    themes: a,
    current: r,
    computedThemes: o,
    prefix: n.prefix,
    themeClasses: s,
    styles: c,
    global: {
      name: g,
      current: r
    }
  };
}
function De(e) {
  Ke("provideTheme");
  const n = Pe(ga, null);
  if (!n) throw new Error("Could not find Vuetify theme injection");
  const t = M(() => {
    var o;
    return (o = e.theme) != null ? o : n.name.value;
  }), a = M(() => n.themes.value[t.value]), l = M(() => n.isDisabled ? void 0 : `${n.prefix}theme--${t.value}`), i = le(v({}, n), {
    name: t,
    current: a,
    themeClasses: l
  });
  return Oe(ga, i), i;
}
function bl() {
  Ke("useTheme");
  const e = Pe(ga, null);
  if (!e) throw new Error("Could not find Vuetify theme injection");
  return e;
}
function pt(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "content";
  const t = tl(), a = Q();
  if (Te) {
    const l = new ResizeObserver((i) => {
      e == null || e(i, l), i.length && (n === "content" ? a.value = i[0].contentRect : a.value = i[0].target.getBoundingClientRect());
    });
    dt(() => {
      l.disconnect();
    }), oe(() => t.el, (i, o) => {
      o && (l.unobserve(o), a.value = void 0), i && l.observe(i);
    }, {
      flush: "post"
    });
  }
  return {
    resizeRef: t,
    contentRect: vl(a)
  };
}
const ha = Symbol.for("vuetify:layout"), Nu = Symbol.for("vuetify:layout-item"), Lr = 1e3, Ru = N({
  overlaps: {
    type: Array,
    default: () => []
  },
  fullHeight: Boolean
}, "layout"), In = N({
  name: {
    type: String
  },
  order: {
    type: [Number, String],
    default: 0
  },
  absolute: Boolean
}, "layout-item");
function io() {
  const e = Pe(ha);
  if (!e) throw new Error("[Vuetify] Could not find injected layout");
  return {
    getLayoutItem: e.getLayoutItem,
    mainRect: e.mainRect,
    mainStyles: e.mainStyles
  };
}
function _n(e) {
  var r;
  const n = Pe(ha);
  if (!n) throw new Error("[Vuetify] Could not find injected layout");
  const t = (r = e.id) != null ? r : `layout-item-${St()}`, a = Ke("useLayoutItem");
  Oe(Nu, {
    id: t
  });
  const l = te(!1);
  nu(() => l.value = !0), Ed(() => l.value = !1);
  const {
    layoutItemStyles: i,
    layoutItemScrimStyles: o
  } = n.register(a, le(v({}, e), {
    active: C(() => l.value ? !1 : e.active.value),
    id: t
  }));
  return dt(() => n.unregister(t)), {
    layoutItemStyles: i,
    layoutRect: n.layoutRect,
    layoutItemScrimStyles: o
  };
}
const Zf = (e, n, t, a) => {
  let l = {
    top: 0,
    left: 0,
    right: 0,
    bottom: 0
  };
  const i = [{
    id: "",
    layer: v({}, l)
  }];
  for (const o of e) {
    const r = n.get(o), u = t.get(o), c = a.get(o);
    if (!r || !u || !c) continue;
    const s = le(v({}, l), {
      [r.value]: parseInt(l[r.value], 10) + (c.value ? parseInt(u.value, 10) : 0)
    });
    i.push({
      id: o,
      layer: s
    }), l = s;
  }
  return i;
};
function Hu(e) {
  const n = Pe(ha, null), t = C(() => n ? n.rootZIndex.value - 100 : Lr), a = Q([]), l = yt(/* @__PURE__ */ new Map()), i = yt(/* @__PURE__ */ new Map()), o = yt(/* @__PURE__ */ new Map()), r = yt(/* @__PURE__ */ new Map()), u = yt(/* @__PURE__ */ new Map()), {
    resizeRef: c,
    contentRect: s
  } = pt(), d = C(() => {
    var _;
    const I = /* @__PURE__ */ new Map(), T = (_ = e.overlaps) != null ? _ : [];
    for (const p of T.filter((L) => L.includes(":"))) {
      const [L, D] = p.split(":");
      if (!a.value.includes(L) || !a.value.includes(D)) continue;
      const A = l.get(L), B = l.get(D), F = i.get(L), $ = i.get(D);
      !A || !B || !F || !$ || (I.set(D, {
        position: A.value,
        amount: parseInt(F.value, 10)
      }), I.set(L, {
        position: B.value,
        amount: -parseInt($.value, 10)
      }));
    }
    return I;
  }), f = C(() => {
    const I = [...new Set([...o.values()].map((_) => _.value))].sort((_, p) => _ - p), T = [];
    for (const _ of I) {
      const p = a.value.filter((L) => {
        var D;
        return ((D = o.get(L)) == null ? void 0 : D.value) === _;
      });
      T.push(...p);
    }
    return Zf(T, l, i, r);
  }), m = C(() => !Array.from(u.values()).some((I) => I.value)), h = C(() => f.value[f.value.length - 1].layer), b = M(() => v({
    "--v-layout-left": ce(h.value.left),
    "--v-layout-right": ce(h.value.right),
    "--v-layout-top": ce(h.value.top),
    "--v-layout-bottom": ce(h.value.bottom)
  }, m.value ? void 0 : {
    transition: "none"
  })), g = C(() => f.value.slice(1).map((I, T) => {
    let {
      id: _
    } = I;
    const {
      layer: p
    } = f.value[T], L = i.get(_), D = l.get(_);
    return le(v({
      id: _
    }, p), {
      size: Number(L.value),
      position: D.value
    });
  })), S = (I) => g.value.find((T) => T.id === I), y = Ke("createLayout"), P = te(!1);
  gt(() => {
    P.value = !0;
  }), Oe(ha, {
    register: (I, T) => {
      let {
        id: _,
        order: p,
        position: L,
        layoutSize: D,
        elementSize: A,
        active: B,
        disableTransitions: F,
        absolute: $
      } = T;
      o.set(_, p), l.set(_, L), i.set(_, D), r.set(_, B), F && u.set(_, F);
      const J = Nn(Nu, y == null ? void 0 : y.vnode).indexOf(I);
      J > -1 ? a.value.splice(J, 0, _) : a.value.push(_);
      const z = C(() => g.value.findIndex((R) => R.id === _)), H = C(() => t.value + f.value.length * 2 - z.value * 2), E = C(() => {
        var ee;
        const R = L.value === "left" || L.value === "right", q = L.value === "right", ae = L.value === "bottom", U = (ee = A.value) != null ? ee : D.value, ne = U === 0 ? "%" : "px", j = v({
          [L.value]: 0,
          zIndex: H.value,
          transform: `translate${R ? "X" : "Y"}(${(B.value ? 0 : -(U === 0 ? 100 : U)) * (q || ae ? -1 : 1)}${ne})`,
          position: $.value || t.value !== Lr ? "absolute" : "fixed"
        }, m.value ? void 0 : {
          transition: "none"
        });
        if (!P.value) return j;
        const ue = g.value[z.value];
        ue || et(`[Vuetify] Could not find layout item "${_}"`);
        const ge = d.value.get(_);
        return ge && (ue[ge.position] += ge.amount), le(v({}, j), {
          height: R ? `calc(100% - ${ue.top}px - ${ue.bottom}px)` : A.value ? `${A.value}px` : void 0,
          left: q ? void 0 : `${ue.left}px`,
          right: q ? `${ue.right}px` : void 0,
          top: L.value !== "bottom" ? `${ue.top}px` : void 0,
          bottom: L.value !== "top" ? `${ue.bottom}px` : void 0,
          width: R ? A.value ? `${A.value}px` : void 0 : `calc(100% - ${ue.left}px - ${ue.right}px)`
        });
      }), O = C(() => ({
        zIndex: H.value - 1
      }));
      return {
        layoutItemStyles: E,
        layoutItemScrimStyles: O,
        zIndex: H
      };
    },
    unregister: (I) => {
      o.delete(I), l.delete(I), i.delete(I), r.delete(I), u.delete(I), a.value = a.value.filter((T) => T !== I);
    },
    mainRect: h,
    mainStyles: b,
    getLayoutItem: S,
    items: g,
    layoutRect: s,
    rootZIndex: t
  });
  const V = M(() => ["v-layout", {
    "v-layout--full-height": e.fullHeight
  }]), x = M(() => ({
    zIndex: n ? t.value : void 0,
    position: n ? "relative" : void 0,
    overflow: n ? "hidden" : void 0
  }));
  return {
    layoutClasses: V,
    layoutStyles: x,
    getLayoutItem: S,
    items: g,
    layoutRect: s,
    layoutRef: c
  };
}
const Qf = {
  // Modifier aliases (from vue-use, other libraries, and current implementation)
  control: "ctrl",
  command: "cmd",
  option: "alt",
  // Arrow key aliases (common abbreviations)
  up: "arrowup",
  down: "arrowdown",
  left: "arrowleft",
  right: "arrowright",
  // Other common key aliases
  esc: "escape",
  spacebar: " ",
  space: " ",
  return: "enter",
  del: "delete",
  // Symbol aliases (existing from hotkey-parsing.ts)
  minus: "-",
  hyphen: "-"
};
function Tr(e) {
  const n = e.toLowerCase();
  return Qf[n] || n;
}
function zu(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
  if (!e)
    return n || et("Invalid hotkey combination: empty string provided"), [];
  const a = (
    // Starts with a single '+' or '_' followed by a non-separator character (e.g. '+a', '_a')
    (e.startsWith("+") || e.startsWith("_")) && !(e.startsWith("++") || e.startsWith("__"))
  );
  if (
    // Invalid leading separator patterns
    e.length > 1 && a || // Disallow literal + or _ keys (they require shift)
    e.includes("++") || e.includes("__") || e === "+" || e === "_" || // Ends with a separator that is not part of a doubled literal
    e.length > 1 && (e.endsWith("+") || e.endsWith("_")) && e.at(-2) !== e.at(-1) || // Stand-alone doubled separators (dangling)
    e === "++" || e === "--" || e === "__"
  )
    return n || et(`Invalid hotkey combination: "${e}" has invalid structure`), [];
  const i = [];
  let o = "";
  const r = () => {
    o && (i.push(Tr(o)), o = "");
  };
  for (let c = 0; c < e.length; c++) {
    const s = e[c], d = e[c + 1];
    s === "+" || s === "_" || s === "-" ? s === d ? (r(), i.push(s), c++) : s === "+" || s === "_" ? r() : o += s : o += s;
  }
  return r(), i.some((c) => c.length > 1 && c.includes("-") && c !== "--") ? (n || et(`Invalid hotkey combination: "${e}" has invalid structure`), []) : i.length === 0 && e ? [Tr(e)] : i;
}
function Jf(e) {
  if (!e)
    return et("Invalid hotkey sequence: empty string provided"), [];
  const n = e.startsWith("-") && !["---", "--+"].includes(e), t = e.endsWith("-") && !e.endsWith("+-") && !e.endsWith("_-") && e !== "-" && e !== "---";
  if (n || t)
    return et(`Invalid hotkey sequence: "${e}" contains invalid combinations`), [];
  const a = [];
  let l = "", i = 0;
  for (; i < e.length; ) {
    const c = e[i];
    if (c === "-") {
      const s = e[i - 1], d = i > 1 ? e[i - 2] : void 0;
      (s === "+" || s === "_") && d !== "+" ? (l += c, i++) : (l ? (a.push(l), l = "") : a.push("-"), i++);
    } else
      l += c, i++;
  }
  l && a.push(l);
  const o = [];
  let r = 0;
  for (const c of a)
    c === "-" ? (r % 2 === 0 && o.push("-"), r++) : (r = 0, o.push(c));
  return o.every((c) => zu(c, !0).length > 0) ? o : (et(`Invalid hotkey sequence: "${e}" contains invalid combinations`), []);
}
function em(e, n) {
  var P, V;
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
  if (!Te) return function() {
  };
  const {
    event: a = "keydown",
    inputs: l = !1,
    preventDefault: i = !0,
    sequenceTimeout: o = 1e3
  } = t, r = (V = (P = navigator == null ? void 0 : navigator.userAgent) == null ? void 0 : P.includes("Macintosh")) != null ? V : !1;
  let u = 0, c, s = !1, d = 0;
  function f() {
    u && (clearTimeout(u), u = 0);
  }
  function m() {
    if (st(l)) return !1;
    const x = document.activeElement;
    return x && (x.tagName === "INPUT" || x.tagName === "TEXTAREA" || x.isContentEditable || x.contentEditable === "true");
  }
  function h() {
    d = 0, f();
  }
  function b(x) {
    const I = c[d];
    if (!(!I || m())) {
      if (!y(x, I)) {
        s && h();
        return;
      }
      if (st(i) && x.preventDefault(), !s) {
        n(x);
        return;
      }
      if (f(), d++, d === c.length) {
        n(x), h();
        return;
      }
      u = window.setTimeout(h, st(o));
    }
  }
  function g() {
    window.removeEventListener(st(a), b), f();
  }
  oe(() => st(e), function(x) {
    if (g(), x) {
      const I = Jf(x.toLowerCase());
      s = I.length > 1, c = I, h(), window.addEventListener(st(a), b);
    }
  }, {
    immediate: !0
  }), oe(() => st(a), function(x, I) {
    I && c && c.length > 0 && (window.removeEventListener(I, b), window.addEventListener(x, b));
  });
  try {
    Ke("useHotkey"), dt(g);
  } catch (x) {
  }
  function S(x) {
    const I = ["ctrl", "shift", "alt", "meta", "cmd"], T = zu(x.toLowerCase());
    if (T.length === 0)
      return {
        modifiers: Object.fromEntries(I.map((L) => [L, !1])),
        actualKey: void 0
      };
    const _ = Object.fromEntries(I.map((L) => [L, !1]));
    let p;
    for (const L of T)
      I.includes(L) ? _[L] = !0 : p = L;
    return {
      modifiers: _,
      actualKey: p
    };
  }
  function y(x, I) {
    const {
      modifiers: T,
      actualKey: _
    } = S(I), p = T.ctrl || !r && (T.cmd || T.meta), L = r && (T.cmd || T.meta);
    return x.ctrlKey === p && x.metaKey === L && x.shiftKey === T.shift && x.altKey === T.alt && x.key.toLowerCase() === (_ == null ? void 0 : _.toLowerCase());
  }
  return g;
}
function Wu() {
  const u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, {
    blueprint: n
  } = u, t = Ge(u, [
    "blueprint"
  ]), a = vt(n, t), {
    aliases: l = {},
    components: i = {},
    directives: o = {}
  } = a, r = Hn();
  return r.run(() => {
    const c = Bv(a.defaults), s = Mf(a.display, a.ssr), d = Xf(a.theme), f = Hf(a.icons), m = jv(a.locale), h = Tf(a.date, m), b = Ef(a.goTo, m);
    function g(y) {
      for (const V in o)
        y.directive(V, o[V]);
      for (const V in i)
        y.component(V, i[V]);
      for (const V in l)
        y.component(V, _t(le(v({}, l[V]), {
          name: V,
          aliasName: l[V].name
        })));
      const P = Hn();
      if (P.run(() => {
        d.install(y);
      }), y.onUnmount(() => P.stop()), y.provide(jn, c), y.provide(di, s), y.provide(ga, d), y.provide(vi, f), y.provide(Yn, m), y.provide(pu, h.options), y.provide(wr, h.instance), y.provide($u, b), Te && a.ssr)
        if (y.$nuxt)
          y.$nuxt.hook("app:suspense:resolve", () => {
            s.update();
          });
        else {
          const {
            mount: V
          } = y;
          y.mount = function() {
            const x = V(...arguments);
            return Ve(() => s.update()), y.mount = V, x;
          };
        }
      y.mixin({
        computed: {
          $vuetify() {
            return yt({
              defaults: Fn.call(this, jn),
              display: Fn.call(this, di),
              theme: Fn.call(this, ga),
              icons: Fn.call(this, vi),
              locale: Fn.call(this, Yn),
              date: Fn.call(this, wr)
            });
          }
        }
      });
    }
    function S() {
      r.stop();
    }
    return {
      install: g,
      unmount: S,
      defaults: c,
      display: s,
      theme: d,
      icons: f,
      locale: m,
      date: h,
      goTo: b
    };
  });
}
const ju = "3.9.7";
Wu.version = ju;
function Fn(e) {
  var a, l, i;
  const n = this.$, t = (i = (a = n.parent) == null ? void 0 : a.provides) != null ? i : (l = n.vnode.appContext) == null ? void 0 : l.provides;
  if (t && e in t)
    return t[e];
}
const z0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createVuetify: Wu,
  useDate: Zn,
  useDefaults: Mv,
  useDisplay: At,
  useGoTo: Ou,
  useHotkey: em,
  useLayout: io,
  useLocale: Ee,
  useRtl: Xe,
  useTheme: bl,
  version: ju
}, Symbol.toStringTag, { value: "Module" })), tm = N(v(v(v({}, de()), $e(Ru(), ["fullHeight"])), Ie()), "VApp"), nm = Y()({
  name: "VApp",
  props: tm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = De(e), {
      layoutClasses: l,
      getLayoutItem: i,
      items: o,
      layoutRef: r
    } = Hu(le(v({}, e), {
      fullHeight: !0
    })), {
      rtlClasses: u
    } = Xe();
    return Z(() => {
      var c;
      return w("div", {
        ref: r,
        class: X(["v-application", a.themeClasses.value, l.value, u.value, e.class]),
        style: ie([e.style])
      }, [w("div", {
        class: "v-application__wrap"
      }, [(c = t.default) == null ? void 0 : c.call(t)])]);
    }), {
      getLayoutItem: i,
      items: o,
      theme: a
    };
  }
}), ke = N({
  tag: {
    type: [String, Object, Function],
    default: "div"
  }
}, "tag"), Yu = N(v(v({
  text: String
}, de()), ke()), "VToolbarTitle"), oo = Y()({
  name: "VToolbarTitle",
  props: Yu(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      const a = !!(t.default || t.text || e.text);
      return k(e.tag, {
        class: X(["v-toolbar-title", e.class]),
        style: ie(e.style)
      }, {
        default: () => {
          var l;
          return [a && w("div", {
            class: "v-toolbar-title__placeholder"
          }, [t.text ? t.text() : e.text, (l = t.default) == null ? void 0 : l.call(t)])];
        }
      });
    }), {};
  }
}), am = N({
  disabled: Boolean,
  group: Boolean,
  hideOnLeave: Boolean,
  leaveAbsolute: Boolean,
  mode: String,
  origin: String
}, "transition");
function Lt(e, n, t) {
  return Y()({
    name: e,
    props: am({
      mode: t,
      origin: n
    }),
    setup(a, l) {
      let {
        slots: i
      } = l;
      const o = {
        onBeforeEnter(r) {
          a.origin && (r.style.transformOrigin = a.origin);
        },
        onLeave(r) {
          if (a.leaveAbsolute) {
            const {
              offsetTop: u,
              offsetLeft: c,
              offsetWidth: s,
              offsetHeight: d
            } = r;
            r._transitionInitialStyles = {
              position: r.style.position,
              top: r.style.top,
              left: r.style.left,
              width: r.style.width,
              height: r.style.height
            }, r.style.position = "absolute", r.style.top = `${u}px`, r.style.left = `${c}px`, r.style.width = `${s}px`, r.style.height = `${d}px`;
          }
          a.hideOnLeave && r.style.setProperty("display", "none", "important");
        },
        onAfterLeave(r) {
          if (a.leaveAbsolute && (r != null && r._transitionInitialStyles)) {
            const {
              position: u,
              top: c,
              left: s,
              width: d,
              height: f
            } = r._transitionInitialStyles;
            delete r._transitionInitialStyles, r.style.position = u || "", r.style.top = c || "", r.style.left = s || "", r.style.width = d || "", r.style.height = f || "";
          }
        }
      };
      return () => {
        const r = a.group ? Yi : en;
        return Vn(r, v(v({
          name: a.disabled ? "" : e,
          css: !a.disabled
        }, a.group ? void 0 : {
          mode: a.mode
        }), a.disabled ? {} : o), i.default);
      };
    }
  });
}
function Gu(e, n) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "in-out";
  return Y()({
    name: e,
    props: {
      mode: {
        type: String,
        default: t
      },
      disabled: Boolean,
      group: Boolean
    },
    setup(a, l) {
      let {
        slots: i
      } = l;
      const o = a.group ? Yi : en;
      return () => Vn(o, v({
        name: a.disabled ? "" : e,
        css: !a.disabled
      }, a.disabled ? {} : n), i.default);
    }
  });
}
function Uu() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
  const t = (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1) ? "width" : "height", a = ji(`offset-${t}`);
  return {
    onBeforeEnter(o) {
      o._parent = o.parentNode, o._initialStyle = {
        transition: o.style.transition,
        overflow: o.style.overflow,
        [t]: o.style[t]
      };
    },
    onEnter(o) {
      const r = o._initialStyle;
      if (!r) return;
      o.style.setProperty("transition", "none", "important"), o.style.overflow = "hidden";
      const u = `${o[a]}px`;
      o.style[t] = "0", o.offsetHeight, o.style.transition = r.transition, e && o._parent && o._parent.classList.add(e), requestAnimationFrame(() => {
        o.style[t] = u;
      });
    },
    onAfterEnter: i,
    onEnterCancelled: i,
    onLeave(o) {
      o._initialStyle = {
        transition: "",
        overflow: o.style.overflow,
        [t]: o.style[t]
      }, o.style.overflow = "hidden", o.style[t] = `${o[a]}px`, o.offsetHeight, requestAnimationFrame(() => o.style[t] = "0");
    },
    onAfterLeave: l,
    onLeaveCancelled: l
  };
  function l(o) {
    e && o._parent && o._parent.classList.remove(e), i(o);
  }
  function i(o) {
    if (!o._initialStyle) return;
    const r = o._initialStyle[t];
    o.style.overflow = o._initialStyle.overflow, r != null && (o.style[t] = r), delete o._initialStyle;
  }
}
const lm = N({
  target: [Object, Array]
}, "v-dialog-transition"), Yl = /* @__PURE__ */ new WeakMap(), Sl = Y()({
  name: "VDialogTransition",
  props: lm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = {
      onBeforeEnter(i) {
        i.style.pointerEvents = "none", i.style.visibility = "hidden";
      },
      onEnter(i, o) {
        return He(this, null, function* () {
          var h;
          yield new Promise((b) => requestAnimationFrame(b)), yield new Promise((b) => requestAnimationFrame(b)), i.style.visibility = "";
          const r = Dr(e.target, i), {
            x: u,
            y: c,
            sx: s,
            sy: d,
            speed: f
          } = r;
          Yl.set(i, r);
          const m = dn(i, [{
            transform: `translate(${u}px, ${c}px) scale(${s}, ${d})`,
            opacity: 0
          }, {}], {
            duration: 225 * f,
            easing: Ev
          });
          (h = Br(i)) == null || h.forEach((b) => {
            dn(b, [{
              opacity: 0
            }, {
              opacity: 0,
              offset: 0.33
            }, {}], {
              duration: 225 * 2 * f,
              easing: ma
            });
          }), m.finished.then(() => o());
        });
      },
      onAfterEnter(i) {
        i.style.removeProperty("pointer-events");
      },
      onBeforeLeave(i) {
        i.style.pointerEvents = "none";
      },
      onLeave(i, o) {
        return He(this, null, function* () {
          var h;
          yield new Promise((b) => requestAnimationFrame(b));
          let r;
          !Yl.has(i) || Array.isArray(e.target) || e.target.offsetParent || e.target.getClientRects().length ? r = Dr(e.target, i) : r = Yl.get(i);
          const {
            x: u,
            y: c,
            sx: s,
            sy: d,
            speed: f
          } = r;
          dn(i, [{}, {
            transform: `translate(${u}px, ${c}px) scale(${s}, ${d})`,
            opacity: 0
          }], {
            duration: 125 * f,
            easing: $v
          }).finished.then(() => o()), (h = Br(i)) == null || h.forEach((b) => {
            dn(b, [{}, {
              opacity: 0,
              offset: 0.2
            }, {
              opacity: 0
            }], {
              duration: 125 * 2 * f,
              easing: ma
            });
          });
        });
      },
      onAfterLeave(i) {
        i.style.removeProperty("pointer-events");
      }
    };
    return () => e.target ? k(en, G({
      name: "dialog-transition"
    }, a, {
      css: !1
    }), t) : k(en, {
      name: "dialog-transition"
    }, t);
  }
});
function Br(e) {
  var t;
  const n = (t = e.querySelector(":scope > .v-card, :scope > .v-sheet, :scope > .v-list")) == null ? void 0 : t.children;
  return n && [...n];
}
function Dr(e, n) {
  const t = mu(e), a = Xi(n), [l, i] = getComputedStyle(n).transformOrigin.split(" ").map((S) => parseFloat(S)), [o, r] = getComputedStyle(n).getPropertyValue("--v-overlay-anchor-origin").split(" ");
  let u = t.left + t.width / 2;
  o === "left" || r === "left" ? u -= t.width / 2 : (o === "right" || r === "right") && (u += t.width / 2);
  let c = t.top + t.height / 2;
  o === "top" || r === "top" ? c -= t.height / 2 : (o === "bottom" || r === "bottom") && (c += t.height / 2);
  const s = t.width / a.width, d = t.height / a.height, f = Math.max(1, s, d), m = s / f || 0, h = d / f || 0, b = a.width * a.height / (window.innerWidth * window.innerHeight), g = b > 0.12 ? Math.min(1.5, (b - 0.12) * 10 + 1) : 1;
  return {
    x: u - (l + a.left),
    y: c - (i + a.top),
    sx: m,
    sy: h,
    speed: g
  };
}
const im = Lt("fab-transition", "center center", "out-in"), om = Lt("dialog-bottom-transition"), rm = Lt("dialog-top-transition"), ya = Lt("fade-transition"), ro = Lt("scale-transition"), um = Lt("scroll-x-transition"), sm = Lt("scroll-x-reverse-transition"), cm = Lt("scroll-y-transition"), dm = Lt("scroll-y-reverse-transition"), vm = Lt("slide-x-transition"), fm = Lt("slide-x-reverse-transition"), uo = Lt("slide-y-transition"), mm = Lt("slide-y-reverse-transition"), kl = Gu("expand-transition", Uu()), so = Gu("expand-x-transition", Uu("", !0)), gm = N({
  defaults: Object,
  disabled: Boolean,
  reset: [Number, String],
  root: [Boolean, String],
  scoped: Boolean
}, "VDefaultsProvider"), Ce = Y(!1)({
  name: "VDefaultsProvider",
  props: gm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      defaults: a,
      disabled: l,
      reset: i,
      root: o,
      scoped: r
    } = Xn(e);
    return je(a, {
      reset: i,
      root: o,
      scoped: r,
      disabled: l
    }), () => {
      var u;
      return (u = t.default) == null ? void 0 : u.call(t);
    };
  }
}), Ze = N({
  height: [Number, String],
  maxHeight: [Number, String],
  maxWidth: [Number, String],
  minHeight: [Number, String],
  minWidth: [Number, String],
  width: [Number, String]
}, "dimension");
function Qe(e) {
  return {
    dimensionStyles: C(() => {
      const t = {}, a = ce(e.height), l = ce(e.maxHeight), i = ce(e.maxWidth), o = ce(e.minHeight), r = ce(e.minWidth), u = ce(e.width);
      return a != null && (t.height = a), l != null && (t.maxHeight = l), i != null && (t.maxWidth = i), o != null && (t.minHeight = o), r != null && (t.minWidth = r), u != null && (t.width = u), t;
    })
  };
}
function hm(e) {
  return {
    aspectStyles: C(() => {
      const n = Number(e.aspectRatio);
      return n ? {
        paddingBottom: String(1 / n * 100) + "%"
      } : void 0;
    })
  };
}
const Ku = N(v(v({
  aspectRatio: [String, Number],
  contentClass: null,
  inline: Boolean
}, de()), Ze()), "VResponsive"), mi = Y()({
  name: "VResponsive",
  props: Ku(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      aspectStyles: a
    } = hm(e), {
      dimensionStyles: l
    } = Qe(e);
    return Z(() => {
      var i;
      return w("div", {
        class: X(["v-responsive", {
          "v-responsive--inline": e.inline
        }, e.class]),
        style: ie([l.value, e.style])
      }, [w("div", {
        class: "v-responsive__sizer",
        style: ie(a.value)
      }, null), (i = t.additional) == null ? void 0 : i.call(t), t.default && w("div", {
        class: X(["v-responsive__content", e.contentClass])
      }, [t.default()])]);
    }), {};
  }
});
function co(e) {
  return qi(() => {
    const n = st(e), t = [], a = {};
    if (n.background)
      if (ii(n.background)) {
        if (a.backgroundColor = n.background, !n.text && xv(n.background)) {
          const l = Pt(n.background);
          if (l.a == null || l.a === 1) {
            const i = Vu(l);
            a.color = i, a.caretColor = i;
          }
        }
      } else
        t.push(`bg-${n.background}`);
    return n.text && (ii(n.text) ? (a.color = n.text, a.caretColor = n.text) : t.push(`text-${n.text}`)), {
      colorClasses: t,
      colorStyles: a
    };
  });
}
function rt(e) {
  const {
    colorClasses: n,
    colorStyles: t
  } = co(() => ({
    text: st(e)
  }));
  return {
    textColorClasses: n,
    textColorStyles: t
  };
}
function pe(e) {
  const {
    colorClasses: n,
    colorStyles: t
  } = co(() => ({
    background: st(e)
  }));
  return {
    backgroundColorClasses: n,
    backgroundColorStyles: t
  };
}
const Ne = N({
  rounded: {
    type: [Boolean, Number, String],
    default: void 0
  },
  tile: Boolean
}, "rounded");
function Ye(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  return {
    roundedClasses: C(() => {
      const a = Jl(e) ? e.value : e.rounded, l = Jl(e) ? e.value : e.tile, i = [];
      if (l || a === !1)
        i.push("rounded-0");
      else if (a === !0 || a === "")
        i.push(`${n}--rounded`);
      else if (typeof a == "string" || a === 0)
        for (const o of String(a).split(" "))
          i.push(`rounded-${o}`);
      return i;
    })
  };
}
const Ft = N({
  transition: {
    type: null,
    default: "fade-transition",
    validator: (e) => e !== !0
  }
}, "transition"), ft = (e, n) => {
  let {
    slots: t
  } = n;
  const s = e, {
    transition: a,
    disabled: l,
    group: i
  } = s, o = Ge(s, [
    "transition",
    "disabled",
    "group"
  ]), d = Ja(a) ? a : {}, {
    component: r = i ? Yi : en
  } = d, u = Ge(d, [
    "component"
  ]);
  let c;
  return Ja(a) ? c = G(u, iv({
    disabled: l,
    group: i
  }), o) : c = G({
    name: l || !a ? "" : a
  }, o), Vn(r, c, t);
};
function ym(e, n) {
  if (!Gi) return;
  const t = n.modifiers || {}, a = n.value, {
    handler: l,
    options: i
  } = typeof a == "object" ? a : {
    handler: a,
    options: {}
  }, o = new IntersectionObserver(function() {
    var d;
    let r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], u = arguments.length > 1 ? arguments[1] : void 0;
    const c = (d = e._observe) == null ? void 0 : d[n.instance.$.uid];
    if (!c) return;
    const s = r.some((f) => f.isIntersecting);
    l && (!t.quiet || c.init) && (!t.once || s || c.init) && l(s, r, u), s && t.once ? qu(e, n) : c.init = !0;
  }, i);
  e._observe = Object(e._observe), e._observe[n.instance.$.uid] = {
    init: !1,
    observer: o
  }, o.observe(e);
}
function qu(e, n) {
  var a;
  const t = (a = e._observe) == null ? void 0 : a[n.instance.$.uid];
  t && (t.observer.unobserve(e), delete e._observe[n.instance.$.uid]);
}
const Ht = {
  mounted: ym,
  unmounted: qu
}, Xu = N(v(v(v(v({
  absolute: Boolean,
  alt: String,
  cover: Boolean,
  color: String,
  draggable: {
    type: [Boolean, String],
    default: void 0
  },
  eager: Boolean,
  gradient: String,
  lazySrc: String,
  options: {
    type: Object,
    // For more information on types, navigate to:
    // https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
    default: () => ({
      root: void 0,
      rootMargin: void 0,
      threshold: void 0
    })
  },
  sizes: String,
  src: {
    type: [String, Object],
    default: ""
  },
  crossorigin: String,
  referrerpolicy: String,
  srcset: String,
  position: String
}, Ku()), de()), Ne()), Ft()), "VImg"), Ut = Y()({
  name: "VImg",
  directives: {
    vIntersect: Ht
  },
  props: Xu(),
  emits: {
    loadstart: (e) => !0,
    load: (e) => !0,
    error: (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      backgroundColorClasses: l,
      backgroundColorStyles: i
    } = pe(() => e.color), {
      roundedClasses: o
    } = Ye(e), r = Ke("VImg"), u = te(""), c = Q(), s = te(e.eager ? "loading" : "idle"), d = te(), f = te(), m = C(() => e.src && typeof e.src == "object" ? {
      src: e.src.src,
      srcset: e.srcset || e.src.srcset,
      lazySrc: e.lazySrc || e.src.lazySrc,
      aspect: Number(e.aspectRatio || e.src.aspect || 0)
    } : {
      src: e.src,
      srcset: e.srcset,
      lazySrc: e.lazySrc,
      aspect: Number(e.aspectRatio || 0)
    }), h = C(() => m.value.aspect || d.value / f.value || 0);
    oe(() => e.src, () => {
      b(s.value !== "idle");
    }), oe(h, (A, B) => {
      !A && B && c.value && V(c.value);
    }), _a(() => b());
    function b(A) {
      if (!(e.eager && A) && !(Gi && !A && !e.eager)) {
        if (s.value = "loading", m.value.lazySrc) {
          const B = new Image();
          B.src = m.value.lazySrc, V(B, null);
        }
        m.value.src && Ve(() => {
          var B;
          t("loadstart", ((B = c.value) == null ? void 0 : B.currentSrc) || m.value.src), setTimeout(() => {
            var F;
            if (!r.isUnmounted)
              if ((F = c.value) != null && F.complete) {
                if (c.value.naturalWidth || S(), s.value === "error") return;
                h.value || V(c.value, null), s.value === "loading" && g();
              } else
                h.value || V(c.value), y();
          });
        });
      }
    }
    function g() {
      var A;
      r.isUnmounted || (y(), V(c.value), s.value = "loaded", t("load", ((A = c.value) == null ? void 0 : A.currentSrc) || m.value.src));
    }
    function S() {
      var A;
      r.isUnmounted || (s.value = "error", t("error", ((A = c.value) == null ? void 0 : A.currentSrc) || m.value.src));
    }
    function y() {
      const A = c.value;
      A && (u.value = A.currentSrc || A.src);
    }
    let P = -1;
    dt(() => {
      clearTimeout(P);
    });
    function V(A) {
      let B = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 100;
      const F = () => {
        if (clearTimeout(P), r.isUnmounted) return;
        const {
          naturalHeight: $,
          naturalWidth: W
        } = A;
        $ || W ? (d.value = W, f.value = $) : !A.complete && s.value === "loading" && B != null ? P = window.setTimeout(F, B) : (A.currentSrc.endsWith(".svg") || A.currentSrc.startsWith("data:image/svg+xml")) && (d.value = 1, f.value = 1);
      };
      F();
    }
    const x = M(() => ({
      "v-img__img--cover": e.cover,
      "v-img__img--contain": !e.cover
    })), I = () => {
      var F;
      if (!m.value.src || s.value === "idle") return null;
      const A = w("img", {
        class: X(["v-img__img", x.value]),
        style: {
          objectPosition: e.position
        },
        crossorigin: e.crossorigin,
        src: m.value.src,
        srcset: m.value.srcset,
        alt: e.alt,
        referrerpolicy: e.referrerpolicy,
        draggable: e.draggable,
        sizes: e.sizes,
        ref: c,
        onLoad: g,
        onError: S
      }, null), B = (F = a.sources) == null ? void 0 : F.call(a);
      return k(ft, {
        transition: e.transition,
        appear: !0
      }, {
        default: () => [Re(B ? w("picture", {
          class: "v-img__picture"
        }, [B, A]) : A, [[$t, s.value === "loaded"]])]
      });
    }, T = () => k(ft, {
      transition: e.transition
    }, {
      default: () => [m.value.lazySrc && s.value !== "loaded" && w("img", {
        class: X(["v-img__img", "v-img__img--preload", x.value]),
        style: {
          objectPosition: e.position
        },
        crossorigin: e.crossorigin,
        src: m.value.lazySrc,
        alt: e.alt,
        referrerpolicy: e.referrerpolicy,
        draggable: e.draggable
      }, null)]
    }), _ = () => a.placeholder ? k(ft, {
      transition: e.transition,
      appear: !0
    }, {
      default: () => [(s.value === "loading" || s.value === "error" && !a.error) && w("div", {
        class: "v-img__placeholder"
      }, [a.placeholder()])]
    }) : null, p = () => a.error ? k(ft, {
      transition: e.transition,
      appear: !0
    }, {
      default: () => [s.value === "error" && w("div", {
        class: "v-img__error"
      }, [a.error()])]
    }) : null, L = () => e.gradient ? w("div", {
      class: "v-img__gradient",
      style: {
        backgroundImage: `linear-gradient(${e.gradient})`
      }
    }, null) : null, D = te(!1);
    {
      const A = oe(h, (B) => {
        B && (requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            D.value = !0;
          });
        }), A());
      });
    }
    return Z(() => {
      const A = mi.filterProps(e);
      return Re(k(mi, G({
        class: ["v-img", {
          "v-img--absolute": e.absolute,
          "v-img--booting": !D.value
        }, l.value, o.value, e.class],
        style: [{
          width: ce(e.width === "auto" ? d.value : e.width)
        }, i.value, e.style]
      }, A, {
        aspectRatio: h.value,
        "aria-label": e.alt,
        role: e.alt ? "img" : void 0
      }), {
        additional: () => w(he, null, [k(I, null, null), k(T, null, null), k(L, null, null), k(_, null, null), k(p, null, null)]),
        default: a.default
      }), [[Ht, {
        handler: b,
        options: e.options
      }, null, {
        once: !0
      }]]);
    }), {
      currentSrc: u,
      image: c,
      state: s,
      naturalWidth: d,
      naturalHeight: f
    };
  }
}), kt = N({
  border: [Boolean, Number, String]
}, "border");
function Ct(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  return {
    borderClasses: C(() => {
      const a = e.border;
      return a === !0 || a === "" ? `${n}--border` : typeof a == "string" || a === 0 ? String(a).split(" ").map((l) => `border-${l}`) : [];
    })
  };
}
const Je = N({
  elevation: {
    type: [Number, String],
    validator(e) {
      const n = parseInt(e);
      return !isNaN(n) && n >= 0 && // Material Design has a maximum elevation of 24
      // https://material.io/design/environment/elevation.html#default-elevations
      n <= 24;
    }
  }
}, "elevation");
function lt(e) {
  return {
    elevationClasses: M(() => {
      const t = Jl(e) ? e.value : e.elevation;
      return t == null ? [] : [`elevation-${t}`];
    })
  };
}
const bm = [null, "prominent", "default", "comfortable", "compact"], Zu = N(v(v(v(v(v(v({
  absolute: Boolean,
  collapse: Boolean,
  color: String,
  density: {
    type: String,
    default: "default",
    validator: (e) => bm.includes(e)
  },
  extended: {
    type: Boolean,
    default: null
  },
  extensionHeight: {
    type: [Number, String],
    default: 48
  },
  flat: Boolean,
  floating: Boolean,
  height: {
    type: [Number, String],
    default: 64
  },
  image: String,
  title: String
}, kt()), de()), Je()), Ne()), ke({
  tag: "header"
})), Ie()), "VToolbar"), gi = Y()({
  name: "VToolbar",
  props: Zu(),
  setup(e, n) {
    var m;
    let {
      slots: t
    } = n;
    const {
      backgroundColorClasses: a,
      backgroundColorStyles: l
    } = pe(() => e.color), {
      borderClasses: i
    } = Ct(e), {
      elevationClasses: o
    } = lt(e), {
      roundedClasses: r
    } = Ye(e), {
      themeClasses: u
    } = De(e), {
      rtlClasses: c
    } = Xe(), s = te(e.extended === null ? !!((m = t.extension) != null && m.call(t)) : e.extended), d = C(() => parseInt(Number(e.height) + (e.density === "prominent" ? Number(e.height) : 0) - (e.density === "comfortable" ? 8 : 0) - (e.density === "compact" ? 16 : 0), 10)), f = C(() => s.value ? parseInt(Number(e.extensionHeight) + (e.density === "prominent" ? Number(e.extensionHeight) : 0) - (e.density === "comfortable" ? 4 : 0) - (e.density === "compact" ? 8 : 0), 10) : 0);
    return je({
      VBtn: {
        variant: "text"
      }
    }), Z(() => {
      var S;
      const h = !!(e.title || t.title), b = !!(t.image || e.image), g = (S = t.extension) == null ? void 0 : S.call(t);
      return s.value = e.extended === null ? !!g : e.extended, k(e.tag, {
        class: X(["v-toolbar", {
          "v-toolbar--absolute": e.absolute,
          "v-toolbar--collapse": e.collapse,
          "v-toolbar--flat": e.flat,
          "v-toolbar--floating": e.floating,
          [`v-toolbar--density-${e.density}`]: !0
        }, a.value, i.value, o.value, r.value, u.value, c.value, e.class]),
        style: ie([l.value, e.style])
      }, {
        default: () => [b && w("div", {
          key: "image",
          class: "v-toolbar__image"
        }, [t.image ? k(Ce, {
          key: "image-defaults",
          disabled: !e.image,
          defaults: {
            VImg: {
              cover: !0,
              src: e.image
            }
          }
        }, t.image) : k(Ut, {
          key: "image-img",
          cover: !0,
          src: e.image
        }, null)]), k(Ce, {
          defaults: {
            VTabs: {
              height: ce(d.value)
            }
          }
        }, {
          default: () => {
            var y, P, V;
            return [w("div", {
              class: "v-toolbar__content",
              style: {
                height: ce(d.value)
              }
            }, [t.prepend && w("div", {
              class: "v-toolbar__prepend"
            }, [(y = t.prepend) == null ? void 0 : y.call(t)]), h && k(oo, {
              key: "title",
              text: e.title
            }, {
              text: t.title
            }), (P = t.default) == null ? void 0 : P.call(t), t.append && w("div", {
              class: "v-toolbar__append"
            }, [(V = t.append) == null ? void 0 : V.call(t)])])];
          }
        }), k(Ce, {
          defaults: {
            VTabs: {
              height: ce(f.value)
            }
          }
        }, {
          default: () => [k(kl, null, {
            default: () => [s.value && w("div", {
              class: "v-toolbar__extension",
              style: {
                height: ce(f.value)
              }
            }, [g])]
          })]
        })]
      });
    }), {
      contentHeight: d,
      extensionHeight: f
    };
  }
}), Sm = N({
  scrollTarget: {
    type: String
  },
  scrollThreshold: {
    type: [String, Number],
    default: 300
  }
}, "scroll");
function km(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  const {
    canScroll: t
  } = n;
  let a = 0, l = 0;
  const i = Q(null), o = te(0), r = te(0), u = te(0), c = te(!1), s = te(!1), d = C(() => Number(e.scrollThreshold)), f = C(() => Fe((d.value - o.value) / d.value || 0)), m = () => {
    const h = i.value;
    if (!h || t && !t.value) return;
    a = o.value, o.value = "window" in h ? h.pageYOffset : h.scrollTop;
    const b = h instanceof Window ? document.documentElement.scrollHeight : h.scrollHeight;
    if (l !== b) {
      l = b;
      return;
    }
    s.value = o.value < a, u.value = Math.abs(o.value - d.value);
  };
  return oe(s, () => {
    r.value = r.value || o.value;
  }), oe(c, () => {
    r.value = 0;
  }), gt(() => {
    oe(() => e.scrollTarget, (h) => {
      var g;
      const b = h ? document.querySelector(h) : window;
      if (!b) {
        et(`Unable to locate element with identifier ${h}`);
        return;
      }
      b !== i.value && ((g = i.value) == null || g.removeEventListener("scroll", m), i.value = b, i.value.addEventListener("scroll", m, {
        passive: !0
      }));
    }, {
      immediate: !0
    });
  }), dt(() => {
    var h;
    (h = i.value) == null || h.removeEventListener("scroll", m);
  }), t && oe(t, m, {
    immediate: !0
  }), {
    scrollThreshold: d,
    currentScroll: o,
    currentThreshold: u,
    isScrollActive: c,
    scrollRatio: f,
    // required only for testing
    // probably can be removed
    // later (2 chars chlng)
    isScrollingUp: s,
    savedScroll: r
  };
}
function An() {
  const e = te(!1);
  return gt(() => {
    window.requestAnimationFrame(() => {
      e.value = !0;
    });
  }), {
    ssrBootStyles: M(() => e.value ? void 0 : {
      transition: "none !important"
    }),
    isBooted: vl(e)
  };
}
const wm = N(le(v(v(v({
  scrollBehavior: String,
  modelValue: {
    type: Boolean,
    default: !0
  },
  location: {
    type: String,
    default: "top",
    validator: (e) => ["top", "bottom"].includes(e)
  }
}, Zu()), In()), Sm()), {
  height: {
    type: [Number, String],
    default: 64
  }
}), "VAppBar"), Cm = Y()({
  name: "VAppBar",
  props: wm(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Q(), l = ve(e, "modelValue"), i = C(() => {
      var P, V;
      const y = new Set((V = (P = e.scrollBehavior) == null ? void 0 : P.split(" ")) != null ? V : []);
      return {
        hide: y.has("hide"),
        fullyHide: y.has("fully-hide"),
        inverted: y.has("inverted"),
        collapse: y.has("collapse"),
        elevate: y.has("elevate"),
        fadeImage: y.has("fade-image")
        // shrink: behavior.has('shrink'),
      };
    }), o = C(() => {
      const y = i.value;
      return y.hide || y.fullyHide || y.inverted || y.collapse || y.elevate || y.fadeImage || // behavior.shrink ||
      !l.value;
    }), {
      currentScroll: r,
      scrollThreshold: u,
      isScrollingUp: c,
      scrollRatio: s
    } = km(e, {
      canScroll: o
    }), d = M(() => i.value.hide || i.value.fullyHide), f = C(() => e.collapse || i.value.collapse && (i.value.inverted ? s.value > 0 : s.value === 0)), m = C(() => e.flat || i.value.fullyHide && !l.value || i.value.elevate && (i.value.inverted ? r.value > 0 : r.value === 0)), h = C(() => i.value.fadeImage ? i.value.inverted ? 1 - s.value : s.value : void 0), b = C(() => {
      var V, x, I, T;
      if (i.value.hide && i.value.inverted) return 0;
      const y = (x = (V = a.value) == null ? void 0 : V.contentHeight) != null ? x : 0, P = (T = (I = a.value) == null ? void 0 : I.extensionHeight) != null ? T : 0;
      return d.value ? r.value < u.value || i.value.fullyHide ? y + P : y : y + P;
    });
    mt(() => !!e.scrollBehavior, () => {
      We(() => {
        d.value ? i.value.inverted ? l.value = r.value > u.value : l.value = c.value || r.value < u.value : l.value = !0;
      });
    });
    const {
      ssrBootStyles: g
    } = An(), {
      layoutItemStyles: S
    } = _n({
      id: e.name,
      order: C(() => parseInt(e.order, 10)),
      position: M(() => e.location),
      layoutSize: b,
      elementSize: te(void 0),
      active: l,
      absolute: M(() => e.absolute)
    });
    return Z(() => {
      const y = gi.filterProps(e);
      return k(gi, G({
        ref: a,
        class: ["v-app-bar", {
          "v-app-bar--bottom": e.location === "bottom"
        }, e.class],
        style: [v(le(v({}, S.value), {
          "--v-toolbar-image-opacity": h.value,
          height: void 0
        }), g.value), e.style]
      }, y, {
        collapse: f.value,
        flat: m.value
      }), t);
    }), {};
  }
}), xm = [null, "default", "comfortable", "compact"], nt = N({
  density: {
    type: String,
    default: "default",
    validator: (e) => xm.includes(e)
  }
}, "density");
function ht(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  return {
    densityClasses: M(() => `${n}--density-${e.density}`)
  };
}
const Vm = ["elevated", "flat", "tonal", "outlined", "text", "plain"];
function ln(e, n) {
  return w(he, null, [e && w("span", {
    key: "overlay",
    class: X(`${n}__overlay`)
  }, null), w("span", {
    key: "underlay",
    class: X(`${n}__underlay`)
  }, null)]);
}
const Dt = N({
  color: String,
  variant: {
    type: String,
    default: "elevated",
    validator: (e) => Vm.includes(e)
  }
}, "variant");
function Ln(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  const t = M(() => {
    const {
      variant: i
    } = st(e);
    return `${n}--variant-${i}`;
  }), {
    colorClasses: a,
    colorStyles: l
  } = co(() => {
    const {
      variant: i,
      color: o
    } = st(e);
    return {
      [["elevated", "flat"].includes(i) ? "background" : "text"]: o
    };
  });
  return {
    colorClasses: a,
    colorStyles: l,
    variantClasses: t
  };
}
const Qu = N(v(v(v(v(v(v(v(v({
  baseColor: String,
  divided: Boolean,
  direction: {
    type: String,
    default: "horizontal"
  }
}, kt()), de()), nt()), Je()), Ne()), ke()), Ie()), Dt()), "VBtnGroup"), hi = Y()({
  name: "VBtnGroup",
  props: Qu(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      densityClasses: l
    } = ht(e), {
      borderClasses: i
    } = Ct(e), {
      elevationClasses: o
    } = lt(e), {
      roundedClasses: r
    } = Ye(e);
    je({
      VBtn: {
        height: M(() => e.direction === "horizontal" ? "auto" : null),
        baseColor: M(() => e.baseColor),
        color: M(() => e.color),
        density: M(() => e.density),
        flat: !0,
        variant: M(() => e.variant)
      }
    }), Z(() => k(e.tag, {
      class: X(["v-btn-group", `v-btn-group--${e.direction}`, {
        "v-btn-group--divided": e.divided
      }, a.value, i.value, l.value, o.value, r.value, e.class]),
      style: ie(e.style)
    }, t));
  }
}), Tn = N({
  modelValue: {
    type: null,
    default: void 0
  },
  multiple: Boolean,
  mandatory: [Boolean, String],
  max: Number,
  selectedClass: String,
  disabled: Boolean
}, "group"), Bn = N({
  value: null,
  disabled: Boolean,
  selectedClass: String
}, "group-item");
function Dn(e, n) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
  const a = Ke("useGroupItem");
  if (!a)
    throw new Error("[Vuetify] useGroupItem composable must be used inside a component setup function");
  const l = St();
  Oe(Symbol.for(`${n.description}:id`), l);
  const i = Pe(n, null);
  if (!i) {
    if (!t) return i;
    throw new Error(`[Vuetify] Could not find useGroup injection with symbol ${n.description}`);
  }
  const o = M(() => e.value), r = C(() => !!(i.disabled.value || e.disabled));
  i.register({
    id: l,
    value: o,
    disabled: r
  }, a), dt(() => {
    i.unregister(l);
  });
  const u = C(() => i.isSelected(l)), c = C(() => i.items.value[0].id === l), s = C(() => i.items.value[i.items.value.length - 1].id === l), d = C(() => u.value && [i.selectedClass.value, e.selectedClass]);
  return oe(u, (f) => {
    a.emit("group:selected", {
      value: f
    });
  }, {
    flush: "sync"
  }), {
    id: l,
    isSelected: u,
    isFirst: c,
    isLast: s,
    toggle: () => i.select(l, !u.value),
    select: (f) => i.select(l, f),
    selectedClass: d,
    value: o,
    disabled: r,
    group: i
  };
}
function on(e, n) {
  let t = !1;
  const a = yt([]), l = ve(e, "modelValue", [], (f) => f == null ? [] : Ju(a, ze(f)), (f) => {
    const m = Im(a, f);
    return e.multiple ? m : m[0];
  }), i = Ke("useGroup");
  function o(f, m) {
    const h = f, b = Symbol.for(`${n.description}:id`), S = Nn(b, i == null ? void 0 : i.vnode).indexOf(m);
    Tt(h.value) == null && (h.value = S, h.useIndexAsValue = !0), S > -1 ? a.splice(S, 0, h) : a.push(h);
  }
  function r(f) {
    if (t) return;
    u();
    const m = a.findIndex((h) => h.id === f);
    a.splice(m, 1);
  }
  function u() {
    const f = a.find((m) => !m.disabled);
    f && e.mandatory === "force" && !l.value.length && (l.value = [f.id]);
  }
  gt(() => {
    u();
  }), dt(() => {
    t = !0;
  }), $d(() => {
    for (let f = 0; f < a.length; f++)
      a[f].useIndexAsValue && (a[f].value = f);
  });
  function c(f, m) {
    const h = a.find((b) => b.id === f);
    if (!(m && (h != null && h.disabled)))
      if (e.multiple) {
        const b = l.value.slice(), g = b.findIndex((y) => y === f), S = ~g;
        if (m = m != null ? m : !S, S && e.mandatory && b.length <= 1 || !S && e.max != null && b.length + 1 > e.max) return;
        g < 0 && m ? b.push(f) : g >= 0 && !m && b.splice(g, 1), l.value = b;
      } else {
        const b = l.value.includes(f);
        if (e.mandatory && b || !b && !m) return;
        l.value = (m != null ? m : !b) ? [f] : [];
      }
  }
  function s(f) {
    if (e.multiple && et('This method is not supported when using "multiple" prop'), l.value.length) {
      const m = l.value[0], h = a.findIndex((S) => S.id === m);
      let b = (h + f) % a.length, g = a[b];
      for (; g.disabled && b !== h; )
        b = (b + f) % a.length, g = a[b];
      if (g.disabled) return;
      l.value = [a[b].id];
    } else {
      const m = a.find((h) => !h.disabled);
      m && (l.value = [m.id]);
    }
  }
  const d = {
    register: o,
    unregister: r,
    selected: l,
    select: c,
    disabled: M(() => e.disabled),
    prev: () => s(a.length - 1),
    next: () => s(1),
    isSelected: (f) => l.value.includes(f),
    selectedClass: M(() => e.selectedClass),
    items: M(() => a),
    getItemIndex: (f) => Pm(a, f)
  };
  return Oe(n, d), d;
}
function Pm(e, n) {
  const t = Ju(e, [n]);
  return t.length ? e.findIndex((a) => a.id === t[0]) : -1;
}
function Ju(e, n) {
  const t = [];
  return n.forEach((a) => {
    const l = e.find((o) => at(a, o.value)), i = e[a];
    (l == null ? void 0 : l.value) != null ? t.push(l.id) : i != null && i.useIndexAsValue && t.push(i.id);
  }), t;
}
function Im(e, n) {
  const t = [];
  return n.forEach((a) => {
    const l = e.findIndex((i) => i.id === a);
    if (~l) {
      const i = e[l];
      t.push(i.value != null ? i.value : l);
    }
  }), t;
}
const vo = Symbol.for("vuetify:v-btn-toggle"), _m = N(v(v({}, Qu()), Tn()), "VBtnToggle"), Am = Y()({
  name: "VBtnToggle",
  props: _m(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      isSelected: a,
      next: l,
      prev: i,
      select: o,
      selected: r
    } = on(e, vo);
    return Z(() => {
      const u = hi.filterProps(e);
      return k(hi, G({
        class: ["v-btn-toggle", e.class]
      }, u, {
        style: e.style
      }), {
        default: () => {
          var c;
          return [(c = t.default) == null ? void 0 : c.call(t, {
            isSelected: a,
            next: l,
            prev: i,
            select: o,
            selected: r
          })];
        }
      });
    }), {
      next: l,
      prev: i,
      select: o
    };
  }
}), Lm = ["x-small", "small", "default", "large", "x-large"], Yt = N({
  size: {
    type: [String, Number],
    default: "default"
  }
}, "size");
function Qn(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  return qi(() => {
    const t = e.size;
    let a, l;
    return el(Lm, t) ? a = `${n}--size-${t}` : t && (l = {
      width: ce(t),
      height: ce(t)
    }), {
      sizeClasses: a,
      sizeStyles: l
    };
  });
}
const Tm = N(v(v(v(v({
  color: String,
  disabled: Boolean,
  start: Boolean,
  end: Boolean,
  icon: me,
  opacity: [String, Number]
}, de()), Yt()), ke({
  tag: "i"
})), Ie()), "VIcon"), Be = Y()({
  name: "VIcon",
  props: Tm(),
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const l = te(), {
      themeClasses: i
    } = bl(), {
      iconData: o
    } = zf(() => l.value || e.icon), {
      sizeClasses: r
    } = Qn(e), {
      textColorClasses: u,
      textColorStyles: c
    } = rt(() => e.color);
    return Z(() => {
      var f, m;
      const s = (f = a.default) == null ? void 0 : f.call(a);
      s && (l.value = (m = uu(s).filter((h) => h.type === Fd && h.children && typeof h.children == "string")[0]) == null ? void 0 : m.children);
      const d = !!(t.onClick || t.onClickOnce);
      return k(o.value.component, {
        tag: e.tag,
        icon: o.value.icon,
        class: X(["v-icon", "notranslate", i.value, r.value, u.value, {
          "v-icon--clickable": d,
          "v-icon--disabled": e.disabled,
          "v-icon--start": e.start,
          "v-icon--end": e.end
        }, e.class]),
        style: ie([{
          "--v-icon-opacity": e.opacity
        }, r.value ? void 0 : {
          fontSize: ce(e.size),
          height: ce(e.size),
          width: ce(e.size)
        }, c.value, e.style]),
        role: d ? "button" : void 0,
        "aria-hidden": !d,
        tabindex: d ? e.disabled ? -1 : 0 : void 0
      }, {
        default: () => [s]
      });
    }), {};
  }
});
function Ta(e, n) {
  const t = Q(), a = te(!1);
  if (Gi) {
    const l = new IntersectionObserver((i) => {
      a.value = !!i.find((o) => o.isIntersecting);
    }, n);
    tt(() => {
      l.disconnect();
    }), oe(t, (i, o) => {
      o && (l.unobserve(o), a.value = !1), i && l.observe(i);
    }, {
      flush: "post"
    });
  }
  return {
    intersectionRef: t,
    isIntersecting: a
  };
}
const Bm = N(v(v(v(v({
  bgColor: String,
  color: String,
  indeterminate: [Boolean, String],
  modelValue: {
    type: [Number, String],
    default: 0
  },
  rotate: {
    type: [Number, String],
    default: 0
  },
  width: {
    type: [Number, String],
    default: 4
  }
}, de()), Yt()), ke({
  tag: "div"
})), Ie()), "VProgressCircular"), bn = Y()({
  name: "VProgressCircular",
  props: Bm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = 20, l = 2 * Math.PI * a, i = Q(), {
      themeClasses: o
    } = De(e), {
      sizeClasses: r,
      sizeStyles: u
    } = Qn(e), {
      textColorClasses: c,
      textColorStyles: s
    } = rt(() => e.color), {
      textColorClasses: d,
      textColorStyles: f
    } = rt(() => e.bgColor), {
      intersectionRef: m,
      isIntersecting: h
    } = Ta(), {
      resizeRef: b,
      contentRect: g
    } = pt(), S = M(() => Fe(parseFloat(e.modelValue), 0, 100)), y = M(() => Number(e.width)), P = M(() => u.value ? Number(e.size) : g.value ? g.value.width : Math.max(y.value, 32)), V = M(() => a / (1 - y.value / P.value) * 2), x = M(() => y.value / P.value * V.value), I = M(() => ce((100 - S.value) / 100 * l));
    return We(() => {
      m.value = i.value, b.value = i.value;
    }), Z(() => k(e.tag, {
      ref: i,
      class: X(["v-progress-circular", {
        "v-progress-circular--indeterminate": !!e.indeterminate,
        "v-progress-circular--visible": h.value,
        "v-progress-circular--disable-shrink": e.indeterminate === "disable-shrink"
      }, o.value, r.value, c.value, e.class]),
      style: ie([u.value, s.value, e.style]),
      role: "progressbar",
      "aria-valuemin": "0",
      "aria-valuemax": "100",
      "aria-valuenow": e.indeterminate ? void 0 : S.value
    }, {
      default: () => [w("svg", {
        style: {
          transform: `rotate(calc(-90deg + ${Number(e.rotate)}deg))`
        },
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: `0 0 ${V.value} ${V.value}`
      }, [w("circle", {
        class: X(["v-progress-circular__underlay", d.value]),
        style: ie(f.value),
        fill: "transparent",
        cx: "50%",
        cy: "50%",
        r: a,
        "stroke-width": x.value,
        "stroke-dasharray": l,
        "stroke-dashoffset": 0
      }, null), w("circle", {
        class: "v-progress-circular__overlay",
        fill: "transparent",
        cx: "50%",
        cy: "50%",
        r: a,
        "stroke-width": x.value,
        "stroke-dasharray": l,
        "stroke-dashoffset": I.value
      }, null)]), t.default && w("div", {
        class: "v-progress-circular__content"
      }, [t.default({
        value: S.value
      })])]
    })), {};
  }
}), Mr = {
  center: "center",
  top: "bottom",
  bottom: "top",
  left: "right",
  right: "left"
}, Zt = N({
  location: String
}, "location");
function Mn(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, t = arguments.length > 2 ? arguments[2] : void 0;
  const {
    isRtl: a
  } = Xe();
  return {
    locationStyles: C(() => {
      if (!e.location) return {};
      const {
        side: i,
        align: o
      } = ai(e.location.split(" ").length > 1 ? e.location : `${e.location} center`, a.value);
      function r(c) {
        return t ? t(c) : 0;
      }
      const u = {};
      return i !== "center" && (n ? u[Mr[i]] = `calc(100% - ${r(i)}px)` : u[i] = 0), o !== "center" ? n ? u[Mr[o]] = `calc(100% - ${r(o)}px)` : u[o] = 0 : (i === "center" ? u.top = u.left = "50%" : u[{
        top: "left",
        bottom: "left",
        left: "top",
        right: "top"
      }[i]] = "50%", u.transform = {
        top: "translateX(-50%)",
        bottom: "translateX(-50%)",
        left: "translateY(-50%)",
        right: "translateY(-50%)",
        center: "translate(-50%, -50%)"
      }[i]), u;
    })
  };
}
const Dm = N(v(v(v(v(v({
  absolute: Boolean,
  active: {
    type: Boolean,
    default: !0
  },
  bgColor: String,
  bgOpacity: [Number, String],
  bufferValue: {
    type: [Number, String],
    default: 0
  },
  bufferColor: String,
  bufferOpacity: [Number, String],
  clickable: Boolean,
  color: String,
  height: {
    type: [Number, String],
    default: 4
  },
  indeterminate: Boolean,
  max: {
    type: [Number, String],
    default: 100
  },
  modelValue: {
    type: [Number, String],
    default: 0
  },
  opacity: [Number, String],
  reverse: Boolean,
  stream: Boolean,
  striped: Boolean,
  roundedBar: Boolean
}, de()), Zt({
  location: "top"
})), Ne()), ke()), Ie()), "VProgressLinear"), wl = Y()({
  name: "VProgressLinear",
  props: Dm(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), {
      isRtl: l,
      rtlClasses: i
    } = Xe(), {
      themeClasses: o
    } = De(e), {
      locationStyles: r
    } = Mn(e), {
      textColorClasses: u,
      textColorStyles: c
    } = rt(() => e.color), {
      backgroundColorClasses: s,
      backgroundColorStyles: d
    } = pe(() => e.bgColor || e.color), {
      backgroundColorClasses: f,
      backgroundColorStyles: m
    } = pe(() => e.bufferColor || e.bgColor || e.color), {
      backgroundColorClasses: h,
      backgroundColorStyles: b
    } = pe(() => e.color), {
      roundedClasses: g
    } = Ye(e), {
      intersectionRef: S,
      isIntersecting: y
    } = Ta(), P = C(() => parseFloat(e.max)), V = C(() => parseFloat(e.height)), x = C(() => Fe(parseFloat(e.bufferValue) / P.value * 100, 0, 100)), I = C(() => Fe(parseFloat(a.value) / P.value * 100, 0, 100)), T = C(() => l.value !== e.reverse), _ = C(() => e.indeterminate ? "fade-transition" : "slide-x-transition");
    function p(L) {
      if (!S.value) return;
      const {
        left: D,
        right: A,
        width: B
      } = S.value.getBoundingClientRect(), F = T.value ? B - L.clientX + (A - B) : L.clientX - D;
      a.value = Math.round(F / B * P.value);
    }
    return Z(() => k(e.tag, {
      ref: S,
      class: X(["v-progress-linear", {
        "v-progress-linear--absolute": e.absolute,
        "v-progress-linear--active": e.active && y.value,
        "v-progress-linear--reverse": T.value,
        "v-progress-linear--rounded": e.rounded,
        "v-progress-linear--rounded-bar": e.roundedBar,
        "v-progress-linear--striped": e.striped,
        "v-progress-linear--clickable": e.clickable
      }, g.value, o.value, i.value, e.class]),
      style: ie([v({
        bottom: e.location === "bottom" ? 0 : void 0,
        top: e.location === "top" ? 0 : void 0,
        height: e.active ? ce(V.value) : 0,
        "--v-progress-linear-height": ce(V.value)
      }, e.absolute ? r.value : {}), e.style]),
      role: "progressbar",
      "aria-hidden": e.active ? "false" : "true",
      "aria-valuemin": "0",
      "aria-valuemax": e.max,
      "aria-valuenow": e.indeterminate ? void 0 : Math.min(parseFloat(a.value), P.value),
      onClick: e.clickable && p
    }, {
      default: () => [e.stream && w("div", {
        key: "stream",
        class: X(["v-progress-linear__stream", u.value]),
        style: le(v({}, c.value), {
          [T.value ? "left" : "right"]: ce(-V.value),
          borderTop: `${ce(V.value / 2)} dotted`,
          opacity: parseFloat(e.bufferOpacity),
          top: `calc(50% - ${ce(V.value / 4)})`,
          width: ce(100 - x.value, "%"),
          "--v-progress-linear-stream-to": ce(V.value * (T.value ? 1 : -1))
        })
      }, null), w("div", {
        class: X(["v-progress-linear__background", s.value]),
        style: ie([d.value, {
          opacity: parseFloat(e.bgOpacity),
          width: e.stream ? 0 : void 0
        }])
      }, null), w("div", {
        class: X(["v-progress-linear__buffer", f.value]),
        style: ie([m.value, {
          opacity: parseFloat(e.bufferOpacity),
          width: ce(x.value, "%")
        }])
      }, null), k(en, {
        name: _.value
      }, {
        default: () => [e.indeterminate ? w("div", {
          class: "v-progress-linear__indeterminate"
        }, [["long", "short"].map((L) => w("div", {
          key: L,
          class: X(["v-progress-linear__indeterminate", L, h.value]),
          style: ie(b.value)
        }, null))]) : w("div", {
          class: X(["v-progress-linear__determinate", h.value]),
          style: ie([b.value, {
            width: ce(I.value, "%")
          }])
        }, null)]
      }), t.default && w("div", {
        class: "v-progress-linear__content"
      }, [t.default({
        value: I.value,
        buffer: x.value
      })])]
    })), {};
  }
}), Cl = N({
  loading: [Boolean, String]
}, "loader");
function Ba(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  return {
    loaderClasses: M(() => ({
      [`${n}--loading`]: e.loading
    }))
  };
}
function Da(e, n) {
  var a;
  let {
    slots: t
  } = n;
  return w("div", {
    class: X(`${e.name}__loader`)
  }, [((a = t.default) == null ? void 0 : a.call(t, {
    color: e.color,
    isActive: e.active
  })) || k(wl, {
    absolute: e.absolute,
    active: e.active,
    color: e.color,
    height: "2",
    indeterminate: !0
  }, null)]);
}
const Mm = ["static", "relative", "fixed", "absolute", "sticky"], Jn = N({
  position: {
    type: String,
    validator: (
      /* istanbul ignore next */
      (e) => Mm.includes(e)
    )
  }
}, "position");
function ea(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  return {
    positionClasses: M(() => e.position ? `${n}--${e.position}` : void 0)
  };
}
function pm() {
  const e = Ke("useRoute");
  return C(() => {
    var n;
    return (n = e == null ? void 0 : e.proxy) == null ? void 0 : n.$route;
  });
}
function es() {
  var e, n;
  return (n = (e = Ke("useRouter")) == null ? void 0 : e.proxy) == null ? void 0 : n.$router;
}
function Ma(e, n) {
  var s, d;
  const t = Od("RouterLink"), a = M(() => !!(e.href || e.to)), l = C(() => (a == null ? void 0 : a.value) || nr(n, "click") || nr(e, "click"));
  if (typeof t == "string" || !("useLink" in t)) {
    const f = M(() => e.href);
    return {
      isLink: a,
      isClickable: l,
      href: f,
      linkProps: yt({
        href: f
      })
    };
  }
  const i = t.useLink({
    to: M(() => e.to || ""),
    replace: M(() => e.replace)
  }), o = C(() => e.to ? i : void 0), r = pm(), u = C(() => {
    var f, m, h, b, g;
    return o.value ? e.exact ? r.value ? ((g = o.value.isExactActive) == null ? void 0 : g.value) && at(o.value.route.value.query, r.value.query) : (b = (h = o.value.isExactActive) == null ? void 0 : h.value) != null ? b : !1 : (m = (f = o.value.isActive) == null ? void 0 : f.value) != null ? m : !1 : !1;
  }), c = C(() => {
    var f;
    return e.to ? (f = o.value) == null ? void 0 : f.route.value.href : e.href;
  });
  return {
    isLink: a,
    isClickable: l,
    isActive: u,
    route: (s = o.value) == null ? void 0 : s.route,
    navigate: (d = o.value) == null ? void 0 : d.navigate,
    href: c,
    linkProps: yt({
      href: c,
      "aria-current": M(() => u.value ? "page" : void 0)
    })
  };
}
const pa = N({
  href: String,
  replace: Boolean,
  to: [String, Object],
  exact: Boolean
}, "router");
let Gl = !1;
function Em(e, n) {
  let t = !1, a, l;
  Te && (e != null && e.beforeEach) && (Ve(() => {
    window.addEventListener("popstate", i), a = e.beforeEach((o, r, u) => {
      Gl ? t ? n(u) : u() : setTimeout(() => t ? n(u) : u()), Gl = !0;
    }), l = e == null ? void 0 : e.afterEach(() => {
      Gl = !1;
    });
  }), tt(() => {
    window.removeEventListener("popstate", i), a == null || a(), l == null || l();
  }));
  function i(o) {
    var r;
    (r = o.state) != null && r.replaced || (t = !0, setTimeout(() => t = !1));
  }
}
function $m(e, n) {
  oe(() => {
    var t;
    return (t = e.isActive) == null ? void 0 : t.value;
  }, (t) => {
    e.isLink.value && t != null && n && Ve(() => {
      n(t);
    });
  }, {
    immediate: !0
  });
}
const yi = Symbol("rippleStop"), Fm = 80;
function pr(e, n) {
  e.style.transform = n, e.style.webkitTransform = n;
}
function bi(e) {
  return e.constructor.name === "TouchEvent";
}
function ts(e) {
  return e.constructor.name === "KeyboardEvent";
}
const Om = function(e, n) {
  var d;
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, a = 0, l = 0;
  if (!ts(e)) {
    const f = n.getBoundingClientRect(), m = bi(e) ? e.touches[e.touches.length - 1] : e;
    a = m.clientX - f.left, l = m.clientY - f.top;
  }
  let i = 0, o = 0.3;
  (d = n._ripple) != null && d.circle ? (o = 0.15, i = n.clientWidth / 2, i = t.center ? i : i + Math.sqrt(Le(a - i, 2) + Le(l - i, 2)) / 4) : i = Math.sqrt(Le(n.clientWidth, 2) + Le(n.clientHeight, 2)) / 2;
  const r = `${(n.clientWidth - i * 2) / 2}px`, u = `${(n.clientHeight - i * 2) / 2}px`, c = t.center ? r : `${a - i}px`, s = t.center ? u : `${l - i}px`;
  return {
    radius: i,
    scale: o,
    x: c,
    y: s,
    centerX: r,
    centerY: u
  };
}, rl = {
  /* eslint-disable max-statements */
  show(e, n) {
    var m;
    let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    if (!((m = n == null ? void 0 : n._ripple) != null && m.enabled))
      return;
    const a = document.createElement("span"), l = document.createElement("span");
    a.appendChild(l), a.className = "v-ripple__container", t.class && (a.className += ` ${t.class}`);
    const {
      radius: i,
      scale: o,
      x: r,
      y: u,
      centerX: c,
      centerY: s
    } = Om(e, n, t), d = `${i * 2}px`;
    l.className = "v-ripple__animation", l.style.width = d, l.style.height = d, n.appendChild(a);
    const f = window.getComputedStyle(n);
    f && f.position === "static" && (n.style.position = "relative", n.dataset.previousPosition = "static"), l.classList.add("v-ripple__animation--enter"), l.classList.add("v-ripple__animation--visible"), pr(l, `translate(${r}, ${u}) scale3d(${o},${o},${o})`), l.dataset.activated = String(performance.now()), requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        l.classList.remove("v-ripple__animation--enter"), l.classList.add("v-ripple__animation--in"), pr(l, `translate(${c}, ${s}) scale3d(1,1,1)`);
      });
    });
  },
  hide(e) {
    var i;
    if (!((i = e == null ? void 0 : e._ripple) != null && i.enabled)) return;
    const n = e.getElementsByClassName("v-ripple__animation");
    if (n.length === 0) return;
    const t = Array.from(n).findLast((o) => !o.dataset.isHiding);
    if (t) t.dataset.isHiding = "true";
    else return;
    const a = performance.now() - Number(t.dataset.activated), l = Math.max(250 - a, 0);
    setTimeout(() => {
      t.classList.remove("v-ripple__animation--in"), t.classList.add("v-ripple__animation--out"), setTimeout(() => {
        var r;
        e.getElementsByClassName("v-ripple__animation").length === 1 && e.dataset.previousPosition && (e.style.position = e.dataset.previousPosition, delete e.dataset.previousPosition), ((r = t.parentNode) == null ? void 0 : r.parentNode) === e && e.removeChild(t.parentNode);
      }, 300);
    }, l);
  }
};
function ns(e) {
  return typeof e == "undefined" || !!e;
}
function ba(e) {
  const n = {}, t = e.currentTarget;
  if (!(!(t != null && t._ripple) || t._ripple.touched || e[yi])) {
    if (e[yi] = !0, bi(e))
      t._ripple.touched = !0, t._ripple.isTouch = !0;
    else if (t._ripple.isTouch) return;
    if (n.center = t._ripple.centered || ts(e), t._ripple.class && (n.class = t._ripple.class), bi(e)) {
      if (t._ripple.showTimerCommit) return;
      t._ripple.showTimerCommit = () => {
        rl.show(e, t, n);
      }, t._ripple.showTimer = window.setTimeout(() => {
        var a;
        (a = t == null ? void 0 : t._ripple) != null && a.showTimerCommit && (t._ripple.showTimerCommit(), t._ripple.showTimerCommit = null);
      }, Fm);
    } else
      rl.show(e, t, n);
  }
}
function Er(e) {
  e[yi] = !0;
}
function xt(e) {
  const n = e.currentTarget;
  if (n != null && n._ripple) {
    if (window.clearTimeout(n._ripple.showTimer), e.type === "touchend" && n._ripple.showTimerCommit) {
      n._ripple.showTimerCommit(), n._ripple.showTimerCommit = null, n._ripple.showTimer = window.setTimeout(() => {
        xt(e);
      });
      return;
    }
    window.setTimeout(() => {
      n._ripple && (n._ripple.touched = !1);
    }), rl.hide(n);
  }
}
function as(e) {
  const n = e.currentTarget;
  n != null && n._ripple && (n._ripple.showTimerCommit && (n._ripple.showTimerCommit = null), window.clearTimeout(n._ripple.showTimer));
}
let Sa = !1;
function $r(e, n) {
  !Sa && n.includes(e.key) && (Sa = !0, ba(e));
}
function ls(e) {
  Sa = !1, xt(e);
}
function is(e) {
  Sa && (Sa = !1, xt(e));
}
function os(e, n, t) {
  var u, c;
  const {
    value: a,
    modifiers: l
  } = n, i = ns(a);
  i || rl.hide(e), e._ripple = (u = e._ripple) != null ? u : {}, e._ripple.enabled = i, e._ripple.centered = l.center, e._ripple.circle = l.circle;
  const o = Ja(a) ? a : {};
  o.class && (e._ripple.class = o.class);
  const r = (c = o.keys) != null ? c : ["Enter", "Space"];
  if (e._ripple.keyDownHandler = (s) => $r(s, r), i && !t) {
    if (l.stop) {
      e.addEventListener("touchstart", Er, {
        passive: !0
      }), e.addEventListener("mousedown", Er);
      return;
    }
    e.addEventListener("touchstart", ba, {
      passive: !0
    }), e.addEventListener("touchend", xt, {
      passive: !0
    }), e.addEventListener("touchmove", as, {
      passive: !0
    }), e.addEventListener("touchcancel", xt), e.addEventListener("mousedown", ba), e.addEventListener("mouseup", xt), e.addEventListener("mouseleave", xt), e.addEventListener("keydown", (s) => $r(s, r)), e.addEventListener("keyup", ls), e.addEventListener("blur", is), e.addEventListener("dragstart", xt, {
      passive: !0
    });
  } else !i && t && rs(e);
}
function rs(e) {
  var n;
  e.removeEventListener("mousedown", ba), e.removeEventListener("touchstart", ba), e.removeEventListener("touchend", xt), e.removeEventListener("touchmove", as), e.removeEventListener("touchcancel", xt), e.removeEventListener("mouseup", xt), e.removeEventListener("mouseleave", xt), (n = e._ripple) != null && n.keyDownHandler && e.removeEventListener("keydown", e._ripple.keyDownHandler), e.removeEventListener("keyup", ls), e.removeEventListener("dragstart", xt), e.removeEventListener("blur", is);
}
function Nm(e, n) {
  os(e, n, !1);
}
function Rm(e) {
  rs(e), delete e._ripple;
}
function Hm(e, n) {
  if (n.value === n.oldValue)
    return;
  const t = ns(n.oldValue);
  os(e, n, t);
}
const bt = {
  mounted: Nm,
  unmounted: Rm,
  updated: Hm
}, xl = N(v(v(v(v(v(v(v(v(v(v(v(v(v(v(v({
  active: {
    type: Boolean,
    default: void 0
  },
  activeColor: String,
  baseColor: String,
  symbol: {
    type: null,
    default: vo
  },
  flat: Boolean,
  icon: [Boolean, String, Function, Object],
  prependIcon: me,
  appendIcon: me,
  block: Boolean,
  readonly: Boolean,
  slim: Boolean,
  stacked: Boolean,
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  text: {
    type: [String, Number, Boolean],
    default: void 0
  }
}, kt()), de()), nt()), Ze()), Je()), Bn()), Cl()), Zt()), Jn()), Ne()), pa()), Yt()), ke({
  tag: "button"
})), Ie()), Dt({
  variant: "elevated"
})), "VBtn"), xe = Y()({
  name: "VBtn",
  props: xl(),
  emits: {
    "group:selected": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      themeClasses: l
    } = De(e), {
      borderClasses: i
    } = Ct(e), {
      densityClasses: o
    } = ht(e), {
      dimensionStyles: r
    } = Qe(e), {
      elevationClasses: u
    } = lt(e), {
      loaderClasses: c
    } = Ba(e), {
      locationStyles: s
    } = Mn(e), {
      positionClasses: d
    } = ea(e), {
      roundedClasses: f
    } = Ye(e), {
      sizeClasses: m,
      sizeStyles: h
    } = Qn(e), b = Dn(e, e.symbol, !1), g = Ma(e, t), S = C(() => {
      var D;
      return e.active !== void 0 ? e.active : g.isLink.value ? (D = g.isActive) == null ? void 0 : D.value : b == null ? void 0 : b.isSelected.value;
    }), y = M(() => {
      var D;
      return S.value && (D = e.activeColor) != null ? D : e.color;
    }), P = C(() => {
      var A, B, F;
      return {
        color: ((b == null ? void 0 : b.isSelected.value) && (!g.isLink.value || ((A = g.isActive) == null ? void 0 : A.value)) || !b || ((B = g.isActive) == null ? void 0 : B.value)) && (F = y.value) != null ? F : e.baseColor,
        variant: e.variant
      };
    }), {
      colorClasses: V,
      colorStyles: x,
      variantClasses: I
    } = Ln(P), T = C(() => (b == null ? void 0 : b.disabled.value) || e.disabled), _ = M(() => e.variant === "elevated" && !(e.disabled || e.flat || e.border)), p = C(() => {
      if (!(e.value === void 0 || typeof e.value == "symbol"))
        return Object(e.value) === e.value ? JSON.stringify(e.value, null, 0) : e.value;
    });
    function L(D) {
      var A;
      T.value || g.isLink.value && (D.metaKey || D.ctrlKey || D.shiftKey || D.button !== 0 || t.target === "_blank") || ((A = g.navigate) == null || A.call(g, D), b == null || b.toggle());
    }
    return $m(g, b == null ? void 0 : b.select), Z(() => {
      const D = g.isLink.value ? "a" : e.tag, A = !!(e.prependIcon || a.prepend), B = !!(e.appendIcon || a.append), F = !!(e.icon && e.icon !== !0);
      return Re(k(D, G({
        type: D === "a" ? void 0 : "button",
        class: ["v-btn", b == null ? void 0 : b.selectedClass.value, {
          "v-btn--active": S.value,
          "v-btn--block": e.block,
          "v-btn--disabled": T.value,
          "v-btn--elevated": _.value,
          "v-btn--flat": e.flat,
          "v-btn--icon": !!e.icon,
          "v-btn--loading": e.loading,
          "v-btn--readonly": e.readonly,
          "v-btn--slim": e.slim,
          "v-btn--stacked": e.stacked
        }, l.value, i.value, V.value, o.value, u.value, c.value, d.value, f.value, m.value, I.value, e.class],
        style: [x.value, r.value, s.value, h.value, e.style],
        "aria-busy": e.loading ? !0 : void 0,
        disabled: T.value || void 0,
        tabindex: e.loading || e.readonly ? -1 : void 0,
        onClick: L,
        value: p.value
      }, g.linkProps), {
        default: () => {
          var $, W;
          return [ln(!0, "v-btn"), !e.icon && A && w("span", {
            key: "prepend",
            class: "v-btn__prepend"
          }, [a.prepend ? k(Ce, {
            key: "prepend-defaults",
            disabled: !e.prependIcon,
            defaults: {
              VIcon: {
                icon: e.prependIcon
              }
            }
          }, a.prepend) : k(Be, {
            key: "prepend-icon",
            icon: e.prependIcon
          }, null)]), w("span", {
            class: "v-btn__content",
            "data-no-activator": ""
          }, [!a.default && F ? k(Be, {
            key: "content-icon",
            icon: e.icon
          }, null) : k(Ce, {
            key: "content-defaults",
            disabled: !F,
            defaults: {
              VIcon: {
                icon: e.icon
              }
            }
          }, {
            default: () => {
              var J, z;
              return [(z = (J = a.default) == null ? void 0 : J.call(a)) != null ? z : hn(e.text)];
            }
          })]), !e.icon && B && w("span", {
            key: "append",
            class: "v-btn__append"
          }, [a.append ? k(Ce, {
            key: "append-defaults",
            disabled: !e.appendIcon,
            defaults: {
              VIcon: {
                icon: e.appendIcon
              }
            }
          }, a.append) : k(Be, {
            key: "append-icon",
            icon: e.appendIcon
          }, null)]), !!e.loading && w("span", {
            key: "loader",
            class: "v-btn__loader"
          }, [(W = ($ = a.loader) == null ? void 0 : $.call(a)) != null ? W : k(bn, {
            color: typeof e.loading == "boolean" ? void 0 : e.loading,
            indeterminate: !0,
            width: "2"
          }, null)])];
        }
      }), [[bt, !T.value && e.ripple, "", {
        center: !!e.icon
      }]]);
    }), {
      group: b
    };
  }
}), zm = N(v({}, xl({
  icon: "$menu",
  variant: "text"
})), "VAppBarNavIcon"), Wm = Y()({
  name: "VAppBarNavIcon",
  props: zm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(xe, G(e, {
      class: ["v-app-bar-nav-icon"]
    }), t)), {};
  }
}), jm = Y()({
  name: "VAppBarTitle",
  props: Yu(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(oo, G(e, {
      class: "v-app-bar-title"
    }), t)), {};
  }
}), us = Xt("v-alert-title"), Ym = N({
  iconSize: [Number, String],
  iconSizes: {
    type: Array,
    default: () => [["x-small", 10], ["small", 16], ["default", 24], ["large", 28], ["x-large", 32]]
  }
}, "iconSize");
function Gm(e, n) {
  return {
    iconSize: C(() => {
      var i, o;
      const a = new Map(e.iconSizes), l = (o = (i = e.iconSize) != null ? i : n()) != null ? o : "default";
      return a.has(l) ? a.get(l) : l;
    })
  };
}
const Um = ["success", "info", "warning", "error"], Km = N(v(v(v(v(v(v(v(v(v(v(v({
  border: {
    type: [Boolean, String],
    validator: (e) => typeof e == "boolean" || ["top", "end", "bottom", "start"].includes(e)
  },
  borderColor: String,
  closable: Boolean,
  closeIcon: {
    type: me,
    default: "$close"
  },
  closeLabel: {
    type: String,
    default: "$vuetify.close"
  },
  icon: {
    type: [Boolean, String, Function, Object],
    default: null
  },
  modelValue: {
    type: Boolean,
    default: !0
  },
  prominent: Boolean,
  title: String,
  text: String,
  type: {
    type: String,
    validator: (e) => Um.includes(e)
  }
}, de()), nt()), Ze()), Je()), Ym()), Zt()), Jn()), Ne()), ke()), Ie()), Dt({
  variant: "flat"
})), "VAlert"), qm = Y()({
  name: "VAlert",
  props: Km(),
  emits: {
    "click:close": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = ve(e, "modelValue"), i = M(() => {
      var x;
      if (e.icon !== !1)
        return e.type ? (x = e.icon) != null ? x : `$${e.type}` : e.icon;
    }), {
      iconSize: o
    } = Gm(e, () => e.prominent ? 44 : void 0), {
      themeClasses: r
    } = De(e), {
      colorClasses: u,
      colorStyles: c,
      variantClasses: s
    } = Ln(() => {
      var x;
      return {
        color: (x = e.color) != null ? x : e.type,
        variant: e.variant
      };
    }), {
      densityClasses: d
    } = ht(e), {
      dimensionStyles: f
    } = Qe(e), {
      elevationClasses: m
    } = lt(e), {
      locationStyles: h
    } = Mn(e), {
      positionClasses: b
    } = ea(e), {
      roundedClasses: g
    } = Ye(e), {
      textColorClasses: S,
      textColorStyles: y
    } = rt(() => e.borderColor), {
      t: P
    } = Ee(), V = M(() => ({
      "aria-label": P(e.closeLabel),
      onClick(x) {
        l.value = !1, t("click:close", x);
      }
    }));
    return () => {
      const x = !!(a.prepend || i.value), I = !!(a.title || e.title), T = !!(a.close || e.closable), _ = {
        density: e.density,
        icon: i.value,
        size: e.iconSize || e.prominent ? o.value : void 0
      };
      return l.value && k(e.tag, {
        class: X(["v-alert", e.border && {
          "v-alert--border": !!e.border,
          [`v-alert--border-${e.border === !0 ? "start" : e.border}`]: !0
        }, {
          "v-alert--prominent": e.prominent
        }, r.value, u.value, d.value, m.value, b.value, g.value, s.value, e.class]),
        style: ie([c.value, f.value, h.value, e.style]),
        role: "alert"
      }, {
        default: () => {
          var p, L, D;
          return [ln(!1, "v-alert"), e.border && w("div", {
            key: "border",
            class: X(["v-alert__border", S.value]),
            style: ie(y.value)
          }, null), x && w("div", {
            key: "prepend",
            class: "v-alert__prepend"
          }, [a.prepend ? k(Ce, {
            key: "prepend-defaults",
            disabled: !i.value,
            defaults: {
              VIcon: v({}, _)
            }
          }, a.prepend) : k(Be, G({
            key: "prepend-icon"
          }, _), null)]), w("div", {
            class: "v-alert__content"
          }, [I && k(us, {
            key: "title"
          }, {
            default: () => {
              var A, B;
              return [(B = (A = a.title) == null ? void 0 : A.call(a)) != null ? B : e.title];
            }
          }), (L = (p = a.text) == null ? void 0 : p.call(a)) != null ? L : e.text, (D = a.default) == null ? void 0 : D.call(a)]), a.append && w("div", {
            key: "append",
            class: "v-alert__append"
          }, [a.append()]), T && w("div", {
            key: "close",
            class: "v-alert__close"
          }, [a.close ? k(Ce, {
            key: "close-defaults",
            defaults: {
              VBtn: {
                icon: e.closeIcon,
                size: "x-small",
                variant: "text"
              }
            }
          }, {
            default: () => {
              var A;
              return [(A = a.close) == null ? void 0 : A.call(a, {
                props: V.value
              })];
            }
          }) : k(xe, G({
            key: "close-btn",
            icon: e.closeIcon,
            size: "x-small",
            variant: "text"
          }, V.value), null)])];
        }
      });
    };
  }
}), Xm = N(v(v(v(v(v(v(v(v({
  start: Boolean,
  end: Boolean,
  icon: me,
  image: String,
  text: String
}, kt()), de()), nt()), Ne()), Yt()), ke()), Ie()), Dt({
  variant: "flat"
})), "VAvatar"), Bt = Y()({
  name: "VAvatar",
  props: Xm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      borderClasses: l
    } = Ct(e), {
      colorClasses: i,
      colorStyles: o,
      variantClasses: r
    } = Ln(e), {
      densityClasses: u
    } = ht(e), {
      roundedClasses: c
    } = Ye(e), {
      sizeClasses: s,
      sizeStyles: d
    } = Qn(e);
    return Z(() => k(e.tag, {
      class: X(["v-avatar", {
        "v-avatar--start": e.start,
        "v-avatar--end": e.end
      }, a.value, l.value, i.value, u.value, c.value, s.value, r.value, e.class]),
      style: ie([o.value, d.value, e.style])
    }, {
      default: () => [t.default ? k(Ce, {
        key: "content-defaults",
        defaults: {
          VImg: {
            cover: !0,
            src: e.image
          },
          VIcon: {
            icon: e.icon
          }
        }
      }, {
        default: () => [t.default()]
      }) : e.image ? k(Ut, {
        key: "image",
        src: e.image,
        alt: "",
        cover: !0
      }, null) : e.icon ? k(Be, {
        key: "icon",
        icon: e.icon
      }, null) : e.text, ln(!1, "v-avatar")]
    })), {};
  }
}), Zm = N(v(v({
  text: String,
  onClick: ot()
}, de()), Ie()), "VLabel"), ta = Y()({
  name: "VLabel",
  props: Zm(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      var a;
      return w("label", {
        class: X(["v-label", {
          "v-label--clickable": !!e.onClick
        }, e.class]),
        style: ie(e.style),
        onClick: e.onClick
      }, [e.text, (a = t.default) == null ? void 0 : a.call(t)]);
    }), {};
  }
}), ss = Symbol.for("vuetify:selection-control-group"), fo = N(v(v(v({
  color: String,
  disabled: {
    type: Boolean,
    default: null
  },
  defaultsTarget: String,
  error: Boolean,
  id: String,
  inline: Boolean,
  falseIcon: me,
  trueIcon: me,
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  multiple: {
    type: Boolean,
    default: null
  },
  name: String,
  readonly: {
    type: Boolean,
    default: null
  },
  modelValue: null,
  type: String,
  valueComparator: {
    type: Function,
    default: at
  }
}, de()), nt()), Ie()), "SelectionControlGroup"), Qm = N(v({}, fo({
  defaultsTarget: "VSelectionControl"
})), "VSelectionControlGroup"), cs = Y()({
  name: "VSelectionControlGroup",
  props: Qm(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), l = St(), i = M(() => e.id || `v-selection-control-group-${l}`), o = M(() => e.name || i.value), r = /* @__PURE__ */ new Set();
    return Oe(ss, {
      modelValue: a,
      forceUpdate: () => {
        r.forEach((u) => u());
      },
      onForceUpdate: (u) => {
        r.add(u), tt(() => {
          r.delete(u);
        });
      }
    }), je({
      [e.defaultsTarget]: {
        color: M(() => e.color),
        disabled: M(() => e.disabled),
        density: M(() => e.density),
        error: M(() => e.error),
        inline: M(() => e.inline),
        modelValue: a,
        multiple: M(() => !!e.multiple || e.multiple == null && Array.isArray(a.value)),
        name: o,
        falseIcon: M(() => e.falseIcon),
        trueIcon: M(() => e.trueIcon),
        readonly: M(() => e.readonly),
        ripple: M(() => e.ripple),
        type: M(() => e.type),
        valueComparator: M(() => e.valueComparator)
      }
    }), Z(() => {
      var u;
      return w("div", {
        class: X(["v-selection-control-group", {
          "v-selection-control-group--inline": e.inline
        }, e.class]),
        style: ie(e.style),
        role: e.type === "radio" ? "radiogroup" : void 0
      }, [(u = t.default) == null ? void 0 : u.call(t)]);
    }), {};
  }
}), Vl = N(v(v({
  label: String,
  baseColor: String,
  trueValue: null,
  falseValue: null,
  value: null
}, de()), fo()), "VSelectionControl");
function Jm(e) {
  const n = Pe(ss, void 0), {
    densityClasses: t
  } = ht(e), a = ve(e, "modelValue"), l = C(() => e.trueValue !== void 0 ? e.trueValue : e.value !== void 0 ? e.value : !0), i = C(() => e.falseValue !== void 0 ? e.falseValue : !1), o = C(() => !!e.multiple || e.multiple == null && Array.isArray(a.value)), r = C({
    get() {
      const m = n ? n.modelValue.value : a.value;
      return o.value ? ze(m).some((h) => e.valueComparator(h, l.value)) : e.valueComparator(m, l.value);
    },
    set(m) {
      if (e.readonly) return;
      const h = m ? l.value : i.value;
      let b = h;
      o.value && (b = m ? [...ze(a.value), h] : ze(a.value).filter((g) => !e.valueComparator(g, l.value))), n ? n.modelValue.value = b : a.value = b;
    }
  }), {
    textColorClasses: u,
    textColorStyles: c
  } = rt(() => {
    if (!(e.error || e.disabled))
      return r.value ? e.color : e.baseColor;
  }), {
    backgroundColorClasses: s,
    backgroundColorStyles: d
  } = pe(() => r.value && !e.error && !e.disabled ? e.color : e.baseColor), f = C(() => r.value ? e.trueIcon : e.falseIcon);
  return {
    group: n,
    densityClasses: t,
    trueValue: l,
    falseValue: i,
    model: r,
    textColorClasses: u,
    textColorStyles: c,
    backgroundColorClasses: s,
    backgroundColorStyles: d,
    icon: f
  };
}
const tn = Y()({
  name: "VSelectionControl",
  directives: {
    vRipple: bt
  },
  inheritAttrs: !1,
  props: Vl(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      group: l,
      densityClasses: i,
      icon: o,
      model: r,
      textColorClasses: u,
      textColorStyles: c,
      backgroundColorClasses: s,
      backgroundColorStyles: d,
      trueValue: f
    } = Jm(e), m = St(), h = te(!1), b = te(!1), g = Q(), S = M(() => e.id || `input-${m}`), y = M(() => !e.disabled && !e.readonly);
    l == null || l.onForceUpdate(() => {
      g.value && (g.value.checked = r.value);
    });
    function P(T) {
      y.value && (h.value = !0, zn(T.target, ":focus-visible") !== !1 && (b.value = !0));
    }
    function V() {
      h.value = !1, b.value = !1;
    }
    function x(T) {
      T.stopPropagation();
    }
    function I(T) {
      if (!y.value) {
        g.value && (g.value.checked = r.value);
        return;
      }
      e.readonly && l && Ve(() => l.forceUpdate()), r.value = T.target.checked;
    }
    return Z(() => {
      var D, A, B;
      const T = a.label ? a.label({
        label: e.label,
        props: {
          for: S.value
        }
      }) : e.label, [_, p] = an(t), L = w("input", G({
        ref: g,
        checked: r.value,
        disabled: !!e.disabled,
        id: S.value,
        onBlur: V,
        onFocus: P,
        onInput: I,
        "aria-disabled": !!e.disabled,
        "aria-label": e.label,
        type: e.type,
        value: f.value,
        name: e.name,
        "aria-checked": e.type === "checkbox" ? r.value : void 0
      }, p), null);
      return w("div", G({
        class: ["v-selection-control", {
          "v-selection-control--dirty": r.value,
          "v-selection-control--disabled": e.disabled,
          "v-selection-control--error": e.error,
          "v-selection-control--focused": h.value,
          "v-selection-control--focus-visible": b.value,
          "v-selection-control--inline": e.inline
        }, i.value, e.class]
      }, _, {
        style: e.style
      }), [w("div", {
        class: X(["v-selection-control__wrapper", u.value]),
        style: ie(c.value)
      }, [(D = a.default) == null ? void 0 : D.call(a, {
        backgroundColorClasses: s,
        backgroundColorStyles: d
      }), Re(w("div", {
        class: X(["v-selection-control__input"])
      }, [(B = (A = a.input) == null ? void 0 : A.call(a, {
        model: r,
        textColorClasses: u,
        textColorStyles: c,
        backgroundColorClasses: s,
        backgroundColorStyles: d,
        inputNode: L,
        icon: o.value,
        props: {
          onFocus: P,
          onBlur: V,
          id: S.value
        }
      })) != null ? B : w(he, null, [o.value && k(Be, {
        key: "icon",
        icon: o.value
      }, null), L])]), [[bt, !e.disabled && !e.readonly && e.ripple, null, {
        center: !0,
        circle: !0
      }]])]), T && k(ta, {
        for: S.value,
        onClick: x
      }, {
        default: () => [T]
      })]);
    }), {
      isFocused: h,
      input: g
    };
  }
}), ds = N(v({
  indeterminate: Boolean,
  indeterminateIcon: {
    type: me,
    default: "$checkboxIndeterminate"
  }
}, Vl({
  falseIcon: "$checkboxOff",
  trueIcon: "$checkboxOn"
})), "VCheckboxBtn"), zt = Y()({
  name: "VCheckboxBtn",
  props: ds(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:indeterminate": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "indeterminate"), l = ve(e, "modelValue");
    function i(u) {
      a.value && (a.value = !1);
    }
    const o = M(() => a.value ? e.indeterminateIcon : e.falseIcon), r = M(() => a.value ? e.indeterminateIcon : e.trueIcon);
    return Z(() => {
      const u = $e(tn.filterProps(e), ["modelValue"]);
      return k(tn, G(u, {
        modelValue: l.value,
        "onUpdate:modelValue": [(c) => l.value = c, i],
        class: ["v-checkbox-btn", e.class],
        style: e.style,
        type: "checkbox",
        falseIcon: o.value,
        trueIcon: r.value,
        "aria-checked": a.value ? "mixed" : void 0
      }), t);
    }), {};
  }
});
function vs(e) {
  const {
    t: n
  } = Ee();
  function t(a) {
    var f;
    let d = a, {
      name: l,
      color: i
    } = d, o = Ge(d, [
      "name",
      "color"
    ]);
    const r = {
      prepend: "prependAction",
      prependInner: "prependAction",
      append: "appendAction",
      appendInner: "appendAction",
      clear: "clear"
    }[l], u = e[`onClick:${l}`];
    function c(m) {
      m.key !== "Enter" && m.key !== " " || (m.preventDefault(), m.stopPropagation(), fl(u, new PointerEvent("click", m)));
    }
    const s = u && r ? n(`$vuetify.input.${r}`, (f = e.label) != null ? f : "") : void 0;
    return k(Be, G({
      icon: e[`${l}Icon`],
      "aria-label": s,
      onClick: u,
      onKeydown: c,
      color: i
    }, o), null);
  }
  return {
    InputIcon: t
  };
}
const eg = N(v(v({
  active: Boolean,
  color: String,
  messages: {
    type: [Array, String],
    default: () => []
  }
}, de()), Ft({
  transition: {
    component: uo,
    leaveAbsolute: !0,
    group: !0
  }
})), "VMessages"), fs = Y()({
  name: "VMessages",
  props: eg(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = C(() => ze(e.messages)), {
      textColorClasses: l,
      textColorStyles: i
    } = rt(() => e.color);
    return Z(() => k(ft, {
      transition: e.transition,
      tag: "div",
      class: X(["v-messages", l.value, e.class]),
      style: ie([i.value, e.style])
    }, {
      default: () => [e.active && a.value.map((o, r) => w("div", {
        class: "v-messages__message",
        key: `${r}-${a.value}`
      }, [t.message ? t.message({
        message: o
      }) : o]))]
    })), {};
  }
}), Ea = N({
  focused: Boolean,
  "onUpdate:focused": ot()
}, "focus");
function Qt(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt();
  const t = ve(e, "focused"), a = M(() => ({
    [`${n}--focused`]: t.value
  }));
  function l() {
    t.value = !0;
  }
  function i() {
    t.value = !1;
  }
  return {
    focusClasses: a,
    isFocused: t,
    focus: l,
    blur: i
  };
}
const ms = Symbol.for("vuetify:form"), tg = N({
  disabled: Boolean,
  fastFail: Boolean,
  readonly: Boolean,
  modelValue: {
    type: Boolean,
    default: null
  },
  validateOn: {
    type: String,
    default: "input"
  }
}, "form");
function ng(e) {
  const n = ve(e, "modelValue"), t = M(() => e.disabled), a = M(() => e.readonly), l = te(!1), i = Q([]), o = Q([]);
  function r() {
    return He(this, null, function* () {
      const s = [];
      let d = !0;
      o.value = [], l.value = !0;
      for (const f of i.value) {
        const m = yield f.validate();
        if (m.length > 0 && (d = !1, s.push({
          id: f.id,
          errorMessages: m
        })), !d && e.fastFail) break;
      }
      return o.value = s, l.value = !1, {
        valid: d,
        errors: o.value
      };
    });
  }
  function u() {
    i.value.forEach((s) => s.reset());
  }
  function c() {
    i.value.forEach((s) => s.resetValidation());
  }
  return oe(i, () => {
    let s = 0, d = 0;
    const f = [];
    for (const m of i.value)
      m.isValid === !1 ? (d++, f.push({
        id: m.id,
        errorMessages: m.errorMessages
      })) : m.isValid === !0 && s++;
    o.value = f, n.value = d > 0 ? !1 : s === i.value.length ? !0 : null;
  }, {
    deep: !0,
    flush: "post"
  }), Oe(ms, {
    register: (s) => {
      let {
        id: d,
        vm: f,
        validate: m,
        reset: h,
        resetValidation: b
      } = s;
      i.value.some((g) => g.id === d) && et(`Duplicate input name "${d}"`), i.value.push({
        id: d,
        validate: m,
        reset: h,
        resetValidation: b,
        vm: Nd(f),
        isValid: null,
        errorMessages: []
      });
    },
    unregister: (s) => {
      i.value = i.value.filter((d) => d.id !== s);
    },
    update: (s, d, f) => {
      const m = i.value.find((h) => h.id === s);
      m && (m.isValid = d, m.errorMessages = f);
    },
    isDisabled: t,
    isReadonly: a,
    isValidating: l,
    isValid: n,
    items: i,
    validateOn: M(() => e.validateOn)
  }), {
    errors: o,
    isDisabled: t,
    isReadonly: a,
    isValidating: l,
    isValid: n,
    items: i,
    validate: r,
    reset: u,
    resetValidation: c
  };
}
function $a(e) {
  const n = Pe(ms, null);
  return le(v({}, n), {
    isReadonly: C(() => {
      var t;
      return !!((t = e == null ? void 0 : e.readonly) != null ? t : n != null && n.isReadonly.value);
    }),
    isDisabled: C(() => {
      var t;
      return !!((t = e == null ? void 0 : e.disabled) != null ? t : n != null && n.isDisabled.value);
    })
  });
}
const ag = Symbol.for("vuetify:rules");
function lg(e) {
  var t;
  const n = Pe(ag, null);
  if (!e) {
    if (!n)
      throw new Error("Could not find Vuetify rules injection");
    return n.aliases;
  }
  return (t = n == null ? void 0 : n.resolve(e)) != null ? t : M(e);
}
const gs = N(v({
  disabled: {
    type: Boolean,
    default: null
  },
  error: Boolean,
  errorMessages: {
    type: [Array, String],
    default: () => []
  },
  maxErrors: {
    type: [Number, String],
    default: 1
  },
  name: String,
  label: String,
  readonly: {
    type: Boolean,
    default: null
  },
  rules: {
    type: Array,
    default: () => []
  },
  modelValue: null,
  validateOn: String,
  validationValue: null
}, Ea()), "validation");
function hs(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : jt(), t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : St();
  const a = ve(e, "modelValue"), l = C(() => e.validationValue === void 0 ? a.value : e.validationValue), i = $a(e), o = lg(() => e.rules), r = Q([]), u = te(!0), c = C(() => !!(ze(a.value === "" ? null : a.value).length || ze(l.value === "" ? null : l.value).length)), s = C(() => {
    var V;
    return (V = e.errorMessages) != null && V.length ? ze(e.errorMessages).concat(r.value).slice(0, Math.max(0, Number(e.maxErrors))) : r.value;
  }), d = C(() => {
    var I, T, _;
    let V = ((T = e.validateOn) != null ? T : (I = i.validateOn) == null ? void 0 : I.value) || "input";
    V === "lazy" && (V = "input lazy"), V === "eager" && (V = "input eager");
    const x = new Set((_ = V == null ? void 0 : V.split(" ")) != null ? _ : []);
    return {
      input: x.has("input"),
      blur: x.has("blur") || x.has("input") || x.has("invalid-input"),
      invalidInput: x.has("invalid-input"),
      lazy: x.has("lazy"),
      eager: x.has("eager")
    };
  }), f = C(() => {
    var V;
    return e.error || (V = e.errorMessages) != null && V.length ? !1 : e.rules.length ? u.value ? r.value.length || d.value.lazy ? null : !0 : !r.value.length : !0;
  }), m = te(!1), h = C(() => ({
    [`${n}--error`]: f.value === !1,
    [`${n}--dirty`]: c.value,
    [`${n}--disabled`]: i.isDisabled.value,
    [`${n}--readonly`]: i.isReadonly.value
  })), b = Ke("validation"), g = C(() => {
    var V;
    return (V = e.name) != null ? V : Tt(t);
  });
  _a(() => {
    var V;
    (V = i.register) == null || V.call(i, {
      id: g.value,
      vm: b,
      validate: P,
      reset: S,
      resetValidation: y
    });
  }), dt(() => {
    var V;
    (V = i.unregister) == null || V.call(i, g.value);
  }), gt(() => He(this, null, function* () {
    var V;
    d.value.lazy || (yield P(!d.value.eager)), (V = i.update) == null || V.call(i, g.value, f.value, s.value);
  })), mt(() => d.value.input || d.value.invalidInput && f.value === !1, () => {
    oe(l, () => {
      if (l.value != null)
        P();
      else if (e.focused) {
        const V = oe(() => e.focused, (x) => {
          x || P(), V();
        });
      }
    });
  }), mt(() => d.value.blur, () => {
    oe(() => e.focused, (V) => {
      V || P();
    });
  }), oe([f, s], () => {
    var V;
    (V = i.update) == null || V.call(i, g.value, f.value, s.value);
  });
  function S() {
    return He(this, null, function* () {
      a.value = null, yield Ve(), yield y();
    });
  }
  function y() {
    return He(this, null, function* () {
      u.value = !0, d.value.lazy ? r.value = [] : yield P(!d.value.eager);
    });
  }
  function P() {
    return He(this, arguments, function* () {
      var I;
      let V = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
      const x = [];
      m.value = !0;
      for (const T of o.value) {
        if (x.length >= Number((I = e.maxErrors) != null ? I : 1))
          break;
        const p = yield (typeof T == "function" ? T : () => T)(l.value);
        if (p !== !0) {
          if (p !== !1 && typeof p != "string") {
            console.warn(`${p} is not a valid value. Rule functions must return boolean true or a string.`);
            continue;
          }
          x.push(p || "");
        }
      }
      return r.value = x, m.value = !1, u.value = V, r.value;
    });
  }
  return {
    errorMessages: s,
    isDirty: c,
    isDisabled: i.isDisabled,
    isReadonly: i.isReadonly,
    isPristine: u,
    isValid: f,
    isValidating: m,
    reset: S,
    resetValidation: y,
    validate: P,
    validationClasses: h
  };
}
const Jt = N(v(v(v(v(v({
  id: String,
  appendIcon: me,
  baseColor: String,
  centerAffix: {
    type: Boolean,
    default: !0
  },
  color: String,
  glow: Boolean,
  iconColor: [Boolean, String],
  prependIcon: me,
  hideDetails: [Boolean, String],
  hideSpinButtons: Boolean,
  hint: String,
  persistentHint: Boolean,
  messages: {
    type: [Array, String],
    default: () => []
  },
  direction: {
    type: String,
    default: "horizontal",
    validator: (e) => ["horizontal", "vertical"].includes(e)
  },
  "onClick:prepend": ot(),
  "onClick:append": ot()
}, de()), nt()), qt(Ze(), ["maxWidth", "minWidth", "width"])), Ie()), gs()), "VInput"), ct = Y()({
  name: "VInput",
  props: v({}, Jt()),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a,
      emit: l
    } = n;
    const {
      densityClasses: i
    } = ht(e), {
      dimensionStyles: o
    } = Qe(e), {
      themeClasses: r
    } = De(e), {
      rtlClasses: u
    } = Xe(), {
      InputIcon: c
    } = vs(e), s = St(), d = C(() => e.id || `input-${s}`), {
      errorMessages: f,
      isDirty: m,
      isDisabled: h,
      isReadonly: b,
      isPristine: g,
      isValid: S,
      isValidating: y,
      reset: P,
      resetValidation: V,
      validate: x,
      validationClasses: I
    } = hs(e, "v-input", d), T = C(() => {
      var F;
      return (F = e.errorMessages) != null && F.length || !g.value && f.value.length ? f.value : e.hint && (e.persistentHint || e.focused) ? e.hint : e.messages;
    }), _ = M(() => T.value.length > 0), p = M(() => !e.hideDetails || e.hideDetails === "auto" && (_.value || !!a.details)), L = C(() => p.value ? `${d.value}-messages` : void 0), D = C(() => ({
      id: d,
      messagesId: L,
      isDirty: m,
      isDisabled: h,
      isReadonly: b,
      isPristine: g,
      isValid: S,
      isValidating: y,
      hasDetails: p,
      reset: P,
      resetValidation: V,
      validate: x
    })), A = M(() => e.error || e.disabled ? void 0 : e.focused ? e.color : e.baseColor), B = M(() => {
      if (e.iconColor)
        return e.iconColor === !0 ? A.value : e.iconColor;
    });
    return Z(() => {
      var W, J, z, H;
      const F = !!(a.prepend || e.prependIcon), $ = !!(a.append || e.appendIcon);
      return w("div", {
        class: X(["v-input", `v-input--${e.direction}`, {
          "v-input--center-affix": e.centerAffix,
          "v-input--focused": e.focused,
          "v-input--glow": e.glow,
          "v-input--hide-spin-buttons": e.hideSpinButtons
        }, i.value, r.value, u.value, I.value, e.class]),
        style: ie([o.value, e.style])
      }, [F && w("div", {
        key: "prepend",
        class: "v-input__prepend"
      }, [(W = a.prepend) == null ? void 0 : W.call(a, D.value), e.prependIcon && k(c, {
        key: "prepend-icon",
        name: "prepend",
        color: B.value
      }, null)]), a.default && w("div", {
        class: "v-input__control"
      }, [(J = a.default) == null ? void 0 : J.call(a, D.value)]), $ && w("div", {
        key: "append",
        class: "v-input__append"
      }, [e.appendIcon && k(c, {
        key: "append-icon",
        name: "append",
        color: B.value
      }, null), (z = a.append) == null ? void 0 : z.call(a, D.value)]), p.value && w("div", {
        id: L.value,
        class: "v-input__details",
        role: "alert",
        "aria-live": "polite"
      }, [k(fs, {
        active: _.value,
        messages: T.value
      }, {
        message: a.message
      }), (H = a.details) == null ? void 0 : H.call(a, D.value)])]);
    }), {
      reset: P,
      resetValidation: V,
      validate: x,
      isValid: S,
      errorMessages: f
    };
  }
}), Ul = Symbol("Forwarded refs");
function Kl(e, n) {
  let t = e;
  for (; t; ) {
    const a = Reflect.getOwnPropertyDescriptor(t, n);
    if (a) return a;
    t = Object.getPrototypeOf(t);
  }
}
function it(e) {
  for (var n = arguments.length, t = new Array(n > 1 ? n - 1 : 0), a = 1; a < n; a++)
    t[a - 1] = arguments[a];
  return e[Ul] = t, new Proxy(e, {
    get(l, i) {
      if (Reflect.has(l, i))
        return Reflect.get(l, i);
      if (!(typeof i == "symbol" || i.startsWith("$") || i.startsWith("__"))) {
        for (const o of t)
          if (o.value && Reflect.has(o.value, i)) {
            const r = Reflect.get(o.value, i);
            return typeof r == "function" ? r.bind(o.value) : r;
          }
      }
    },
    has(l, i) {
      if (Reflect.has(l, i))
        return !0;
      if (typeof i == "symbol" || i.startsWith("$") || i.startsWith("__")) return !1;
      for (const o of t)
        if (o.value && Reflect.has(o.value, i))
          return !0;
      return !1;
    },
    set(l, i, o) {
      if (Reflect.has(l, i))
        return Reflect.set(l, i, o);
      if (typeof i == "symbol" || i.startsWith("$") || i.startsWith("__")) return !1;
      for (const r of t)
        if (r.value && Reflect.has(r.value, i))
          return Reflect.set(r.value, i, o);
      return !1;
    },
    getOwnPropertyDescriptor(l, i) {
      var r, u;
      const o = Reflect.getOwnPropertyDescriptor(l, i);
      if (o) return o;
      if (!(typeof i == "symbol" || i.startsWith("$") || i.startsWith("__"))) {
        for (const c of t) {
          if (!c.value) continue;
          const s = (u = Kl(c.value, i)) != null ? u : "_" in c.value ? Kl((r = c.value._) == null ? void 0 : r.setupState, i) : void 0;
          if (s) return s;
        }
        for (const c of t) {
          const s = c.value && c.value[Ul];
          if (!s) continue;
          const d = s.slice();
          for (; d.length; ) {
            const f = d.shift(), m = Kl(f.value, i);
            if (m) return m;
            const h = f.value && f.value[Ul];
            h && d.push(...h);
          }
        }
      }
    }
  });
}
const ig = N(v(v({}, Jt()), $e(ds(), ["inline"])), "VCheckbox"), og = Y()({
  name: "VCheckbox",
  inheritAttrs: !1,
  props: ig(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:focused": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const l = ve(e, "modelValue"), {
      isFocused: i,
      focus: o,
      blur: r
    } = Qt(e), u = Q(), c = St();
    return Z(() => {
      const [s, d] = an(t), f = ct.filterProps(e), m = zt.filterProps(e);
      return k(ct, G({
        ref: u,
        class: ["v-checkbox", e.class]
      }, s, f, {
        modelValue: l.value,
        "onUpdate:modelValue": (h) => l.value = h,
        id: e.id || `checkbox-${c}`,
        focused: i.value,
        style: e.style
      }), le(v({}, a), {
        default: (h) => {
          let {
            id: b,
            messagesId: g,
            isDisabled: S,
            isReadonly: y,
            isValid: P
          } = h;
          return k(zt, G(m, {
            id: b.value,
            "aria-describedby": g.value,
            disabled: S.value,
            readonly: y.value
          }, d, {
            error: P.value === !1,
            modelValue: l.value,
            "onUpdate:modelValue": (V) => l.value = V,
            onFocus: o,
            onBlur: r
          }), a);
        }
      }));
    }), it({}, u);
  }
});
function rg(e) {
  let {
    selectedElement: n,
    containerElement: t,
    isRtl: a,
    isHorizontal: l
  } = e;
  const i = ka(l, t), o = ys(l, a, t), r = ka(l, n), u = bs(l, n), c = r * 0.4;
  return o > u ? u - c : o + i < u + r ? u - i + r + c : o;
}
function ug(e) {
  let {
    selectedElement: n,
    containerElement: t,
    isHorizontal: a
  } = e;
  const l = ka(a, t), i = bs(a, n), o = ka(a, n);
  return i - l / 2 + o / 2;
}
function Fr(e, n) {
  const t = e ? "scrollWidth" : "scrollHeight";
  return (n == null ? void 0 : n[t]) || 0;
}
function sg(e, n) {
  const t = e ? "clientWidth" : "clientHeight";
  return (n == null ? void 0 : n[t]) || 0;
}
function ys(e, n, t) {
  if (!t)
    return 0;
  const {
    scrollLeft: a,
    offsetWidth: l,
    scrollWidth: i
  } = t;
  return e ? n ? i - l + a : a : t.scrollTop;
}
function ka(e, n) {
  const t = e ? "offsetWidth" : "offsetHeight";
  return (n == null ? void 0 : n[t]) || 0;
}
function bs(e, n) {
  const t = e ? "offsetLeft" : "offsetTop";
  return (n == null ? void 0 : n[t]) || 0;
}
const Ss = Symbol.for("vuetify:v-slide-group"), mo = N(v(v(v(v({
  centerActive: Boolean,
  contentClass: null,
  direction: {
    type: String,
    default: "horizontal"
  },
  symbol: {
    type: null,
    default: Ss
  },
  nextIcon: {
    type: me,
    default: "$next"
  },
  prevIcon: {
    type: me,
    default: "$prev"
  },
  showArrows: {
    type: [Boolean, String],
    validator: (e) => typeof e == "boolean" || ["always", "desktop", "mobile"].includes(e)
  }
}, de()), Pn({
  mobile: null
})), ke()), Tn({
  selectedClass: "v-slide-group-item--active"
})), "VSlideGroup"), wa = Y()({
  name: "VSlideGroup",
  props: mo(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      isRtl: a
    } = Xe(), {
      displayClasses: l,
      mobile: i
    } = At(e), o = on(e, e.symbol), r = te(!1), u = te(0), c = te(0), s = te(0), d = C(() => e.direction === "horizontal"), {
      resizeRef: f,
      contentRect: m
    } = pt(), {
      resizeRef: h,
      contentRect: b
    } = pt(), g = Ou(), S = C(() => ({
      container: f.el,
      duration: 200,
      easing: "easeOutQuart"
    })), y = C(() => o.selected.value.length ? o.items.value.findIndex((R) => R.id === o.selected.value[0]) : -1), P = C(() => o.selected.value.length ? o.items.value.findIndex((R) => R.id === o.selected.value[o.selected.value.length - 1]) : -1);
    if (Te) {
      let R = -1;
      oe(() => [o.selected.value, m.value, b.value, d.value], () => {
        cancelAnimationFrame(R), R = requestAnimationFrame(() => {
          if (m.value && b.value) {
            const q = d.value ? "width" : "height";
            c.value = m.value[q], s.value = b.value[q], r.value = c.value + 1 < s.value;
          }
          if (y.value >= 0 && h.el) {
            const q = h.el.children[P.value];
            x(q, e.centerActive);
          }
        });
      });
    }
    const V = te(!1);
    function x(R, q) {
      let ae = 0;
      q ? ae = ug({
        containerElement: f.el,
        isHorizontal: d.value,
        selectedElement: R
      }) : ae = rg({
        containerElement: f.el,
        isHorizontal: d.value,
        isRtl: a.value,
        selectedElement: R
      }), I(ae);
    }
    function I(R) {
      if (!Te || !f.el) return;
      const q = ka(d.value, f.el), ae = ys(d.value, a.value, f.el);
      if (!(Fr(d.value, f.el) <= q || // Prevent scrolling by only a couple of pixels, which doesn't look smooth
      Math.abs(R - ae) < 16)) {
        if (d.value && a.value && f.el) {
          const {
            scrollWidth: ne,
            offsetWidth: j
          } = f.el;
          R = ne - j - R;
        }
        d.value ? g.horizontal(R, S.value) : g(R, S.value);
      }
    }
    function T(R) {
      const {
        scrollTop: q,
        scrollLeft: ae
      } = R.target;
      u.value = d.value ? ae : q;
    }
    function _(R) {
      if (V.value = !0, !(!r.value || !h.el)) {
        for (const q of R.composedPath())
          for (const ae of h.el.children)
            if (ae === q) {
              x(ae);
              return;
            }
      }
    }
    function p(R) {
      V.value = !1;
    }
    let L = !1;
    function D(R) {
      var q;
      !L && !V.value && !(R.relatedTarget && ((q = h.el) != null && q.contains(R.relatedTarget))) && $(), L = !1;
    }
    function A() {
      L = !0;
    }
    function B(R) {
      if (!h.el) return;
      function q(ae) {
        R.preventDefault(), $(ae);
      }
      d.value ? R.key === "ArrowRight" ? q(a.value ? "prev" : "next") : R.key === "ArrowLeft" && q(a.value ? "next" : "prev") : R.key === "ArrowDown" ? q("next") : R.key === "ArrowUp" && q("prev"), R.key === "Home" ? q("first") : R.key === "End" && q("last");
    }
    function F(R, q) {
      if (!R) return;
      let ae = R;
      do
        ae = ae == null ? void 0 : ae[q === "next" ? "nextElementSibling" : "previousElementSibling"];
      while (ae != null && ae.hasAttribute("disabled"));
      return ae;
    }
    function $(R) {
      if (!h.el) return;
      let q;
      if (!R)
        q = va(h.el)[0];
      else if (R === "next") {
        if (q = F(h.el.querySelector(":focus"), R), !q) return $("first");
      } else if (R === "prev") {
        if (q = F(h.el.querySelector(":focus"), R), !q) return $("last");
      } else R === "first" ? (q = h.el.firstElementChild, q != null && q.hasAttribute("disabled") && (q = F(q, "next"))) : R === "last" && (q = h.el.lastElementChild, q != null && q.hasAttribute("disabled") && (q = F(q, "prev")));
      q && q.focus({
        preventScroll: !0
      });
    }
    function W(R) {
      const q = d.value && a.value ? -1 : 1, ae = (R === "prev" ? -q : q) * c.value;
      let U = u.value + ae;
      if (d.value && a.value && f.el) {
        const {
          scrollWidth: ne,
          offsetWidth: j
        } = f.el;
        U += ne - j;
      }
      I(U);
    }
    const J = C(() => ({
      next: o.next,
      prev: o.prev,
      select: o.select,
      isSelected: o.isSelected
    })), z = C(() => r.value || Math.abs(u.value) > 0), H = C(() => {
      switch (e.showArrows) {
        case "always":
          return !0;
        case "desktop":
          return !i.value;
        case !0:
          return z.value;
        case "mobile":
          return i.value || z.value;
        default:
          return !i.value && z.value;
      }
    }), E = C(() => Math.abs(u.value) > 1), O = C(() => {
      if (!f.value || !z.value) return !1;
      const R = Fr(d.value, f.el), q = sg(d.value, f.el);
      return R - q - Math.abs(u.value) > 1;
    });
    return Z(() => k(e.tag, {
      class: X(["v-slide-group", {
        "v-slide-group--vertical": !d.value,
        "v-slide-group--has-affixes": H.value,
        "v-slide-group--is-overflowing": r.value
      }, l.value, e.class]),
      style: ie(e.style),
      tabindex: V.value || o.selected.value.length ? -1 : 0,
      onFocus: D
    }, {
      default: () => {
        var R, q, ae, U, ne;
        return [H.value && w("div", {
          key: "prev",
          class: X(["v-slide-group__prev", {
            "v-slide-group__prev--disabled": !E.value
          }]),
          onMousedown: A,
          onClick: () => E.value && W("prev")
        }, [(q = (R = t.prev) == null ? void 0 : R.call(t, J.value)) != null ? q : k(ya, null, {
          default: () => [k(Be, {
            icon: a.value ? e.nextIcon : e.prevIcon
          }, null)]
        })]), w("div", {
          key: "container",
          ref: f,
          class: X(["v-slide-group__container", e.contentClass]),
          onScroll: T
        }, [w("div", {
          ref: h,
          class: "v-slide-group__content",
          onFocusin: _,
          onFocusout: p,
          onKeydown: B
        }, [(ae = t.default) == null ? void 0 : ae.call(t, J.value)])]), H.value && w("div", {
          key: "next",
          class: X(["v-slide-group__next", {
            "v-slide-group__next--disabled": !O.value
          }]),
          onMousedown: A,
          onClick: () => O.value && W("next")
        }, [(ne = (U = t.next) == null ? void 0 : U.call(t, J.value)) != null ? ne : k(ya, null, {
          default: () => [k(Be, {
            icon: a.value ? e.prevIcon : e.nextIcon
          }, null)]
        })])];
      }
    })), {
      selected: o.selected,
      scrollTo: W,
      scrollOffset: u,
      focus: $,
      hasPrev: E,
      hasNext: O
    };
  }
}), ks = Symbol.for("vuetify:v-chip-group"), cg = N(v(v(v(v(v(v({
  baseColor: String,
  column: Boolean,
  filter: Boolean,
  valueComparator: {
    type: Function,
    default: at
  }
}, mo()), de()), Tn({
  selectedClass: "v-chip--selected"
})), ke()), Ie()), Dt({
  variant: "tonal"
})), "VChipGroup"), dg = Y()({
  name: "VChipGroup",
  props: cg(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      isSelected: l,
      select: i,
      next: o,
      prev: r,
      selected: u
    } = on(e, ks);
    return je({
      VChip: {
        baseColor: M(() => e.baseColor),
        color: M(() => e.color),
        disabled: M(() => e.disabled),
        filter: M(() => e.filter),
        variant: M(() => e.variant)
      }
    }), Z(() => {
      const c = wa.filterProps(e);
      return k(wa, G(c, {
        class: ["v-chip-group", {
          "v-chip-group--column": e.column
        }, a.value, e.class],
        style: e.style
      }), {
        default: () => {
          var s;
          return [(s = t.default) == null ? void 0 : s.call(t, {
            isSelected: l,
            select: i,
            next: o,
            prev: r,
            selected: u.value
          })];
        }
      });
    }), {};
  }
}), vg = N(v(v(v(v(v(v(v(v(v(v(v({
  activeClass: String,
  appendAvatar: String,
  appendIcon: me,
  baseColor: String,
  closable: Boolean,
  closeIcon: {
    type: me,
    default: "$delete"
  },
  closeLabel: {
    type: String,
    default: "$vuetify.close"
  },
  draggable: Boolean,
  filter: Boolean,
  filterIcon: {
    type: me,
    default: "$complete"
  },
  label: Boolean,
  link: {
    type: Boolean,
    default: void 0
  },
  pill: Boolean,
  prependAvatar: String,
  prependIcon: me,
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  text: {
    type: [String, Number, Boolean],
    default: void 0
  },
  modelValue: {
    type: Boolean,
    default: !0
  },
  onClick: ot(),
  onClickOnce: ot()
}, kt()), de()), nt()), Je()), Bn()), Ne()), pa()), Yt()), ke({
  tag: "span"
})), Ie()), Dt({
  variant: "tonal"
})), "VChip"), na = Y()({
  name: "VChip",
  directives: {
    vRipple: bt
  },
  props: vg(),
  emits: {
    "click:close": (e) => !0,
    "update:modelValue": (e) => !0,
    "group:selected": (e) => !0,
    click: (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const {
      t: i
    } = Ee(), {
      borderClasses: o
    } = Ct(e), {
      densityClasses: r
    } = ht(e), {
      elevationClasses: u
    } = lt(e), {
      roundedClasses: c
    } = Ye(e), {
      sizeClasses: s
    } = Qn(e), {
      themeClasses: d
    } = De(e), f = ve(e, "modelValue"), m = Dn(e, ks, !1), h = Ma(e, t), b = M(() => e.link !== !1 && h.isLink.value), g = C(() => !e.disabled && e.link !== !1 && (!!m || e.link || h.isClickable.value)), S = M(() => ({
      "aria-label": i(e.closeLabel),
      disabled: e.disabled,
      onClick(T) {
        T.preventDefault(), T.stopPropagation(), f.value = !1, a("click:close", T);
      }
    })), {
      colorClasses: y,
      colorStyles: P,
      variantClasses: V
    } = Ln(() => {
      var _;
      return {
        color: (!m || m.isSelected.value) && (_ = e.color) != null ? _ : e.baseColor,
        variant: e.variant
      };
    });
    function x(T) {
      var _;
      a("click", T), g.value && ((_ = h.navigate) == null || _.call(h, T), m == null || m.toggle());
    }
    function I(T) {
      (T.key === "Enter" || T.key === " ") && (T.preventDefault(), x(T));
    }
    return () => {
      var F;
      const T = h.isLink.value ? "a" : e.tag, _ = !!(e.appendIcon || e.appendAvatar), p = !!(_ || l.append), L = !!(l.close || e.closable), D = !!(l.filter || e.filter) && m, A = !!(e.prependIcon || e.prependAvatar), B = !!(A || l.prepend);
      return f.value && Re(k(T, G({
        class: ["v-chip", {
          "v-chip--disabled": e.disabled,
          "v-chip--label": e.label,
          "v-chip--link": g.value,
          "v-chip--filter": D,
          "v-chip--pill": e.pill,
          [`${e.activeClass}`]: e.activeClass && ((F = h.isActive) == null ? void 0 : F.value)
        }, d.value, o.value, y.value, r.value, u.value, c.value, s.value, V.value, m == null ? void 0 : m.selectedClass.value, e.class],
        style: [P.value, e.style],
        disabled: e.disabled || void 0,
        draggable: e.draggable,
        tabindex: g.value ? 0 : void 0,
        onClick: x,
        onKeydown: g.value && !b.value && I
      }, h.linkProps), {
        default: () => {
          var $, W;
          return [ln(g.value, "v-chip"), D && k(so, {
            key: "filter"
          }, {
            default: () => [Re(w("div", {
              class: "v-chip__filter"
            }, [l.filter ? k(Ce, {
              key: "filter-defaults",
              disabled: !e.filterIcon,
              defaults: {
                VIcon: {
                  icon: e.filterIcon
                }
              }
            }, l.filter) : k(Be, {
              key: "filter-icon",
              icon: e.filterIcon
            }, null)]), [[$t, m.isSelected.value]])]
          }), B && w("div", {
            key: "prepend",
            class: "v-chip__prepend"
          }, [l.prepend ? k(Ce, {
            key: "prepend-defaults",
            disabled: !A,
            defaults: {
              VAvatar: {
                image: e.prependAvatar,
                start: !0
              },
              VIcon: {
                icon: e.prependIcon,
                start: !0
              }
            }
          }, l.prepend) : w(he, null, [e.prependIcon && k(Be, {
            key: "prepend-icon",
            icon: e.prependIcon,
            start: !0
          }, null), e.prependAvatar && k(Bt, {
            key: "prepend-avatar",
            image: e.prependAvatar,
            start: !0
          }, null)])]), w("div", {
            class: "v-chip__content",
            "data-no-activator": ""
          }, [(W = ($ = l.default) == null ? void 0 : $.call(l, {
            isSelected: m == null ? void 0 : m.isSelected.value,
            selectedClass: m == null ? void 0 : m.selectedClass.value,
            select: m == null ? void 0 : m.select,
            toggle: m == null ? void 0 : m.toggle,
            value: m == null ? void 0 : m.value.value,
            disabled: e.disabled
          })) != null ? W : hn(e.text)]), p && w("div", {
            key: "append",
            class: "v-chip__append"
          }, [l.append ? k(Ce, {
            key: "append-defaults",
            disabled: !_,
            defaults: {
              VAvatar: {
                end: !0,
                image: e.appendAvatar
              },
              VIcon: {
                end: !0,
                icon: e.appendIcon
              }
            }
          }, l.append) : w(he, null, [e.appendIcon && k(Be, {
            key: "append-icon",
            end: !0,
            icon: e.appendIcon
          }, null), e.appendAvatar && k(Bt, {
            key: "append-avatar",
            end: !0,
            image: e.appendAvatar
          }, null)])]), L && w("button", G({
            key: "close",
            class: "v-chip__close",
            type: "button",
            "data-testid": "close-chip"
          }, S.value), [l.close ? k(Ce, {
            key: "close-defaults",
            defaults: {
              VIcon: {
                icon: e.closeIcon,
                size: "x-small"
              }
            }
          }, l.close) : k(Be, {
            key: "close-icon",
            icon: e.closeIcon,
            size: "x-small"
          }, null)])];
        }
      }), [[bt, g.value && e.ripple, null]]);
    };
  }
}), fg = N(v(v({
  color: String,
  inset: Boolean,
  length: [Number, String],
  opacity: [Number, String],
  thickness: [Number, String],
  vertical: Boolean
}, de()), Ie()), "VDivider"), It = Y()({
  name: "VDivider",
  props: fg(),
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      themeClasses: l
    } = De(e), {
      textColorClasses: i,
      textColorStyles: o
    } = rt(() => e.color), r = C(() => {
      const u = {};
      return e.length && (u[e.vertical ? "height" : "width"] = ce(e.length)), e.thickness && (u[e.vertical ? "borderRightWidth" : "borderTopWidth"] = ce(e.thickness)), u;
    });
    return Z(() => {
      const u = w("hr", {
        class: X([{
          "v-divider": !0,
          "v-divider--inset": e.inset,
          "v-divider--vertical": e.vertical
        }, l.value, i.value, e.class]),
        style: ie([r.value, o.value, {
          "--v-border-opacity": e.opacity
        }, e.style]),
        "aria-orientation": !t.role || t.role === "separator" ? e.vertical ? "vertical" : "horizontal" : void 0,
        role: `${t.role || "separator"}`
      }, null);
      return a.default ? w("div", {
        class: X(["v-divider__wrapper", {
          "v-divider__wrapper--vertical": e.vertical,
          "v-divider__wrapper--inset": e.inset
        }])
      }, [u, w("div", {
        class: "v-divider__content"
      }, [a.default()]), u]) : u;
    }), {};
  }
}), Si = Symbol.for("vuetify:list");
function ws() {
  let {
    filterable: e
  } = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {
    filterable: !1
  };
  const n = Pe(Si, {
    filterable: !1,
    hasPrepend: te(!1),
    updateHasPrepend: () => null
  }), t = {
    filterable: n.filterable || e,
    hasPrepend: te(!1),
    updateHasPrepend: (a) => {
      a && (t.hasPrepend.value = a);
    }
  };
  return Oe(Si, t), n;
}
function Cs() {
  return Pe(Si, null);
}
const go = (e) => {
  const n = {
    activate: (t) => {
      let {
        id: a,
        value: l,
        activated: i
      } = t;
      return a = Ue(a), e && !l && i.size === 1 && i.has(a) || (l ? i.add(a) : i.delete(a)), i;
    },
    in: (t, a, l) => {
      let i = /* @__PURE__ */ new Set();
      if (t != null)
        for (const o of ze(t))
          i = n.activate({
            id: o,
            value: !0,
            activated: new Set(i),
            children: a,
            parents: l
          });
      return i;
    },
    out: (t) => Array.from(t)
  };
  return n;
}, xs = (e) => {
  const n = go(e);
  return {
    activate: (a) => {
      let u = a, {
        activated: l,
        id: i
      } = u, o = Ge(u, [
        "activated",
        "id"
      ]);
      i = Ue(i);
      const r = l.has(i) ? /* @__PURE__ */ new Set([i]) : /* @__PURE__ */ new Set();
      return n.activate(le(v({}, o), {
        id: i,
        activated: r
      }));
    },
    in: (a, l, i) => {
      let o = /* @__PURE__ */ new Set();
      if (a != null) {
        const r = ze(a);
        r.length && (o = n.in(r.slice(0, 1), l, i));
      }
      return o;
    },
    out: (a, l, i) => n.out(a, l, i)
  };
}, mg = (e) => {
  const n = go(e);
  return {
    activate: (a) => {
      let u = a, {
        id: l,
        activated: i,
        children: o
      } = u, r = Ge(u, [
        "id",
        "activated",
        "children"
      ]);
      return l = Ue(l), o.has(l) ? i : n.activate(v({
        id: l,
        activated: i,
        children: o
      }, r));
    },
    in: n.in,
    out: n.out
  };
}, gg = (e) => {
  const n = xs(e);
  return {
    activate: (a) => {
      let u = a, {
        id: l,
        activated: i,
        children: o
      } = u, r = Ge(u, [
        "id",
        "activated",
        "children"
      ]);
      return l = Ue(l), o.has(l) ? i : n.activate(v({
        id: l,
        activated: i,
        children: o
      }, r));
    },
    in: n.in,
    out: n.out
  };
}, hg = {
  open: (e) => {
    let {
      id: n,
      value: t,
      opened: a,
      parents: l
    } = e;
    if (t) {
      const i = /* @__PURE__ */ new Set();
      i.add(n);
      let o = l.get(n);
      for (; o != null; )
        i.add(o), o = l.get(o);
      return i;
    } else
      return a.delete(n), a;
  },
  select: () => null
}, Vs = {
  open: (e) => {
    let {
      id: n,
      value: t,
      opened: a,
      parents: l
    } = e;
    if (t) {
      let i = l.get(n);
      for (a.add(n); i != null && i !== n; )
        a.add(i), i = l.get(i);
      return a;
    } else
      a.delete(n);
    return a;
  },
  select: () => null
}, yg = {
  open: Vs.open,
  select: (e) => {
    let {
      id: n,
      value: t,
      opened: a,
      parents: l
    } = e;
    if (!t) return a;
    const i = [];
    let o = l.get(n);
    for (; o != null; )
      i.push(o), o = l.get(o);
    return new Set(i);
  }
}, ho = (e) => {
  const n = {
    select: (t) => {
      let {
        id: a,
        value: l,
        selected: i
      } = t;
      if (a = Ue(a), e && !l) {
        const o = Array.from(i.entries()).reduce((r, u) => {
          let [c, s] = u;
          return s === "on" && r.push(c), r;
        }, []);
        if (o.length === 1 && o[0] === a) return i;
      }
      return i.set(a, l ? "on" : "off"), i;
    },
    in: (t, a, l, i) => {
      const o = /* @__PURE__ */ new Map();
      for (const r of t || [])
        n.select({
          id: r,
          value: !0,
          selected: o,
          children: a,
          parents: l,
          disabled: i
        });
      return o;
    },
    out: (t) => {
      const a = [];
      for (const [l, i] of t.entries())
        i === "on" && a.push(l);
      return a;
    }
  };
  return n;
}, Ps = (e) => {
  const n = ho(e);
  return {
    select: (a) => {
      let u = a, {
        selected: l,
        id: i
      } = u, o = Ge(u, [
        "selected",
        "id"
      ]);
      i = Ue(i);
      const r = l.has(i) ? /* @__PURE__ */ new Map([[i, l.get(i)]]) : /* @__PURE__ */ new Map();
      return n.select(le(v({}, o), {
        id: i,
        selected: r
      }));
    },
    in: (a, l, i, o) => a != null && a.length ? n.in(a.slice(0, 1), l, i, o) : /* @__PURE__ */ new Map(),
    out: (a, l, i) => n.out(a, l, i)
  };
}, bg = (e) => {
  const n = ho(e);
  return {
    select: (a) => {
      let u = a, {
        id: l,
        selected: i,
        children: o
      } = u, r = Ge(u, [
        "id",
        "selected",
        "children"
      ]);
      return l = Ue(l), o.has(l) ? i : n.select(v({
        id: l,
        selected: i,
        children: o
      }, r));
    },
    in: n.in,
    out: n.out
  };
}, Sg = (e) => {
  const n = Ps(e);
  return {
    select: (a) => {
      let u = a, {
        id: l,
        selected: i,
        children: o
      } = u, r = Ge(u, [
        "id",
        "selected",
        "children"
      ]);
      return l = Ue(l), o.has(l) ? i : n.select(v({
        id: l,
        selected: i,
        children: o
      }, r));
    },
    in: n.in,
    out: n.out
  };
}, Is = (e) => {
  const n = {
    select: (t) => {
      let {
        id: a,
        value: l,
        selected: i,
        children: o,
        parents: r,
        disabled: u
      } = t;
      a = Ue(a);
      const c = new Map(i), s = [a];
      for (; s.length; ) {
        const f = s.shift();
        u.has(f) || i.set(Ue(f), l ? "on" : "off"), o.has(f) && s.push(...o.get(f));
      }
      let d = Ue(r.get(a));
      for (; d; ) {
        let f = !0, m = !0;
        for (const h of o.get(d)) {
          const b = Ue(h);
          if (!u.has(b) && (i.get(b) !== "on" && (f = !1), i.has(b) && i.get(b) !== "off" && (m = !1), !f && !m))
            break;
        }
        i.set(d, f ? "on" : m ? "off" : "indeterminate"), d = Ue(r.get(d));
      }
      return e && !l && Array.from(i.entries()).reduce((m, h) => {
        let [b, g] = h;
        return g === "on" && m.push(b), m;
      }, []).length === 0 ? c : i;
    },
    in: (t, a, l, i) => {
      let o = /* @__PURE__ */ new Map();
      for (const r of t || [])
        o = n.select({
          id: r,
          value: !0,
          selected: o,
          children: a,
          parents: l,
          disabled: i
        });
      return o;
    },
    out: (t, a) => {
      const l = [];
      for (const [i, o] of t.entries())
        o === "on" && !a.has(i) && l.push(i);
      return l;
    }
  };
  return n;
}, kg = (e) => {
  const n = Is(e);
  return {
    select: n.select,
    in: n.in,
    out: (a, l, i) => {
      const o = [];
      for (const [r, u] of a.entries())
        if (u === "on") {
          if (i.has(r)) {
            const c = i.get(r);
            if (a.get(c) === "on") continue;
          }
          o.push(r);
        }
      return o;
    }
  };
}, Ca = Symbol.for("vuetify:nested"), _s = {
  id: te(),
  root: {
    register: () => null,
    unregister: () => null,
    children: Q(/* @__PURE__ */ new Map()),
    parents: Q(/* @__PURE__ */ new Map()),
    disabled: Q(/* @__PURE__ */ new Set()),
    open: () => null,
    openOnSelect: () => null,
    activate: () => null,
    select: () => null,
    activatable: Q(!1),
    selectable: Q(!1),
    opened: Q(/* @__PURE__ */ new Set()),
    activated: Q(/* @__PURE__ */ new Set()),
    selected: Q(/* @__PURE__ */ new Map()),
    selectedValues: Q([]),
    getPath: () => []
  }
}, wg = N({
  activatable: Boolean,
  selectable: Boolean,
  activeStrategy: [String, Function, Object],
  selectStrategy: [String, Function, Object],
  openStrategy: [String, Object],
  opened: null,
  activated: null,
  selected: null,
  mandatory: Boolean
}, "nested"), Cg = (e) => {
  let n = !1;
  const t = te(/* @__PURE__ */ new Map()), a = te(/* @__PURE__ */ new Map()), l = te(/* @__PURE__ */ new Set()), i = ve(e, "opened", e.opened, (b) => new Set(Array.isArray(b) ? b.map((g) => Ue(g)) : b), (b) => [...b.values()]), o = C(() => {
    if (typeof e.activeStrategy == "object") return e.activeStrategy;
    if (typeof e.activeStrategy == "function") return e.activeStrategy(e.mandatory);
    switch (e.activeStrategy) {
      case "leaf":
        return mg(e.mandatory);
      case "single-leaf":
        return gg(e.mandatory);
      case "independent":
        return go(e.mandatory);
      case "single-independent":
      default:
        return xs(e.mandatory);
    }
  }), r = C(() => {
    if (typeof e.selectStrategy == "object") return e.selectStrategy;
    if (typeof e.selectStrategy == "function") return e.selectStrategy(e.mandatory);
    switch (e.selectStrategy) {
      case "single-leaf":
        return Sg(e.mandatory);
      case "leaf":
        return bg(e.mandatory);
      case "independent":
        return ho(e.mandatory);
      case "single-independent":
        return Ps(e.mandatory);
      case "trunk":
        return kg(e.mandatory);
      case "classic":
      default:
        return Is(e.mandatory);
    }
  }), u = C(() => {
    if (typeof e.openStrategy == "object") return e.openStrategy;
    switch (e.openStrategy) {
      case "list":
        return yg;
      case "single":
        return hg;
      case "multiple":
      default:
        return Vs;
    }
  }), c = ve(e, "activated", e.activated, (b) => o.value.in(b, t.value, a.value), (b) => o.value.out(b, t.value, a.value)), s = ve(e, "selected", e.selected, (b) => r.value.in(b, t.value, a.value, l.value), (b) => r.value.out(b, t.value, a.value));
  dt(() => {
    n = !0;
  });
  function d(b) {
    const g = [];
    let S = Ue(b);
    for (; S !== void 0; )
      g.unshift(S), S = a.value.get(S);
    return g;
  }
  const f = Ke("nested"), m = /* @__PURE__ */ new Set(), h = {
    id: te(),
    root: {
      opened: i,
      activatable: M(() => e.activatable),
      selectable: M(() => e.selectable),
      activated: c,
      selected: s,
      selectedValues: C(() => {
        const b = [];
        for (const [g, S] of s.value.entries())
          S === "on" && b.push(g);
        return b;
      }),
      register: (b, g, S, y) => {
        if (m.has(b)) {
          const P = d(b).map(String).join(" -> "), V = d(g).concat(b).map(String).join(" -> ");
          fa(`Multiple nodes with the same ID
	${P}
	${V}`);
          return;
        } else
          m.add(b);
        g && b !== g && a.value.set(b, g), S && l.value.add(b), y && t.value.set(b, []), g != null && t.value.set(g, [...t.value.get(g) || [], b]);
      },
      unregister: (b) => {
        var S;
        if (n) return;
        m.delete(b), t.value.delete(b), l.value.delete(b);
        const g = a.value.get(b);
        if (g) {
          const y = (S = t.value.get(g)) != null ? S : [];
          t.value.set(g, y.filter((P) => P !== b));
        }
        a.value.delete(b);
      },
      open: (b, g, S) => {
        f.emit("click:open", {
          id: b,
          value: g,
          path: d(b),
          event: S
        });
        const y = u.value.open({
          id: b,
          value: g,
          opened: new Set(i.value),
          children: t.value,
          parents: a.value,
          event: S
        });
        y && (i.value = y);
      },
      openOnSelect: (b, g, S) => {
        const y = u.value.select({
          id: b,
          value: g,
          selected: new Map(s.value),
          opened: new Set(i.value),
          children: t.value,
          parents: a.value,
          event: S
        });
        y && (i.value = y);
      },
      select: (b, g, S) => {
        f.emit("click:select", {
          id: b,
          value: g,
          path: d(b),
          event: S
        });
        const y = r.value.select({
          id: b,
          value: g,
          selected: new Map(s.value),
          children: t.value,
          parents: a.value,
          disabled: l.value,
          event: S
        });
        y && (s.value = y), h.root.openOnSelect(b, g, S);
      },
      activate: (b, g, S) => {
        if (!e.activatable)
          return h.root.select(b, !0, S);
        f.emit("click:activate", {
          id: b,
          value: g,
          path: d(b),
          event: S
        });
        const y = o.value.activate({
          id: b,
          value: g,
          activated: new Set(c.value),
          children: t.value,
          parents: a.value,
          event: S
        });
        if (y.size !== c.value.size)
          c.value = y;
        else {
          for (const P of y)
            if (!c.value.has(P)) {
              c.value = y;
              return;
            }
          for (const P of c.value)
            if (!y.has(P)) {
              c.value = y;
              return;
            }
        }
      },
      children: t,
      parents: a,
      disabled: l,
      getPath: d
    }
  };
  return Oe(Ca, h), h.root;
}, As = (e, n, t) => {
  const a = Pe(Ca, _s), l = Symbol("nested item"), i = C(() => {
    const r = Ue(st(e));
    return r !== void 0 ? r : l;
  }), o = le(v({}, a), {
    id: i,
    open: (r, u) => a.root.open(i.value, r, u),
    openOnSelect: (r, u) => a.root.openOnSelect(i.value, r, u),
    isOpen: C(() => a.root.opened.value.has(i.value)),
    parent: C(() => a.root.parents.value.get(i.value)),
    activate: (r, u) => a.root.activate(i.value, r, u),
    isActivated: C(() => a.root.activated.value.has(i.value)),
    select: (r, u) => a.root.select(i.value, r, u),
    isSelected: C(() => a.root.selected.value.get(i.value) === "on"),
    isIndeterminate: C(() => a.root.selected.value.get(i.value) === "indeterminate"),
    isLeaf: C(() => !a.root.children.value.get(i.value)),
    isGroupActivator: a.isGroupActivator
  });
  return _a(() => {
    a.isGroupActivator || a.root.register(i.value, a.id.value, st(n), t);
  }), dt(() => {
    a.isGroupActivator || a.root.unregister(i.value);
  }), t && Oe(Ca, o), o;
}, xg = () => {
  const e = Pe(Ca, _s);
  Oe(Ca, le(v({}, e), {
    isGroupActivator: !0
  }));
}, Vg = _t({
  name: "VListGroupActivator",
  setup(e, n) {
    let {
      slots: t
    } = n;
    return xg(), () => {
      var a;
      return (a = t.default) == null ? void 0 : a.call(t);
    };
  }
}), Ls = N(v(v({
  /* @deprecated */
  activeColor: String,
  baseColor: String,
  color: String,
  collapseIcon: {
    type: me,
    default: "$collapse"
  },
  disabled: Boolean,
  expandIcon: {
    type: me,
    default: "$expand"
  },
  rawId: [String, Number],
  prependIcon: me,
  appendIcon: me,
  fluid: Boolean,
  subgroup: Boolean,
  title: String,
  value: null
}, de()), ke()), "VListGroup"), xa = Y()({
  name: "VListGroup",
  props: Ls(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      isOpen: a,
      open: l,
      id: i
    } = As(() => e.value, () => e.disabled, !0), o = C(() => {
      var m;
      return `v-list-group--id-${String((m = e.rawId) != null ? m : i.value)}`;
    }), r = Cs(), {
      isBooted: u
    } = An();
    function c(m) {
      var h;
      ["INPUT", "TEXTAREA"].includes((h = m.target) == null ? void 0 : h.tagName) || l(!a.value, m);
    }
    const s = C(() => ({
      onClick: c,
      class: "v-list-group__header",
      id: o.value
    })), d = C(() => a.value ? e.collapseIcon : e.expandIcon), f = C(() => ({
      VListItem: {
        activeColor: e.activeColor,
        baseColor: e.baseColor,
        color: e.color,
        prependIcon: e.prependIcon || e.subgroup && d.value,
        appendIcon: e.appendIcon || !e.subgroup && d.value,
        title: e.title,
        value: e.value
      }
    }));
    return Z(() => k(e.tag, {
      class: X(["v-list-group", {
        "v-list-group--prepend": r == null ? void 0 : r.hasPrepend.value,
        "v-list-group--fluid": e.fluid,
        "v-list-group--subgroup": e.subgroup,
        "v-list-group--open": a.value
      }, e.class]),
      style: ie(e.style)
    }, {
      default: () => [t.activator && k(Ce, {
        defaults: f.value
      }, {
        default: () => [k(Vg, null, {
          default: () => [t.activator({
            props: s.value,
            isOpen: a.value
          })]
        })]
      }), k(ft, {
        transition: {
          component: kl
        },
        disabled: !u.value
      }, {
        default: () => {
          var m;
          return [Re(w("div", {
            class: "v-list-group__items",
            role: "group",
            "aria-labelledby": o.value
          }, [(m = t.default) == null ? void 0 : m.call(t)]), [[$t, a.value]])];
        }
      })]
    })), {
      isOpen: a
    };
  }
}), Pg = N(v(v({
  opacity: [Number, String]
}, de()), ke()), "VListItemSubtitle"), Ts = Y()({
  name: "VListItemSubtitle",
  props: Pg(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(e.tag, {
      class: X(["v-list-item-subtitle", e.class]),
      style: ie([{
        "--v-list-item-subtitle-opacity": e.opacity
      }, e.style])
    }, t)), {};
  }
}), Bs = Xt("v-list-item-title"), Ds = N(v(v(v(v(v(v(v(v(v(v({
  active: {
    type: Boolean,
    default: void 0
  },
  activeClass: String,
  /* @deprecated */
  activeColor: String,
  appendAvatar: String,
  appendIcon: me,
  baseColor: String,
  disabled: Boolean,
  lines: [Boolean, String],
  link: {
    type: Boolean,
    default: void 0
  },
  nav: Boolean,
  prependAvatar: String,
  prependIcon: me,
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  slim: Boolean,
  subtitle: {
    type: [String, Number, Boolean],
    default: void 0
  },
  title: {
    type: [String, Number, Boolean],
    default: void 0
  },
  value: null,
  onClick: ot(),
  onClickOnce: ot()
}, kt()), de()), nt()), Ze()), Je()), Ne()), pa()), ke()), Ie()), Dt({
  variant: "text"
})), "VListItem"), Et = Y()({
  name: "VListItem",
  directives: {
    vRipple: bt
  },
  props: Ds(),
  emits: {
    click: (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a,
      emit: l
    } = n;
    const i = Ma(e, t), o = C(() => e.value === void 0 ? i.href.value : e.value), {
      activate: r,
      isActivated: u,
      select: c,
      isOpen: s,
      isSelected: d,
      isIndeterminate: f,
      isGroupActivator: m,
      root: h,
      parent: b,
      openOnSelect: g,
      id: S
    } = As(o, () => e.disabled, !1), y = Cs(), P = C(() => {
      var U;
      return e.active !== !1 && (e.active || ((U = i.isActive) == null ? void 0 : U.value) || (h.activatable.value ? u.value : d.value));
    }), V = M(() => e.link !== !1 && i.isLink.value), x = C(() => !!y && (h.selectable.value || h.activatable.value || e.value != null)), I = C(() => !e.disabled && e.link !== !1 && (e.link || i.isClickable.value || x.value)), T = M(() => e.rounded || e.nav), _ = M(() => {
      var U;
      return (U = e.color) != null ? U : e.activeColor;
    }), p = M(() => {
      var U;
      return {
        color: P.value && (U = _.value) != null ? U : e.baseColor,
        variant: e.variant
      };
    });
    oe(() => {
      var U;
      return (U = i.isActive) == null ? void 0 : U.value;
    }, (U) => {
      U && L();
    }), _a(() => {
      var U;
      (U = i.isActive) != null && U.value && L();
    });
    function L() {
      b.value != null && h.open(b.value, !0), g(!0);
    }
    const {
      themeClasses: D
    } = De(e), {
      borderClasses: A
    } = Ct(e), {
      colorClasses: B,
      colorStyles: F,
      variantClasses: $
    } = Ln(p), {
      densityClasses: W
    } = ht(e), {
      dimensionStyles: J
    } = Qe(e), {
      elevationClasses: z
    } = lt(e), {
      roundedClasses: H
    } = Ye(T), E = M(() => e.lines ? `v-list-item--${e.lines}-line` : void 0), O = M(() => e.ripple !== void 0 && e.ripple && (y != null && y.filterable) ? {
      keys: ["Enter"]
    } : e.ripple), R = C(() => ({
      isActive: P.value,
      select: c,
      isOpen: s.value,
      isSelected: d.value,
      isIndeterminate: f.value
    }));
    function q(U) {
      var ne, j;
      l("click", U), !["INPUT", "TEXTAREA"].includes((ne = U.target) == null ? void 0 : ne.tagName) && I.value && ((j = i.navigate) == null || j.call(i, U), !m && (h.activatable.value ? r(!u.value, U) : (h.selectable.value || e.value != null) && c(!d.value, U)));
    }
    function ae(U) {
      const ne = U.target;
      ["INPUT", "TEXTAREA"].includes(ne.tagName) || (U.key === "Enter" || U.key === " " && !(y != null && y.filterable)) && (U.preventDefault(), U.stopPropagation(), U.target.dispatchEvent(new MouseEvent("click", U)));
    }
    return Z(() => {
      const U = V.value ? "a" : e.tag, ne = a.title || e.title != null, j = a.subtitle || e.subtitle != null, ue = !!(e.appendAvatar || e.appendIcon), ge = !!(ue || a.append), ee = !!(e.prependAvatar || e.prependIcon), re = !!(ee || a.prepend);
      return y == null || y.updateHasPrepend(re), e.activeColor && gu("active-color", ["color", "base-color"]), Re(k(U, G({
        class: ["v-list-item", {
          "v-list-item--active": P.value,
          "v-list-item--disabled": e.disabled,
          "v-list-item--link": I.value,
          "v-list-item--nav": e.nav,
          "v-list-item--prepend": !re && (y == null ? void 0 : y.hasPrepend.value),
          "v-list-item--slim": e.slim,
          [`${e.activeClass}`]: e.activeClass && P.value
        }, D.value, A.value, B.value, W.value, z.value, E.value, H.value, $.value, e.class],
        style: [F.value, J.value, e.style],
        tabindex: I.value ? y ? -2 : 0 : void 0,
        "aria-selected": x.value ? h.activatable.value ? u.value : h.selectable.value ? d.value : P.value : void 0,
        onClick: q,
        onKeydown: I.value && !V.value && ae
      }, i.linkProps), {
        default: () => {
          var fe;
          return [ln(I.value || P.value, "v-list-item"), re && w("div", {
            key: "prepend",
            class: "v-list-item__prepend"
          }, [a.prepend ? k(Ce, {
            key: "prepend-defaults",
            disabled: !ee,
            defaults: {
              VAvatar: {
                density: e.density,
                image: e.prependAvatar
              },
              VIcon: {
                density: e.density,
                icon: e.prependIcon
              },
              VListItemAction: {
                start: !0
              }
            }
          }, {
            default: () => {
              var K;
              return [(K = a.prepend) == null ? void 0 : K.call(a, R.value)];
            }
          }) : w(he, null, [e.prependAvatar && k(Bt, {
            key: "prepend-avatar",
            density: e.density,
            image: e.prependAvatar
          }, null), e.prependIcon && k(Be, {
            key: "prepend-icon",
            density: e.density,
            icon: e.prependIcon
          }, null)]), w("div", {
            class: "v-list-item__spacer"
          }, null)]), w("div", {
            class: "v-list-item__content",
            "data-no-activator": ""
          }, [ne && k(Bs, {
            key: "title"
          }, {
            default: () => {
              var K, se;
              return [(se = (K = a.title) == null ? void 0 : K.call(a, {
                title: e.title
              })) != null ? se : hn(e.title)];
            }
          }), j && k(Ts, {
            key: "subtitle"
          }, {
            default: () => {
              var K, se;
              return [(se = (K = a.subtitle) == null ? void 0 : K.call(a, {
                subtitle: e.subtitle
              })) != null ? se : hn(e.subtitle)];
            }
          }), (fe = a.default) == null ? void 0 : fe.call(a, R.value)]), ge && w("div", {
            key: "append",
            class: "v-list-item__append"
          }, [a.append ? k(Ce, {
            key: "append-defaults",
            disabled: !ue,
            defaults: {
              VAvatar: {
                density: e.density,
                image: e.appendAvatar
              },
              VIcon: {
                density: e.density,
                icon: e.appendIcon
              },
              VListItemAction: {
                end: !0
              }
            }
          }, {
            default: () => {
              var K;
              return [(K = a.append) == null ? void 0 : K.call(a, R.value)];
            }
          }) : w(he, null, [e.appendIcon && k(Be, {
            key: "append-icon",
            density: e.density,
            icon: e.appendIcon
          }, null), e.appendAvatar && k(Bt, {
            key: "append-avatar",
            density: e.density,
            image: e.appendAvatar
          }, null)]), w("div", {
            class: "v-list-item__spacer"
          }, null)])];
        }
      }), [[bt, I.value && O.value]]);
    }), {
      activate: r,
      isActivated: u,
      isGroupActivator: m,
      isSelected: d,
      list: y,
      select: c,
      root: h,
      id: S,
      link: i
    };
  }
}), Ig = N(v(v({
  color: String,
  inset: Boolean,
  sticky: Boolean,
  title: String
}, de()), ke()), "VListSubheader"), aa = Y()({
  name: "VListSubheader",
  props: Ig(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      textColorClasses: a,
      textColorStyles: l
    } = rt(() => e.color);
    return Z(() => {
      const i = !!(t.default || e.title);
      return k(e.tag, {
        class: X(["v-list-subheader", {
          "v-list-subheader--inset": e.inset,
          "v-list-subheader--sticky": e.sticky
        }, a.value, e.class]),
        style: ie([{
          textColorStyles: l
        }, e.style])
      }, {
        default: () => {
          var o, r;
          return [i && w("div", {
            class: "v-list-subheader__text"
          }, [(r = (o = t.default) == null ? void 0 : o.call(t)) != null ? r : e.title])];
        }
      });
    }), {};
  }
}), _g = N({
  items: Array,
  returnObject: Boolean
}, "VListChildren"), Ms = Y()({
  name: "VListChildren",
  props: _g(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return ws(), () => {
      var a, l, i;
      return (i = (a = t.default) == null ? void 0 : a.call(t)) != null ? i : (l = e.items) == null ? void 0 : l.map((o) => {
        var m, h, b, g;
        let {
          children: r,
          props: u,
          type: c,
          raw: s
        } = o;
        if (c === "divider")
          return (h = (m = t.divider) == null ? void 0 : m.call(t, {
            props: u
          })) != null ? h : k(It, u, null);
        if (c === "subheader")
          return (g = (b = t.subheader) == null ? void 0 : b.call(t, {
            props: u
          })) != null ? g : k(aa, u, null);
        const d = {
          subtitle: t.subtitle ? (S) => {
            var y;
            return (y = t.subtitle) == null ? void 0 : y.call(t, le(v({}, S), {
              item: s
            }));
          } : void 0,
          prepend: t.prepend ? (S) => {
            var y;
            return (y = t.prepend) == null ? void 0 : y.call(t, le(v({}, S), {
              item: s
            }));
          } : void 0,
          append: t.append ? (S) => {
            var y;
            return (y = t.append) == null ? void 0 : y.call(t, le(v({}, S), {
              item: s
            }));
          } : void 0,
          title: t.title ? (S) => {
            var y;
            return (y = t.title) == null ? void 0 : y.call(t, le(v({}, S), {
              item: s
            }));
          } : void 0
        }, f = xa.filterProps(u);
        return r ? k(xa, G(f, {
          value: e.returnObject ? s : u == null ? void 0 : u.value,
          rawId: u == null ? void 0 : u.value
        }), {
          activator: (S) => {
            let {
              props: y
            } = S;
            const P = G(u, y, {
              value: e.returnObject ? s : u.value
            });
            return t.header ? t.header({
              props: P
            }) : k(Et, P, d);
          },
          default: () => k(Ms, {
            items: r,
            returnObject: e.returnObject
          }, t)
        }) : t.item ? t.item({
          props: u
        }) : k(Et, G(u, {
          value: e.returnObject ? s : u.value
        }), d);
      });
    };
  }
}), ps = N({
  items: {
    type: Array,
    default: () => []
  },
  itemTitle: {
    type: [String, Array, Function],
    default: "title"
  },
  itemValue: {
    type: [String, Array, Function],
    default: "value"
  },
  itemChildren: {
    type: [Boolean, String, Array, Function],
    default: "children"
  },
  itemProps: {
    type: [Boolean, String, Array, Function],
    default: "props"
  },
  itemType: {
    type: [Boolean, String, Array, Function],
    default: "type"
  },
  returnObject: Boolean,
  valueComparator: Function
}, "list-items"), Ag = /* @__PURE__ */ new Set(["item", "divider", "subheader"]);
function Mt(e, n) {
  var u;
  const t = qe(n, e.itemTitle, n), a = qe(n, e.itemValue, t), l = qe(n, e.itemChildren), i = e.itemProps === !0 ? typeof n == "object" && n != null && !Array.isArray(n) ? "children" in n ? $e(n, ["children"]) : n : void 0 : qe(n, e.itemProps);
  let o = qe(n, e.itemType, "item");
  Ag.has(o) || (o = "item");
  const r = v({
    title: t,
    value: a
  }, i);
  return {
    type: o,
    title: String((u = r.title) != null ? u : ""),
    value: r.value,
    props: r,
    children: o === "item" && Array.isArray(l) ? Es(e, l) : void 0,
    raw: n
  };
}
Mt.neededProps = ["itemTitle", "itemValue", "itemChildren", "itemProps", "itemType"];
function Es(e, n) {
  const t = qt(e, Mt.neededProps), a = [];
  for (const l of n)
    a.push(Mt(t, l));
  return a;
}
function yo(e) {
  const n = C(() => Es(e, e.items)), t = C(() => n.value.some((r) => r.value === null)), a = te(/* @__PURE__ */ new Map()), l = te([]);
  We(() => {
    const r = n.value, u = /* @__PURE__ */ new Map(), c = [];
    for (let s = 0; s < r.length; s++) {
      const d = r[s];
      if (ni(d.value) || d.value === null) {
        let f = u.get(d.value);
        f || (f = [], u.set(d.value, f)), f.push(d);
      } else
        c.push(d);
    }
    a.value = u, l.value = c;
  });
  function i(r) {
    const u = a.value, c = n.value, s = l.value, d = t.value, f = e.returnObject, m = !!e.valueComparator, h = e.valueComparator || at, b = qt(e, Mt.neededProps), g = [];
    e: for (const S of r) {
      if (!d && S === null) continue;
      if (f && typeof S == "string") {
        g.push(Mt(b, S));
        continue;
      }
      const y = u.get(S);
      if (m || !y) {
        for (const P of m ? c : s)
          if (h(S, P.value)) {
            g.push(P);
            continue e;
          }
        g.push(Mt(b, S));
        continue;
      }
      g.push(...y);
    }
    return g;
  }
  function o(r) {
    return e.returnObject ? r.map((u) => {
      let {
        raw: c
      } = u;
      return c;
    }) : r.map((u) => {
      let {
        value: c
      } = u;
      return c;
    });
  }
  return {
    items: n,
    transformIn: i,
    transformOut: o
  };
}
const Lg = /* @__PURE__ */ new Set(["item", "divider", "subheader"]);
function Tg(e, n) {
  const t = ni(n) ? n : qe(n, e.itemTitle), a = ni(n) ? n : qe(n, e.itemValue, void 0), l = qe(n, e.itemChildren), i = e.itemProps === !0 ? $e(n, ["children"]) : qe(n, e.itemProps);
  let o = qe(n, e.itemType, "item");
  Lg.has(o) || (o = "item");
  const r = v({
    title: t,
    value: a
  }, i);
  return {
    type: o,
    title: r.title,
    value: r.value,
    props: r,
    children: o === "item" && l ? $s(e, l) : void 0,
    raw: n
  };
}
function $s(e, n) {
  const t = [];
  for (const a of n)
    t.push(Tg(e, a));
  return t;
}
function Fs(e) {
  return {
    items: C(() => $s(e, e.items))
  };
}
const Os = N(v(v(v(v(v(v(v(v(v(v(v({
  baseColor: String,
  /* @deprecated */
  activeColor: String,
  activeClass: String,
  bgColor: String,
  disabled: Boolean,
  filterable: Boolean,
  expandIcon: me,
  collapseIcon: me,
  lines: {
    type: [Boolean, String],
    default: "one"
  },
  slim: Boolean,
  nav: Boolean,
  "onClick:open": ot(),
  "onClick:select": ot(),
  "onUpdate:opened": ot()
}, wg({
  selectStrategy: "single-leaf",
  openStrategy: "list"
})), kt()), de()), nt()), Ze()), Je()), ps()), Ne()), ke()), Ie()), Dt({
  variant: "text"
})), "VList"), Gn = Y()({
  name: "VList",
  props: Os(),
  emits: {
    "update:selected": (e) => !0,
    "update:activated": (e) => !0,
    "update:opened": (e) => !0,
    "click:open": (e) => !0,
    "click:activate": (e) => !0,
    "click:select": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      items: a
    } = Fs(e), {
      themeClasses: l
    } = De(e), {
      backgroundColorClasses: i,
      backgroundColorStyles: o
    } = pe(() => e.bgColor), {
      borderClasses: r
    } = Ct(e), {
      densityClasses: u
    } = ht(e), {
      dimensionStyles: c
    } = Qe(e), {
      elevationClasses: s
    } = lt(e), {
      roundedClasses: d
    } = Ye(e), {
      children: f,
      open: m,
      parents: h,
      select: b,
      getPath: g
    } = Cg(e), S = M(() => e.lines ? `v-list--${e.lines}-line` : void 0), y = M(() => e.activeColor), P = M(() => e.baseColor), V = M(() => e.color);
    ws({
      filterable: e.filterable
    }), je({
      VListGroup: {
        activeColor: y,
        baseColor: P,
        color: V,
        expandIcon: M(() => e.expandIcon),
        collapseIcon: M(() => e.collapseIcon)
      },
      VListItem: {
        activeClass: M(() => e.activeClass),
        activeColor: y,
        baseColor: P,
        color: V,
        density: M(() => e.density),
        disabled: M(() => e.disabled),
        lines: M(() => e.lines),
        nav: M(() => e.nav),
        slim: M(() => e.slim),
        variant: M(() => e.variant)
      }
    });
    const x = te(!1), I = Q();
    function T(B) {
      x.value = !0;
    }
    function _(B) {
      x.value = !1;
    }
    function p(B) {
      var F;
      !x.value && !(B.relatedTarget && ((F = I.value) != null && F.contains(B.relatedTarget))) && A();
    }
    function L(B) {
      const F = B.target;
      if (!(!I.value || F.tagName === "INPUT" && ["Home", "End"].includes(B.key) || F.tagName === "TEXTAREA")) {
        if (B.key === "ArrowDown")
          A("next");
        else if (B.key === "ArrowUp")
          A("prev");
        else if (B.key === "Home")
          A("first");
        else if (B.key === "End")
          A("last");
        else
          return;
        B.preventDefault();
      }
    }
    function D(B) {
      x.value = !0;
    }
    function A(B) {
      if (I.value)
        return mn(I.value, B);
    }
    return Z(() => k(e.tag, {
      ref: I,
      class: X(["v-list", {
        "v-list--disabled": e.disabled,
        "v-list--nav": e.nav,
        "v-list--slim": e.slim
      }, l.value, i.value, r.value, u.value, s.value, S.value, d.value, e.class]),
      style: ie([o.value, c.value, e.style]),
      tabindex: e.disabled ? -1 : 0,
      role: "listbox",
      "aria-activedescendant": void 0,
      onFocusin: T,
      onFocusout: _,
      onFocus: p,
      onKeydown: L,
      onMousedown: D
    }, {
      default: () => [k(Ms, {
        items: a.value,
        returnObject: e.returnObject
      }, t)]
    })), {
      open: m,
      select: b,
      focus: A,
      children: f,
      parents: h,
      getPath: g
    };
  }
}), Bg = Xt("v-list-img"), Dg = N(v(v({
  start: Boolean,
  end: Boolean
}, de()), ke()), "VListItemAction"), Ns = Y()({
  name: "VListItemAction",
  props: Dg(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(e.tag, {
      class: X(["v-list-item-action", {
        "v-list-item-action--start": e.start,
        "v-list-item-action--end": e.end
      }, e.class]),
      style: ie(e.style)
    }, t)), {};
  }
}), Mg = N(v(v({
  start: Boolean,
  end: Boolean
}, de()), ke()), "VListItemMedia"), pg = Y()({
  name: "VListItemMedia",
  props: Mg(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(e.tag, {
      class: X(["v-list-item-media", {
        "v-list-item-media--start": e.start,
        "v-list-item-media--end": e.end
      }, e.class]),
      style: ie(e.style)
    }, t)), {};
  }
});
function ql(e, n) {
  return {
    x: e.x + n.x,
    y: e.y + n.y
  };
}
function Eg(e, n) {
  return {
    x: e.x - n.x,
    y: e.y - n.y
  };
}
function Or(e, n) {
  if (e.side === "top" || e.side === "bottom") {
    const {
      side: t,
      align: a
    } = e, l = a === "left" ? 0 : a === "center" ? n.width / 2 : a === "right" ? n.width : a, i = t === "top" ? 0 : t === "bottom" ? n.height : t;
    return ql({
      x: l,
      y: i
    }, n);
  } else if (e.side === "left" || e.side === "right") {
    const {
      side: t,
      align: a
    } = e, l = t === "left" ? 0 : t === "right" ? n.width : t, i = a === "top" ? 0 : a === "center" ? n.height / 2 : a === "bottom" ? n.height : a;
    return ql({
      x: l,
      y: i
    }, n);
  }
  return ql({
    x: n.width / 2,
    y: n.height / 2
  }, n);
}
const Rs = {
  static: Og,
  // specific viewport position, usually centered
  connected: Rg
  // connected to a certain element
}, $g = N({
  locationStrategy: {
    type: [String, Function],
    default: "static",
    validator: (e) => typeof e == "function" || e in Rs
  },
  location: {
    type: String,
    default: "bottom"
  },
  origin: {
    type: String,
    default: "auto"
  },
  offset: [Number, String, Array]
}, "VOverlay-location-strategies");
function Fg(e, n) {
  const t = Q({}), a = Q();
  Te && mt(() => !!(n.isActive.value && e.locationStrategy), (r) => {
    var u, c;
    oe(() => e.locationStrategy, r), tt(() => {
      window.removeEventListener("resize", l), visualViewport == null || visualViewport.removeEventListener("resize", i), visualViewport == null || visualViewport.removeEventListener("scroll", o), a.value = void 0;
    }), window.addEventListener("resize", l, {
      passive: !0
    }), visualViewport == null || visualViewport.addEventListener("resize", i, {
      passive: !0
    }), visualViewport == null || visualViewport.addEventListener("scroll", o, {
      passive: !0
    }), typeof e.locationStrategy == "function" ? a.value = (u = e.locationStrategy(n, e, t)) == null ? void 0 : u.updateLocation : a.value = (c = Rs[e.locationStrategy](n, e, t)) == null ? void 0 : c.updateLocation;
  });
  function l(r) {
    var u;
    (u = a.value) == null || u.call(a, r);
  }
  function i(r) {
    var u;
    (u = a.value) == null || u.call(a, r);
  }
  function o(r) {
    var u;
    (u = a.value) == null || u.call(a, r);
  }
  return {
    contentStyles: t,
    updateLocation: a
  };
}
function Og() {
}
function Ng(e, n) {
  const t = Xi(e);
  return n ? t.x += parseFloat(e.style.right || 0) : t.x -= parseFloat(e.style.left || 0), t.y -= parseFloat(e.style.top || 0), t;
}
function Rg(e, n, t) {
  (Array.isArray(e.target.value) || Rv(e.target.value)) && Object.assign(t.value, {
    position: "fixed",
    top: 0,
    [e.isRtl.value ? "right" : "left"]: 0
  });
  const {
    preferredAnchor: l,
    preferredOrigin: i
  } = qi(() => {
    const S = ai(n.location, e.isRtl.value), y = n.origin === "overlap" ? S : n.origin === "auto" ? Hl(S) : ai(n.origin, e.isRtl.value);
    return S.side === y.side && S.align === zl(y).align ? {
      preferredAnchor: ar(S),
      preferredOrigin: ar(y)
    } : {
      preferredAnchor: S,
      preferredOrigin: y
    };
  }), [o, r, u, c] = ["minWidth", "minHeight", "maxWidth", "maxHeight"].map((S) => C(() => {
    const y = parseFloat(n[S]);
    return isNaN(y) ? 1 / 0 : y;
  })), s = C(() => {
    if (Array.isArray(n.offset))
      return n.offset;
    if (typeof n.offset == "string") {
      const S = n.offset.split(" ").map(parseFloat);
      return S.length < 2 && S.push(0), S;
    }
    return typeof n.offset == "number" ? [n.offset, 0] : [0, 0];
  });
  let d = !1, f = -1;
  const m = new su(4), h = new ResizeObserver(() => {
    if (!d) return;
    if (requestAnimationFrame((y) => {
      y !== f && m.clear(), requestAnimationFrame((P) => {
        f = P;
      });
    }), m.isFull) {
      const y = m.values();
      if (at(y.at(-1), y.at(-3)) && !at(y.at(-1), y.at(-2)))
        return;
    }
    const S = g();
    S && m.push(S.flipped);
  });
  let b = new Ot({
    x: 0,
    y: 0,
    width: 0,
    height: 0
  });
  oe(e.target, (S, y) => {
    y && !Array.isArray(y) && h.unobserve(y), Array.isArray(S) ? at(S, y) || g() : S && h.observe(S);
  }, {
    immediate: !0
  }), oe(e.contentEl, (S, y) => {
    y && h.unobserve(y), S && h.observe(S);
  }, {
    immediate: !0
  }), tt(() => {
    h.disconnect();
  });
  function g() {
    if (d = !1, requestAnimationFrame(() => d = !0), !e.target.value || !e.contentEl.value) return;
    (Array.isArray(e.target.value) || e.target.value.offsetParent || e.target.value.getClientRects().length) && (b = mu(e.target.value));
    const S = Ng(e.contentEl.value, e.isRtl.value), y = ll(e.contentEl.value), P = 12;
    y.length || (y.push(document.documentElement), e.contentEl.value.style.top && e.contentEl.value.style.left || (S.x -= parseFloat(document.documentElement.style.getPropertyValue("--v-body-scroll-x") || 0), S.y -= parseFloat(document.documentElement.style.getPropertyValue("--v-body-scroll-y") || 0)));
    const V = y.reduce((B, F) => {
      const $ = rv(F);
      return B ? new Ot({
        x: Math.max(B.left, $.left),
        y: Math.max(B.top, $.top),
        width: Math.min(B.right, $.right) - Math.max(B.left, $.left),
        height: Math.min(B.bottom, $.bottom) - Math.max(B.top, $.top)
      }) : $;
    }, void 0);
    V.x += P, V.y += P, V.width -= P * 2, V.height -= P * 2;
    let x = {
      anchor: l.value,
      origin: i.value
    };
    function I(B) {
      const F = new Ot(S), $ = Or(B.anchor, b), W = Or(B.origin, F);
      let {
        x: J,
        y: z
      } = Eg($, W);
      switch (B.anchor.side) {
        case "top":
          z -= s.value[0];
          break;
        case "bottom":
          z += s.value[0];
          break;
        case "left":
          J -= s.value[0];
          break;
        case "right":
          J += s.value[0];
          break;
      }
      switch (B.anchor.align) {
        case "top":
          z -= s.value[1];
          break;
        case "bottom":
          z += s.value[1];
          break;
        case "left":
          J -= s.value[1];
          break;
        case "right":
          J += s.value[1];
          break;
      }
      return F.x += J, F.y += z, F.width = Math.min(F.width, u.value), F.height = Math.min(F.height, c.value), {
        overflows: ir(F, V),
        x: J,
        y: z
      };
    }
    let T = 0, _ = 0;
    const p = {
      x: 0,
      y: 0
    }, L = {
      x: !1,
      y: !1
    };
    let D = -1;
    for (; ; ) {
      if (D++ > 10) {
        fa("Infinite loop detected in connectedLocationStrategy");
        break;
      }
      const {
        x: B,
        y: F,
        overflows: $
      } = I(x);
      T += B, _ += F, S.x += B, S.y += F;
      {
        const W = lr(x.anchor), J = $.x.before || $.x.after, z = $.y.before || $.y.after;
        let H = !1;
        if (["x", "y"].forEach((E) => {
          if (E === "x" && J && !L.x || E === "y" && z && !L.y) {
            const O = {
              anchor: v({}, x.anchor),
              origin: v({}, x.origin)
            }, R = E === "x" ? W === "y" ? zl : Hl : W === "y" ? Hl : zl;
            O.anchor = R(O.anchor), O.origin = R(O.origin);
            const {
              overflows: q
            } = I(O);
            (q[E].before <= $[E].before && q[E].after <= $[E].after || q[E].before + q[E].after < ($[E].before + $[E].after) / 2) && (x = O, H = L[E] = !0);
          }
        }), H) continue;
      }
      $.x.before && (T += $.x.before, S.x += $.x.before), $.x.after && (T -= $.x.after, S.x -= $.x.after), $.y.before && (_ += $.y.before, S.y += $.y.before), $.y.after && (_ -= $.y.after, S.y -= $.y.after);
      {
        const W = ir(S, V);
        p.x = V.width - W.x.before - W.x.after, p.y = V.height - W.y.before - W.y.after, T += W.x.before, S.x += W.x.before, _ += W.y.before, S.y += W.y.before;
      }
      break;
    }
    const A = lr(x.anchor);
    return Object.assign(t.value, {
      "--v-overlay-anchor-origin": `${x.anchor.side} ${x.anchor.align}`,
      transformOrigin: `${x.origin.side} ${x.origin.align}`,
      // transform: `translate(${pixelRound(x)}px, ${pixelRound(y)}px)`,
      top: ce(Xl(_)),
      left: e.isRtl.value ? void 0 : ce(Xl(T)),
      right: e.isRtl.value ? ce(Xl(-T)) : void 0,
      minWidth: ce(A === "y" ? Math.min(o.value, b.width) : o.value),
      maxWidth: ce(Nr(Fe(p.x, o.value === 1 / 0 ? 0 : o.value, u.value))),
      maxHeight: ce(Nr(Fe(p.y, r.value === 1 / 0 ? 0 : r.value, c.value)))
    }), {
      available: p,
      contentBox: S,
      flipped: L
    };
  }
  return oe(() => [l.value, i.value, n.offset, n.minWidth, n.minHeight, n.maxWidth, n.maxHeight], () => g()), Ve(() => {
    const S = g();
    if (!S) return;
    const {
      available: y,
      contentBox: P
    } = S;
    P.height > y.y && requestAnimationFrame(() => {
      g(), requestAnimationFrame(() => {
        g();
      });
    });
  }), {
    updateLocation: g
  };
}
function Xl(e) {
  return Math.round(e * devicePixelRatio) / devicePixelRatio;
}
function Nr(e) {
  return Math.ceil(e * devicePixelRatio) / devicePixelRatio;
}
let ki = !0;
const ul = [];
function Hg(e) {
  !ki || ul.length ? (ul.push(e), wi()) : (ki = !1, e(), wi());
}
let Rr = -1;
function wi() {
  cancelAnimationFrame(Rr), Rr = requestAnimationFrame(() => {
    const e = ul.shift();
    e && e(), ul.length ? wi() : ki = !0;
  });
}
const Qa = {
  none: null,
  close: jg,
  block: Yg,
  reposition: Gg
}, zg = N({
  scrollStrategy: {
    type: [String, Function],
    default: "block",
    validator: (e) => typeof e == "function" || e in Qa
  }
}, "VOverlay-scroll-strategies");
function Wg(e, n) {
  if (!Te) return;
  let t;
  We(() => He(this, null, function* () {
    t == null || t.stop(), n.isActive.value && e.scrollStrategy && (t = Hn(), yield new Promise((a) => setTimeout(a)), t.active && t.run(() => {
      var a;
      typeof e.scrollStrategy == "function" ? e.scrollStrategy(n, e, t) : (a = Qa[e.scrollStrategy]) == null || a.call(Qa, n, e, t);
    }));
  })), tt(() => {
    t == null || t.stop();
  });
}
function jg(e) {
  function n(t) {
    e.isActive.value = !1;
  }
  Hs(bo(e.target.value, e.contentEl.value), n);
}
function Yg(e, n) {
  var r;
  const t = (r = e.root.value) == null ? void 0 : r.offsetParent, a = bo(e.target.value, e.contentEl.value), l = [.../* @__PURE__ */ new Set([...ll(a, n.contained ? t : void 0), ...ll(e.contentEl.value, n.contained ? t : void 0)])].filter((u) => !u.classList.contains("v-overlay-scroll-blocked")), i = window.innerWidth - document.documentElement.offsetWidth, o = ((u) => to(u) && u)(t || document.documentElement);
  o && e.root.value.classList.add("v-overlay--scroll-blocked"), l.forEach((u, c) => {
    u.style.setProperty("--v-body-scroll-x", ce(-u.scrollLeft)), u.style.setProperty("--v-body-scroll-y", ce(-u.scrollTop)), u !== document.documentElement && u.style.setProperty("--v-scrollbar-offset", ce(i)), u.classList.add("v-overlay-scroll-blocked");
  }), tt(() => {
    l.forEach((u, c) => {
      const s = parseFloat(u.style.getPropertyValue("--v-body-scroll-x")), d = parseFloat(u.style.getPropertyValue("--v-body-scroll-y")), f = u.style.scrollBehavior;
      u.style.scrollBehavior = "auto", u.style.removeProperty("--v-body-scroll-x"), u.style.removeProperty("--v-body-scroll-y"), u.style.removeProperty("--v-scrollbar-offset"), u.classList.remove("v-overlay-scroll-blocked"), u.scrollLeft = -s, u.scrollTop = -d, u.style.scrollBehavior = f;
    }), o && e.root.value.classList.remove("v-overlay--scroll-blocked");
  });
}
function Gg(e, n, t) {
  let a = !1, l = -1, i = -1;
  function o(r) {
    Hg(() => {
      var s, d;
      const u = performance.now();
      (d = (s = e.updateLocation).value) == null || d.call(s, r), a = (performance.now() - u) / (1e3 / 60) > 2;
    });
  }
  i = (typeof requestIdleCallback == "undefined" ? (r) => r() : requestIdleCallback)(() => {
    t.run(() => {
      Hs(bo(e.target.value, e.contentEl.value), (r) => {
        a ? (cancelAnimationFrame(l), l = requestAnimationFrame(() => {
          l = requestAnimationFrame(() => {
            o(r);
          });
        })) : o(r);
      });
    });
  }), tt(() => {
    typeof cancelIdleCallback != "undefined" && cancelIdleCallback(i), cancelAnimationFrame(l);
  });
}
function bo(e, n) {
  return Array.isArray(e) ? document.elementsFromPoint(...e).find((t) => !(n != null && n.contains(t))) : e != null ? e : n;
}
function Hs(e, n) {
  const t = [document, ...ll(e)];
  t.forEach((a) => {
    a.addEventListener("scroll", n, {
      passive: !0
    });
  }), tt(() => {
    t.forEach((a) => {
      a.removeEventListener("scroll", n);
    });
  });
}
const Ci = Symbol.for("vuetify:v-menu"), So = N({
  closeDelay: [Number, String],
  openDelay: [Number, String]
}, "delay");
function ko(e, n) {
  let t = () => {
  };
  function a(o) {
    t == null || t();
    const r = Number(o ? e.openDelay : e.closeDelay);
    return new Promise((u) => {
      t = tv(r, () => {
        n == null || n(o), u(o);
      });
    });
  }
  function l() {
    return a(!0);
  }
  function i() {
    return a(!1);
  }
  return {
    clearDelay: t,
    runOpenDelay: l,
    runCloseDelay: i
  };
}
const Ug = N(v({
  target: [String, Object],
  activator: [String, Object],
  activatorProps: {
    type: Object,
    default: () => ({})
  },
  openOnClick: {
    type: Boolean,
    default: void 0
  },
  openOnHover: Boolean,
  openOnFocus: {
    type: Boolean,
    default: void 0
  },
  closeOnContentClick: Boolean
}, So()), "VOverlay-activator");
function Kg(e, n) {
  let {
    isActive: t,
    isTop: a,
    contentEl: l
  } = n;
  const i = Ke("useActivator"), o = Q();
  let r = !1, u = !1, c = !0;
  const s = C(() => e.openOnFocus || e.openOnFocus == null && e.openOnHover), d = C(() => e.openOnClick || e.openOnClick == null && !e.openOnHover && !s.value), {
    runOpenDelay: f,
    runCloseDelay: m
  } = ko(e, (_) => {
    _ === (e.openOnHover && r || s.value && u) && !(e.openOnHover && t.value && !a.value) && (t.value !== _ && (c = !0), t.value = _);
  }), h = Q(), b = {
    onClick: (_) => {
      _.stopPropagation(), o.value = _.currentTarget || _.target, t.value || (h.value = [_.clientX, _.clientY]), t.value = !t.value;
    },
    onMouseenter: (_) => {
      var p;
      (p = _.sourceCapabilities) != null && p.firesTouchEvents || (r = !0, o.value = _.currentTarget || _.target, f());
    },
    onMouseleave: (_) => {
      r = !1, m();
    },
    onFocus: (_) => {
      zn(_.target, ":focus-visible") !== !1 && (u = !0, _.stopPropagation(), o.value = _.currentTarget || _.target, f());
    },
    onBlur: (_) => {
      u = !1, _.stopPropagation(), m();
    }
  }, g = C(() => {
    const _ = {};
    return d.value && (_.onClick = b.onClick), e.openOnHover && (_.onMouseenter = b.onMouseenter, _.onMouseleave = b.onMouseleave), s.value && (_.onFocus = b.onFocus, _.onBlur = b.onBlur), _;
  }), S = C(() => {
    const _ = {};
    if (e.openOnHover && (_.onMouseenter = () => {
      r = !0, f();
    }, _.onMouseleave = () => {
      r = !1, m();
    }), s.value && (_.onFocusin = () => {
      u = !0, f();
    }, _.onFocusout = () => {
      u = !1, m();
    }), e.closeOnContentClick) {
      const p = Pe(Ci, null);
      _.onClick = () => {
        t.value = !1, p == null || p.closeParents();
      };
    }
    return _;
  }), y = C(() => {
    const _ = {};
    return e.openOnHover && (_.onMouseenter = () => {
      c && (r = !0, c = !1, f());
    }, _.onMouseleave = () => {
      r = !1, m();
    }), _;
  });
  oe(a, (_) => {
    var p;
    _ && (e.openOnHover && !r && (!s.value || !u) || s.value && !u && (!e.openOnHover || !r)) && !((p = l.value) != null && p.contains(document.activeElement)) && (t.value = !1);
  }), oe(t, (_) => {
    _ || setTimeout(() => {
      h.value = void 0;
    });
  }, {
    flush: "post"
  });
  const P = tl();
  We(() => {
    P.value && Ve(() => {
      o.value = P.el;
    });
  });
  const V = tl(), x = C(() => e.target === "cursor" && h.value ? h.value : V.value ? V.el : zs(e.target, i) || o.value), I = C(() => Array.isArray(x.value) ? void 0 : x.value);
  let T;
  return oe(() => !!e.activator, (_) => {
    _ && Te ? (T = Hn(), T.run(() => {
      qg(e, i, {
        activatorEl: o,
        activatorEvents: g
      });
    })) : T && T.stop();
  }, {
    flush: "post",
    immediate: !0
  }), tt(() => {
    T == null || T.stop();
  }), {
    activatorEl: o,
    activatorRef: P,
    target: x,
    targetEl: I,
    targetRef: V,
    activatorEvents: g,
    contentEvents: S,
    scrimEvents: y
  };
}
function qg(e, n, t) {
  let {
    activatorEl: a,
    activatorEvents: l
  } = t;
  oe(() => e.activator, (u, c) => {
    if (c && u !== c) {
      const s = r(c);
      s && o(s);
    }
    u && Ve(() => i());
  }, {
    immediate: !0
  }), oe(() => e.activatorProps, () => {
    i();
  }), tt(() => {
    o();
  });
  function i() {
    let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : r(), c = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e.activatorProps;
    u && uv(u, G(l.value, c));
  }
  function o() {
    let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : r(), c = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e.activatorProps;
    u && sv(u, G(l.value, c));
  }
  function r() {
    let u = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : e.activator;
    const c = zs(u, n);
    return a.value = (c == null ? void 0 : c.nodeType) === Node.ELEMENT_NODE ? c : void 0, a.value;
  }
}
function zs(e, n) {
  var a, l;
  if (!e) return;
  let t;
  if (e === "parent") {
    let i = (l = (a = n == null ? void 0 : n.proxy) == null ? void 0 : a.$el) == null ? void 0 : l.parentNode;
    for (; i != null && i.hasAttribute("data-no-activator"); )
      i = i.parentNode;
    t = i;
  } else typeof e == "string" ? t = document.querySelector(e) : "$el" in e ? t = e.$el : t = e;
  return t;
}
function Ws() {
  if (!Te) return te(!1);
  const {
    ssr: e
  } = At();
  if (e) {
    const n = te(!1);
    return gt(() => {
      n.value = !0;
    }), n;
  } else
    return te(!0);
}
const wo = N({
  eager: Boolean
}, "lazy");
function Co(e, n) {
  const t = te(!1), a = M(() => t.value || e.eager || n.value);
  oe(n, () => t.value = !0);
  function l() {
    e.eager || (t.value = !1);
  }
  return {
    isBooted: t,
    hasContent: a,
    onAfterLeave: l
  };
}
function pn() {
  const n = Ke("useScopeId").vnode.scopeId;
  return {
    scopeId: n ? {
      [n]: ""
    } : void 0
  };
}
const Hr = Symbol.for("vuetify:stack"), ca = yt([]);
function Xg(e, n, t) {
  const a = Ke("useStack"), l = !t, i = Pe(Hr, void 0), o = yt({
    activeChildren: /* @__PURE__ */ new Set()
  });
  Oe(Hr, o);
  const r = te(Number(st(n)));
  mt(e, () => {
    var d;
    const s = (d = ca.at(-1)) == null ? void 0 : d[1];
    r.value = s ? s + 10 : Number(st(n)), l && ca.push([a.uid, r.value]), i == null || i.activeChildren.add(a.uid), tt(() => {
      if (l) {
        const f = Ue(ca).findIndex((m) => m[0] === a.uid);
        ca.splice(f, 1);
      }
      i == null || i.activeChildren.delete(a.uid);
    });
  });
  const u = te(!0);
  l && We(() => {
    var d;
    const s = ((d = ca.at(-1)) == null ? void 0 : d[0]) === a.uid;
    setTimeout(() => u.value = s);
  });
  const c = M(() => !o.activeChildren.size);
  return {
    globalTop: vl(u),
    localTop: c,
    stackStyles: M(() => ({
      zIndex: r.value
    }))
  };
}
function Zg(e) {
  return {
    teleportTarget: C(() => {
      const t = e();
      if (t === !0 || !Te) return;
      const a = t === !1 ? document.body : typeof t == "string" ? document.querySelector(t) : t;
      if (a == null) {
        dl(`Unable to locate target ${t}`);
        return;
      }
      let l = [...a.children].find((i) => i.matches(".v-overlay-container"));
      return l || (l = document.createElement("div"), l.className = "v-overlay-container", a.appendChild(l)), l;
    })
  };
}
function Qg() {
  return !0;
}
function js(e, n, t) {
  if (!e || Ys(e, t) === !1) return !1;
  const a = Iu(n);
  if (typeof ShadowRoot != "undefined" && a instanceof ShadowRoot && a.host === e.target) return !1;
  const l = (typeof t.value == "object" && t.value.include || (() => []))();
  return l.push(n), !l.some((i) => i == null ? void 0 : i.contains(e.target));
}
function Ys(e, n) {
  return (typeof n.value == "object" && n.value.closeConditional || Qg)(e);
}
function Jg(e, n, t) {
  const a = typeof t.value == "function" ? t.value : t.value.handler;
  e.shadowTarget = e.target, n._clickOutside.lastMousedownWasOutside && js(e, n, t) && setTimeout(() => {
    Ys(e, t) && a && a(e);
  }, 0);
}
function zr(e, n) {
  const t = Iu(e);
  n(document), typeof ShadowRoot != "undefined" && t instanceof ShadowRoot && n(t);
}
const Wr = {
  // [data-app] may not be found
  // if using bind, inserted makes
  // sure that the root element is
  // available, iOS does not support
  // clicks on body
  mounted(e, n) {
    const t = (l) => Jg(l, e, n), a = (l) => {
      e._clickOutside.lastMousedownWasOutside = js(l, e, n);
    };
    zr(e, (l) => {
      l.addEventListener("click", t, !0), l.addEventListener("mousedown", a, !0);
    }), e._clickOutside || (e._clickOutside = {
      lastMousedownWasOutside: !1
    }), e._clickOutside[n.instance.$.uid] = {
      onClick: t,
      onMousedown: a
    };
  },
  beforeUnmount(e, n) {
    e._clickOutside && (zr(e, (t) => {
      var i;
      if (!t || !((i = e._clickOutside) != null && i[n.instance.$.uid])) return;
      const {
        onClick: a,
        onMousedown: l
      } = e._clickOutside[n.instance.$.uid];
      t.removeEventListener("click", a, !0), t.removeEventListener("mousedown", l, !0);
    }), delete e._clickOutside[n.instance.$.uid]);
  }
};
function eh(e) {
  const l = e, {
    modelValue: n,
    color: t
  } = l, a = Ge(l, [
    "modelValue",
    "color"
  ]);
  return k(en, {
    name: "fade-transition",
    appear: !0
  }, {
    default: () => [e.modelValue && w("div", G({
      class: ["v-overlay__scrim", e.color.backgroundColorClasses.value],
      style: e.color.backgroundColorStyles.value
    }, a), null)]
  });
}
const Fa = N(v(v(v(v(v(v(v(v({
  absolute: Boolean,
  attach: [Boolean, String, Object],
  closeOnBack: {
    type: Boolean,
    default: !0
  },
  contained: Boolean,
  contentClass: null,
  contentProps: null,
  disabled: Boolean,
  opacity: [Number, String],
  noClickAnimation: Boolean,
  modelValue: Boolean,
  persistent: Boolean,
  scrim: {
    type: [Boolean, String],
    default: !0
  },
  zIndex: {
    type: [Number, String],
    default: 2e3
  }
}, Ug()), de()), Ze()), wo()), $g()), zg()), Ie()), Ft()), "VOverlay"), Wt = Y()({
  name: "VOverlay",
  directives: {
    vClickOutside: Wr
  },
  inheritAttrs: !1,
  props: v({
    _disableGlobalStack: Boolean
  }, Fa()),
  emits: {
    "click:outside": (e) => !0,
    "update:modelValue": (e) => !0,
    keydown: (e) => !0,
    afterEnter: () => !0,
    afterLeave: () => !0
  },
  setup(e, n) {
    let {
      slots: t,
      attrs: a,
      emit: l
    } = n;
    const i = Ke("VOverlay"), o = Q(), r = Q(), u = Q(), c = ve(e, "modelValue"), s = C({
      get: () => c.value,
      set: (j) => {
        j && e.disabled || (c.value = j);
      }
    }), {
      themeClasses: d
    } = De(e), {
      rtlClasses: f,
      isRtl: m
    } = Xe(), {
      hasContent: h,
      onAfterLeave: b
    } = Co(e, s), g = pe(() => typeof e.scrim == "string" ? e.scrim : null), {
      globalTop: S,
      localTop: y,
      stackStyles: P
    } = Xg(s, () => e.zIndex, e._disableGlobalStack), {
      activatorEl: V,
      activatorRef: x,
      target: I,
      targetEl: T,
      targetRef: _,
      activatorEvents: p,
      contentEvents: L,
      scrimEvents: D
    } = Kg(e, {
      isActive: s,
      isTop: y,
      contentEl: u
    }), {
      teleportTarget: A
    } = Zg(() => {
      var ge, ee, re;
      const j = e.attach || e.contained;
      if (j) return j;
      const ue = ((ge = V == null ? void 0 : V.value) == null ? void 0 : ge.getRootNode()) || ((re = (ee = i.proxy) == null ? void 0 : ee.$el) == null ? void 0 : re.getRootNode());
      return ue instanceof ShadowRoot ? ue : !1;
    }), {
      dimensionStyles: B
    } = Qe(e), F = Ws(), {
      scopeId: $
    } = pn();
    oe(() => e.disabled, (j) => {
      j && (s.value = !1);
    });
    const {
      contentStyles: W,
      updateLocation: J
    } = Fg(e, {
      isRtl: m,
      contentEl: u,
      target: I,
      isActive: s
    });
    Wg(e, {
      root: o,
      contentEl: u,
      targetEl: T,
      target: I,
      isActive: s,
      updateLocation: J
    });
    function z(j) {
      l("click:outside", j), e.persistent ? ae() : s.value = !1;
    }
    function H(j) {
      return s.value && S.value && // If using scrim, only close if clicking on it rather than anything opened on top
      (!e.scrim || j.target === r.value || j instanceof MouseEvent && j.shadowTarget === r.value);
    }
    Te && oe(s, (j) => {
      j ? window.addEventListener("keydown", E) : window.removeEventListener("keydown", E);
    }, {
      immediate: !0
    }), dt(() => {
      Te && window.removeEventListener("keydown", E);
    });
    function E(j) {
      var ue, ge, ee;
      j.key === "Escape" && S.value && ((ue = u.value) != null && ue.contains(document.activeElement) || l("keydown", j), e.persistent ? ae() : (s.value = !1, (ge = u.value) != null && ge.contains(document.activeElement) && ((ee = V.value) == null || ee.focus())));
    }
    function O(j) {
      j.key === "Escape" && !S.value || l("keydown", j);
    }
    const R = es();
    mt(() => e.closeOnBack, () => {
      Em(R, (j) => {
        S.value && s.value ? (j(!1), e.persistent ? ae() : s.value = !1) : j();
      });
    });
    const q = Q();
    oe(() => s.value && (e.absolute || e.contained) && A.value == null, (j) => {
      if (j) {
        const ue = eo(o.value);
        ue && ue !== document.scrollingElement && (q.value = ue.scrollTop);
      }
    });
    function ae() {
      e.noClickAnimation || u.value && dn(u.value, [{
        transformOrigin: "center"
      }, {
        transform: "scale(1.03)"
      }, {
        transformOrigin: "center"
      }], {
        duration: 150,
        easing: ma
      });
    }
    function U() {
      l("afterEnter");
    }
    function ne() {
      b(), l("afterLeave");
    }
    return Z(() => {
      var j;
      return w(he, null, [(j = t.activator) == null ? void 0 : j.call(t, {
        isActive: s.value,
        targetRef: _,
        props: G({
          ref: x
        }, p.value, e.activatorProps)
      }), F.value && h.value && k(Rd, {
        disabled: !A.value,
        to: A.value
      }, {
        default: () => [w("div", G({
          class: ["v-overlay", {
            "v-overlay--absolute": e.absolute || e.contained,
            "v-overlay--active": s.value,
            "v-overlay--contained": e.contained
          }, d.value, f.value, e.class],
          style: [P.value, {
            "--v-overlay-opacity": e.opacity,
            top: ce(q.value)
          }, e.style],
          ref: o,
          onKeydown: O
        }, $, a), [k(eh, G({
          color: g,
          modelValue: s.value && !!e.scrim,
          ref: r
        }, D.value), null), k(ft, {
          appear: !0,
          persisted: !0,
          transition: e.transition,
          target: I.value,
          onAfterEnter: U,
          onAfterLeave: ne
        }, {
          default: () => {
            var ue;
            return [Re(w("div", G({
              ref: u,
              class: ["v-overlay__content", e.contentClass],
              style: [B.value, W.value]
            }, L.value, e.contentProps), [(ue = t.default) == null ? void 0 : ue.call(t, {
              isActive: s
            })]), [[$t, s.value], [Wr, {
              handler: z,
              closeConditional: H,
              include: () => [V.value]
            }]])];
          }
        })])]
      })]);
    }), {
      activatorEl: V,
      scrimEl: r,
      target: I,
      animateClick: ae,
      contentEl: u,
      globalTop: S,
      localTop: y,
      updateLocation: J
    };
  }
}), Gs = N(v({
  // TODO
  // disableKeys: Boolean,
  id: String,
  submenu: Boolean,
  disableInitialFocus: Boolean
}, $e(Fa({
  closeDelay: 250,
  closeOnContentClick: !0,
  locationStrategy: "connected",
  location: void 0,
  openDelay: 300,
  scrim: !1,
  scrollStrategy: "reposition",
  transition: {
    component: Sl
  }
}), ["absolute"])), "VMenu"), Un = Y()({
  name: "VMenu",
  props: Gs(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), {
      scopeId: l
    } = pn(), {
      isRtl: i
    } = Xe(), o = St(), r = M(() => e.id || `v-menu-${o}`), u = Q(), c = Pe(Ci, null), s = te(/* @__PURE__ */ new Set());
    Oe(Ci, {
      register() {
        s.value.add(o);
      },
      unregister() {
        s.value.delete(o);
      },
      closeParents(g) {
        setTimeout(() => {
          var S;
          !s.value.size && !e.persistent && (g == null || (S = u.value) != null && S.contentEl && !nv(g, u.value.contentEl)) && (a.value = !1, c == null || c.closeParents());
        }, 40);
      }
    }), dt(() => {
      c == null || c.unregister(), document.removeEventListener("focusin", d);
    }), nu(() => a.value = !1);
    function d(g) {
      return He(this, null, function* () {
        var P, V, x;
        const S = g.relatedTarget, y = g.target;
        yield Ve(), a.value && S !== y && ((P = u.value) != null && P.contentEl) && // We're the topmost menu
        ((V = u.value) != null && V.globalTop) && // It isn't the document or the menu body
        ![document, u.value.contentEl].includes(y) && // It isn't inside the menu body
        !u.value.contentEl.contains(y) && ((x = va(u.value.contentEl)[0]) == null || x.focus());
      });
    }
    oe(a, (g) => {
      g ? (c == null || c.register(), Te && !e.disableInitialFocus && document.addEventListener("focusin", d, {
        once: !0
      })) : (c == null || c.unregister(), Te && document.removeEventListener("focusin", d));
    }, {
      immediate: !0
    });
    function f(g) {
      c == null || c.closeParents(g);
    }
    function m(g) {
      var S, y, P, V, x;
      if (!e.disabled)
        if (g.key === "Tab" || g.key === "Enter" && !e.closeOnContentClick) {
          if (g.key === "Enter" && (g.target instanceof HTMLTextAreaElement || g.target instanceof HTMLInputElement && g.target.closest("form"))) return;
          g.key === "Enter" && g.preventDefault(), du(va((S = u.value) == null ? void 0 : S.contentEl, !1), g.shiftKey ? "prev" : "next", (T) => T.tabIndex >= 0) || (a.value = !1, (P = (y = u.value) == null ? void 0 : y.activatorEl) == null || P.focus());
        } else e.submenu && g.key === (i.value ? "ArrowRight" : "ArrowLeft") && (a.value = !1, (x = (V = u.value) == null ? void 0 : V.activatorEl) == null || x.focus());
    }
    function h(g) {
      var y;
      if (e.disabled) return;
      const S = (y = u.value) == null ? void 0 : y.contentEl;
      S && a.value ? g.key === "ArrowDown" ? (g.preventDefault(), g.stopImmediatePropagation(), mn(S, "next")) : g.key === "ArrowUp" ? (g.preventDefault(), g.stopImmediatePropagation(), mn(S, "prev")) : e.submenu && (g.key === (i.value ? "ArrowRight" : "ArrowLeft") ? a.value = !1 : g.key === (i.value ? "ArrowLeft" : "ArrowRight") && (g.preventDefault(), mn(S, "first"))) : (e.submenu ? g.key === (i.value ? "ArrowLeft" : "ArrowRight") : ["ArrowDown", "ArrowUp"].includes(g.key)) && (a.value = !0, g.preventDefault(), setTimeout(() => setTimeout(() => h(g))));
    }
    const b = C(() => G({
      "aria-haspopup": "menu",
      "aria-expanded": String(a.value),
      "aria-controls": r.value,
      onKeydown: h
    }, e.activatorProps));
    return Z(() => {
      var S;
      const g = Wt.filterProps(e);
      return k(Wt, G({
        ref: u,
        id: r.value,
        class: ["v-menu", e.class],
        style: e.style
      }, g, {
        modelValue: a.value,
        "onUpdate:modelValue": (y) => a.value = y,
        absolute: !0,
        activatorProps: b.value,
        location: (S = e.location) != null ? S : e.submenu ? "end" : "bottom",
        "onClick:outside": f,
        onKeydown: m
      }, l), {
        activator: t.activator,
        default: function() {
          for (var y = arguments.length, P = new Array(y), V = 0; V < y; V++)
            P[V] = arguments[V];
          return k(Ce, {
            root: "VMenu"
          }, {
            default: () => {
              var x;
              return [(x = t.default) == null ? void 0 : x.call(t, ...P)];
            }
          });
        }
      });
    }), it({
      id: r,
      ΨopenChildren: s
    }, u);
  }
}), th = N(v(v({
  active: Boolean,
  disabled: Boolean,
  max: [Number, String],
  value: {
    type: [Number, String],
    default: 0
  }
}, de()), Ft({
  transition: {
    component: uo
  }
})), "VCounter"), Pl = Y()({
  name: "VCounter",
  functional: !0,
  props: th(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = M(() => e.max ? `${e.value} / ${e.max}` : String(e.value));
    return Z(() => k(ft, {
      transition: e.transition
    }, {
      default: () => [Re(w("div", {
        class: X(["v-counter", {
          "text-error": e.max && !e.disabled && parseFloat(e.value) > parseFloat(e.max)
        }, e.class]),
        style: ie(e.style)
      }, [t.default ? t.default({
        counter: a.value,
        max: e.max,
        value: e.value
      }) : a.value]), [[$t, e.active]])]
    })), {};
  }
}), nh = N(v({
  floating: Boolean
}, de()), "VFieldLabel"), da = Y()({
  name: "VFieldLabel",
  props: nh(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(ta, {
      class: X(["v-field-label", {
        "v-field-label--floating": e.floating
      }, e.class]),
      style: ie(e.style)
    }, t)), {};
  }
}), ah = ["underlined", "outlined", "filled", "solo", "solo-inverted", "solo-filled", "plain"], Oa = N(v(v(v(v({
  appendInnerIcon: me,
  bgColor: String,
  clearable: Boolean,
  clearIcon: {
    type: me,
    default: "$clear"
  },
  active: Boolean,
  centerAffix: {
    type: Boolean,
    default: void 0
  },
  color: String,
  baseColor: String,
  details: Boolean,
  dirty: Boolean,
  disabled: {
    type: Boolean,
    default: null
  },
  glow: Boolean,
  error: Boolean,
  flat: Boolean,
  iconColor: [Boolean, String],
  label: String,
  persistentClear: Boolean,
  prependInnerIcon: me,
  reverse: Boolean,
  singleLine: Boolean,
  variant: {
    type: String,
    default: "filled",
    validator: (e) => ah.includes(e)
  },
  "onClick:clear": ot(),
  "onClick:appendInner": ot(),
  "onClick:prependInner": ot()
}, de()), Cl()), Ne()), Ie()), "VField"), nn = Y()({
  name: "VField",
  inheritAttrs: !1,
  props: v(v({
    id: String
  }, Ea()), Oa()),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const {
      themeClasses: i
    } = De(e), {
      loaderClasses: o
    } = Ba(e), {
      focusClasses: r,
      isFocused: u,
      focus: c,
      blur: s
    } = Qt(e), {
      InputIcon: d
    } = vs(e), {
      roundedClasses: f
    } = Ye(e), {
      rtlClasses: m
    } = Xe(), h = M(() => e.dirty || e.active), b = M(() => !!(e.label || l.label)), g = M(() => !e.singleLine && b.value), S = St(), y = C(() => e.id || `input-${S}`), P = M(() => e.details ? `${y.value}-messages` : void 0), V = Q(), x = Q(), I = Q(), T = C(() => ["plain", "underlined"].includes(e.variant)), _ = C(() => e.error || e.disabled ? void 0 : h.value && u.value ? e.color : e.baseColor), p = C(() => {
      if (!(!e.iconColor || e.glow && !u.value))
        return e.iconColor === !0 ? _.value : e.iconColor;
    }), {
      backgroundColorClasses: L,
      backgroundColorStyles: D
    } = pe(() => e.bgColor), {
      textColorClasses: A,
      textColorStyles: B
    } = rt(_);
    oe(h, (W) => {
      if (g.value) {
        const J = V.value.$el, z = x.value.$el;
        requestAnimationFrame(() => {
          const H = Xi(J), E = z.getBoundingClientRect(), O = E.x - H.x, R = E.y - H.y - (H.height / 2 - E.height / 2), q = E.width / 0.75, ae = Math.abs(q - H.width) > 1 ? {
            maxWidth: ce(q)
          } : void 0, U = getComputedStyle(J), ne = getComputedStyle(z), j = parseFloat(U.transitionDuration) * 1e3 || 150, ue = parseFloat(ne.getPropertyValue("--v-field-label-scale")), ge = ne.getPropertyValue("color");
          J.style.visibility = "visible", z.style.visibility = "hidden", dn(J, v({
            transform: `translate(${O}px, ${R}px) scale(${ue})`,
            color: ge
          }, ae), {
            duration: j,
            easing: ma,
            direction: W ? "normal" : "reverse"
          }).finished.then(() => {
            J.style.removeProperty("visibility"), z.style.removeProperty("visibility");
          });
        });
      }
    }, {
      flush: "post"
    });
    const F = C(() => ({
      isActive: h,
      isFocused: u,
      controlRef: I,
      blur: s,
      focus: c
    }));
    function $(W) {
      W.target !== document.activeElement && W.preventDefault();
    }
    return Z(() => {
      var O, R, q, ae, U;
      const W = e.variant === "outlined", J = !!(l["prepend-inner"] || e.prependInnerIcon), z = !!(e.clearable || l.clear) && !e.disabled, H = !!(l["append-inner"] || e.appendInnerIcon || z), E = () => l.label ? l.label(le(v({}, F.value), {
        label: e.label,
        props: {
          for: y.value
        }
      })) : e.label;
      return w("div", G({
        class: ["v-field", {
          "v-field--active": h.value,
          "v-field--appended": H,
          "v-field--center-affix": (O = e.centerAffix) != null ? O : !T.value,
          "v-field--disabled": e.disabled,
          "v-field--dirty": e.dirty,
          "v-field--error": e.error,
          "v-field--glow": e.glow,
          "v-field--flat": e.flat,
          "v-field--has-background": !!e.bgColor,
          "v-field--persistent-clear": e.persistentClear,
          "v-field--prepended": J,
          "v-field--reverse": e.reverse,
          "v-field--single-line": e.singleLine,
          "v-field--no-label": !E(),
          [`v-field--variant-${e.variant}`]: !0
        }, i.value, L.value, r.value, o.value, f.value, m.value, e.class],
        style: [D.value, e.style],
        onClick: $
      }, t), [w("div", {
        class: "v-field__overlay"
      }, null), k(Da, {
        name: "v-field",
        active: !!e.loading,
        color: e.error ? "error" : typeof e.loading == "string" ? e.loading : e.color
      }, {
        default: l.loader
      }), J && w("div", {
        key: "prepend",
        class: "v-field__prepend-inner"
      }, [e.prependInnerIcon && k(d, {
        key: "prepend-icon",
        name: "prependInner",
        color: p.value
      }, null), (R = l["prepend-inner"]) == null ? void 0 : R.call(l, F.value)]), w("div", {
        class: "v-field__field",
        "data-no-activator": ""
      }, [["filled", "solo", "solo-inverted", "solo-filled"].includes(e.variant) && g.value && k(da, {
        key: "floating-label",
        ref: x,
        class: X([A.value]),
        floating: !0,
        for: y.value,
        "aria-hidden": !h.value,
        style: ie(B.value)
      }, {
        default: () => [E()]
      }), b.value && k(da, {
        key: "label",
        ref: V,
        for: y.value
      }, {
        default: () => [E()]
      }), (ae = (q = l.default) == null ? void 0 : q.call(l, le(v({}, F.value), {
        props: {
          id: y.value,
          class: "v-field__input",
          "aria-describedby": P.value
        },
        focus: c,
        blur: s
      }))) != null ? ae : w("div", {
        id: y.value,
        class: "v-field__input",
        "aria-describedby": P.value
      }, null)]), z && k(so, {
        key: "clear"
      }, {
        default: () => [Re(w("div", {
          class: "v-field__clearable",
          onMousedown: (ne) => {
            ne.preventDefault(), ne.stopPropagation();
          }
        }, [k(Ce, {
          defaults: {
            VIcon: {
              icon: e.clearIcon
            }
          }
        }, {
          default: () => [l.clear ? l.clear(le(v({}, F.value), {
            props: {
              onFocus: c,
              onBlur: s,
              onClick: e["onClick:clear"],
              tabindex: -1
            }
          })) : k(d, {
            name: "clear",
            onFocus: c,
            onBlur: s,
            tabindex: -1
          }, null)]
        })]), [[$t, e.dirty]])]
      }), H && w("div", {
        key: "append",
        class: "v-field__append-inner"
      }, [(U = l["append-inner"]) == null ? void 0 : U.call(l, F.value), e.appendInnerIcon && k(d, {
        key: "append-icon",
        name: "appendInner",
        color: p.value
      }, null)]), w("div", {
        class: X(["v-field__outline", A.value]),
        style: ie(B.value)
      }, [W && w(he, null, [w("div", {
        class: "v-field__outline__start"
      }, null), g.value && w("div", {
        class: "v-field__outline__notch"
      }, [k(da, {
        ref: x,
        floating: !0,
        for: y.value,
        "aria-hidden": !h.value
      }, {
        default: () => [E()]
      })]), w("div", {
        class: "v-field__outline__end"
      }, null)]), T.value && g.value && k(da, {
        ref: x,
        floating: !0,
        for: y.value,
        "aria-hidden": !h.value
      }, {
        default: () => [E()]
      })])]);
    }), {
      controlRef: I,
      fieldIconColor: p
    };
  }
});
function Us(e) {
  function n(t, a) {
    var l, i;
    !e.autofocus || !t || (i = (l = a[0].target) == null ? void 0 : l.focus) == null || i.call(l);
  }
  return {
    onIntersect: n
  };
}
const lh = ["color", "file", "time", "date", "datetime-local", "week", "month"], Na = N(v(v({
  autofocus: Boolean,
  counter: [Boolean, Number, String],
  counterValue: [Number, Function],
  prefix: String,
  placeholder: String,
  persistentPlaceholder: Boolean,
  persistentCounter: Boolean,
  suffix: String,
  role: String,
  type: {
    type: String,
    default: "text"
  },
  modelModifiers: Object
}, Jt()), Oa()), "VTextField"), Kt = Y()({
  name: "VTextField",
  directives: {
    vIntersect: Ht
  },
  inheritAttrs: !1,
  props: Na(),
  emits: {
    "click:control": (e) => !0,
    "mousedown:control": (e) => !0,
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const i = ve(e, "modelValue"), {
      isFocused: o,
      focus: r,
      blur: u
    } = Qt(e), {
      onIntersect: c
    } = Us(e), s = C(() => {
      var I;
      return typeof e.counterValue == "function" ? e.counterValue(i.value) : typeof e.counterValue == "number" ? e.counterValue : ((I = i.value) != null ? I : "").toString().length;
    }), d = C(() => {
      if (t.maxlength) return t.maxlength;
      if (!(!e.counter || typeof e.counter != "number" && typeof e.counter != "string"))
        return e.counter;
    }), f = C(() => ["plain", "underlined"].includes(e.variant)), m = Q(), h = Q(), b = Q(), g = C(() => lh.includes(e.type) || e.persistentPlaceholder || o.value || e.active);
    function S() {
      o.value || r(), Ve(() => {
        var I;
        b.value !== document.activeElement && ((I = b.value) == null || I.focus());
      });
    }
    function y(I) {
      a("mousedown:control", I), I.target !== b.value && (S(), I.preventDefault());
    }
    function P(I) {
      a("click:control", I);
    }
    function V(I, T) {
      I.stopPropagation(), S(), Ve(() => {
        i.value = null, T(), fl(e["onClick:clear"], I);
      });
    }
    function x(I) {
      var _;
      const T = I.target;
      if (i.value = T.value, (_ = e.modelModifiers) != null && _.trim && ["text", "search", "password", "tel", "url"].includes(e.type)) {
        const p = [T.selectionStart, T.selectionEnd];
        Ve(() => {
          T.selectionStart = p[0], T.selectionEnd = p[1];
        });
      }
    }
    return Z(() => {
      const I = !!(l.counter || e.counter !== !1 && e.counter != null), T = !!(I || l.details), [_, p] = an(t), B = ct.filterProps(e), {
        modelValue: L
      } = B, D = Ge(B, [
        "modelValue"
      ]), A = nn.filterProps(e);
      return k(ct, G({
        ref: m,
        modelValue: i.value,
        "onUpdate:modelValue": (F) => i.value = F,
        class: ["v-text-field", {
          "v-text-field--prefixed": e.prefix,
          "v-text-field--suffixed": e.suffix,
          "v-input--plain-underlined": f.value
        }, e.class],
        style: e.style
      }, _, D, {
        centerAffix: !f.value,
        focused: o.value
      }), le(v({}, l), {
        default: (F) => {
          let {
            id: $,
            isDisabled: W,
            isDirty: J,
            isReadonly: z,
            isValid: H,
            hasDetails: E,
            reset: O
          } = F;
          return k(nn, G({
            ref: h,
            onMousedown: y,
            onClick: P,
            "onClick:clear": (R) => V(R, O),
            "onClick:prependInner": e["onClick:prependInner"],
            "onClick:appendInner": e["onClick:appendInner"],
            role: e.role
          }, $e(A, ["onClick:clear"]), {
            id: $.value,
            active: g.value || J.value,
            dirty: J.value || e.dirty,
            disabled: W.value,
            focused: o.value,
            details: E.value,
            error: H.value === !1
          }), le(v({}, l), {
            default: (R) => {
              let {
                props: ne
              } = R, j = ne, {
                class: q
              } = j, ae = Ge(j, [
                "class"
              ]);
              const U = Re(w("input", G({
                ref: b,
                value: i.value,
                onInput: x,
                autofocus: e.autofocus,
                readonly: z.value,
                disabled: W.value,
                name: e.name,
                placeholder: e.placeholder,
                size: 1,
                role: e.role,
                type: e.type,
                onFocus: r,
                onBlur: u
              }, ae, p), null), [[Ht, {
                handler: c
              }, null, {
                once: !0
              }]]);
              return w(he, null, [e.prefix && w("span", {
                class: "v-text-field__prefix"
              }, [w("span", {
                class: "v-text-field__prefix__text"
              }, [e.prefix])]), l.default ? w("div", {
                class: X(q),
                "data-no-activator": ""
              }, [l.default(), U]) : Hd(U, {
                class: q
              }), e.suffix && w("span", {
                class: "v-text-field__suffix"
              }, [w("span", {
                class: "v-text-field__suffix__text"
              }, [e.suffix])])]);
            }
          }));
        },
        details: T ? (F) => {
          var $;
          return w(he, null, [($ = l.details) == null ? void 0 : $.call(l, F), I && w(he, null, [w("span", null, null), k(Pl, {
            active: e.persistentCounter || o.value,
            value: s.value,
            max: d.value,
            disabled: e.disabled
          }, l.counter)])]);
        } : void 0
      }));
    }), it({}, m, h, b);
  }
}), ih = N(v({
  renderless: Boolean
}, de()), "VVirtualScrollItem"), Ks = Y()({
  name: "VVirtualScrollItem",
  inheritAttrs: !1,
  props: ih(),
  emits: {
    "update:height": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const {
      resizeRef: i,
      contentRect: o
    } = pt(void 0, "border");
    oe(() => {
      var r;
      return (r = o.value) == null ? void 0 : r.height;
    }, (r) => {
      r != null && a("update:height", r);
    }), Z(() => {
      var r, u;
      return e.renderless ? w(he, null, [(r = l.default) == null ? void 0 : r.call(l, {
        itemRef: i
      })]) : w("div", G({
        ref: i,
        class: ["v-virtual-scroll__item", e.class],
        style: e.style
      }, t), [(u = l.default) == null ? void 0 : u.call(l)]);
    });
  }
}), oh = -1, rh = 1, Zl = 100, qs = N({
  itemHeight: {
    type: [Number, String],
    default: null
  },
  itemKey: {
    type: [String, Array, Function],
    default: null
  },
  height: [Number, String]
}, "virtual");
function Xs(e, n) {
  const t = At(), a = te(0);
  We(() => {
    a.value = parseFloat(e.itemHeight || 0);
  });
  const l = te(0), i = te(Math.ceil(
    // Assume 16px items filling the entire screen height if
    // not provided. This is probably incorrect but it minimises
    // the chance of ending up with empty space at the bottom.
    // The default value is set here to avoid poisoning getSize()
    (parseInt(e.height) || t.height.value) / (a.value || 16)
  ) || 1), o = te(0), r = te(0), u = Q(), c = Q();
  let s = 0;
  const {
    resizeRef: d,
    contentRect: f
  } = pt();
  We(() => {
    d.value = u.value;
  });
  const m = C(() => {
    var E;
    return u.value === document.documentElement ? t.height.value : ((E = f.value) == null ? void 0 : E.height) || parseInt(e.height) || 0;
  }), h = C(() => !!(u.value && c.value && m.value && a.value));
  let b = Array.from({
    length: n.value.length
  }), g = Array.from({
    length: n.value.length
  });
  const S = te(0);
  let y = -1;
  function P(E) {
    return b[E] || a.value;
  }
  const V = ru(() => {
    const E = performance.now();
    g[0] = 0;
    const O = n.value.length;
    for (let R = 1; R <= O - 1; R++)
      g[R] = (g[R - 1] || 0) + P(R - 1);
    S.value = Math.max(S.value, performance.now() - E);
  }, S), x = oe(h, (E) => {
    E && (x(), s = c.value.offsetTop, V.immediate(), W(), ~y && Ve(() => {
      Te && window.requestAnimationFrame(() => {
        z(y), y = -1;
      });
    }));
  });
  tt(() => {
    V.clear();
  });
  function I(E, O) {
    const R = b[E], q = a.value;
    a.value = q ? Math.min(a.value, O) : O, (R !== O || q !== a.value) && (b[E] = O, V());
  }
  function T(E) {
    E = Fe(E, 0, n.value.length - 1);
    const O = Math.floor(E), R = E % 1, q = O + 1, ae = g[O] || 0, U = g[q] || ae;
    return ae + (U - ae) * R;
  }
  function _(E) {
    return uh(g, E);
  }
  let p = 0, L = 0, D = 0;
  oe(m, (E, O) => {
    O && (W(), E < O && requestAnimationFrame(() => {
      L = 0, W();
    }));
  });
  let A = -1;
  function B() {
    if (!u.value || !c.value) return;
    const E = u.value.scrollTop, O = performance.now();
    O - D > 500 ? (L = Math.sign(E - p), s = c.value.offsetTop) : L = E - p, p = E, D = O, window.clearTimeout(A), A = window.setTimeout(F, 500), W();
  }
  function F() {
    !u.value || !c.value || (L = 0, D = 0, window.clearTimeout(A), W());
  }
  let $ = -1;
  function W() {
    cancelAnimationFrame($), $ = requestAnimationFrame(J);
  }
  function J() {
    if (!u.value || !m.value || !a.value) return;
    const E = p - s, O = Math.sign(L), R = Math.max(0, E - Zl), q = Fe(_(R), 0, n.value.length), ae = E + m.value + Zl, U = Fe(_(ae) + 1, q + 1, n.value.length);
    if (
      // Only update the side we're scrolling towards,
      // the other side will be updated incidentally
      (O !== oh || q < l.value) && (O !== rh || U > i.value)
    ) {
      const ne = T(l.value) - T(q), j = T(U) - T(i.value);
      Math.max(ne, j) > Zl ? (l.value = q, i.value = U) : (q <= 0 && (l.value = q), U >= n.value.length && (i.value = U));
    }
    o.value = T(l.value), r.value = T(n.value.length) - T(i.value);
  }
  function z(E) {
    const O = T(E);
    !u.value || E && !O ? y = E : u.value.scrollTop = O;
  }
  const H = C(() => n.value.slice(l.value, i.value).map((E, O) => {
    const R = O + l.value;
    return {
      raw: E,
      index: R,
      key: qe(E, e.itemKey, R)
    };
  }));
  return oe(n, () => {
    b = Array.from({
      length: n.value.length
    }), g = Array.from({
      length: n.value.length
    }), V.immediate(), W();
  }, {
    deep: 1
  }), {
    calculateVisibleItems: W,
    containerRef: u,
    markerRef: c,
    computedItems: H,
    paddingTop: o,
    paddingBottom: r,
    scrollToIndex: z,
    handleScroll: B,
    handleScrollend: F,
    handleItemResize: I
  };
}
function uh(e, n) {
  let t = e.length - 1, a = 0, l = 0, i = null, o = -1;
  if (e[t] < n)
    return t;
  for (; a <= t; )
    if (l = a + t >> 1, i = e[l], i > n)
      t = l - 1;
    else if (i < n)
      o = l, a = l + 1;
    else return i === n ? l : a;
  return o;
}
const sh = N(v(v(v({
  items: {
    type: Array,
    default: () => []
  },
  renderless: Boolean
}, qs()), de()), Ze()), "VVirtualScroll"), Il = Y()({
  name: "VVirtualScroll",
  props: sh(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Ke("VVirtualScroll"), {
      dimensionStyles: l
    } = Qe(e), {
      calculateVisibleItems: i,
      containerRef: o,
      markerRef: r,
      handleScroll: u,
      handleScrollend: c,
      handleItemResize: s,
      scrollToIndex: d,
      paddingTop: f,
      paddingBottom: m,
      computedItems: h
    } = Xs(e, M(() => e.items));
    return mt(() => e.renderless, () => {
      function b() {
        var y, P;
        const S = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1) ? "addEventListener" : "removeEventListener";
        o.value === document.documentElement ? (document[S]("scroll", u, {
          passive: !0
        }), document[S]("scrollend", c)) : ((y = o.value) == null || y[S]("scroll", u, {
          passive: !0
        }), (P = o.value) == null || P[S]("scrollend", c));
      }
      gt(() => {
        o.value = eo(a.vnode.el, !0), b(!0);
      }), tt(b);
    }), Z(() => {
      const b = h.value.map((g) => k(Ks, {
        key: g.key,
        renderless: e.renderless,
        "onUpdate:height": (S) => s(g.index, S)
      }, {
        default: (S) => {
          var y;
          return (y = t.default) == null ? void 0 : y.call(t, v({
            item: g.raw,
            index: g.index
          }, S));
        }
      }));
      return e.renderless ? w(he, null, [w("div", {
        ref: r,
        class: "v-virtual-scroll__spacer",
        style: {
          paddingTop: ce(f.value)
        }
      }, null), b, w("div", {
        class: "v-virtual-scroll__spacer",
        style: {
          paddingBottom: ce(m.value)
        }
      }, null)]) : w("div", {
        ref: o,
        class: X(["v-virtual-scroll", e.class]),
        onScrollPassive: u,
        onScrollend: c,
        style: ie([l.value, e.style])
      }, [w("div", {
        ref: r,
        class: "v-virtual-scroll__container",
        style: {
          paddingTop: ce(f.value),
          paddingBottom: ce(m.value)
        }
      }, [b])]);
    }), {
      calculateVisibleItems: i,
      scrollToIndex: d
    };
  }
});
function xo(e, n) {
  const t = te(!1);
  let a;
  function l(r) {
    cancelAnimationFrame(a), t.value = !0, a = requestAnimationFrame(() => {
      a = requestAnimationFrame(() => {
        t.value = !1;
      });
    });
  }
  function i() {
    return He(this, null, function* () {
      yield new Promise((r) => requestAnimationFrame(r)), yield new Promise((r) => requestAnimationFrame(r)), yield new Promise((r) => requestAnimationFrame(r)), yield new Promise((r) => {
        if (t.value) {
          const u = oe(t, () => {
            u(), r();
          });
        } else r();
      });
    });
  }
  function o(r) {
    return He(this, null, function* () {
      var s, d;
      if (r.key === "Tab" && ((s = n.value) == null || s.focus()), !["PageDown", "PageUp", "Home", "End"].includes(r.key)) return;
      const u = (d = e.value) == null ? void 0 : d.$el;
      if (!u) return;
      (r.key === "Home" || r.key === "End") && u.scrollTo({
        top: r.key === "Home" ? 0 : u.scrollHeight,
        behavior: "smooth"
      }), yield i();
      const c = u.querySelectorAll(":scope > :not(.v-virtual-scroll__spacer)");
      if (r.key === "PageDown" || r.key === "Home") {
        const f = u.getBoundingClientRect().top;
        for (const m of c)
          if (m.getBoundingClientRect().top >= f) {
            m.focus();
            break;
          }
      } else {
        const f = u.getBoundingClientRect().bottom;
        for (const m of [...c].reverse())
          if (m.getBoundingClientRect().bottom <= f) {
            m.focus();
            break;
          }
      }
    });
  }
  return {
    onScrollPassive: l,
    onKeydown: o
  };
}
const Vo = N(v({
  chips: Boolean,
  closableChips: Boolean,
  closeText: {
    type: String,
    default: "$vuetify.close"
  },
  openText: {
    type: String,
    default: "$vuetify.open"
  },
  eager: Boolean,
  hideNoData: Boolean,
  hideSelected: Boolean,
  listProps: {
    type: Object
  },
  menu: Boolean,
  menuIcon: {
    type: me,
    default: "$dropdown"
  },
  menuProps: {
    type: Object
  },
  multiple: Boolean,
  noDataText: {
    type: String,
    default: "$vuetify.noDataText"
  },
  openOnClear: Boolean,
  itemColor: String,
  noAutoScroll: Boolean
}, ps({
  itemChildren: !1
})), "Select"), ch = N(v(v(v({}, Vo()), $e(Na({
  modelValue: null,
  role: "combobox"
}), ["validationValue", "dirty", "appendInnerIcon"])), Ft({
  transition: {
    component: Sl
  }
})), "VSelect"), Po = Y()({
  name: "VSelect",
  props: ch(),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0,
    "update:menu": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      t: a
    } = Ee(), l = Q(), i = Q(), o = Q(), {
      items: r,
      transformIn: u,
      transformOut: c
    } = yo(e), s = ve(e, "modelValue", [], (E) => u(E === null ? [null] : ze(E)), (E) => {
      var R;
      const O = c(E);
      return e.multiple ? O : (R = O[0]) != null ? R : null;
    }), d = C(() => typeof e.counterValue == "function" ? e.counterValue(s.value) : typeof e.counterValue == "number" ? e.counterValue : s.value.length), f = $a(e), m = C(() => s.value.map((E) => E.value)), h = te(!1);
    let b = "", g = -1, S;
    const y = C(() => e.hideSelected ? r.value.filter((E) => !s.value.some((O) => (e.valueComparator || at)(O, E))) : r.value), P = C(() => e.hideNoData && !y.value.length || f.isReadonly.value || f.isDisabled.value), V = ve(e, "menu"), x = C({
      get: () => V.value,
      set: (E) => {
        var O;
        V.value && !E && ((O = i.value) != null && O.ΨopenChildren.size) || E && P.value || (V.value = E);
      }
    }), I = M(() => x.value ? e.closeText : e.openText), T = C(() => {
      var E;
      return le(v({}, e.menuProps), {
        activatorProps: le(v({}, ((E = e.menuProps) == null ? void 0 : E.activatorProps) || {}), {
          "aria-haspopup": "listbox"
          // Set aria-haspopup to 'listbox'
        })
      });
    }), _ = Q(), p = xo(_, l);
    function L(E) {
      e.openOnClear && (x.value = !0);
    }
    function D() {
      P.value || (x.value = !x.value);
    }
    function A(E) {
      Wn(E) && B(E);
    }
    function B(E) {
      var ge, ee, re;
      if (!E.key || f.isReadonly.value) return;
      ["Enter", " ", "ArrowDown", "ArrowUp", "Home", "End"].includes(E.key) && E.preventDefault(), ["Enter", "ArrowDown", " "].includes(E.key) && (x.value = !0), ["Escape", "Tab"].includes(E.key) && (x.value = !1), E.key === "Home" ? (ge = _.value) == null || ge.focus("first") : E.key === "End" && ((ee = _.value) == null || ee.focus("last"));
      const O = 1e3;
      if (!Wn(E)) return;
      const R = performance.now();
      R - S > O && (b = "", g = -1), b += E.key.toLowerCase(), S = R;
      const q = y.value;
      function ae() {
        let fe = U();
        return fe || b.at(-1) === b.at(-2) && (b = b.slice(0, -1), fe = U(), fe) || (g = -1, fe = U(), fe) ? fe : (b = E.key.toLowerCase(), U());
      }
      function U() {
        for (let fe = g + 1; fe < q.length; fe++) {
          const K = q[fe];
          if (K.title.toLowerCase().startsWith(b))
            return [K, fe];
        }
      }
      const ne = ae();
      if (!ne) return;
      const [j, ue] = ne;
      g = ue, (re = _.value) == null || re.focus(ue), e.multiple || (s.value = [j]);
    }
    function F(E) {
      let O = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      if (!E.props.disabled)
        if (e.multiple) {
          const R = s.value.findIndex((ae) => (e.valueComparator || at)(ae.value, E.value)), q = O == null ? !~R : O;
          if (~R) {
            const ae = q ? [...s.value, E] : [...s.value];
            ae.splice(R, 1), s.value = ae;
          } else q && (s.value = [...s.value, E]);
        } else {
          const R = O !== !1;
          s.value = R ? [E] : [], Ve(() => {
            x.value = !1;
          });
        }
    }
    function $(E) {
      var O;
      (O = _.value) != null && O.$el.contains(E.relatedTarget) || (x.value = !1);
    }
    function W() {
      var E;
      e.eager && ((E = o.value) == null || E.calculateVisibleItems());
    }
    function J() {
      var E;
      h.value && ((E = l.value) == null || E.focus());
    }
    function z(E) {
      h.value = !0;
    }
    function H(E) {
      if (E == null) s.value = [];
      else if (zn(l.value, ":autofill") || zn(l.value, ":-webkit-autofill")) {
        const O = r.value.find((R) => R.title === E);
        O && F(O);
      } else l.value && (l.value.value = "");
    }
    return oe(x, () => {
      if (!e.hideSelected && x.value && s.value.length) {
        const E = y.value.findIndex((O) => s.value.some((R) => (e.valueComparator || at)(R.value, O.value)));
        Te && !e.noAutoScroll && window.requestAnimationFrame(() => {
          var O;
          E >= 0 && ((O = o.value) == null || O.scrollToIndex(E));
        });
      }
    }), oe(() => e.items, (E, O) => {
      x.value || h.value && e.hideNoData && !O.length && E.length && (x.value = !0);
    }), Z(() => {
      const E = !!(e.chips || t.chip), O = !!(!e.hideNoData || y.value.length || t["prepend-item"] || t["append-item"] || t["no-data"]), R = s.value.length > 0, q = Kt.filterProps(e), ae = R || !h.value && e.label && !e.persistentPlaceholder ? void 0 : e.placeholder;
      return k(Kt, G({
        ref: l
      }, q, {
        modelValue: s.value.map((U) => U.props.title).join(", "),
        "onUpdate:modelValue": H,
        focused: h.value,
        "onUpdate:focused": (U) => h.value = U,
        validationValue: s.externalValue,
        counterValue: d.value,
        dirty: R,
        class: ["v-select", {
          "v-select--active-menu": x.value,
          "v-select--chips": !!e.chips,
          [`v-select--${e.multiple ? "multiple" : "single"}`]: !0,
          "v-select--selected": s.value.length,
          "v-select--selection-slot": !!t.selection
        }, e.class],
        style: e.style,
        inputmode: "none",
        placeholder: ae,
        "onClick:clear": L,
        "onMousedown:control": D,
        onBlur: $,
        onKeydown: B,
        "aria-label": a(I.value),
        title: a(I.value)
      }), le(v({}, t), {
        default: () => w(he, null, [k(Un, G({
          ref: i,
          modelValue: x.value,
          "onUpdate:modelValue": (U) => x.value = U,
          activator: "parent",
          contentClass: "v-select__content",
          disabled: P.value,
          eager: e.eager,
          maxHeight: 310,
          openOnClick: !1,
          closeOnContentClick: !1,
          transition: e.transition,
          onAfterEnter: W,
          onAfterLeave: J
        }, T.value), {
          default: () => {
            var U;
            return [O && k(Gn, G({
              ref: _,
              selected: m.value,
              selectStrategy: e.multiple ? "independent" : "single-independent",
              onMousedown: (ne) => ne.preventDefault(),
              onKeydown: A,
              onFocusin: z,
              tabindex: "-1",
              "aria-live": "polite",
              "aria-label": `${e.label}-list`,
              color: (U = e.itemColor) != null ? U : e.color
            }, p, e.listProps), {
              default: () => {
                var ne, j, ue, ge;
                return [(ne = t["prepend-item"]) == null ? void 0 : ne.call(t), !y.value.length && !e.hideNoData && ((ue = (j = t["no-data"]) == null ? void 0 : j.call(t)) != null ? ue : k(Et, {
                  key: "no-data",
                  title: a(e.noDataText)
                }, null)), k(Il, {
                  ref: o,
                  renderless: !0,
                  items: y.value,
                  itemKey: "value"
                }, {
                  default: (ee) => {
                    var be, we, Me, Se, _e, ut;
                    let {
                      item: re,
                      index: fe,
                      itemRef: K
                    } = ee;
                    const se = lv(re.props), ye = G(re.props, {
                      ref: K,
                      key: re.value,
                      onClick: () => F(re, null)
                    });
                    return re.type === "divider" ? (we = (be = t.divider) == null ? void 0 : be.call(t, {
                      props: re.raw,
                      index: fe
                    })) != null ? we : k(It, G(re.props, {
                      key: `divider-${fe}`
                    }), null) : re.type === "subheader" ? (Se = (Me = t.subheader) == null ? void 0 : Me.call(t, {
                      props: re.raw,
                      index: fe
                    })) != null ? Se : k(aa, G(re.props, {
                      key: `subheader-${fe}`
                    }), null) : (ut = (_e = t.item) == null ? void 0 : _e.call(t, {
                      item: re,
                      index: fe,
                      props: ye
                    })) != null ? ut : k(Et, G(ye, {
                      role: "option"
                    }), {
                      prepend: (Ae) => {
                        let {
                          isSelected: wt
                        } = Ae;
                        return w(he, null, [e.multiple && !e.hideSelected ? k(zt, {
                          key: re.value,
                          modelValue: wt,
                          ripple: !1,
                          tabindex: "-1"
                        }, null) : void 0, se.prependAvatar && k(Bt, {
                          image: se.prependAvatar
                        }, null), se.prependIcon && k(Be, {
                          icon: se.prependIcon
                        }, null)]);
                      }
                    });
                  }
                }), (ge = t["append-item"]) == null ? void 0 : ge.call(t)];
              }
            })];
          }
        }), s.value.map((U, ne) => {
          function j(re) {
            re.stopPropagation(), re.preventDefault(), F(U, !1);
          }
          const ue = {
            "onClick:close": j,
            onKeydown(re) {
              re.key !== "Enter" && re.key !== " " || (re.preventDefault(), re.stopPropagation(), j(re));
            },
            onMousedown(re) {
              re.preventDefault(), re.stopPropagation();
            },
            modelValue: !0,
            "onUpdate:modelValue": void 0
          }, ge = E ? !!t.chip : !!t.selection, ee = ge ? ml(E ? t.chip({
            item: U,
            index: ne,
            props: ue
          }) : t.selection({
            item: U,
            index: ne
          })) : void 0;
          if (!(ge && !ee))
            return w("div", {
              key: U.value,
              class: "v-select__selection"
            }, [E ? t.chip ? k(Ce, {
              key: "chip-defaults",
              defaults: {
                VChip: {
                  closable: e.closableChips,
                  size: "small",
                  text: U.title
                }
              }
            }, {
              default: () => [ee]
            }) : k(na, G({
              key: "chip",
              closable: e.closableChips,
              size: "small",
              text: U.title,
              disabled: U.props.disabled
            }, ue), null) : ee != null ? ee : w("span", {
              class: "v-select__selection-text"
            }, [U.title, e.multiple && ne < s.value.length - 1 && w("span", {
              class: "v-select__selection-comma"
            }, [Nt(",")])])]);
        })]),
        "append-inner": function() {
          var ue, ge;
          for (var U = arguments.length, ne = new Array(U), j = 0; j < U; j++)
            ne[j] = arguments[j];
          return w(he, null, [(ue = t["append-inner"]) == null ? void 0 : ue.call(t, ...ne), e.menuIcon ? k(Be, {
            class: "v-select__menu-icon",
            color: (ge = l.value) == null ? void 0 : ge.fieldIconColor,
            icon: e.menuIcon
          }, null) : void 0]);
        }
      }));
    }), it({
      isFocused: h,
      menu: x,
      select: F
    }, l);
  }
}), dh = (e, n, t) => {
  if (e == null || n == null) return -1;
  if (!n.length) return 0;
  e = e.toString().toLocaleLowerCase(), n = n.toString().toLocaleLowerCase();
  const a = [];
  let l = e.indexOf(n);
  for (; ~l; )
    a.push([l, l + n.length]), l = e.indexOf(n, l + n.length);
  return a.length ? a : -1;
};
function Ql(e, n) {
  if (!(e == null || typeof e == "boolean" || e === -1))
    return typeof e == "number" ? [[e, e + n.length]] : Array.isArray(e[0]) ? e : [e];
}
const la = N({
  customFilter: Function,
  customKeyFilter: Object,
  filterKeys: [Array, String],
  filterMode: {
    type: String,
    default: "intersection"
  },
  noFilter: Boolean
}, "filter");
function vh(e, n, t) {
  var r, u, c;
  const a = [], l = (r = t == null ? void 0 : t.default) != null ? r : dh, i = t != null && t.filterKeys ? ze(t.filterKeys) : !1, o = Object.keys((u = t == null ? void 0 : t.customKeyFilter) != null ? u : {}).length;
  if (!(e != null && e.length)) return a;
  e: for (let s = 0; s < e.length; s++) {
    const [d, f = d] = ze(e[s]), m = {}, h = {};
    let b = -1;
    if ((n || o > 0) && !(t != null && t.noFilter)) {
      let g = !1;
      if (typeof d == "object") {
        if (d.type === "divider" || d.type === "subheader")
          continue;
        const P = i || Object.keys(f);
        g = P.length === o;
        for (const V of P) {
          const x = qe(f, V), I = (c = t == null ? void 0 : t.customKeyFilter) == null ? void 0 : c[V];
          if (b = I ? I(x, n, d) : l(x, n, d), b !== -1 && b !== !1)
            I ? m[V] = Ql(b, n) : h[V] = Ql(b, n);
          else if ((t == null ? void 0 : t.filterMode) === "every")
            continue e;
        }
      } else
        b = l(d, n, d), b !== -1 && b !== !1 && (h.title = Ql(b, n));
      const S = Object.keys(h).length, y = Object.keys(m).length;
      if (!S && !y || (t == null ? void 0 : t.filterMode) === "union" && y !== o && !S || (t == null ? void 0 : t.filterMode) === "intersection" && (y !== o || !S && o > 0 && !g)) continue;
    }
    a.push({
      index: s,
      matches: v(v({}, h), m)
    });
  }
  return a;
}
function ia(e, n, t, a) {
  const l = te([]), i = te(/* @__PURE__ */ new Map()), o = C(() => a != null && a.transform ? Tt(n).map((u) => [u, a.transform(u)]) : Tt(n));
  We(() => {
    const u = typeof t == "function" ? t() : Tt(t), c = typeof u != "string" && typeof u != "number" ? "" : String(u), s = vh(o.value, c, {
      customKeyFilter: v(v({}, e.customKeyFilter), Tt(a == null ? void 0 : a.customKeyFilter)),
      default: e.customFilter,
      filterKeys: e.filterKeys,
      filterMode: e.filterMode,
      noFilter: e.noFilter
    }), d = Tt(n), f = [], m = /* @__PURE__ */ new Map();
    s.forEach((h) => {
      let {
        index: b,
        matches: g
      } = h;
      const S = d[b];
      f.push(S), m.set(S.value, g);
    }), l.value = f, i.value = m;
  });
  function r(u) {
    return i.value.get(u.value);
  }
  return {
    filteredItems: l,
    filteredMatches: i,
    getMatches: r
  };
}
function Zs(e, n, t) {
  return t == null || !t.length ? n : t.map((a, l) => {
    const i = l === 0 ? 0 : t[l - 1][1], o = [w("span", {
      class: X(`${e}__unmask`)
    }, [n.slice(i, a[0])]), w("span", {
      class: X(`${e}__mask`)
    }, [n.slice(a[0], a[1])])];
    return l === t.length - 1 && o.push(w("span", {
      class: X(`${e}__unmask`)
    }, [n.slice(a[1])])), w(he, null, [o]);
  });
}
const fh = N(v(v(v(v({
  autoSelectFirst: {
    type: [Boolean, String]
  },
  clearOnSelect: Boolean,
  search: String
}, la({
  filterKeys: ["title"]
})), Vo()), $e(Na({
  modelValue: null,
  role: "combobox"
}), ["validationValue", "dirty", "appendInnerIcon"])), Ft({
  transition: !1
})), "VAutocomplete"), mh = Y()({
  name: "VAutocomplete",
  props: fh(),
  emits: {
    "update:focused": (e) => !0,
    "update:search": (e) => !0,
    "update:modelValue": (e) => !0,
    "update:menu": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      t: a
    } = Ee(), l = Q(), i = te(!1), o = te(!0), r = te(!1), u = Q(), c = Q(), s = te(-1), {
      items: d,
      transformIn: f,
      transformOut: m
    } = yo(e), {
      textColorClasses: h,
      textColorStyles: b
    } = rt(() => {
      var ee;
      return (ee = l.value) == null ? void 0 : ee.color;
    }), g = ve(e, "search", ""), S = ve(e, "modelValue", [], (ee) => f(ee === null ? [null] : ze(ee)), (ee) => {
      var fe;
      const re = m(ee);
      return e.multiple ? re : (fe = re[0]) != null ? fe : null;
    }), y = C(() => typeof e.counterValue == "function" ? e.counterValue(S.value) : typeof e.counterValue == "number" ? e.counterValue : S.value.length), P = $a(e), {
      filteredItems: V,
      getMatches: x
    } = ia(e, d, () => o.value ? "" : g.value), I = C(() => e.hideSelected ? V.value.filter((ee) => !S.value.some((re) => re.value === ee.value)) : V.value), T = C(() => !!(e.chips || t.chip)), _ = C(() => T.value || !!t.selection), p = C(() => S.value.map((ee) => ee.props.value)), L = C(() => {
      var re;
      return (e.autoSelectFirst === !0 || e.autoSelectFirst === "exact" && g.value === ((re = I.value[0]) == null ? void 0 : re.title)) && I.value.length > 0 && !o.value && !r.value;
    }), D = C(() => e.hideNoData && !I.value.length || P.isReadonly.value || P.isDisabled.value), A = ve(e, "menu"), B = C({
      get: () => A.value,
      set: (ee) => {
        var re;
        A.value && !ee && ((re = u.value) != null && re.ΨopenChildren.size) || ee && D.value || (A.value = ee);
      }
    }), F = C(() => B.value ? e.closeText : e.openText), $ = Q(), W = xo($, l);
    function J(ee) {
      e.openOnClear && (B.value = !0), g.value = "";
    }
    function z() {
      D.value || (B.value = !0);
    }
    function H(ee) {
      D.value || (i.value && (ee.preventDefault(), ee.stopPropagation()), B.value = !B.value);
    }
    function E(ee) {
      var re;
      (Wn(ee) || ee.key === "Backspace") && ((re = l.value) == null || re.focus());
    }
    function O(ee) {
      var K, se, ye, be, we, Me;
      if (P.isReadonly.value) return;
      const re = (K = l.value) == null ? void 0 : K.selectionStart, fe = S.value.length;
      if (["Enter", "ArrowDown", "ArrowUp"].includes(ee.key) && ee.preventDefault(), ["Enter", "ArrowDown"].includes(ee.key) && (B.value = !0), ["Escape"].includes(ee.key) && (B.value = !1), L.value && ["Enter", "Tab"].includes(ee.key) && !S.value.some((Se) => {
        let {
          value: _e
        } = Se;
        return _e === I.value[0].value;
      }) && ge(I.value[0]), ee.key === "ArrowDown" && L.value && ((se = $.value) == null || se.focus("next")), ["Backspace", "Delete"].includes(ee.key)) {
        if (!e.multiple && _.value && S.value.length > 0 && !g.value) return ge(S.value[0], !1);
        if (~s.value) {
          ee.preventDefault();
          const Se = s.value;
          ge(S.value[s.value], !1), s.value = Se >= fe - 1 ? fe - 2 : Se;
        } else ee.key === "Backspace" && !g.value && (s.value = fe - 1);
        return;
      }
      if (e.multiple)
        if (ee.key === "ArrowLeft") {
          if (s.value < 0 && re && re > 0) return;
          const Se = s.value > -1 ? s.value - 1 : fe - 1;
          if (S.value[Se])
            s.value = Se;
          else {
            const _e = (be = (ye = g.value) == null ? void 0 : ye.length) != null ? be : null;
            s.value = -1, (we = l.value) == null || we.setSelectionRange(_e, _e);
          }
        } else if (ee.key === "ArrowRight") {
          if (s.value < 0) return;
          const Se = s.value + 1;
          S.value[Se] ? s.value = Se : (s.value = -1, (Me = l.value) == null || Me.setSelectionRange(0, 0));
        } else ~s.value && Wn(ee) && (s.value = -1);
    }
    function R(ee) {
      if (zn(l.value, ":autofill") || zn(l.value, ":-webkit-autofill")) {
        const re = d.value.find((fe) => fe.title === ee.target.value);
        re && ge(re);
      }
    }
    function q() {
      var ee;
      e.eager && ((ee = c.value) == null || ee.calculateVisibleItems());
    }
    function ae() {
      var ee;
      i.value && (o.value = !0, (ee = l.value) == null || ee.focus());
    }
    function U(ee) {
      i.value = !0, setTimeout(() => {
        r.value = !0;
      });
    }
    function ne(ee) {
      r.value = !1;
    }
    function j(ee) {
      (ee == null || ee === "" && !e.multiple && !_.value) && (S.value = []);
    }
    const ue = te(!1);
    function ge(ee) {
      let re = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      if (!(!ee || ee.props.disabled))
        if (e.multiple) {
          const fe = S.value.findIndex((se) => (e.valueComparator || at)(se.value, ee.value)), K = re == null ? !~fe : re;
          if (~fe) {
            const se = K ? [...S.value, ee] : [...S.value];
            se.splice(fe, 1), S.value = se;
          } else K && (S.value = [...S.value, ee]);
          e.clearOnSelect && (g.value = "");
        } else {
          const fe = re !== !1;
          S.value = fe ? [ee] : [], g.value = fe && !_.value ? ee.title : "", Ve(() => {
            B.value = !1, o.value = !0;
          });
        }
    }
    return oe(i, (ee, re) => {
      var fe, K;
      ee !== re && (ee ? (ue.value = !0, g.value = e.multiple || _.value ? "" : String((K = (fe = S.value.at(-1)) == null ? void 0 : fe.props.title) != null ? K : ""), o.value = !0, Ve(() => ue.value = !1)) : (!e.multiple && g.value == null && (S.value = []), B.value = !1, (e.multiple || _.value) && (g.value = ""), s.value = -1));
    }), oe(g, (ee) => {
      !i.value || ue.value || (ee && (B.value = !0), o.value = !ee);
    }), oe(B, () => {
      if (!e.hideSelected && B.value && S.value.length) {
        const ee = I.value.findIndex((re) => S.value.some((fe) => re.value === fe.value));
        Te && window.requestAnimationFrame(() => {
          var re;
          ee >= 0 && ((re = c.value) == null || re.scrollToIndex(ee));
        });
      }
    }), oe(() => e.items, (ee, re) => {
      B.value || i.value && !re.length && ee.length && (B.value = !0);
    }), Z(() => {
      const ee = !!(!e.hideNoData || I.value.length || t["prepend-item"] || t["append-item"] || t["no-data"]), re = S.value.length > 0, fe = Kt.filterProps(e);
      return k(Kt, G({
        ref: l
      }, fe, {
        modelValue: g.value,
        "onUpdate:modelValue": [(K) => g.value = K, j],
        focused: i.value,
        "onUpdate:focused": (K) => i.value = K,
        validationValue: S.externalValue,
        counterValue: y.value,
        dirty: re,
        onChange: R,
        class: ["v-autocomplete", `v-autocomplete--${e.multiple ? "multiple" : "single"}`, {
          "v-autocomplete--active-menu": B.value,
          "v-autocomplete--chips": !!e.chips,
          "v-autocomplete--selection-slot": !!_.value,
          "v-autocomplete--selecting-index": s.value > -1
        }, e.class],
        style: e.style,
        readonly: P.isReadonly.value,
        placeholder: re ? void 0 : e.placeholder,
        "onClick:clear": J,
        "onMousedown:control": z,
        onKeydown: O
      }), le(v({}, t), {
        default: () => w(he, null, [k(Un, G({
          ref: u,
          modelValue: B.value,
          "onUpdate:modelValue": (K) => B.value = K,
          activator: "parent",
          contentClass: "v-autocomplete__content",
          disabled: D.value,
          eager: e.eager,
          maxHeight: 310,
          openOnClick: !1,
          closeOnContentClick: !1,
          transition: e.transition,
          onAfterEnter: q,
          onAfterLeave: ae
        }, e.menuProps), {
          default: () => {
            var K;
            return [ee && k(Gn, G({
              ref: $,
              filterable: !0,
              selected: p.value,
              selectStrategy: e.multiple ? "independent" : "single-independent",
              onMousedown: (se) => se.preventDefault(),
              onKeydown: E,
              onFocusin: U,
              onFocusout: ne,
              tabindex: "-1",
              "aria-live": "polite",
              color: (K = e.itemColor) != null ? K : e.color
            }, W, e.listProps), {
              default: () => {
                var se, ye, be, we;
                return [(se = t["prepend-item"]) == null ? void 0 : se.call(t), !I.value.length && !e.hideNoData && ((be = (ye = t["no-data"]) == null ? void 0 : ye.call(t)) != null ? be : k(Et, {
                  key: "no-data",
                  title: a(e.noDataText)
                }, null)), k(Il, {
                  ref: c,
                  renderless: !0,
                  items: I.value,
                  itemKey: "value"
                }, {
                  default: (Me) => {
                    var wt, Ra, oa, ra, ua, sa;
                    let {
                      item: Se,
                      index: _e,
                      itemRef: ut
                    } = Me;
                    const Ae = G(Se.props, {
                      ref: ut,
                      key: Se.value,
                      active: L.value && _e === 0 ? !0 : void 0,
                      onClick: () => ge(Se, null)
                    });
                    return Se.type === "divider" ? (Ra = (wt = t.divider) == null ? void 0 : wt.call(t, {
                      props: Se.raw,
                      index: _e
                    })) != null ? Ra : k(It, G(Se.props, {
                      key: `divider-${_e}`
                    }), null) : Se.type === "subheader" ? (ra = (oa = t.subheader) == null ? void 0 : oa.call(t, {
                      props: Se.raw,
                      index: _e
                    })) != null ? ra : k(aa, G(Se.props, {
                      key: `subheader-${_e}`
                    }), null) : (sa = (ua = t.item) == null ? void 0 : ua.call(t, {
                      item: Se,
                      index: _e,
                      props: Ae
                    })) != null ? sa : k(Et, G(Ae, {
                      role: "option"
                    }), {
                      prepend: (rn) => {
                        let {
                          isSelected: Ha
                        } = rn;
                        return w(he, null, [e.multiple && !e.hideSelected ? k(zt, {
                          key: Se.value,
                          modelValue: Ha,
                          ripple: !1,
                          tabindex: "-1"
                        }, null) : void 0, Se.props.prependAvatar && k(Bt, {
                          image: Se.props.prependAvatar
                        }, null), Se.props.prependIcon && k(Be, {
                          icon: Se.props.prependIcon
                        }, null)]);
                      },
                      title: () => {
                        var rn;
                        return o.value ? Se.title : Zs("v-autocomplete", Se.title, (rn = x(Se)) == null ? void 0 : rn.title);
                      }
                    });
                  }
                }), (we = t["append-item"]) == null ? void 0 : we.call(t)];
              }
            })];
          }
        }), S.value.map((K, se) => {
          function ye(Se) {
            Se.stopPropagation(), Se.preventDefault(), ge(K, !1);
          }
          const be = {
            "onClick:close": ye,
            onKeydown(Se) {
              Se.key !== "Enter" && Se.key !== " " || (Se.preventDefault(), Se.stopPropagation(), ye(Se));
            },
            onMousedown(Se) {
              Se.preventDefault(), Se.stopPropagation();
            },
            modelValue: !0,
            "onUpdate:modelValue": void 0
          }, we = T.value ? !!t.chip : !!t.selection, Me = we ? ml(T.value ? t.chip({
            item: K,
            index: se,
            props: be
          }) : t.selection({
            item: K,
            index: se
          })) : void 0;
          if (!(we && !Me))
            return w("div", {
              key: K.value,
              class: X(["v-autocomplete__selection", se === s.value && ["v-autocomplete__selection--selected", h.value]]),
              style: ie(se === s.value ? b.value : {})
            }, [T.value ? t.chip ? k(Ce, {
              key: "chip-defaults",
              defaults: {
                VChip: {
                  closable: e.closableChips,
                  size: "small",
                  text: K.title
                }
              }
            }, {
              default: () => [Me]
            }) : k(na, G({
              key: "chip",
              closable: e.closableChips,
              size: "small",
              text: K.title,
              disabled: K.props.disabled
            }, be), null) : Me != null ? Me : w("span", {
              class: "v-autocomplete__selection-text"
            }, [K.title, e.multiple && se < S.value.length - 1 && w("span", {
              class: "v-autocomplete__selection-comma"
            }, [Nt(",")])])]);
        })]),
        "append-inner": function() {
          var be, we;
          for (var K = arguments.length, se = new Array(K), ye = 0; ye < K; ye++)
            se[ye] = arguments[ye];
          return w(he, null, [(be = t["append-inner"]) == null ? void 0 : be.call(t, ...se), e.menuIcon ? k(Be, {
            class: "v-autocomplete__menu-icon",
            color: (we = l.value) == null ? void 0 : we.fieldIconColor,
            icon: e.menuIcon,
            onMousedown: H,
            onClick: vu,
            "aria-label": a(F.value),
            title: a(F.value),
            tabindex: "-1"
          }, null) : void 0]);
        }
      }));
    }), it({
      isFocused: i,
      isPristine: o,
      menu: B,
      search: g,
      filteredItems: V,
      select: ge
    }, l);
  }
}), gh = N(v(v(v(v(v(v(v({
  bordered: Boolean,
  color: String,
  content: [Number, String],
  dot: Boolean,
  floating: Boolean,
  icon: me,
  inline: Boolean,
  label: {
    type: String,
    default: "$vuetify.badge"
  },
  max: [Number, String],
  modelValue: {
    type: Boolean,
    default: !0
  },
  offsetX: [Number, String],
  offsetY: [Number, String],
  textColor: String
}, de()), Zt({
  location: "top end"
})), Ne()), ke()), Ie()), Ft({
  transition: "scale-rotate-transition"
})), Ze()), "VBadge"), hh = Y()({
  name: "VBadge",
  inheritAttrs: !1,
  props: gh(),
  setup(e, n) {
    const {
      backgroundColorClasses: t,
      backgroundColorStyles: a
    } = pe(() => e.color), {
      roundedClasses: l
    } = Ye(e), {
      t: i
    } = Ee(), {
      textColorClasses: o,
      textColorStyles: r
    } = rt(() => e.textColor), {
      themeClasses: u
    } = bl(), {
      locationStyles: c
    } = Mn(e, !0, (d) => {
      var m, h;
      return (e.floating ? e.dot ? 2 : 4 : e.dot ? 8 : 12) + (["top", "bottom"].includes(d) ? Number((m = e.offsetY) != null ? m : 0) : ["left", "right"].includes(d) ? Number((h = e.offsetX) != null ? h : 0) : 0);
    }), {
      dimensionStyles: s
    } = Qe(e);
    return Z(() => {
      const d = Number(e.content), f = !e.max || isNaN(d) ? e.content : d <= Number(e.max) ? d : `${e.max}+`, [m, h] = ti(n.attrs, ["aria-atomic", "aria-label", "aria-live", "role", "title"]);
      return k(e.tag, G({
        class: ["v-badge", {
          "v-badge--bordered": e.bordered,
          "v-badge--dot": e.dot,
          "v-badge--floating": e.floating,
          "v-badge--inline": e.inline
        }, e.class]
      }, h, {
        style: e.style
      }), {
        default: () => {
          var b, g;
          return [w("div", {
            class: "v-badge__wrapper"
          }, [(g = (b = n.slots).default) == null ? void 0 : g.call(b), k(ft, {
            transition: e.transition
          }, {
            default: () => {
              var S, y;
              return [Re(w("span", G({
                class: ["v-badge__badge", u.value, t.value, l.value, o.value],
                style: [a.value, r.value, s.value, e.inline ? {} : c.value],
                "aria-atomic": "true",
                "aria-label": i(e.label, d),
                "aria-live": "polite",
                role: "status"
              }, m), [e.dot ? void 0 : n.slots.badge ? (y = (S = n.slots).badge) == null ? void 0 : y.call(S) : e.icon ? k(Be, {
                icon: e.icon
              }, null) : f]), [[$t, e.modelValue]])];
            }
          })])];
        }
      });
    }), {};
  }
}), yh = N(v({
  color: String,
  density: String
}, de()), "VBannerActions"), Qs = Y()({
  name: "VBannerActions",
  props: yh(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return je({
      VBtn: {
        color: e.color,
        density: e.density,
        slim: !0,
        variant: "text"
      }
    }), Z(() => {
      var a;
      return w("div", {
        class: X(["v-banner-actions", e.class]),
        style: ie(e.style)
      }, [(a = t.default) == null ? void 0 : a.call(t)]);
    }), {};
  }
}), Js = Xt("v-banner-text"), bh = N(v(v(v(v(v(v(v(v(v(v(v({
  avatar: String,
  bgColor: String,
  color: String,
  icon: me,
  lines: String,
  stacked: Boolean,
  sticky: Boolean,
  text: String
}, kt()), de()), nt()), Ze()), Pn({
  mobile: null
})), Je()), Zt()), Jn()), Ne()), ke()), Ie()), "VBanner"), Sh = Y()({
  name: "VBanner",
  props: bh(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      backgroundColorClasses: a,
      backgroundColorStyles: l
    } = pe(() => e.bgColor), {
      borderClasses: i
    } = Ct(e), {
      densityClasses: o
    } = ht(e), {
      displayClasses: r,
      mobile: u
    } = At(e), {
      dimensionStyles: c
    } = Qe(e), {
      elevationClasses: s
    } = lt(e), {
      locationStyles: d
    } = Mn(e), {
      positionClasses: f
    } = ea(e), {
      roundedClasses: m
    } = Ye(e), {
      themeClasses: h
    } = De(e), b = M(() => e.color), g = M(() => e.density);
    je({
      VBannerActions: {
        color: b,
        density: g
      }
    }), Z(() => {
      const S = !!(e.text || t.text), y = !!(e.avatar || e.icon), P = !!(y || t.prepend);
      return k(e.tag, {
        class: X(["v-banner", {
          "v-banner--stacked": e.stacked || u.value,
          "v-banner--sticky": e.sticky,
          [`v-banner--${e.lines}-line`]: !!e.lines
        }, h.value, a.value, i.value, o.value, r.value, s.value, f.value, m.value, e.class]),
        style: ie([l.value, c.value, d.value, e.style]),
        role: "banner"
      }, {
        default: () => {
          var V;
          return [P && w("div", {
            key: "prepend",
            class: "v-banner__prepend"
          }, [t.prepend ? k(Ce, {
            key: "prepend-defaults",
            disabled: !y,
            defaults: {
              VAvatar: {
                color: b.value,
                density: g.value,
                icon: e.icon,
                image: e.avatar
              }
            }
          }, t.prepend) : k(Bt, {
            key: "prepend-avatar",
            color: b.value,
            density: g.value,
            icon: e.icon,
            image: e.avatar
          }, null)]), w("div", {
            class: "v-banner__content"
          }, [S && k(Js, {
            key: "text"
          }, {
            default: () => {
              var x, I;
              return [(I = (x = t.text) == null ? void 0 : x.call(t)) != null ? I : e.text];
            }
          }), (V = t.default) == null ? void 0 : V.call(t)]), t.actions && k(Qs, {
            key: "actions"
          }, t.actions)];
        }
      });
    });
  }
}), kh = N(v(v(v(v(v(v(v(v(v({
  baseColor: String,
  bgColor: String,
  color: String,
  grow: Boolean,
  mode: {
    type: String,
    validator: (e) => !e || ["horizontal", "shift"].includes(e)
  },
  height: {
    type: [Number, String],
    default: 56
  },
  active: {
    type: Boolean,
    default: !0
  }
}, kt()), de()), nt()), Je()), Ne()), In({
  name: "bottom-navigation"
})), ke({
  tag: "header"
})), Tn({
  selectedClass: "v-btn--selected"
})), Ie()), "VBottomNavigation"), wh = Y()({
  name: "VBottomNavigation",
  props: kh(),
  emits: {
    "update:active": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = bl(), {
      borderClasses: l
    } = Ct(e), {
      backgroundColorClasses: i,
      backgroundColorStyles: o
    } = pe(() => e.bgColor), {
      densityClasses: r
    } = ht(e), {
      elevationClasses: u
    } = lt(e), {
      roundedClasses: c
    } = Ye(e), {
      ssrBootStyles: s
    } = An(), d = C(() => Number(e.height) - (e.density === "comfortable" ? 8 : 0) - (e.density === "compact" ? 16 : 0)), f = ve(e, "active", e.active), {
      layoutItemStyles: m
    } = _n({
      id: e.name,
      order: C(() => parseInt(e.order, 10)),
      position: M(() => "bottom"),
      layoutSize: M(() => f.value ? d.value : 0),
      elementSize: d,
      active: f,
      absolute: M(() => e.absolute)
    });
    return on(e, vo), je({
      VBtn: {
        baseColor: M(() => e.baseColor),
        color: M(() => e.color),
        density: M(() => e.density),
        stacked: M(() => e.mode !== "horizontal"),
        variant: "text"
      }
    }, {
      scoped: !0
    }), Z(() => k(e.tag, {
      class: X(["v-bottom-navigation", {
        "v-bottom-navigation--active": f.value,
        "v-bottom-navigation--grow": e.grow,
        "v-bottom-navigation--shift": e.mode === "shift"
      }, a.value, i.value, l.value, r.value, u.value, c.value, e.class]),
      style: ie([o.value, m.value, {
        height: ce(d.value)
      }, s.value, e.style])
    }, {
      default: () => [t.default && w("div", {
        class: "v-bottom-navigation__content"
      }, [t.default()])]
    })), {};
  }
}), ec = N(v({
  fullscreen: Boolean,
  retainFocus: {
    type: Boolean,
    default: !0
  },
  scrollable: Boolean
}, Fa({
  origin: "center center",
  scrollStrategy: "block",
  transition: {
    component: Sl
  },
  zIndex: 2400
})), "VDialog"), xi = Y()({
  name: "VDialog",
  props: ec(),
  emits: {
    "update:modelValue": (e) => !0,
    afterEnter: () => !0,
    afterLeave: () => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = ve(e, "modelValue"), {
      scopeId: i
    } = pn(), o = Q();
    function r(s) {
      var m, h;
      const d = s.relatedTarget, f = s.target;
      if (d !== f && ((m = o.value) != null && m.contentEl) && // We're the topmost dialog
      ((h = o.value) != null && h.globalTop) && // It isn't the document or the dialog body
      ![document, o.value.contentEl].includes(f) && // It isn't inside the dialog body
      !o.value.contentEl.contains(f)) {
        const b = va(o.value.contentEl);
        if (!b.length) return;
        const g = b[0], S = b[b.length - 1];
        d === g ? S.focus() : g.focus();
      }
    }
    dt(() => {
      document.removeEventListener("focusin", r);
    }), Te && oe(() => l.value && e.retainFocus, (s) => {
      s ? document.addEventListener("focusin", r) : document.removeEventListener("focusin", r);
    }, {
      immediate: !0
    });
    function u() {
      var s;
      t("afterEnter"), (e.scrim || e.retainFocus) && ((s = o.value) != null && s.contentEl) && !o.value.contentEl.contains(document.activeElement) && o.value.contentEl.focus({
        preventScroll: !0
      });
    }
    function c() {
      t("afterLeave");
    }
    return oe(l, (s) => He(this, null, function* () {
      var d;
      s || (yield Ve(), (d = o.value.activatorEl) == null || d.focus({
        preventScroll: !0
      }));
    })), Z(() => {
      const s = Wt.filterProps(e), d = G({
        "aria-haspopup": "dialog"
      }, e.activatorProps), f = G({
        tabindex: -1
      }, e.contentProps);
      return k(Wt, G({
        ref: o,
        class: ["v-dialog", {
          "v-dialog--fullscreen": e.fullscreen,
          "v-dialog--scrollable": e.scrollable
        }, e.class],
        style: e.style
      }, s, {
        modelValue: l.value,
        "onUpdate:modelValue": (m) => l.value = m,
        "aria-modal": "true",
        activatorProps: d,
        contentProps: f,
        height: e.fullscreen ? void 0 : e.height,
        width: e.fullscreen ? void 0 : e.width,
        maxHeight: e.fullscreen ? void 0 : e.maxHeight,
        maxWidth: e.fullscreen ? void 0 : e.maxWidth,
        role: "dialog",
        onAfterEnter: u,
        onAfterLeave: c
      }, i), {
        activator: a.activator,
        default: function() {
          for (var m = arguments.length, h = new Array(m), b = 0; b < m; b++)
            h[b] = arguments[b];
          return k(Ce, {
            root: "VDialog"
          }, {
            default: () => {
              var g;
              return [(g = a.default) == null ? void 0 : g.call(a, ...h)];
            }
          });
        }
      });
    }), it({}, o);
  }
}), Ch = N(v({
  inset: Boolean
}, ec({
  transition: "bottom-sheet-transition"
})), "VBottomSheet"), xh = Y()({
  name: "VBottomSheet",
  props: Ch(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue");
    return Z(() => {
      const l = xi.filterProps(e);
      return k(xi, G(l, {
        contentClass: ["v-bottom-sheet__content", e.contentClass],
        modelValue: a.value,
        "onUpdate:modelValue": (i) => a.value = i,
        class: ["v-bottom-sheet", {
          "v-bottom-sheet--inset": e.inset
        }, e.class],
        style: e.style
      }), t);
    }), {};
  }
}), Vh = N(v({
  divider: [Number, String]
}, de()), "VBreadcrumbsDivider"), tc = Y()({
  name: "VBreadcrumbsDivider",
  props: Vh(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      var a, l;
      return w("li", {
        "aria-hidden": "true",
        class: X(["v-breadcrumbs-divider", e.class]),
        style: ie(e.style)
      }, [(l = (a = t == null ? void 0 : t.default) == null ? void 0 : a.call(t)) != null ? l : e.divider]);
    }), {};
  }
}), Ph = N(v(v(v({
  active: Boolean,
  activeClass: String,
  activeColor: String,
  color: String,
  disabled: Boolean,
  title: String
}, de()), pa()), ke({
  tag: "li"
})), "VBreadcrumbsItem"), nc = Y()({
  name: "VBreadcrumbsItem",
  props: Ph(),
  setup(e, n) {
    let {
      slots: t,
      attrs: a
    } = n;
    const l = Ma(e, a), i = C(() => {
      var u;
      return e.active || ((u = l.isActive) == null ? void 0 : u.value);
    }), {
      textColorClasses: o,
      textColorStyles: r
    } = rt(() => i.value ? e.activeColor : e.color);
    return Z(() => k(e.tag, {
      class: X(["v-breadcrumbs-item", {
        "v-breadcrumbs-item--active": i.value,
        "v-breadcrumbs-item--disabled": e.disabled,
        [`${e.activeClass}`]: i.value && e.activeClass
      }, o.value, e.class]),
      style: ie([r.value, e.style]),
      "aria-current": i.value ? "page" : void 0
    }, {
      default: () => {
        var u, c, s, d;
        return [l.isLink.value ? w("a", G({
          class: "v-breadcrumbs-item--link",
          onClick: l.navigate
        }, l.linkProps), [(d = (s = t.default) == null ? void 0 : s.call(t)) != null ? d : e.title]) : (c = (u = t.default) == null ? void 0 : u.call(t)) != null ? c : e.title];
      }
    })), {};
  }
}), Ih = N(v(v(v(v({
  activeClass: String,
  activeColor: String,
  bgColor: String,
  color: String,
  disabled: Boolean,
  divider: {
    type: String,
    default: "/"
  },
  icon: me,
  items: {
    type: Array,
    default: () => []
  }
}, de()), nt()), Ne()), ke({
  tag: "ul"
})), "VBreadcrumbs"), _h = Y()({
  name: "VBreadcrumbs",
  props: Ih(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      backgroundColorClasses: a,
      backgroundColorStyles: l
    } = pe(() => e.bgColor), {
      densityClasses: i
    } = ht(e), {
      roundedClasses: o
    } = Ye(e);
    je({
      VBreadcrumbsDivider: {
        divider: M(() => e.divider)
      },
      VBreadcrumbsItem: {
        activeClass: M(() => e.activeClass),
        activeColor: M(() => e.activeColor),
        color: M(() => e.color),
        disabled: M(() => e.disabled)
      }
    });
    const r = C(() => e.items.map((u) => typeof u == "string" ? {
      item: {
        title: u
      },
      raw: u
    } : {
      item: u,
      raw: u
    }));
    return Z(() => {
      const u = !!(t.prepend || e.icon);
      return k(e.tag, {
        class: X(["v-breadcrumbs", a.value, i.value, o.value, e.class]),
        style: ie([l.value, e.style])
      }, {
        default: () => {
          var c;
          return [u && w("li", {
            key: "prepend",
            class: "v-breadcrumbs__prepend"
          }, [t.prepend ? k(Ce, {
            key: "prepend-defaults",
            disabled: !e.icon,
            defaults: {
              VIcon: {
                icon: e.icon,
                start: !0
              }
            }
          }, t.prepend) : k(Be, {
            key: "prepend-icon",
            start: !0,
            icon: e.icon
          }, null)]), r.value.map((s, d, f) => {
            var b, g;
            let {
              item: m,
              raw: h
            } = s;
            return w(he, null, [(g = (b = t.item) == null ? void 0 : b.call(t, {
              item: m,
              index: d
            })) != null ? g : k(nc, G({
              key: d,
              disabled: d >= f.length - 1
            }, typeof m == "string" ? {
              title: m
            } : m), {
              default: t.title ? () => {
                var S;
                return (S = t.title) == null ? void 0 : S.call(t, {
                  item: m,
                  index: d
                });
              } : void 0
            }), d < f.length - 1 && k(tc, null, {
              default: t.divider ? () => {
                var S;
                return (S = t.divider) == null ? void 0 : S.call(t, {
                  item: h,
                  index: d
                });
              } : void 0
            })]);
          }), (c = t.default) == null ? void 0 : c.call(t)];
        }
      });
    }), {};
  }
}), ac = Y()({
  name: "VCardActions",
  props: de(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return je({
      VBtn: {
        slim: !0,
        variant: "text"
      }
    }), Z(() => {
      var a;
      return w("div", {
        class: X(["v-card-actions", e.class]),
        style: ie(e.style)
      }, [(a = t.default) == null ? void 0 : a.call(t)]);
    }), {};
  }
}), Ah = N(v(v({
  opacity: [Number, String]
}, de()), ke()), "VCardSubtitle"), lc = Y()({
  name: "VCardSubtitle",
  props: Ah(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(e.tag, {
      class: X(["v-card-subtitle", e.class]),
      style: ie([{
        "--v-card-subtitle-opacity": e.opacity
      }, e.style])
    }, t)), {};
  }
}), ic = Xt("v-card-title"), Lh = N(v(v({
  appendAvatar: String,
  appendIcon: me,
  prependAvatar: String,
  prependIcon: me,
  subtitle: {
    type: [String, Number, Boolean],
    default: void 0
  },
  title: {
    type: [String, Number, Boolean],
    default: void 0
  }
}, de()), nt()), "VCardItem"), oc = Y()({
  name: "VCardItem",
  props: Lh(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      var c;
      const a = !!(e.prependAvatar || e.prependIcon), l = !!(a || t.prepend), i = !!(e.appendAvatar || e.appendIcon), o = !!(i || t.append), r = !!(e.title != null || t.title), u = !!(e.subtitle != null || t.subtitle);
      return w("div", {
        class: X(["v-card-item", e.class]),
        style: ie(e.style)
      }, [l && w("div", {
        key: "prepend",
        class: "v-card-item__prepend"
      }, [t.prepend ? k(Ce, {
        key: "prepend-defaults",
        disabled: !a,
        defaults: {
          VAvatar: {
            density: e.density,
            image: e.prependAvatar
          },
          VIcon: {
            density: e.density,
            icon: e.prependIcon
          }
        }
      }, t.prepend) : w(he, null, [e.prependAvatar && k(Bt, {
        key: "prepend-avatar",
        density: e.density,
        image: e.prependAvatar
      }, null), e.prependIcon && k(Be, {
        key: "prepend-icon",
        density: e.density,
        icon: e.prependIcon
      }, null)])]), w("div", {
        class: "v-card-item__content"
      }, [r && k(ic, {
        key: "title"
      }, {
        default: () => {
          var s, d;
          return [(d = (s = t.title) == null ? void 0 : s.call(t)) != null ? d : hn(e.title)];
        }
      }), u && k(lc, {
        key: "subtitle"
      }, {
        default: () => {
          var s, d;
          return [(d = (s = t.subtitle) == null ? void 0 : s.call(t)) != null ? d : hn(e.subtitle)];
        }
      }), (c = t.default) == null ? void 0 : c.call(t)]), o && w("div", {
        key: "append",
        class: "v-card-item__append"
      }, [t.append ? k(Ce, {
        key: "append-defaults",
        disabled: !i,
        defaults: {
          VAvatar: {
            density: e.density,
            image: e.appendAvatar
          },
          VIcon: {
            density: e.density,
            icon: e.appendIcon
          }
        }
      }, t.append) : w(he, null, [e.appendIcon && k(Be, {
        key: "append-icon",
        density: e.density,
        icon: e.appendIcon
      }, null), e.appendAvatar && k(Bt, {
        key: "append-avatar",
        density: e.density,
        image: e.appendAvatar
      }, null)])])]);
    }), {};
  }
}), Th = N(v(v({
  opacity: [Number, String]
}, de()), ke()), "VCardText"), rc = Y()({
  name: "VCardText",
  props: Th(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => k(e.tag, {
      class: X(["v-card-text", e.class]),
      style: ie([{
        "--v-card-text-opacity": e.opacity
      }, e.style])
    }, t)), {};
  }
}), Bh = N(v(v(v(v(v(v(v(v(v(v(v(v(v({
  appendAvatar: String,
  appendIcon: me,
  disabled: Boolean,
  flat: Boolean,
  hover: Boolean,
  image: String,
  link: {
    type: Boolean,
    default: void 0
  },
  prependAvatar: String,
  prependIcon: me,
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  subtitle: {
    type: [String, Number, Boolean],
    default: void 0
  },
  text: {
    type: [String, Number, Boolean],
    default: void 0
  },
  title: {
    type: [String, Number, Boolean],
    default: void 0
  }
}, kt()), de()), nt()), Ze()), Je()), Cl()), Zt()), Jn()), Ne()), pa()), ke()), Ie()), Dt({
  variant: "elevated"
})), "VCard"), Dh = Y()({
  name: "VCard",
  directives: {
    vRipple: bt
  },
  props: Bh(),
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      themeClasses: l
    } = De(e), {
      borderClasses: i
    } = Ct(e), {
      colorClasses: o,
      colorStyles: r,
      variantClasses: u
    } = Ln(e), {
      densityClasses: c
    } = ht(e), {
      dimensionStyles: s
    } = Qe(e), {
      elevationClasses: d
    } = lt(e), {
      loaderClasses: f
    } = Ba(e), {
      locationStyles: m
    } = Mn(e), {
      positionClasses: h
    } = ea(e), {
      roundedClasses: b
    } = Ye(e), g = Ma(e, t);
    return Z(() => {
      const S = e.link !== !1 && g.isLink.value, y = !e.disabled && e.link !== !1 && (e.link || g.isClickable.value), P = S ? "a" : e.tag, V = !!(a.title || e.title != null), x = !!(a.subtitle || e.subtitle != null), I = V || x, T = !!(a.append || e.appendAvatar || e.appendIcon), _ = !!(a.prepend || e.prependAvatar || e.prependIcon), p = !!(a.image || e.image), L = I || _ || T, D = !!(a.text || e.text != null);
      return Re(k(P, G({
        class: ["v-card", {
          "v-card--disabled": e.disabled,
          "v-card--flat": e.flat,
          "v-card--hover": e.hover && !(e.disabled || e.flat),
          "v-card--link": y
        }, l.value, i.value, o.value, c.value, d.value, f.value, h.value, b.value, u.value, e.class],
        style: [r.value, s.value, m.value, e.style],
        onClick: y && g.navigate,
        tabindex: e.disabled ? -1 : void 0
      }, g.linkProps), {
        default: () => {
          var A;
          return [p && w("div", {
            key: "image",
            class: "v-card__image"
          }, [a.image ? k(Ce, {
            key: "image-defaults",
            disabled: !e.image,
            defaults: {
              VImg: {
                cover: !0,
                src: e.image
              }
            }
          }, a.image) : k(Ut, {
            key: "image-img",
            cover: !0,
            src: e.image
          }, null)]), k(Da, {
            name: "v-card",
            active: !!e.loading,
            color: typeof e.loading == "boolean" ? void 0 : e.loading
          }, {
            default: a.loader
          }), L && k(oc, {
            key: "item",
            prependAvatar: e.prependAvatar,
            prependIcon: e.prependIcon,
            title: e.title,
            subtitle: e.subtitle,
            appendAvatar: e.appendAvatar,
            appendIcon: e.appendIcon
          }, {
            default: a.item,
            prepend: a.prepend,
            title: a.title,
            subtitle: a.subtitle,
            append: a.append
          }), D && k(rc, {
            key: "text"
          }, {
            default: () => {
              var B, F;
              return [(F = (B = a.text) == null ? void 0 : B.call(a)) != null ? F : e.text];
            }
          }), (A = a.default) == null ? void 0 : A.call(a), a.actions && k(ac, null, {
            default: a.actions
          }), ln(y, "v-card")];
        }
      }), [[bt, y && e.ripple]]);
    }), {};
  }
}), Mh = (e) => {
  const {
    touchstartX: n,
    touchendX: t,
    touchstartY: a,
    touchendY: l
  } = e, i = 0.5, o = 16;
  e.offsetX = t - n, e.offsetY = l - a, Math.abs(e.offsetY) < i * Math.abs(e.offsetX) && (e.left && t < n - o && e.left(e), e.right && t > n + o && e.right(e)), Math.abs(e.offsetX) < i * Math.abs(e.offsetY) && (e.up && l < a - o && e.up(e), e.down && l > a + o && e.down(e));
};
function ph(e, n) {
  var a;
  const t = e.changedTouches[0];
  n.touchstartX = t.clientX, n.touchstartY = t.clientY, (a = n.start) == null || a.call(n, v({
    originalEvent: e
  }, n));
}
function Eh(e, n) {
  var a;
  const t = e.changedTouches[0];
  n.touchendX = t.clientX, n.touchendY = t.clientY, (a = n.end) == null || a.call(n, v({
    originalEvent: e
  }, n)), Mh(n);
}
function $h(e, n) {
  var a;
  const t = e.changedTouches[0];
  n.touchmoveX = t.clientX, n.touchmoveY = t.clientY, (a = n.move) == null || a.call(n, v({
    originalEvent: e
  }, n));
}
function Fh() {
  let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
  const n = {
    touchstartX: 0,
    touchstartY: 0,
    touchendX: 0,
    touchendY: 0,
    touchmoveX: 0,
    touchmoveY: 0,
    offsetX: 0,
    offsetY: 0,
    left: e.left,
    right: e.right,
    up: e.up,
    down: e.down,
    start: e.start,
    move: e.move,
    end: e.end
  };
  return {
    touchstart: (t) => ph(t, n),
    touchend: (t) => Eh(t, n),
    touchmove: (t) => $h(t, n)
  };
}
function Oh(e, n) {
  var r, u, c;
  const t = n.value, a = t != null && t.parent ? e.parentElement : e, l = (r = t == null ? void 0 : t.options) != null ? r : {
    passive: !0
  }, i = (u = n.instance) == null ? void 0 : u.$.uid;
  if (!a || i === void 0) return;
  const o = Fh(n.value);
  a._touchHandlers = (c = a._touchHandlers) != null ? c : /* @__PURE__ */ Object.create(null), a._touchHandlers[i] = o, iu(o).forEach((s) => {
    a.addEventListener(s, o[s], l);
  });
}
function Nh(e, n) {
  var i, o;
  const t = (i = n.value) != null && i.parent ? e.parentElement : e, a = (o = n.instance) == null ? void 0 : o.$.uid;
  if (!(t != null && t._touchHandlers) || a === void 0) return;
  const l = t._touchHandlers[a];
  iu(l).forEach((r) => {
    t.removeEventListener(r, l[r]);
  }), delete t._touchHandlers[a];
}
const Vi = {
  mounted: Oh,
  unmounted: Nh
}, uc = Symbol.for("vuetify:v-window"), sc = Symbol.for("vuetify:v-window-group"), _l = N(v(v(v({
  continuous: Boolean,
  nextIcon: {
    type: [Boolean, String, Function, Object],
    default: "$next"
  },
  prevIcon: {
    type: [Boolean, String, Function, Object],
    default: "$prev"
  },
  reverse: Boolean,
  showArrows: {
    type: [Boolean, String],
    validator: (e) => typeof e == "boolean" || e === "hover"
  },
  verticalArrows: [Boolean, String],
  touch: {
    type: [Object, Boolean],
    default: void 0
  },
  direction: {
    type: String,
    default: "horizontal"
  },
  modelValue: null,
  disabled: Boolean,
  selectedClass: {
    type: String,
    default: "v-window-item--active"
  },
  // TODO: mandatory should probably not be exposed but do this for now
  mandatory: {
    type: [Boolean, String],
    default: "force"
  }
}, de()), ke()), Ie()), "VWindow"), Sn = Y()({
  name: "VWindow",
  directives: {
    vTouch: Vi
  },
  props: _l(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      isRtl: l
    } = Xe(), {
      t: i
    } = Ee(), o = on(e, sc), r = Q(), u = C(() => l.value ? !e.reverse : e.reverse), c = te(!1), s = C(() => {
      const V = e.direction === "vertical" ? "y" : "x", I = (u.value ? !c.value : c.value) ? "-reverse" : "";
      return `v-window-${V}${I}-transition`;
    }), d = te(0), f = Q(void 0), m = C(() => o.items.value.findIndex((V) => o.selected.value.includes(V.id)));
    oe(m, (V, x) => {
      const I = o.items.value.length, T = I - 1;
      I <= 2 ? c.value = V < x : V === T && x === 0 ? c.value = !0 : V === 0 && x === T ? c.value = !1 : c.value = V < x;
    }), Oe(uc, {
      transition: s,
      isReversed: c,
      transitionCount: d,
      transitionHeight: f,
      rootRef: r
    });
    const h = M(() => e.continuous || m.value !== 0), b = M(() => e.continuous || m.value !== o.items.value.length - 1);
    function g() {
      h.value && o.prev();
    }
    function S() {
      b.value && o.next();
    }
    const y = C(() => {
      const V = [], x = {
        icon: l.value ? e.nextIcon : e.prevIcon,
        class: `v-window__${u.value ? "right" : "left"}`,
        onClick: o.prev,
        "aria-label": i("$vuetify.carousel.prev")
      };
      V.push(h.value ? t.prev ? t.prev({
        props: x
      }) : k(xe, x, null) : w("div", null, null));
      const I = {
        icon: l.value ? e.prevIcon : e.nextIcon,
        class: `v-window__${u.value ? "left" : "right"}`,
        onClick: o.next,
        "aria-label": i("$vuetify.carousel.next")
      };
      return V.push(b.value ? t.next ? t.next({
        props: I
      }) : k(xe, I, null) : w("div", null, null)), V;
    }), P = C(() => e.touch === !1 ? e.touch : v(v({}, {
      left: () => {
        u.value ? g() : S();
      },
      right: () => {
        u.value ? S() : g();
      },
      start: (x) => {
        let {
          originalEvent: I
        } = x;
        I.stopPropagation();
      }
    }), e.touch === !0 ? {} : e.touch));
    return Z(() => Re(k(e.tag, {
      ref: r,
      class: X(["v-window", {
        "v-window--show-arrows-on-hover": e.showArrows === "hover",
        "v-window--vertical-arrows": !!e.verticalArrows
      }, a.value, e.class]),
      style: ie(e.style)
    }, {
      default: () => {
        var V, x;
        return [w("div", {
          class: "v-window__container",
          style: {
            height: f.value
          }
        }, [(V = t.default) == null ? void 0 : V.call(t, {
          group: o
        }), e.showArrows !== !1 && w("div", {
          class: X(["v-window__controls", {
            "v-window__controls--left": e.verticalArrows === "left" || e.verticalArrows === !0
          }, {
            "v-window__controls--right": e.verticalArrows === "right"
          }])
        }, [y.value])]), (x = t.additional) == null ? void 0 : x.call(t, {
          group: o
        })];
      }
    }), [[Vi, P.value]])), {
      group: o
    };
  }
}), Rh = N(v({
  color: String,
  cycle: Boolean,
  delimiterIcon: {
    type: me,
    default: "$delimiter"
  },
  height: {
    type: [Number, String],
    default: 500
  },
  hideDelimiters: Boolean,
  hideDelimiterBackground: Boolean,
  interval: {
    type: [Number, String],
    default: 6e3,
    validator: (e) => Number(e) > 0
  },
  progress: [Boolean, String],
  verticalDelimiters: [Boolean, String]
}, _l({
  continuous: !0,
  mandatory: "force",
  showArrows: !0
})), "VCarousel"), Hh = Y()({
  name: "VCarousel",
  props: Rh(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), {
      t: l
    } = Ee(), i = Q();
    let o = -1;
    oe(a, u), oe(() => e.interval, u), oe(() => e.cycle, (c) => {
      c ? u() : window.clearTimeout(o);
    }), gt(r);
    function r() {
      !e.cycle || !i.value || (o = window.setTimeout(i.value.group.next, Number(e.interval) > 0 ? Number(e.interval) : 6e3));
    }
    function u() {
      window.clearTimeout(o), window.requestAnimationFrame(r);
    }
    return Z(() => {
      const c = Sn.filterProps(e);
      return k(Sn, G({
        ref: i
      }, c, {
        modelValue: a.value,
        "onUpdate:modelValue": (s) => a.value = s,
        class: ["v-carousel", {
          "v-carousel--hide-delimiter-background": e.hideDelimiterBackground,
          "v-carousel--vertical-delimiters": e.verticalDelimiters
        }, e.class],
        style: [{
          height: ce(e.height)
        }, e.style]
      }), {
        default: t.default,
        additional: (s) => {
          let {
            group: d
          } = s;
          return w(he, null, [!e.hideDelimiters && w("div", {
            class: "v-carousel__controls",
            style: {
              left: e.verticalDelimiters === "left" && e.verticalDelimiters ? 0 : "auto",
              right: e.verticalDelimiters === "right" ? 0 : "auto"
            }
          }, [d.items.value.length > 0 && k(Ce, {
            defaults: {
              VBtn: {
                color: e.color,
                icon: e.delimiterIcon,
                size: "x-small",
                variant: "text"
              }
            },
            scoped: !0
          }, {
            default: () => [d.items.value.map((f, m) => {
              const h = {
                id: `carousel-item-${f.id}`,
                "aria-label": l("$vuetify.carousel.ariaLabel.delimiter", m + 1, d.items.value.length),
                class: ["v-carousel__controls__item", d.isSelected(f.id) && "v-btn--active"],
                onClick: () => d.select(f.id, !0)
              };
              return t.item ? t.item({
                props: h,
                item: f
              }) : k(xe, G(f, h), null);
            })]
          })]), e.progress && k(wl, {
            absolute: !0,
            class: "v-carousel__progress",
            color: typeof e.progress == "string" ? e.progress : void 0,
            modelValue: (d.getItemIndex(a.value) + 1) / d.items.value.length * 100
          }, null)]);
        },
        prev: t.prev,
        next: t.next
      });
    }), {};
  }
}), Al = N(v(v(v({
  reverseTransition: {
    type: [Boolean, String],
    default: void 0
  },
  transition: {
    type: [Boolean, String],
    default: void 0
  }
}, de()), Bn()), wo()), "VWindowItem"), kn = Y()({
  name: "VWindowItem",
  directives: {
    vTouch: Vi
  },
  props: Al(),
  emits: {
    "group:selected": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Pe(uc), l = Dn(e, sc), {
      isBooted: i
    } = An();
    if (!a || !l) throw new Error("[Vuetify] VWindowItem must be used inside VWindow");
    const o = te(!1), r = C(() => i.value && (a.isReversed.value ? e.reverseTransition !== !1 : e.transition !== !1));
    function u() {
      !o.value || !a || (o.value = !1, a.transitionCount.value > 0 && (a.transitionCount.value -= 1, a.transitionCount.value === 0 && (a.transitionHeight.value = void 0)));
    }
    function c() {
      var h;
      o.value || !a || (o.value = !0, a.transitionCount.value === 0 && (a.transitionHeight.value = ce((h = a.rootRef.value) == null ? void 0 : h.clientHeight)), a.transitionCount.value += 1);
    }
    function s() {
      u();
    }
    function d(h) {
      o.value && Ve(() => {
        !r.value || !o.value || !a || (a.transitionHeight.value = ce(h.clientHeight));
      });
    }
    const f = C(() => {
      const h = a.isReversed.value ? e.reverseTransition : e.transition;
      return r.value ? {
        name: typeof h != "string" ? a.transition.value : h,
        onBeforeEnter: c,
        onAfterEnter: u,
        onEnterCancelled: s,
        onBeforeLeave: c,
        onAfterLeave: u,
        onLeaveCancelled: s,
        onEnter: d
      } : !1;
    }), {
      hasContent: m
    } = Co(e, l.isSelected);
    return Z(() => k(ft, {
      transition: f.value,
      disabled: !i.value
    }, {
      default: () => {
        var h;
        return [Re(w("div", {
          class: X(["v-window-item", l.selectedClass.value, e.class]),
          style: ie(e.style)
        }, [m.value && ((h = t.default) == null ? void 0 : h.call(t))]), [[$t, l.isSelected.value]])];
      }
    })), {
      groupItem: l
    };
  }
}), zh = N(v(v({}, Xu()), Al()), "VCarouselItem"), Wh = Y()({
  name: "VCarouselItem",
  inheritAttrs: !1,
  props: zh(),
  setup(e, n) {
    let {
      slots: t,
      attrs: a
    } = n;
    Z(() => {
      const l = Ut.filterProps(e), i = kn.filterProps(e);
      return k(kn, G({
        class: ["v-carousel-item", e.class]
      }, i), {
        default: () => [k(Ut, G(a, l), t)]
      });
    });
  }
}), jh = Xt("v-code", "code"), Yh = N(v({
  color: {
    type: Object
  },
  disabled: Boolean,
  dotSize: {
    type: [Number, String],
    default: 10
  },
  height: {
    type: [Number, String],
    default: 150
  },
  width: {
    type: [Number, String],
    default: 300
  }
}, de()), "VColorPickerCanvas"), Gh = _t({
  name: "VColorPickerCanvas",
  props: Yh(),
  emits: {
    "update:color": (e) => !0,
    "update:position": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    const a = te(!1), l = Q(), i = te(parseFloat(e.width)), o = te(parseFloat(e.height)), r = Q({
      x: 0,
      y: 0
    }), u = C({
      get: () => r.value,
      set(g) {
        var P, V, x, I;
        if (!l.value) return;
        const {
          x: S,
          y
        } = g;
        r.value = g, t("update:color", {
          h: (V = (P = e.color) == null ? void 0 : P.h) != null ? V : 0,
          s: Fe(S, 0, i.value) / i.value,
          v: 1 - Fe(y, 0, o.value) / o.value,
          a: (I = (x = e.color) == null ? void 0 : x.a) != null ? I : 1
        });
      }
    }), c = C(() => {
      const {
        x: g,
        y: S
      } = u.value, y = parseInt(e.dotSize, 10) / 2;
      return {
        width: ce(e.dotSize),
        height: ce(e.dotSize),
        transform: `translate(${ce(g - y)}, ${ce(S - y)})`
      };
    }), {
      resizeRef: s
    } = pt((g) => {
      var P;
      if (!((P = s.el) != null && P.offsetParent)) return;
      const {
        width: S,
        height: y
      } = g[0].contentRect;
      i.value = S, o.value = y;
    });
    function d(g, S, y) {
      const {
        left: P,
        top: V,
        width: x,
        height: I
      } = y;
      u.value = {
        x: Fe(g - P, 0, x),
        y: Fe(S - V, 0, I)
      };
    }
    function f(g) {
      g.type === "mousedown" && g.preventDefault(), !e.disabled && (m(g), window.addEventListener("mousemove", m), window.addEventListener("mouseup", h), window.addEventListener("touchmove", m), window.addEventListener("touchend", h));
    }
    function m(g) {
      if (e.disabled || !l.value) return;
      a.value = !0;
      const S = ev(g);
      d(S.clientX, S.clientY, l.value.getBoundingClientRect());
    }
    function h() {
      window.removeEventListener("mousemove", m), window.removeEventListener("mouseup", h), window.removeEventListener("touchmove", m), window.removeEventListener("touchend", h);
    }
    function b() {
      var V, x;
      if (!l.value) return;
      const g = l.value, S = g.getContext("2d");
      if (!S) return;
      const y = S.createLinearGradient(0, 0, g.width, 0);
      y.addColorStop(0, "hsla(0, 0%, 100%, 1)"), y.addColorStop(1, `hsla(${(x = (V = e.color) == null ? void 0 : V.h) != null ? x : 0}, 100%, 50%, 1)`), S.fillStyle = y, S.fillRect(0, 0, g.width, g.height);
      const P = S.createLinearGradient(0, 0, 0, g.height);
      P.addColorStop(0, "hsla(0, 0%, 0%, 0)"), P.addColorStop(1, "hsla(0, 0%, 0%, 1)"), S.fillStyle = P, S.fillRect(0, 0, g.width, g.height);
    }
    return oe(() => {
      var g;
      return (g = e.color) == null ? void 0 : g.h;
    }, b, {
      immediate: !0
    }), oe(() => [i.value, o.value], (g, S) => {
      b(), r.value = {
        x: u.value.x * g[0] / S[0],
        y: u.value.y * g[1] / S[1]
      };
    }, {
      flush: "post"
    }), oe(() => e.color, () => {
      if (a.value) {
        a.value = !1;
        return;
      }
      r.value = e.color ? {
        x: e.color.s * i.value,
        y: (1 - e.color.v) * o.value
      } : {
        x: 0,
        y: 0
      };
    }, {
      deep: !0,
      immediate: !0
    }), gt(() => b()), Z(() => w("div", {
      ref: s,
      class: X(["v-color-picker-canvas", e.class]),
      style: ie(e.style),
      onMousedown: f,
      onTouchstartPassive: f
    }, [w("canvas", {
      ref: l,
      width: i.value,
      height: o.value
    }, null), e.color && w("div", {
      class: X(["v-color-picker-canvas__dot", {
        "v-color-picker-canvas__dot--disabled": e.disabled
      }]),
      style: ie(c.value)
    }, null)])), {};
  }
});
function Uh(e, n) {
  if (n) {
    const t = e, {
      a
    } = t;
    return Ge(t, [
      "a"
    ]);
  }
  return e;
}
function Kh(e, n) {
  if (n == null || typeof n == "string") {
    const t = e.a !== 1;
    if (n != null && n.startsWith("rgb(")) {
      const {
        r: l,
        g: i,
        b: o,
        a: r
      } = Rt(e);
      return `rgb(${l} ${i} ${o}` + (t ? ` / ${r})` : ")");
    } else if (n != null && n.startsWith("hsl(")) {
      const {
        h: l,
        s: i,
        l: o,
        a: r
      } = oi(e);
      return `hsl(${l} ${Math.round(i * 100)} ${Math.round(o * 100)}` + (t ? ` / ${r})` : ")");
    }
    const a = xu(e);
    return e.a === 1 ? a.slice(0, 7) : a;
  }
  if (typeof n == "object") {
    let t;
    return cn(n, ["r", "g", "b"]) ? t = Rt(e) : cn(n, ["h", "s", "l"]) ? t = oi(e) : cn(n, ["h", "s", "v"]) && (t = e), Uh(t, !cn(n, ["a"]) && e.a === 1);
  }
  return e;
}
const Rn = {
  h: 0,
  s: 0,
  v: 0,
  a: 1
}, Pi = {
  inputProps: {
    type: "number",
    min: 0
  },
  inputs: [{
    label: "R",
    max: 255,
    step: 1,
    getValue: (e) => Math.round(e.r),
    getColor: (e, n) => le(v({}, e), {
      r: Number(n)
    }),
    localeKey: "redInput"
  }, {
    label: "G",
    max: 255,
    step: 1,
    getValue: (e) => Math.round(e.g),
    getColor: (e, n) => le(v({}, e), {
      g: Number(n)
    }),
    localeKey: "greenInput"
  }, {
    label: "B",
    max: 255,
    step: 1,
    getValue: (e) => Math.round(e.b),
    getColor: (e, n) => le(v({}, e), {
      b: Number(n)
    }),
    localeKey: "blueInput"
  }, {
    label: "A",
    max: 1,
    step: 0.01,
    getValue: (e) => {
      let {
        a: n
      } = e;
      return n != null ? Math.round(n * 100) / 100 : 1;
    },
    getColor: (e, n) => le(v({}, e), {
      a: Number(n)
    }),
    localeKey: "alphaInput"
  }],
  to: Rt,
  from: Aa
};
var tu;
const qh = le(v({}, Pi), {
  inputs: (tu = Pi.inputs) == null ? void 0 : tu.slice(0, 3)
}), Ii = {
  inputProps: {
    type: "number",
    min: 0
  },
  inputs: [{
    label: "H",
    max: 360,
    step: 1,
    getValue: (e) => Math.round(e.h),
    getColor: (e, n) => le(v({}, e), {
      h: Number(n)
    }),
    localeKey: "hueInput"
  }, {
    label: "S",
    max: 1,
    step: 0.01,
    getValue: (e) => Math.round(e.s * 100) / 100,
    getColor: (e, n) => le(v({}, e), {
      s: Number(n)
    }),
    localeKey: "saturationInput"
  }, {
    label: "L",
    max: 1,
    step: 0.01,
    getValue: (e) => Math.round(e.l * 100) / 100,
    getColor: (e, n) => le(v({}, e), {
      l: Number(n)
    }),
    localeKey: "lightnessInput"
  }, {
    label: "A",
    max: 1,
    step: 0.01,
    getValue: (e) => {
      let {
        a: n
      } = e;
      return n != null ? Math.round(n * 100) / 100 : 1;
    },
    getColor: (e, n) => le(v({}, e), {
      a: Number(n)
    }),
    localeKey: "alphaInput"
  }],
  to: oi,
  from: Qi
}, Xh = le(v({}, Ii), {
  inputs: Ii.inputs.slice(0, 3)
}), cc = {
  inputProps: {
    type: "text"
  },
  inputs: [{
    label: "HEXA",
    getValue: (e) => e,
    getColor: (e, n) => n,
    localeKey: "hexaInput"
  }],
  to: xu,
  from: Pv
}, Zh = le(v({}, cc), {
  inputs: [{
    label: "HEX",
    getValue: (e) => e.slice(0, 7),
    getColor: (e, n) => n,
    localeKey: "hexInput"
  }]
}), gn = {
  rgb: qh,
  rgba: Pi,
  hsl: Xh,
  hsla: Ii,
  hex: Zh,
  hexa: cc
}, Qh = (e) => {
  let a = e, {
    label: n
  } = a, t = Ge(a, [
    "label"
  ]);
  return w("div", {
    class: "v-color-picker-edit__input"
  }, [w("input", zd(Wd(t)), null), w("span", null, [n])]);
}, Jh = N(v({
  color: Object,
  disabled: Boolean,
  mode: {
    type: String,
    default: "rgba",
    validator: (e) => Object.keys(gn).includes(e)
  },
  modes: {
    type: Array,
    default: () => Object.keys(gn),
    validator: (e) => Array.isArray(e) && e.every((n) => Object.keys(gn).includes(n))
  }
}, de()), "VColorPickerEdit"), ey = _t({
  name: "VColorPickerEdit",
  props: Jh(),
  emits: {
    "update:color": (e) => !0,
    "update:mode": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    const {
      t: a
    } = Ee(), l = C(() => e.modes.map((o) => le(v({}, gn[o]), {
      name: o
    }))), i = C(() => {
      var u;
      const o = l.value.find((c) => c.name === e.mode);
      if (!o) return [];
      const r = e.color ? o.to(e.color) : null;
      return (u = o.inputs) == null ? void 0 : u.map((c) => {
        let h = c, {
          getValue: s,
          getColor: d,
          localeKey: f
        } = h, m = Ge(h, [
          "getValue",
          "getColor",
          "localeKey"
        ]);
        return le(v(v({}, o.inputProps), m), {
          ariaLabel: a(`$vuetify.colorPicker.ariaLabel.${f}`),
          disabled: e.disabled,
          value: r && s(r),
          onChange: (b) => {
            const g = b.target;
            g && t("update:color", o.from(d(r != null ? r : o.to(Rn), g.value)));
          }
        });
      });
    });
    return Z(() => {
      var o;
      return w("div", {
        class: X(["v-color-picker-edit", e.class]),
        style: ie(e.style)
      }, [(o = i.value) == null ? void 0 : o.map((r) => k(Qh, r, null)), l.value.length > 1 && k(xe, {
        icon: "$unfold",
        size: "x-small",
        variant: "plain",
        "aria-label": a("$vuetify.colorPicker.ariaLabel.changeFormat"),
        onClick: () => {
          const r = l.value.findIndex((u) => u.name === e.mode);
          t("update:mode", l.value[(r + 1) % l.value.length].name);
        }
      }, null)]);
    }), {};
  }
}), Io = Symbol.for("vuetify:v-slider");
function _i(e, n, t) {
  const a = t === "vertical", l = n.getBoundingClientRect(), i = "touches" in e ? e.touches[0] : e;
  return a ? i.clientY - (l.top + l.height / 2) : i.clientX - (l.left + l.width / 2);
}
function ty(e, n) {
  return "touches" in e && e.touches.length ? e.touches[0][n] : "changedTouches" in e && e.changedTouches.length ? e.changedTouches[0][n] : e[n];
}
const dc = N(le(v(v({
  disabled: {
    type: Boolean,
    default: null
  },
  error: Boolean,
  readonly: {
    type: Boolean,
    default: null
  },
  max: {
    type: [Number, String],
    default: 100
  },
  min: {
    type: [Number, String],
    default: 0
  },
  step: {
    type: [Number, String],
    default: 0
  },
  thumbColor: String,
  thumbLabel: {
    type: [Boolean, String],
    default: void 0,
    validator: (e) => typeof e == "boolean" || e === "always"
  },
  thumbSize: {
    type: [Number, String],
    default: 20
  },
  showTicks: {
    type: [Boolean, String],
    default: !1,
    validator: (e) => typeof e == "boolean" || e === "always"
  },
  ticks: {
    type: [Array, Object]
  },
  tickSize: {
    type: [Number, String],
    default: 2
  },
  color: String,
  trackColor: String,
  trackFillColor: String,
  trackSize: {
    type: [Number, String],
    default: 4
  },
  direction: {
    type: String,
    default: "horizontal",
    validator: (e) => ["vertical", "horizontal"].includes(e)
  },
  reverse: Boolean,
  noKeyboard: Boolean
}, Ne()), Je({
  elevation: 2
})), {
  ripple: {
    type: Boolean,
    default: !0
  }
}), "Slider"), vc = (e) => {
  const n = C(() => parseFloat(e.min)), t = C(() => parseFloat(e.max)), a = C(() => Number(e.step) > 0 ? parseFloat(e.step) : 0), l = C(() => Math.max(Qo(a.value), Qo(n.value)));
  function i(o) {
    if (o = parseFloat(o), a.value <= 0) return o;
    const r = Fe(o, n.value, t.value), u = n.value % a.value;
    let c = Math.round((r - u) / a.value) * a.value + u;
    return r > c && c + a.value > t.value && (c = t.value), parseFloat(Math.min(c, t.value).toFixed(l.value));
  }
  return {
    min: n,
    max: t,
    step: a,
    decimals: l,
    roundValue: i
  };
}, fc = (e) => {
  let {
    props: n,
    steps: t,
    onSliderStart: a,
    onSliderMove: l,
    onSliderEnd: i,
    getActiveThumb: o
  } = e;
  const {
    isRtl: r
  } = Xe(), u = M(() => n.reverse), c = C(() => n.direction === "vertical"), s = C(() => c.value !== u.value), {
    min: d,
    max: f,
    step: m,
    decimals: h,
    roundValue: b
  } = t, g = C(() => parseInt(n.thumbSize, 10)), S = C(() => parseInt(n.tickSize, 10)), y = C(() => parseInt(n.trackSize, 10)), P = C(() => (f.value - d.value) / m.value), V = M(() => n.disabled), x = C(() => {
    var j;
    return n.error || n.disabled ? void 0 : (j = n.thumbColor) != null ? j : n.color;
  }), I = C(() => n.error || n.disabled ? void 0 : n.thumbColor), T = C(() => {
    var j;
    return n.error || n.disabled ? void 0 : (j = n.trackColor) != null ? j : n.color;
  }), _ = C(() => {
    var j;
    return n.error || n.disabled ? void 0 : (j = n.trackFillColor) != null ? j : n.color;
  }), p = te(!1), L = te(0), D = Q(), A = Q();
  function B(j) {
    var we;
    const ue = (we = D.value) == null ? void 0 : we.$el;
    if (!ue) return;
    const ge = n.direction === "vertical", ee = ge ? "top" : "left", re = ge ? "height" : "width", fe = ge ? "clientY" : "clientX", {
      [ee]: K,
      [re]: se
    } = ue.getBoundingClientRect(), ye = ty(j, fe);
    let be = Fe((ye - K - L.value) / se) || 0;
    return (ge ? s.value : s.value !== r.value) && (be = 1 - be), b(d.value + be * (f.value - d.value));
  }
  const F = (j) => {
    const ue = B(j);
    ue != null && i({
      value: ue
    }), p.value = !1, L.value = 0;
  }, $ = (j) => {
    const ue = B(j);
    A.value = o(j), A.value && (p.value = !0, A.value.contains(j.target) ? L.value = _i(j, A.value, n.direction) : (L.value = 0, ue != null && l({
      value: ue
    })), ue != null && a({
      value: ue
    }), Ve(() => {
      var ge;
      return (ge = A.value) == null ? void 0 : ge.focus();
    }));
  }, W = {
    passive: !0,
    capture: !0
  };
  function J(j) {
    const ue = B(j);
    ue != null && l({
      value: ue
    });
  }
  function z(j) {
    j.stopPropagation(), j.preventDefault(), F(j), window.removeEventListener("mousemove", J, W), window.removeEventListener("mouseup", z);
  }
  function H(j) {
    var ue;
    F(j), window.removeEventListener("touchmove", J, W), (ue = j.target) == null || ue.removeEventListener("touchend", H);
  }
  function E(j) {
    var ue;
    $(j), window.addEventListener("touchmove", J, W), (ue = j.target) == null || ue.addEventListener("touchend", H, {
      passive: !1
    });
  }
  function O(j) {
    j.button === 0 && (j.preventDefault(), $(j), window.addEventListener("mousemove", J, W), window.addEventListener("mouseup", z, {
      passive: !1
    }));
  }
  const R = (j) => {
    const ue = (j - d.value) / (f.value - d.value) * 100;
    return Fe(isNaN(ue) ? 0 : ue, 0, 100);
  }, q = M(() => n.showTicks), ae = C(() => q.value ? n.ticks ? Array.isArray(n.ticks) ? n.ticks.map((j) => ({
    value: j,
    position: R(j),
    label: j.toString()
  })) : Object.keys(n.ticks).map((j) => ({
    value: parseFloat(j),
    position: R(parseFloat(j)),
    label: n.ticks[j]
  })) : P.value !== 1 / 0 ? Vt(P.value + 1).map((j) => {
    const ue = d.value + j * m.value;
    return {
      value: ue,
      position: R(ue)
    };
  }) : [] : []), U = C(() => ae.value.some((j) => {
    let {
      label: ue
    } = j;
    return !!ue;
  })), ne = {
    activeThumbRef: A,
    color: M(() => n.color),
    decimals: h,
    disabled: V,
    direction: M(() => n.direction),
    elevation: M(() => n.elevation),
    hasLabels: U,
    isReversed: u,
    indexFromEnd: s,
    min: d,
    max: f,
    mousePressed: p,
    noKeyboard: M(() => n.noKeyboard),
    numTicks: P,
    onSliderMousedown: O,
    onSliderTouchstart: E,
    parsedTicks: ae,
    parseMouseMove: B,
    position: R,
    readonly: M(() => n.readonly),
    rounded: M(() => n.rounded),
    roundValue: b,
    showTicks: q,
    startOffset: L,
    step: m,
    thumbSize: g,
    thumbColor: x,
    thumbLabelColor: I,
    thumbLabel: M(() => n.thumbLabel),
    ticks: M(() => n.ticks),
    tickSize: S,
    trackColor: T,
    trackContainerRef: D,
    trackFillColor: _,
    trackSize: y,
    vertical: c
  };
  return Oe(Io, ne), ne;
}, ny = N(v({
  focused: Boolean,
  max: {
    type: Number,
    required: !0
  },
  min: {
    type: Number,
    required: !0
  },
  modelValue: {
    type: Number,
    required: !0
  },
  position: {
    type: Number,
    required: !0
  },
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  name: String,
  noKeyboard: Boolean
}, de()), "VSliderThumb"), Ai = Y()({
  name: "VSliderThumb",
  directives: {
    vRipple: bt
  },
  props: ny(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = Pe(Io), {
      isRtl: i,
      rtlClasses: o
    } = Xe();
    if (!l) throw new Error("[Vuetify] v-slider-thumb must be used inside v-slider or v-range-slider");
    const {
      min: r,
      max: u,
      thumbColor: c,
      thumbLabelColor: s,
      step: d,
      disabled: f,
      thumbSize: m,
      thumbLabel: h,
      direction: b,
      isReversed: g,
      vertical: S,
      readonly: y,
      elevation: P,
      mousePressed: V,
      decimals: x,
      indexFromEnd: I
    } = l, T = C(() => f.value ? void 0 : P.value), {
      elevationClasses: _
    } = lt(T), {
      textColorClasses: p,
      textColorStyles: L
    } = rt(c), {
      backgroundColorClasses: D,
      backgroundColorStyles: A
    } = pe(s), {
      pageup: B,
      pagedown: F,
      end: $,
      home: W,
      left: J,
      right: z,
      down: H,
      up: E
    } = ei, O = [B, F, $, W, J, z, H, E], R = C(() => d.value ? [1, 2, 3] : [1, 5, 10]);
    function q(U, ne) {
      if (e.noKeyboard || !O.includes(U.key)) return;
      U.preventDefault();
      const j = d.value || 0.1, ue = (u.value - r.value) / j;
      if ([J, z, H, E].includes(U.key)) {
        const ee = (S.value ? [i.value ? J : z, g.value ? H : E] : I.value !== i.value ? [J, E] : [z, E]).includes(U.key) ? 1 : -1, re = U.shiftKey ? 2 : U.ctrlKey ? 1 : 0;
        ee === -1 && ne === u.value && !re && !Number.isInteger(ue) ? ne = ne - ue % 1 * j : ne = ne + ee * j * R.value[re];
      } else if (U.key === W)
        ne = r.value;
      else if (U.key === $)
        ne = u.value;
      else {
        const ge = U.key === F ? 1 : -1;
        ne = ne - ge * j * (ue > 100 ? ue / 10 : 10);
      }
      return Math.max(e.min, Math.min(e.max, ne));
    }
    function ae(U) {
      const ne = q(U, e.modelValue);
      ne != null && a("update:modelValue", ne);
    }
    return Z(() => {
      const U = ce(I.value ? 100 - e.position : e.position, "%");
      return w("div", {
        class: X(["v-slider-thumb", {
          "v-slider-thumb--focused": e.focused,
          "v-slider-thumb--pressed": e.focused && V.value
        }, e.class, o.value]),
        style: ie([{
          "--v-slider-thumb-position": U,
          "--v-slider-thumb-size": ce(m.value)
        }, e.style]),
        role: "slider",
        tabindex: f.value ? -1 : 0,
        "aria-label": e.name,
        "aria-valuemin": r.value,
        "aria-valuemax": u.value,
        "aria-valuenow": e.modelValue,
        "aria-readonly": !!y.value,
        "aria-orientation": b.value,
        onKeydown: y.value ? void 0 : ae
      }, [w("div", {
        class: X(["v-slider-thumb__surface", p.value, _.value]),
        style: ie(L.value)
      }, null), Re(w("div", {
        class: X(["v-slider-thumb__ripple", p.value]),
        style: ie(L.value)
      }, null), [[bt, e.ripple, null, {
        circle: !0,
        center: !0
      }]]), k(ro, {
        origin: "bottom center"
      }, {
        default: () => {
          var ne, j;
          return [Re(w("div", {
            class: "v-slider-thumb__label-container"
          }, [w("div", {
            class: X(["v-slider-thumb__label", D.value]),
            style: ie(A.value)
          }, [w("div", null, [(j = (ne = t["thumb-label"]) == null ? void 0 : ne.call(t, {
            modelValue: e.modelValue
          })) != null ? j : e.modelValue.toFixed(d.value ? x.value : 1)]), w("div", {
            class: "v-slider-thumb__label-wedge"
          }, null)])]), [[$t, h.value && e.focused || h.value === "always"]])];
        }
      })]);
    }), {};
  }
}), ay = N(v({
  start: {
    type: Number,
    required: !0
  },
  stop: {
    type: Number,
    required: !0
  }
}, de()), "VSliderTrack"), mc = Y()({
  name: "VSliderTrack",
  props: ay(),
  emits: {},
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Pe(Io);
    if (!a) throw new Error("[Vuetify] v-slider-track must be inside v-slider or v-range-slider");
    const {
      color: l,
      parsedTicks: i,
      rounded: o,
      showTicks: r,
      tickSize: u,
      trackColor: c,
      trackFillColor: s,
      trackSize: d,
      vertical: f,
      min: m,
      max: h,
      indexFromEnd: b
    } = a, {
      roundedClasses: g
    } = Ye(o), {
      backgroundColorClasses: S,
      backgroundColorStyles: y
    } = pe(s), {
      backgroundColorClasses: P,
      backgroundColorStyles: V
    } = pe(c), x = C(() => `inset-${f.value ? "block" : "inline"}-${b.value ? "end" : "start"}`), I = C(() => f.value ? "height" : "width"), T = C(() => ({
      [x.value]: "0%",
      [I.value]: "100%"
    })), _ = C(() => e.stop - e.start), p = C(() => ({
      [x.value]: ce(e.start, "%"),
      [I.value]: ce(_.value, "%")
    })), L = C(() => r.value ? (f.value ? i.value.slice().reverse() : i.value).map((A, B) => {
      var $, W;
      const F = A.value !== m.value && A.value !== h.value ? ce(A.position, "%") : void 0;
      return w("div", {
        key: A.value,
        class: X(["v-slider-track__tick", {
          "v-slider-track__tick--filled": A.position >= e.start && A.position <= e.stop,
          "v-slider-track__tick--first": A.value === m.value,
          "v-slider-track__tick--last": A.value === h.value
        }]),
        style: {
          [x.value]: F
        }
      }, [(A.label || t["tick-label"]) && w("div", {
        class: "v-slider-track__tick-label"
      }, [(W = ($ = t["tick-label"]) == null ? void 0 : $.call(t, {
        tick: A,
        index: B
      })) != null ? W : A.label])]);
    }) : []);
    return Z(() => w("div", {
      class: X(["v-slider-track", g.value, e.class]),
      style: ie([{
        "--v-slider-track-size": ce(d.value),
        "--v-slider-tick-size": ce(u.value)
      }, e.style])
    }, [w("div", {
      class: X(["v-slider-track__background", P.value, {
        "v-slider-track__background--opacity": !!l.value || !s.value
      }]),
      style: v(v({}, T.value), V.value)
    }, null), w("div", {
      class: X(["v-slider-track__fill", S.value]),
      style: v(v({}, p.value), y.value)
    }, null), r.value && w("div", {
      class: X(["v-slider-track__ticks", {
        "v-slider-track__ticks--always-show": r.value === "always"
      }])
    }, [L.value])])), {};
  }
}), ly = N(le(v(v(v({}, Ea()), dc()), Jt()), {
  modelValue: {
    type: [Number, String],
    default: 0
  }
}), "VSlider"), Li = Y()({
  name: "VSlider",
  props: ly(),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0,
    start: (e) => !0,
    end: (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = Q(), i = Q(), {
      rtlClasses: o
    } = Xe(), r = vc(e), u = ve(e, "modelValue", void 0, (_) => r.roundValue(_ == null ? r.min.value : _)), {
      min: c,
      max: s,
      mousePressed: d,
      roundValue: f,
      onSliderMousedown: m,
      onSliderTouchstart: h,
      trackContainerRef: b,
      position: g,
      hasLabels: S,
      readonly: y,
      noKeyboard: P
    } = fc({
      props: e,
      steps: r,
      onSliderStart: () => {
        a("start", u.value);
      },
      onSliderEnd: (_) => {
        let {
          value: p
        } = _;
        const L = f(p);
        u.value = L, a("end", L);
      },
      onSliderMove: (_) => {
        let {
          value: p
        } = _;
        return u.value = f(p);
      },
      getActiveThumb: () => {
        var _;
        return (_ = l.value) == null ? void 0 : _.$el;
      }
    }), {
      isFocused: V,
      focus: x,
      blur: I
    } = Qt(e), T = C(() => g(u.value));
    return Z(() => {
      const _ = ct.filterProps(e), p = !!(e.label || t.label || t.prepend);
      return k(ct, G({
        ref: i,
        class: ["v-slider", {
          "v-slider--has-labels": !!t["tick-label"] || S.value,
          "v-slider--focused": V.value,
          "v-slider--pressed": d.value,
          "v-slider--disabled": e.disabled
        }, o.value, e.class],
        style: e.style
      }, _, {
        focused: V.value
      }), le(v({}, t), {
        prepend: p ? (L) => {
          var D, A, B;
          return w(he, null, [(A = (D = t.label) == null ? void 0 : D.call(t, L)) != null ? A : e.label ? k(ta, {
            id: L.id.value,
            class: "v-slider__label",
            text: e.label
          }, null) : void 0, (B = t.prepend) == null ? void 0 : B.call(t, L)]);
        } : void 0,
        default: (L) => {
          let {
            id: D,
            messagesId: A
          } = L;
          return w("div", {
            class: "v-slider__container",
            onMousedown: y.value ? void 0 : m,
            onTouchstartPassive: y.value ? void 0 : h
          }, [w("input", {
            id: D.value,
            name: e.name || D.value,
            disabled: !!e.disabled,
            readonly: !!e.readonly,
            tabindex: "-1",
            value: u.value
          }, null), k(mc, {
            ref: b,
            start: 0,
            stop: T.value
          }, {
            "tick-label": t["tick-label"]
          }), k(Ai, {
            ref: l,
            "aria-describedby": A.value,
            focused: V.value,
            noKeyboard: P.value,
            min: c.value,
            max: s.value,
            modelValue: u.value,
            "onUpdate:modelValue": (B) => u.value = B,
            position: T.value,
            elevation: e.elevation,
            onFocus: x,
            onBlur: I,
            ripple: e.ripple,
            name: e.name
          }, {
            "thumb-label": t["thumb-label"]
          })]);
        }
      }));
    }), it({
      focus: () => {
        var _;
        return (_ = l.value) == null ? void 0 : _.$el.focus();
      }
    }, i);
  }
}), iy = N(v({
  color: {
    type: Object
  },
  disabled: Boolean,
  hideAlpha: Boolean
}, de()), "VColorPickerPreview"), oy = _t({
  name: "VColorPickerPreview",
  props: iy(),
  emits: {
    "update:color": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    const {
      t: a
    } = Ee(), l = new AbortController();
    jd(() => l.abort());
    function i() {
      return He(this, null, function* () {
        var r;
        if (!Ko || e.disabled) return;
        const o = new window.EyeDropper();
        try {
          const u = yield o.open({
            signal: l.signal
          }), c = Aa(Pt(u.sRGBHex));
          t("update:color", v(v({}, (r = e.color) != null ? r : Rn), c));
        } catch (u) {
        }
      });
    }
    return Z(() => {
      var o, r, u, c;
      return w("div", {
        class: X(["v-color-picker-preview", {
          "v-color-picker-preview--hide-alpha": e.hideAlpha
        }, e.class]),
        style: ie(e.style)
      }, [Ko && w("div", {
        class: "v-color-picker-preview__eye-dropper",
        key: "eyeDropper"
      }, [k(xe, {
        "aria-label": a("$vuetify.colorPicker.ariaLabel.eyedropper"),
        density: "comfortable",
        disabled: e.disabled,
        icon: "$eyeDropper",
        variant: "plain",
        onClick: i
      }, null)]), w("div", {
        class: "v-color-picker-preview__dot"
      }, [w("div", {
        style: {
          background: ku((o = e.color) != null ? o : Rn)
        }
      }, null)]), w("div", {
        class: "v-color-picker-preview__sliders"
      }, [k(Li, {
        class: "v-color-picker-preview__track v-color-picker-preview__hue",
        name: a("$vuetify.colorPicker.ariaLabel.hueSlider"),
        modelValue: (r = e.color) == null ? void 0 : r.h,
        "onUpdate:modelValue": (s) => {
          var d;
          return t("update:color", le(v({}, (d = e.color) != null ? d : Rn), {
            h: s
          }));
        },
        step: 0,
        min: 0,
        max: 360,
        disabled: e.disabled,
        thumbSize: 14,
        trackSize: 8,
        trackFillColor: "white",
        hideDetails: !0
      }, null), !e.hideAlpha && k(Li, {
        class: "v-color-picker-preview__track v-color-picker-preview__alpha",
        name: a("$vuetify.colorPicker.ariaLabel.alphaSlider"),
        modelValue: (c = (u = e.color) == null ? void 0 : u.a) != null ? c : 1,
        "onUpdate:modelValue": (s) => {
          var d;
          return t("update:color", le(v({}, (d = e.color) != null ? d : Rn), {
            a: s
          }));
        },
        step: 1 / 256,
        min: 0,
        max: 1,
        disabled: e.disabled,
        thumbSize: 14,
        trackSize: 8,
        trackFillColor: "white",
        hideDetails: !0
      }, null)])]);
    }), {};
  }
}), ry = {
  base: "#f44336",
  lighten5: "#ffebee",
  lighten4: "#ffcdd2",
  lighten3: "#ef9a9a",
  lighten2: "#e57373",
  lighten1: "#ef5350",
  darken1: "#e53935",
  darken2: "#d32f2f",
  darken3: "#c62828",
  darken4: "#b71c1c",
  accent1: "#ff8a80",
  accent2: "#ff5252",
  accent3: "#ff1744",
  accent4: "#d50000"
}, uy = {
  base: "#e91e63",
  lighten5: "#fce4ec",
  lighten4: "#f8bbd0",
  lighten3: "#f48fb1",
  lighten2: "#f06292",
  lighten1: "#ec407a",
  darken1: "#d81b60",
  darken2: "#c2185b",
  darken3: "#ad1457",
  darken4: "#880e4f",
  accent1: "#ff80ab",
  accent2: "#ff4081",
  accent3: "#f50057",
  accent4: "#c51162"
}, sy = {
  base: "#9c27b0",
  lighten5: "#f3e5f5",
  lighten4: "#e1bee7",
  lighten3: "#ce93d8",
  lighten2: "#ba68c8",
  lighten1: "#ab47bc",
  darken1: "#8e24aa",
  darken2: "#7b1fa2",
  darken3: "#6a1b9a",
  darken4: "#4a148c",
  accent1: "#ea80fc",
  accent2: "#e040fb",
  accent3: "#d500f9",
  accent4: "#aa00ff"
}, cy = {
  base: "#673ab7",
  lighten5: "#ede7f6",
  lighten4: "#d1c4e9",
  lighten3: "#b39ddb",
  lighten2: "#9575cd",
  lighten1: "#7e57c2",
  darken1: "#5e35b1",
  darken2: "#512da8",
  darken3: "#4527a0",
  darken4: "#311b92",
  accent1: "#b388ff",
  accent2: "#7c4dff",
  accent3: "#651fff",
  accent4: "#6200ea"
}, dy = {
  base: "#3f51b5",
  lighten5: "#e8eaf6",
  lighten4: "#c5cae9",
  lighten3: "#9fa8da",
  lighten2: "#7986cb",
  lighten1: "#5c6bc0",
  darken1: "#3949ab",
  darken2: "#303f9f",
  darken3: "#283593",
  darken4: "#1a237e",
  accent1: "#8c9eff",
  accent2: "#536dfe",
  accent3: "#3d5afe",
  accent4: "#304ffe"
}, vy = {
  base: "#2196f3",
  lighten5: "#e3f2fd",
  lighten4: "#bbdefb",
  lighten3: "#90caf9",
  lighten2: "#64b5f6",
  lighten1: "#42a5f5",
  darken1: "#1e88e5",
  darken2: "#1976d2",
  darken3: "#1565c0",
  darken4: "#0d47a1",
  accent1: "#82b1ff",
  accent2: "#448aff",
  accent3: "#2979ff",
  accent4: "#2962ff"
}, fy = {
  base: "#03a9f4",
  lighten5: "#e1f5fe",
  lighten4: "#b3e5fc",
  lighten3: "#81d4fa",
  lighten2: "#4fc3f7",
  lighten1: "#29b6f6",
  darken1: "#039be5",
  darken2: "#0288d1",
  darken3: "#0277bd",
  darken4: "#01579b",
  accent1: "#80d8ff",
  accent2: "#40c4ff",
  accent3: "#00b0ff",
  accent4: "#0091ea"
}, my = {
  base: "#00bcd4",
  lighten5: "#e0f7fa",
  lighten4: "#b2ebf2",
  lighten3: "#80deea",
  lighten2: "#4dd0e1",
  lighten1: "#26c6da",
  darken1: "#00acc1",
  darken2: "#0097a7",
  darken3: "#00838f",
  darken4: "#006064",
  accent1: "#84ffff",
  accent2: "#18ffff",
  accent3: "#00e5ff",
  accent4: "#00b8d4"
}, gy = {
  base: "#009688",
  lighten5: "#e0f2f1",
  lighten4: "#b2dfdb",
  lighten3: "#80cbc4",
  lighten2: "#4db6ac",
  lighten1: "#26a69a",
  darken1: "#00897b",
  darken2: "#00796b",
  darken3: "#00695c",
  darken4: "#004d40",
  accent1: "#a7ffeb",
  accent2: "#64ffda",
  accent3: "#1de9b6",
  accent4: "#00bfa5"
}, hy = {
  base: "#4caf50",
  lighten5: "#e8f5e9",
  lighten4: "#c8e6c9",
  lighten3: "#a5d6a7",
  lighten2: "#81c784",
  lighten1: "#66bb6a",
  darken1: "#43a047",
  darken2: "#388e3c",
  darken3: "#2e7d32",
  darken4: "#1b5e20",
  accent1: "#b9f6ca",
  accent2: "#69f0ae",
  accent3: "#00e676",
  accent4: "#00c853"
}, yy = {
  base: "#8bc34a",
  lighten5: "#f1f8e9",
  lighten4: "#dcedc8",
  lighten3: "#c5e1a5",
  lighten2: "#aed581",
  lighten1: "#9ccc65",
  darken1: "#7cb342",
  darken2: "#689f38",
  darken3: "#558b2f",
  darken4: "#33691e",
  accent1: "#ccff90",
  accent2: "#b2ff59",
  accent3: "#76ff03",
  accent4: "#64dd17"
}, by = {
  base: "#cddc39",
  lighten5: "#f9fbe7",
  lighten4: "#f0f4c3",
  lighten3: "#e6ee9c",
  lighten2: "#dce775",
  lighten1: "#d4e157",
  darken1: "#c0ca33",
  darken2: "#afb42b",
  darken3: "#9e9d24",
  darken4: "#827717",
  accent1: "#f4ff81",
  accent2: "#eeff41",
  accent3: "#c6ff00",
  accent4: "#aeea00"
}, Sy = {
  base: "#ffeb3b",
  lighten5: "#fffde7",
  lighten4: "#fff9c4",
  lighten3: "#fff59d",
  lighten2: "#fff176",
  lighten1: "#ffee58",
  darken1: "#fdd835",
  darken2: "#fbc02d",
  darken3: "#f9a825",
  darken4: "#f57f17",
  accent1: "#ffff8d",
  accent2: "#ffff00",
  accent3: "#ffea00",
  accent4: "#ffd600"
}, ky = {
  base: "#ffc107",
  lighten5: "#fff8e1",
  lighten4: "#ffecb3",
  lighten3: "#ffe082",
  lighten2: "#ffd54f",
  lighten1: "#ffca28",
  darken1: "#ffb300",
  darken2: "#ffa000",
  darken3: "#ff8f00",
  darken4: "#ff6f00",
  accent1: "#ffe57f",
  accent2: "#ffd740",
  accent3: "#ffc400",
  accent4: "#ffab00"
}, wy = {
  base: "#ff9800",
  lighten5: "#fff3e0",
  lighten4: "#ffe0b2",
  lighten3: "#ffcc80",
  lighten2: "#ffb74d",
  lighten1: "#ffa726",
  darken1: "#fb8c00",
  darken2: "#f57c00",
  darken3: "#ef6c00",
  darken4: "#e65100",
  accent1: "#ffd180",
  accent2: "#ffab40",
  accent3: "#ff9100",
  accent4: "#ff6d00"
}, Cy = {
  base: "#ff5722",
  lighten5: "#fbe9e7",
  lighten4: "#ffccbc",
  lighten3: "#ffab91",
  lighten2: "#ff8a65",
  lighten1: "#ff7043",
  darken1: "#f4511e",
  darken2: "#e64a19",
  darken3: "#d84315",
  darken4: "#bf360c",
  accent1: "#ff9e80",
  accent2: "#ff6e40",
  accent3: "#ff3d00",
  accent4: "#dd2c00"
}, xy = {
  base: "#795548",
  lighten5: "#efebe9",
  lighten4: "#d7ccc8",
  lighten3: "#bcaaa4",
  lighten2: "#a1887f",
  lighten1: "#8d6e63",
  darken1: "#6d4c41",
  darken2: "#5d4037",
  darken3: "#4e342e",
  darken4: "#3e2723"
}, Vy = {
  base: "#607d8b",
  lighten5: "#eceff1",
  lighten4: "#cfd8dc",
  lighten3: "#b0bec5",
  lighten2: "#90a4ae",
  lighten1: "#78909c",
  darken1: "#546e7a",
  darken2: "#455a64",
  darken3: "#37474f",
  darken4: "#263238"
}, Py = {
  base: "#9e9e9e",
  lighten5: "#fafafa",
  lighten4: "#f5f5f5",
  lighten3: "#eeeeee",
  lighten2: "#e0e0e0",
  lighten1: "#bdbdbd",
  darken1: "#757575",
  darken2: "#616161",
  darken3: "#424242",
  darken4: "#212121"
}, Iy = {
  black: "#000000",
  white: "#ffffff",
  transparent: "#ffffff00"
}, _y = {
  red: ry,
  pink: uy,
  purple: sy,
  deepPurple: cy,
  indigo: dy,
  blue: vy,
  lightBlue: fy,
  cyan: my,
  teal: gy,
  green: hy,
  lightGreen: yy,
  lime: by,
  yellow: Sy,
  amber: ky,
  orange: wy,
  deepOrange: Cy,
  brown: xy,
  blueGrey: Vy,
  grey: Py,
  shades: Iy
}, Ay = N(v({
  swatches: {
    type: Array,
    default: () => Ly(_y)
  },
  disabled: Boolean,
  color: Object,
  maxHeight: [Number, String]
}, de()), "VColorPickerSwatches");
function Ly(e) {
  return Object.keys(e).map((n) => {
    const t = e[n];
    return t.base ? [t.base, t.darken4, t.darken3, t.darken2, t.darken1, t.lighten1, t.lighten2, t.lighten3, t.lighten4, t.lighten5] : [t.black, t.white, t.transparent];
  });
}
const Ty = _t({
  name: "VColorPickerSwatches",
  props: Ay(),
  emits: {
    "update:color": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    return Z(() => w("div", {
      class: X(["v-color-picker-swatches", e.class]),
      style: ie([{
        maxHeight: ce(e.maxHeight)
      }, e.style])
    }, [w("div", null, [e.swatches.map((a) => w("div", {
      class: "v-color-picker-swatches__swatch"
    }, [a.map((l) => {
      const i = Pt(l), o = Aa(i), r = Su(i);
      return w("div", {
        class: "v-color-picker-swatches__color",
        onClick: () => o && t("update:color", o)
      }, [w("div", {
        style: {
          background: r
        }
      }, [e.color && at(e.color, o) ? k(Be, {
        size: "x-small",
        icon: "$success",
        color: Lv(l, "#FFFFFF") > 2 ? "white" : "black"
      }, null) : void 0])]);
    })]))])])), {};
  }
}), By = Xt("v-picker-title"), _o = N(v(v(v(v(v(v(v(v(v({
  color: String
}, kt()), de()), Ze()), Je()), Zt()), Jn()), Ne()), ke()), Ie()), "VSheet"), Va = Y()({
  name: "VSheet",
  props: _o(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      backgroundColorClasses: l,
      backgroundColorStyles: i
    } = pe(() => e.color), {
      borderClasses: o
    } = Ct(e), {
      dimensionStyles: r
    } = Qe(e), {
      elevationClasses: u
    } = lt(e), {
      locationStyles: c
    } = Mn(e), {
      positionClasses: s
    } = ea(e), {
      roundedClasses: d
    } = Ye(e);
    return Z(() => k(e.tag, {
      class: X(["v-sheet", a.value, l.value, o.value, u.value, s.value, d.value, e.class]),
      style: ie([i.value, r.value, c.value, e.style])
    }, t)), {};
  }
}), Ll = N(v({
  bgColor: String,
  divided: Boolean,
  landscape: Boolean,
  title: String,
  hideHeader: Boolean
}, _o()), "VPicker"), Kn = Y()({
  name: "VPicker",
  props: Ll(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      backgroundColorClasses: a,
      backgroundColorStyles: l
    } = pe(() => e.color);
    return Z(() => {
      const i = Va.filterProps(e), o = !!(e.title || t.title);
      return k(Va, G(i, {
        color: e.bgColor,
        class: ["v-picker", {
          "v-picker--divided": e.divided,
          "v-picker--landscape": e.landscape,
          "v-picker--with-actions": !!t.actions
        }, e.class],
        style: e.style
      }), {
        default: () => {
          var r;
          return [!e.hideHeader && w("div", {
            key: "header",
            class: X([a.value]),
            style: ie([l.value])
          }, [o && k(By, {
            key: "picker-title"
          }, {
            default: () => {
              var u, c;
              return [(c = (u = t.title) == null ? void 0 : u.call(t)) != null ? c : e.title];
            }
          }), t.header && w("div", {
            class: "v-picker__header"
          }, [t.header()])]), w("div", {
            class: "v-picker__body"
          }, [(r = t.default) == null ? void 0 : r.call(t)]), t.actions && k(Ce, {
            defaults: {
              VBtn: {
                slim: !0,
                variant: "text"
              }
            }
          }, {
            default: () => [w("div", {
              class: "v-picker__actions"
            }, [t.actions()])]
          })];
        }
      });
    }), {};
  }
}), Dy = N(v({
  canvasHeight: {
    type: [String, Number],
    default: 150
  },
  disabled: Boolean,
  dotSize: {
    type: [Number, String],
    default: 10
  },
  hideCanvas: Boolean,
  hideSliders: Boolean,
  hideInputs: Boolean,
  mode: {
    type: String,
    default: "rgba",
    validator: (e) => Object.keys(gn).includes(e)
  },
  modes: {
    type: Array,
    default: () => Object.keys(gn),
    validator: (e) => Array.isArray(e) && e.every((n) => Object.keys(gn).includes(n))
  },
  showSwatches: Boolean,
  swatches: Array,
  swatchesMaxHeight: {
    type: [Number, String],
    default: 150
  },
  modelValue: {
    type: [Object, String]
  }
}, Ll({
  hideHeader: !0
})), "VColorPicker"), My = _t({
  name: "VColorPicker",
  props: Dy(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:mode": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "mode"), l = Q(null), i = ve(e, "modelValue", void 0, (s) => {
      if (s == null || s === "") return null;
      let d;
      try {
        d = Aa(Pt(s));
      } catch (f) {
        return et(f), null;
      }
      return d;
    }, (s) => s ? Kh(s, e.modelValue) : null), o = C(() => {
      var s;
      return i.value ? le(v({}, i.value), {
        h: (s = l.value) != null ? s : i.value.h
      }) : null;
    }), {
      rtlClasses: r
    } = Xe();
    let u = !0;
    oe(i, (s) => {
      if (!u) {
        u = !0;
        return;
      }
      s && (l.value = s.h);
    }, {
      immediate: !0
    });
    const c = (s) => {
      u = !1, l.value = s.h, i.value = s;
    };
    return _a(() => {
      e.modes.includes(a.value) || (a.value = e.modes[0]);
    }), je({
      VSlider: {
        color: void 0,
        trackColor: void 0,
        trackFillColor: void 0
      }
    }), Z(() => {
      var d;
      const s = Kn.filterProps(e);
      return k(Kn, G(s, {
        class: ["v-color-picker", r.value, e.class],
        style: [{
          "--v-color-picker-color-hsv": ku(le(v({}, (d = o.value) != null ? d : Rn), {
            a: 1
          }))
        }, e.style]
      }), le(v({}, t), {
        default: () => w(he, null, [!e.hideCanvas && k(Gh, {
          key: "canvas",
          color: o.value,
          "onUpdate:color": c,
          disabled: e.disabled,
          dotSize: e.dotSize,
          width: e.width,
          height: e.canvasHeight
        }, null), (!e.hideSliders || !e.hideInputs) && w("div", {
          key: "controls",
          class: "v-color-picker__controls"
        }, [!e.hideSliders && k(oy, {
          key: "preview",
          color: o.value,
          "onUpdate:color": c,
          hideAlpha: !a.value.endsWith("a"),
          disabled: e.disabled
        }, null), !e.hideInputs && k(ey, {
          key: "edit",
          modes: e.modes,
          mode: a.value,
          "onUpdate:mode": (f) => a.value = f,
          color: o.value,
          "onUpdate:color": c,
          disabled: e.disabled
        }, null)]), e.showSwatches && k(Ty, {
          key: "swatches",
          color: o.value,
          "onUpdate:color": c,
          maxHeight: e.swatchesMaxHeight,
          swatches: e.swatches,
          disabled: e.disabled
        }, null)])
      }));
    }), {};
  }
}), py = N(v(v(v(v({
  autoSelectFirst: {
    type: [Boolean, String]
  },
  clearOnSelect: {
    type: Boolean,
    default: !0
  },
  delimiters: Array
}, la({
  filterKeys: ["title"]
})), Vo({
  hideNoData: !0,
  returnObject: !0
})), $e(Na({
  modelValue: null,
  role: "combobox"
}), ["validationValue", "dirty", "appendInnerIcon"])), Ft({
  transition: !1
})), "VCombobox"), Ey = Y()({
  name: "VCombobox",
  props: py(),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0,
    "update:search": (e) => !0,
    "update:menu": (e) => !0
  },
  setup(e, n) {
    var re, fe;
    let {
      emit: t,
      slots: a
    } = n;
    const {
      t: l
    } = Ee(), i = Q(), o = te(!1), r = te(!0), u = te(!1), c = Q(), s = Q(), d = te(-1);
    let f = !1;
    const {
      items: m,
      transformIn: h,
      transformOut: b
    } = yo(e), {
      textColorClasses: g,
      textColorStyles: S
    } = rt(() => {
      var K;
      return (K = i.value) == null ? void 0 : K.color;
    }), y = ve(e, "modelValue", [], (K) => h(ze(K)), (K) => {
      var ye;
      const se = b(K);
      return e.multiple ? se : (ye = se[0]) != null ? ye : null;
    }), P = $a(e), V = C(() => !!(e.chips || a.chip)), x = C(() => V.value || !!a.selection), I = te(!e.multiple && !x.value && (fe = (re = y.value[0]) == null ? void 0 : re.title) != null ? fe : ""), T = C({
      get: () => I.value,
      set: (K) => He(this, null, function* () {
        var se;
        if (I.value = K != null ? K : "", !e.multiple && !x.value && (y.value = [Mt(e, K)], Ve(() => {
          var ye;
          return (ye = s.value) == null ? void 0 : ye.scrollToIndex(0);
        })), K && e.multiple && ((se = e.delimiters) != null && se.length)) {
          const ye = e.delimiters.map(nl).join("|"), be = K.split(new RegExp(`(?:${ye})+`));
          if (be.length > 1) {
            for (let we of be)
              we = we.trim(), we && (j(Mt(e, we)), yield Ve());
            I.value = "";
          }
        }
        K || (d.value = -1), r.value = !K;
      })
    }), _ = C(() => typeof e.counterValue == "function" ? e.counterValue(y.value) : typeof e.counterValue == "number" ? e.counterValue : e.multiple ? y.value.length : T.value.length), {
      filteredItems: p,
      getMatches: L
    } = ia(e, m, () => r.value ? "" : T.value), D = C(() => e.hideSelected ? p.value.filter((K) => !y.value.some((se) => se.value === K.value)) : p.value), A = C(() => e.hideNoData && !D.value.length || P.isReadonly.value || P.isDisabled.value), B = ve(e, "menu"), F = C({
      get: () => B.value,
      set: (K) => {
        var se;
        B.value && !K && ((se = c.value) != null && se.ΨopenChildren.size) || K && A.value || (B.value = K);
      }
    }), $ = M(() => F.value ? e.closeText : e.openText);
    oe(I, (K) => {
      f ? Ve(() => f = !1) : o.value && !F.value && (F.value = !0), t("update:search", K);
    }), oe(y, (K) => {
      var se, ye;
      !e.multiple && !x.value && (I.value = (ye = (se = K[0]) == null ? void 0 : se.title) != null ? ye : "");
    });
    const W = C(() => y.value.map((K) => K.value)), J = C(() => {
      var se;
      return (e.autoSelectFirst === !0 || e.autoSelectFirst === "exact" && T.value === ((se = D.value[0]) == null ? void 0 : se.title)) && D.value.length > 0 && !r.value && !u.value;
    }), z = Q(), H = xo(z, i);
    function E(K) {
      f = !0, e.openOnClear && (F.value = !0);
    }
    function O() {
      A.value || (F.value = !0);
    }
    function R(K) {
      A.value || (o.value && (K.preventDefault(), K.stopPropagation()), F.value = !F.value);
    }
    function q(K) {
      var se;
      (Wn(K) || K.key === "Backspace") && ((se = i.value) == null || se.focus());
    }
    function ae(K) {
      var be, we, Me, Se;
      if (Qd(K) || P.isReadonly.value) return;
      const se = (be = i.value) == null ? void 0 : be.selectionStart, ye = y.value.length;
      if (["Enter", "ArrowDown", "ArrowUp"].includes(K.key) && K.preventDefault(), ["Enter", "ArrowDown"].includes(K.key) && (F.value = !0), ["Escape"].includes(K.key) && (F.value = !1), ["Enter", "Escape", "Tab"].includes(K.key) && (J.value && ["Enter", "Tab"].includes(K.key) && !y.value.some((_e) => {
        let {
          value: ut
        } = _e;
        return ut === D.value[0].value;
      }) && j(p.value[0]), r.value = !0), K.key === "ArrowDown" && J.value && ((we = z.value) == null || we.focus("next")), K.key === "Enter" && T.value && (j(Mt(e, T.value)), x.value && (I.value = "")), ["Backspace", "Delete"].includes(K.key)) {
        if (!e.multiple && x.value && y.value.length > 0 && !T.value) return j(y.value[0], !1);
        if (~d.value) {
          K.preventDefault();
          const _e = d.value;
          j(y.value[d.value], !1), d.value = _e >= ye - 1 ? ye - 2 : _e;
        } else K.key === "Backspace" && !T.value && (d.value = ye - 1);
        return;
      }
      if (e.multiple)
        if (K.key === "ArrowLeft") {
          if (d.value < 0 && se && se > 0) return;
          const _e = d.value > -1 ? d.value - 1 : ye - 1;
          y.value[_e] ? d.value = _e : (d.value = -1, (Me = i.value) == null || Me.setSelectionRange(T.value.length, T.value.length));
        } else if (K.key === "ArrowRight") {
          if (d.value < 0) return;
          const _e = d.value + 1;
          y.value[_e] ? d.value = _e : (d.value = -1, (Se = i.value) == null || Se.setSelectionRange(0, 0));
        } else ~d.value && Wn(K) && (d.value = -1);
    }
    function U() {
      var K;
      e.eager && ((K = s.value) == null || K.calculateVisibleItems());
    }
    function ne() {
      var K;
      o.value && (r.value = !0, (K = i.value) == null || K.focus());
    }
    function j(K) {
      let se = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      if (!(!K || K.props.disabled))
        if (e.multiple) {
          const ye = y.value.findIndex((we) => (e.valueComparator || at)(we.value, K.value)), be = se == null ? !~ye : se;
          if (~ye) {
            const we = be ? [...y.value, K] : [...y.value];
            we.splice(ye, 1), y.value = we;
          } else be && (y.value = [...y.value, K]);
          e.clearOnSelect && (T.value = "");
        } else {
          const ye = se !== !1;
          y.value = ye ? [K] : [], I.value = ye && !x.value ? K.title : "", Ve(() => {
            F.value = !1, r.value = !0;
          });
        }
    }
    function ue(K) {
      o.value = !0, setTimeout(() => {
        u.value = !0;
      });
    }
    function ge(K) {
      u.value = !1;
    }
    function ee(K) {
      (K == null || K === "" && !e.multiple && !x.value) && (y.value = []);
    }
    return oe(o, (K, se) => {
      if (!(K || K === se) && (d.value = -1, F.value = !1, T.value)) {
        if (e.multiple) {
          j(Mt(e, T.value));
          return;
        }
        if (!x.value) return;
        y.value.some((ye) => {
          let {
            title: be
          } = ye;
          return be === T.value;
        }) ? I.value = "" : j(Mt(e, T.value));
      }
    }), oe(F, () => {
      if (!e.hideSelected && F.value && y.value.length) {
        const K = D.value.findIndex((se) => y.value.some((ye) => (e.valueComparator || at)(ye.value, se.value)));
        Te && window.requestAnimationFrame(() => {
          var se;
          K >= 0 && ((se = s.value) == null || se.scrollToIndex(K));
        });
      }
    }), oe(() => e.items, (K, se) => {
      F.value || o.value && !se.length && K.length && (F.value = !0);
    }), Z(() => {
      const K = !!(!e.hideNoData || D.value.length || a["prepend-item"] || a["append-item"] || a["no-data"]), se = y.value.length > 0, ye = Kt.filterProps(e);
      return k(Kt, G({
        ref: i
      }, ye, {
        modelValue: T.value,
        "onUpdate:modelValue": [(be) => T.value = be, ee],
        focused: o.value,
        "onUpdate:focused": (be) => o.value = be,
        validationValue: y.externalValue,
        counterValue: _.value,
        dirty: se,
        class: ["v-combobox", {
          "v-combobox--active-menu": F.value,
          "v-combobox--chips": !!e.chips,
          "v-combobox--selection-slot": !!x.value,
          "v-combobox--selecting-index": d.value > -1,
          [`v-combobox--${e.multiple ? "multiple" : "single"}`]: !0
        }, e.class],
        style: e.style,
        readonly: P.isReadonly.value,
        placeholder: se ? void 0 : e.placeholder,
        "onClick:clear": E,
        "onMousedown:control": O,
        onKeydown: ae
      }), le(v({}, a), {
        default: () => w(he, null, [k(Un, G({
          ref: c,
          modelValue: F.value,
          "onUpdate:modelValue": (be) => F.value = be,
          activator: "parent",
          contentClass: "v-combobox__content",
          disabled: A.value,
          eager: e.eager,
          maxHeight: 310,
          openOnClick: !1,
          closeOnContentClick: !1,
          transition: e.transition,
          onAfterEnter: U,
          onAfterLeave: ne
        }, e.menuProps), {
          default: () => {
            var be;
            return [K && k(Gn, G({
              ref: z,
              filterable: !0,
              selected: W.value,
              selectStrategy: e.multiple ? "independent" : "single-independent",
              onMousedown: (we) => we.preventDefault(),
              onKeydown: q,
              onFocusin: ue,
              onFocusout: ge,
              tabindex: "-1",
              "aria-live": "polite",
              color: (be = e.itemColor) != null ? be : e.color
            }, H, e.listProps), {
              default: () => {
                var we, Me, Se, _e;
                return [(we = a["prepend-item"]) == null ? void 0 : we.call(a), !D.value.length && !e.hideNoData && ((Se = (Me = a["no-data"]) == null ? void 0 : Me.call(a)) != null ? Se : k(Et, {
                  key: "no-data",
                  title: l(e.noDataText)
                }, null)), k(Il, {
                  ref: s,
                  renderless: !0,
                  items: D.value,
                  itemKey: "value"
                }, {
                  default: (ut) => {
                    var ra, ua, sa, rn, Ha, jo;
                    let {
                      item: Ae,
                      index: wt,
                      itemRef: Ra
                    } = ut;
                    const oa = G(Ae.props, {
                      ref: Ra,
                      key: Ae.value,
                      active: J.value && wt === 0 ? !0 : void 0,
                      onClick: () => j(Ae, null)
                    });
                    return Ae.type === "divider" ? (ua = (ra = a.divider) == null ? void 0 : ra.call(a, {
                      props: Ae.raw,
                      index: wt
                    })) != null ? ua : k(It, G(Ae.props, {
                      key: `divider-${wt}`
                    }), null) : Ae.type === "subheader" ? (rn = (sa = a.subheader) == null ? void 0 : sa.call(a, {
                      props: Ae.raw,
                      index: wt
                    })) != null ? rn : k(aa, G(Ae.props, {
                      key: `subheader-${wt}`
                    }), null) : (jo = (Ha = a.item) == null ? void 0 : Ha.call(a, {
                      item: Ae,
                      index: wt,
                      props: oa
                    })) != null ? jo : k(Et, G(oa, {
                      role: "option"
                    }), {
                      prepend: (za) => {
                        let {
                          isSelected: Id
                        } = za;
                        return w(he, null, [e.multiple && !e.hideSelected ? k(zt, {
                          key: Ae.value,
                          modelValue: Id,
                          ripple: !1,
                          tabindex: "-1"
                        }, null) : void 0, Ae.props.prependAvatar && k(Bt, {
                          image: Ae.props.prependAvatar
                        }, null), Ae.props.prependIcon && k(Be, {
                          icon: Ae.props.prependIcon
                        }, null)]);
                      },
                      title: () => {
                        var za;
                        return r.value ? Ae.title : Zs("v-combobox", Ae.title, (za = L(Ae)) == null ? void 0 : za.title);
                      }
                    });
                  }
                }), (_e = a["append-item"]) == null ? void 0 : _e.call(a)];
              }
            })];
          }
        }), y.value.map((be, we) => {
          function Me(Ae) {
            Ae.stopPropagation(), Ae.preventDefault(), j(be, !1);
          }
          const Se = {
            "onClick:close": Me,
            onKeydown(Ae) {
              Ae.key !== "Enter" && Ae.key !== " " || (Ae.preventDefault(), Ae.stopPropagation(), Me(Ae));
            },
            onMousedown(Ae) {
              Ae.preventDefault(), Ae.stopPropagation();
            },
            modelValue: !0,
            "onUpdate:modelValue": void 0
          }, _e = V.value ? !!a.chip : !!a.selection, ut = _e ? ml(V.value ? a.chip({
            item: be,
            index: we,
            props: Se
          }) : a.selection({
            item: be,
            index: we
          })) : void 0;
          if (!(_e && !ut))
            return w("div", {
              key: be.value,
              class: X(["v-combobox__selection", we === d.value && ["v-combobox__selection--selected", g.value]]),
              style: ie(we === d.value ? S.value : {})
            }, [V.value ? a.chip ? k(Ce, {
              key: "chip-defaults",
              defaults: {
                VChip: {
                  closable: e.closableChips,
                  size: "small",
                  text: be.title
                }
              }
            }, {
              default: () => [ut]
            }) : k(na, G({
              key: "chip",
              closable: e.closableChips,
              size: "small",
              text: be.title,
              disabled: be.props.disabled
            }, Se), null) : ut != null ? ut : w("span", {
              class: "v-combobox__selection-text"
            }, [be.title, e.multiple && we < y.value.length - 1 && w("span", {
              class: "v-combobox__selection-comma"
            }, [Nt(",")])])]);
        })]),
        "append-inner": function() {
          var Se, _e;
          for (var be = arguments.length, we = new Array(be), Me = 0; Me < be; Me++)
            we[Me] = arguments[Me];
          return w(he, null, [(Se = a["append-inner"]) == null ? void 0 : Se.call(a, ...we), (!e.hideNoData || e.items.length) && e.menuIcon ? k(Be, {
            class: "v-combobox__menu-icon",
            color: (_e = i.value) == null ? void 0 : _e.fieldIconColor,
            icon: e.menuIcon,
            onMousedown: R,
            onClick: vu,
            "aria-label": l($.value),
            title: l($.value),
            tabindex: "-1"
          }, null) : void 0]);
        }
      }));
    }), it({
      isFocused: o,
      isPristine: r,
      menu: F,
      search: T,
      selectionIndex: d,
      filteredItems: p,
      select: j
    }, i);
  }
}), $y = N({
  modelValue: null,
  color: String,
  cancelText: {
    type: String,
    default: "$vuetify.confirmEdit.cancel"
  },
  okText: {
    type: String,
    default: "$vuetify.confirmEdit.ok"
  },
  disabled: {
    type: [Boolean, Array],
    default: void 0
  },
  hideActions: Boolean
}, "VConfirmEdit"), Fy = Y()({
  name: "VConfirmEdit",
  props: $y(),
  emits: {
    cancel: () => !0,
    save: (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = ve(e, "modelValue"), i = Q();
    We(() => {
      i.value = structuredClone(Ue(l.value));
    });
    const {
      t: o
    } = Ee(), r = C(() => at(l.value, i.value));
    function u(b) {
      return typeof e.disabled == "boolean" ? e.disabled : Array.isArray(e.disabled) ? e.disabled.includes(b) : r.value;
    }
    const c = C(() => u("save")), s = C(() => u("cancel"));
    function d() {
      l.value = i.value, t("save", i.value);
    }
    function f() {
      i.value = structuredClone(Ue(l.value)), t("cancel");
    }
    function m(b) {
      return w(he, null, [k(xe, G({
        disabled: s.value,
        variant: "text",
        color: e.color,
        onClick: f,
        text: o(e.cancelText)
      }, b), null), k(xe, G({
        disabled: c.value,
        variant: "text",
        color: e.color,
        onClick: d,
        text: o(e.okText)
      }, b), null)]);
    }
    let h = !1;
    return Z(() => {
      var b;
      return w(he, null, [(b = a.default) == null ? void 0 : b.call(a, {
        model: i,
        save: d,
        cancel: f,
        isPristine: r.value,
        get actions() {
          return h = !0, m;
        }
      }), !e.hideActions && !h && m()]);
    }), {
      save: d,
      cancel: f,
      isPristine: r
    };
  }
}), gc = N({
  expandOnClick: Boolean,
  showExpand: Boolean,
  expanded: {
    type: Array,
    default: () => []
  }
}, "DataTable-expand"), hc = Symbol.for("vuetify:datatable:expanded");
function Tl(e) {
  const n = M(() => e.expandOnClick), t = ve(e, "expanded", e.expanded, (r) => new Set(r), (r) => [...r.values()]);
  function a(r, u) {
    const c = new Set(t.value);
    u ? c.add(r.value) : c.delete(r.value), t.value = c;
  }
  function l(r) {
    return t.value.has(r.value);
  }
  function i(r) {
    a(r, !l(r));
  }
  const o = {
    expand: a,
    expanded: t,
    expandOnClick: n,
    isExpanded: l,
    toggleExpand: i
  };
  return Oe(hc, o), o;
}
function yc() {
  const e = Pe(hc);
  if (!e) throw new Error("foo");
  return e;
}
const Ao = N({
  groupBy: {
    type: Array,
    default: () => []
  }
}, "DataTable-group"), bc = Symbol.for("vuetify:data-table-group");
function Lo(e) {
  return {
    groupBy: ve(e, "groupBy")
  };
}
function Bl(e) {
  const {
    disableSort: n,
    groupBy: t,
    sortBy: a
  } = e, l = Q(/* @__PURE__ */ new Set()), i = C(() => t.value.map((s) => {
    var d;
    return le(v({}, s), {
      order: (d = s.order) != null ? d : !1
    });
  }).concat(n != null && n.value ? [] : a.value));
  function o(s) {
    return l.value.has(s.id);
  }
  function r(s) {
    const d = new Set(l.value);
    o(s) ? d.delete(s.id) : d.add(s.id), l.value = d;
  }
  function u(s) {
    function d(f) {
      const m = [];
      for (const h of f.items)
        "type" in h && h.type === "group" ? m.push(...d(h)) : m.push(h);
      return [...new Set(m)];
    }
    return d({
      items: s
    });
  }
  const c = {
    sortByWithGroups: i,
    toggleGroup: r,
    opened: l,
    groupBy: t,
    extractRows: u,
    isGroupOpen: o
  };
  return Oe(bc, c), c;
}
function Sc() {
  const e = Pe(bc);
  if (!e) throw new Error("Missing group!");
  return e;
}
function Oy(e, n) {
  if (!e.length) return [];
  const t = /* @__PURE__ */ new Map();
  for (const a of e) {
    const l = yn(a.raw, n);
    t.has(l) || t.set(l, []), t.get(l).push(a);
  }
  return t;
}
function kc(e, n) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "root";
  if (!n.length) return [];
  const l = Oy(e, n[0]), i = [], o = n.slice(1);
  return l.forEach((r, u) => {
    const c = n[0], s = `${a}_${c}_${u}`;
    i.push({
      depth: t,
      id: s,
      key: c,
      value: u,
      items: o.length ? kc(r, o, t + 1, s) : r,
      type: "group"
    });
  }), i;
}
function wc(e, n) {
  const t = [];
  for (const a of e)
    "type" in a && a.type === "group" ? (a.value != null && t.push(a), (n.has(a.id) || a.value == null) && t.push(...wc(a.items, n))) : t.push(a);
  return t;
}
function Dl(e, n, t) {
  return {
    flatItems: C(() => {
      if (!n.value.length) return e.value;
      const l = kc(e.value, n.value.map((i) => i.key));
      return wc(l, t.value);
    })
  };
}
function Ml(e) {
  let {
    page: n,
    itemsPerPage: t,
    sortBy: a,
    groupBy: l,
    search: i
  } = e;
  const o = Ke("VDataTable"), r = () => ({
    page: n.value,
    itemsPerPage: t.value,
    sortBy: a.value,
    groupBy: l.value,
    search: i.value
  });
  let u = null;
  oe(r, (c) => {
    at(u, c) || (u && u.search !== c.search && (n.value = 1), o.emit("update:options", c), u = c);
  }, {
    deep: !0,
    immediate: !0
  });
}
const To = N({
  page: {
    type: [Number, String],
    default: 1
  },
  itemsPerPage: {
    type: [Number, String],
    default: 10
  }
}, "DataTable-paginate"), Cc = Symbol.for("vuetify:data-table-pagination");
function Bo(e) {
  const n = ve(e, "page", void 0, (a) => Number(a != null ? a : 1)), t = ve(e, "itemsPerPage", void 0, (a) => Number(a != null ? a : 10));
  return {
    page: n,
    itemsPerPage: t
  };
}
function Do(e) {
  const {
    page: n,
    itemsPerPage: t,
    itemsLength: a
  } = e, l = C(() => t.value === -1 ? 0 : t.value * (n.value - 1)), i = C(() => t.value === -1 ? a.value : Math.min(a.value, l.value + t.value)), o = C(() => t.value === -1 || a.value === 0 ? 1 : Math.ceil(a.value / t.value));
  oe([n, o], () => {
    n.value > o.value && (n.value = o.value);
  });
  function r(f) {
    t.value = f, n.value = 1;
  }
  function u() {
    n.value = Fe(n.value + 1, 1, o.value);
  }
  function c() {
    n.value = Fe(n.value - 1, 1, o.value);
  }
  function s(f) {
    n.value = Fe(f, 1, o.value);
  }
  const d = {
    page: n,
    itemsPerPage: t,
    startIndex: l,
    stopIndex: i,
    pageCount: o,
    itemsLength: a,
    nextPage: u,
    prevPage: c,
    setPage: s,
    setItemsPerPage: r
  };
  return Oe(Cc, d), d;
}
function Ny() {
  const e = Pe(Cc);
  if (!e) throw new Error("Missing pagination!");
  return e;
}
function xc(e) {
  const n = Ke("usePaginatedItems"), {
    items: t,
    startIndex: a,
    stopIndex: l,
    itemsPerPage: i
  } = e, o = C(() => i.value <= 0 ? t.value : t.value.slice(a.value, l.value));
  return oe(o, (r) => {
    n.emit("update:currentItems", r);
  }, {
    immediate: !0
  }), {
    paginatedItems: o
  };
}
const Ry = {
  showSelectAll: !1,
  allSelected: () => [],
  select: (e) => {
    var a;
    let {
      items: n,
      value: t
    } = e;
    return new Set(t ? [(a = n[0]) == null ? void 0 : a.value] : []);
  },
  selectAll: (e) => {
    let {
      selected: n
    } = e;
    return n;
  }
}, Vc = {
  showSelectAll: !0,
  allSelected: (e) => {
    let {
      currentPage: n
    } = e;
    return n;
  },
  select: (e) => {
    let {
      items: n,
      value: t,
      selected: a
    } = e;
    for (const l of n)
      t ? a.add(l.value) : a.delete(l.value);
    return a;
  },
  selectAll: (e) => {
    let {
      value: n,
      currentPage: t,
      selected: a
    } = e;
    return Vc.select({
      items: t,
      value: n,
      selected: a
    });
  }
}, Pc = {
  showSelectAll: !0,
  allSelected: (e) => {
    let {
      allItems: n
    } = e;
    return n;
  },
  select: (e) => {
    let {
      items: n,
      value: t,
      selected: a
    } = e;
    for (const l of n)
      t ? a.add(l.value) : a.delete(l.value);
    return a;
  },
  selectAll: (e) => {
    let {
      value: n,
      allItems: t,
      selected: a
    } = e;
    return Pc.select({
      items: t,
      value: n,
      selected: a
    });
  }
}, Ic = N({
  showSelect: Boolean,
  selectStrategy: {
    type: [String, Object],
    default: "page"
  },
  modelValue: {
    type: Array,
    default: () => []
  },
  valueComparator: {
    type: Function,
    default: at
  }
}, "DataTable-select"), _c = Symbol.for("vuetify:data-table-selection");
function pl(e, n) {
  let {
    allItems: t,
    currentPage: a
  } = n;
  const l = ve(e, "modelValue", e.modelValue, (y) => new Set(ze(y).map((P) => {
    var V, x;
    return (x = (V = t.value.find((I) => e.valueComparator(P, I.value))) == null ? void 0 : V.value) != null ? x : P;
  })), (y) => [...y.values()]), i = C(() => t.value.filter((y) => y.selectable)), o = C(() => a.value.filter((y) => y.selectable)), r = C(() => {
    if (typeof e.selectStrategy == "object") return e.selectStrategy;
    switch (e.selectStrategy) {
      case "single":
        return Ry;
      case "all":
        return Pc;
      case "page":
      default:
        return Vc;
    }
  }), u = te(null);
  function c(y) {
    return ze(y).every((P) => l.value.has(P.value));
  }
  function s(y) {
    return ze(y).some((P) => l.value.has(P.value));
  }
  function d(y, P) {
    const V = r.value.select({
      items: y,
      value: P,
      selected: new Set(l.value)
    });
    l.value = V;
  }
  function f(y, P, V) {
    const x = [];
    if (P = P != null ? P : a.value.findIndex((I) => I.value === y.value), e.selectStrategy !== "single" && (V != null && V.shiftKey) && u.value !== null) {
      const [I, T] = [u.value, P].sort((_, p) => _ - p);
      x.push(...a.value.slice(I, T + 1).filter((_) => _.selectable));
    } else
      x.push(y), u.value = P;
    d(x, !c([y]));
  }
  function m(y) {
    const P = r.value.selectAll({
      value: y,
      allItems: i.value,
      currentPage: o.value,
      selected: new Set(l.value)
    });
    l.value = P;
  }
  const h = C(() => l.value.size > 0), b = C(() => {
    const y = r.value.allSelected({
      allItems: i.value,
      currentPage: o.value
    });
    return !!y.length && c(y);
  }), g = M(() => r.value.showSelectAll), S = {
    toggleSelect: f,
    select: d,
    selectAll: m,
    isSelected: c,
    isSomeSelected: s,
    someSelected: h,
    allSelected: b,
    showSelectAll: g,
    lastSelectedIndex: u,
    selectStrategy: r
  };
  return Oe(_c, S), S;
}
function El() {
  const e = Pe(_c);
  if (!e) throw new Error("Missing selection!");
  return e;
}
const Ac = N({
  sortBy: {
    type: Array,
    default: () => []
  },
  customKeySort: Object,
  multiSort: Boolean,
  mustSort: Boolean
}, "DataTable-sort"), Lc = Symbol.for("vuetify:data-table-sort");
function $l(e) {
  const n = ve(e, "sortBy"), t = M(() => e.mustSort), a = M(() => e.multiSort);
  return {
    sortBy: n,
    mustSort: t,
    multiSort: a
  };
}
function Fl(e) {
  const {
    sortBy: n,
    mustSort: t,
    multiSort: a,
    page: l
  } = e, i = (u) => {
    var d;
    if (u.key == null) return;
    let c = (d = n.value.map((f) => v({}, f))) != null ? d : [];
    const s = c.find((f) => f.key === u.key);
    s ? s.order === "desc" ? t.value && c.length === 1 ? s.order = "asc" : c = c.filter((f) => f.key !== u.key) : s.order = "desc" : a.value ? c.push({
      key: u.key,
      order: "asc"
    }) : c = [{
      key: u.key,
      order: "asc"
    }], n.value = c, l && (l.value = 1);
  };
  function o(u) {
    return !!n.value.find((c) => c.key === u.key);
  }
  const r = {
    sortBy: n,
    toggleSort: i,
    isSorted: o
  };
  return Oe(Lc, r), r;
}
function Tc() {
  const e = Pe(Lc);
  if (!e) throw new Error("Missing sort!");
  return e;
}
function Mo(e, n, t, a) {
  const l = Ee();
  return {
    sortedItems: C(() => {
      var o, r;
      return t.value.length ? Hy(n.value, t.value, l.current.value, {
        transform: a == null ? void 0 : a.transform,
        sortFunctions: v(v({}, e.customKeySort), (o = a == null ? void 0 : a.sortFunctions) == null ? void 0 : o.value),
        sortRawFunctions: (r = a == null ? void 0 : a.sortRawFunctions) == null ? void 0 : r.value
      }) : n.value;
    })
  };
}
function Hy(e, n, t, a) {
  const l = new Intl.Collator(t, {
    sensitivity: "accent",
    usage: "sort"
  });
  return e.map((o) => [o, a != null && a.transform ? a.transform(o) : o]).sort((o, r) => {
    var u, c, s;
    for (let d = 0; d < n.length; d++) {
      let f = !1;
      const m = n[d].key, h = (u = n[d].order) != null ? u : "asc";
      if (h === !1) continue;
      let b = yn(o[1], m), g = yn(r[1], m), S = o[0].raw, y = r[0].raw;
      if (h === "desc" && ([b, g] = [g, b], [S, y] = [y, S]), (c = a == null ? void 0 : a.sortRawFunctions) != null && c[m]) {
        const P = a.sortRawFunctions[m](S, y);
        if (P == null) continue;
        if (f = !0, P) return P;
      }
      if ((s = a == null ? void 0 : a.sortFunctions) != null && s[m]) {
        const P = a.sortFunctions[m](b, g);
        if (P == null) continue;
        if (f = !0, P) return P;
      }
      if (!f && (b instanceof Date && g instanceof Date && (b = b.getTime(), g = g.getTime()), [b, g] = [b, g].map((P) => P != null ? P.toString().toLocaleLowerCase() : P), b !== g))
        return Ya(b) && Ya(g) ? 0 : Ya(b) ? -1 : Ya(g) ? 1 : !isNaN(b) && !isNaN(g) ? Number(b) - Number(g) : l.compare(b, g);
    }
    return 0;
  }).map((o) => {
    let [r] = o;
    return r;
  });
}
const zy = N({
  items: {
    type: Array,
    default: () => []
  },
  itemValue: {
    type: [String, Array, Function],
    default: "id"
  },
  itemSelectable: {
    type: [String, Array, Function],
    default: null
  },
  returnObject: Boolean
}, "DataIterator-items");
function Wy(e, n) {
  const t = e.returnObject ? n : qe(n, e.itemValue), a = qe(n, e.itemSelectable, !0);
  return {
    type: "item",
    value: t,
    selectable: a,
    raw: n
  };
}
function jy(e, n) {
  const t = [];
  for (const a of n)
    t.push(Wy(e, a));
  return t;
}
function Yy(e) {
  return {
    items: C(() => jy(e, e.items))
  };
}
const Gy = N(v(v(v(v(v(v(v(v(v(v({
  search: String,
  loading: Boolean
}, de()), zy()), Ic()), Ac()), To({
  itemsPerPage: 5
})), gc()), Ao()), la()), ke()), Ft({
  transition: {
    component: ya,
    hideOnLeave: !0
  }
})), "VDataIterator"), Uy = Y()({
  name: "VDataIterator",
  props: Gy(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:groupBy": (e) => !0,
    "update:page": (e) => !0,
    "update:itemsPerPage": (e) => !0,
    "update:sortBy": (e) => !0,
    "update:options": (e) => !0,
    "update:expanded": (e) => !0,
    "update:currentItems": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "groupBy"), l = M(() => e.search), {
      items: i
    } = Yy(e), {
      filteredItems: o
    } = ia(e, i, l, {
      transform: (O) => O.raw
    }), {
      sortBy: r,
      multiSort: u,
      mustSort: c
    } = $l(e), {
      page: s,
      itemsPerPage: d
    } = Bo(e), {
      toggleSort: f
    } = Fl({
      sortBy: r,
      multiSort: u,
      mustSort: c,
      page: s
    }), {
      sortByWithGroups: m,
      opened: h,
      extractRows: b,
      isGroupOpen: g,
      toggleGroup: S
    } = Bl({
      groupBy: a,
      sortBy: r
    }), {
      sortedItems: y
    } = Mo(e, o, m, {
      transform: (O) => O.raw
    }), {
      flatItems: P
    } = Dl(y, a, h), V = M(() => P.value.length), {
      startIndex: x,
      stopIndex: I,
      pageCount: T,
      prevPage: _,
      nextPage: p,
      setItemsPerPage: L,
      setPage: D
    } = Do({
      page: s,
      itemsPerPage: d,
      itemsLength: V
    }), {
      paginatedItems: A
    } = xc({
      items: P,
      startIndex: x,
      stopIndex: I,
      itemsPerPage: d
    }), B = C(() => b(A.value)), {
      isSelected: F,
      select: $,
      selectAll: W,
      toggleSelect: J
    } = pl(e, {
      allItems: i,
      currentPage: B
    }), {
      isExpanded: z,
      toggleExpand: H
    } = Tl(e);
    Ml({
      page: s,
      itemsPerPage: d,
      sortBy: r,
      groupBy: a,
      search: l
    });
    const E = C(() => ({
      page: s.value,
      itemsPerPage: d.value,
      sortBy: r.value,
      pageCount: T.value,
      toggleSort: f,
      prevPage: _,
      nextPage: p,
      setPage: D,
      setItemsPerPage: L,
      isSelected: F,
      select: $,
      selectAll: W,
      toggleSelect: J,
      isExpanded: z,
      toggleExpand: H,
      isGroupOpen: g,
      toggleGroup: S,
      items: B.value,
      groupedItems: A.value
    }));
    return Z(() => k(e.tag, {
      class: X(["v-data-iterator", {
        "v-data-iterator--loading": e.loading
      }, e.class]),
      style: ie(e.style)
    }, {
      default: () => {
        var O, R;
        return [(O = t.header) == null ? void 0 : O.call(t, E.value), k(ft, {
          transition: e.transition
        }, {
          default: () => {
            var q, ae;
            return [e.loading ? k(Da, {
              key: "loader",
              name: "v-data-iterator",
              active: !0
            }, {
              default: (U) => {
                var ne;
                return (ne = t.loader) == null ? void 0 : ne.call(t, U);
              }
            }) : w("div", {
              key: "items"
            }, [A.value.length ? (ae = t.default) == null ? void 0 : ae.call(t, E.value) : (q = t["no-data"]) == null ? void 0 : q.call(t)])];
          }
        }), (R = t.footer) == null ? void 0 : R.call(t, E.value)];
      }
    })), {};
  }
});
function Ky() {
  const e = Q([]);
  Yd(() => e.value = []);
  function n(t, a) {
    e.value[a] = t;
  }
  return {
    refs: e,
    updateRef: n
  };
}
const qy = N(v(v(v(v(v(v(v(v(v({
  activeColor: String,
  start: {
    type: [Number, String],
    default: 1
  },
  modelValue: {
    type: Number,
    default: (e) => e.start
  },
  disabled: Boolean,
  length: {
    type: [Number, String],
    default: 1,
    validator: (e) => e % 1 === 0
  },
  totalVisible: [Number, String],
  firstIcon: {
    type: me,
    default: "$first"
  },
  prevIcon: {
    type: me,
    default: "$prev"
  },
  nextIcon: {
    type: me,
    default: "$next"
  },
  lastIcon: {
    type: me,
    default: "$last"
  },
  ariaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.root"
  },
  pageAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.page"
  },
  currentPageAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.currentPage"
  },
  firstAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.first"
  },
  previousAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.previous"
  },
  nextAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.next"
  },
  lastAriaLabel: {
    type: String,
    default: "$vuetify.pagination.ariaLabel.last"
  },
  ellipsis: {
    type: String,
    default: "..."
  },
  showFirstLastPage: Boolean
}, kt()), de()), nt()), Je()), Ne()), Yt()), ke({
  tag: "nav"
})), Ie()), Dt({
  variant: "text"
})), "VPagination"), Ti = Y()({
  name: "VPagination",
  props: qy(),
  emits: {
    "update:modelValue": (e) => !0,
    first: (e) => !0,
    prev: (e) => !0,
    next: (e) => !0,
    last: (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = ve(e, "modelValue"), {
      t: i,
      n: o
    } = Ee(), {
      isRtl: r
    } = Xe(), {
      themeClasses: u
    } = De(e), {
      width: c
    } = At(), s = te(-1);
    je(void 0, {
      scoped: !0
    });
    const {
      resizeRef: d
    } = pt((_) => {
      if (!_.length) return;
      const {
        target: p,
        contentRect: L
      } = _[0], D = p.querySelector(".v-pagination__list > *");
      if (!D) return;
      const A = L.width, B = D.offsetWidth + parseFloat(getComputedStyle(D).marginRight) * 2;
      s.value = b(A, B);
    }), f = C(() => parseInt(e.length, 10)), m = C(() => parseInt(e.start, 10)), h = C(() => e.totalVisible != null ? parseInt(e.totalVisible, 10) : s.value >= 0 ? s.value : b(c.value, 58));
    function b(_, p) {
      const L = e.showFirstLastPage ? 5 : 3;
      return Math.max(0, Math.floor(
        // Round to two decimal places to avoid floating point errors
        Number(((_ - p * L) / p).toFixed(2))
      ));
    }
    const g = C(() => {
      if (f.value <= 0 || isNaN(f.value) || f.value > Number.MAX_SAFE_INTEGER) return [];
      if (h.value <= 0) return [];
      if (h.value === 1) return [l.value];
      if (f.value <= h.value)
        return Vt(f.value, m.value);
      const _ = h.value % 2 === 0, p = _ ? h.value / 2 : Math.floor(h.value / 2), L = _ ? p : p + 1, D = f.value - p;
      if (L - l.value >= 0)
        return [...Vt(Math.max(1, h.value - 1), m.value), e.ellipsis, f.value];
      if (l.value - D >= (_ ? 1 : 0)) {
        const A = h.value - 1, B = f.value - A + m.value;
        return [m.value, e.ellipsis, ...Vt(A, B)];
      } else {
        const A = Math.max(1, h.value - 2), B = A === 1 ? l.value : l.value - Math.ceil(A / 2) + m.value;
        return [m.value, e.ellipsis, ...Vt(A, B), e.ellipsis, f.value];
      }
    });
    function S(_, p, L) {
      _.preventDefault(), l.value = p, L && a(L, p);
    }
    const {
      refs: y,
      updateRef: P
    } = Ky();
    je({
      VPaginationBtn: {
        color: M(() => e.color),
        border: M(() => e.border),
        density: M(() => e.density),
        size: M(() => e.size),
        variant: M(() => e.variant),
        rounded: M(() => e.rounded),
        elevation: M(() => e.elevation)
      }
    });
    const V = C(() => g.value.map((_, p) => {
      const L = (D) => P(D, p);
      if (typeof _ == "string")
        return {
          isActive: !1,
          key: `ellipsis-${p}`,
          page: _,
          props: {
            ref: L,
            ellipsis: !0,
            icon: !0,
            disabled: !0
          }
        };
      {
        const D = _ === l.value;
        return {
          isActive: D,
          key: _,
          page: o(_),
          props: {
            ref: L,
            ellipsis: !1,
            icon: !0,
            disabled: !!e.disabled || Number(e.length) < 2,
            color: D ? e.activeColor : e.color,
            "aria-current": D,
            "aria-label": i(D ? e.currentPageAriaLabel : e.pageAriaLabel, _),
            onClick: (A) => S(A, _)
          }
        };
      }
    })), x = C(() => {
      const _ = !!e.disabled || l.value <= m.value, p = !!e.disabled || l.value >= m.value + f.value - 1;
      return {
        first: e.showFirstLastPage ? {
          icon: r.value ? e.lastIcon : e.firstIcon,
          onClick: (L) => S(L, m.value, "first"),
          disabled: _,
          "aria-label": i(e.firstAriaLabel),
          "aria-disabled": _
        } : void 0,
        prev: {
          icon: r.value ? e.nextIcon : e.prevIcon,
          onClick: (L) => S(L, l.value - 1, "prev"),
          disabled: _,
          "aria-label": i(e.previousAriaLabel),
          "aria-disabled": _
        },
        next: {
          icon: r.value ? e.prevIcon : e.nextIcon,
          onClick: (L) => S(L, l.value + 1, "next"),
          disabled: p,
          "aria-label": i(e.nextAriaLabel),
          "aria-disabled": p
        },
        last: e.showFirstLastPage ? {
          icon: r.value ? e.firstIcon : e.lastIcon,
          onClick: (L) => S(L, m.value + f.value - 1, "last"),
          disabled: p,
          "aria-label": i(e.lastAriaLabel),
          "aria-disabled": p
        } : void 0
      };
    });
    function I() {
      var p;
      const _ = l.value - m.value;
      (p = y.value[_]) == null || p.$el.focus();
    }
    function T(_) {
      _.key === ei.left && !e.disabled && l.value > Number(e.start) ? (l.value = l.value - 1, Ve(I)) : _.key === ei.right && !e.disabled && l.value < m.value + f.value - 1 && (l.value = l.value + 1, Ve(I));
    }
    return Z(() => k(e.tag, {
      ref: d,
      class: X(["v-pagination", u.value, e.class]),
      style: ie(e.style),
      role: "navigation",
      "aria-label": i(e.ariaLabel),
      onKeydown: T,
      "data-test": "v-pagination-root"
    }, {
      default: () => [w("ul", {
        class: "v-pagination__list"
      }, [e.showFirstLastPage && w("li", {
        key: "first",
        class: "v-pagination__first",
        "data-test": "v-pagination-first"
      }, [t.first ? t.first(x.value.first) : k(xe, G({
        _as: "VPaginationBtn"
      }, x.value.first), null)]), w("li", {
        key: "prev",
        class: "v-pagination__prev",
        "data-test": "v-pagination-prev"
      }, [t.prev ? t.prev(x.value.prev) : k(xe, G({
        _as: "VPaginationBtn"
      }, x.value.prev), null)]), V.value.map((_, p) => w("li", {
        key: _.key,
        class: X(["v-pagination__item", {
          "v-pagination__item--is-active": _.isActive
        }]),
        "data-test": "v-pagination-item"
      }, [t.item ? t.item(_) : k(xe, G({
        _as: "VPaginationBtn"
      }, _.props), {
        default: () => [_.page]
      })])), w("li", {
        key: "next",
        class: "v-pagination__next",
        "data-test": "v-pagination-next"
      }, [t.next ? t.next(x.value.next) : k(xe, G({
        _as: "VPaginationBtn"
      }, x.value.next), null)]), e.showFirstLastPage && w("li", {
        key: "last",
        class: "v-pagination__last",
        "data-test": "v-pagination-last"
      }, [t.last ? t.last(x.value.last) : k(xe, G({
        _as: "VPaginationBtn"
      }, x.value.last), null)])])]
    })), {};
  }
}), po = N({
  prevIcon: {
    type: me,
    default: "$prev"
  },
  nextIcon: {
    type: me,
    default: "$next"
  },
  firstIcon: {
    type: me,
    default: "$first"
  },
  lastIcon: {
    type: me,
    default: "$last"
  },
  itemsPerPageText: {
    type: String,
    default: "$vuetify.dataFooter.itemsPerPageText"
  },
  pageText: {
    type: String,
    default: "$vuetify.dataFooter.pageText"
  },
  firstPageLabel: {
    type: String,
    default: "$vuetify.dataFooter.firstPage"
  },
  prevPageLabel: {
    type: String,
    default: "$vuetify.dataFooter.prevPage"
  },
  nextPageLabel: {
    type: String,
    default: "$vuetify.dataFooter.nextPage"
  },
  lastPageLabel: {
    type: String,
    default: "$vuetify.dataFooter.lastPage"
  },
  itemsPerPageOptions: {
    type: Array,
    default: () => [{
      value: 10,
      title: "10"
    }, {
      value: 25,
      title: "25"
    }, {
      value: 50,
      title: "50"
    }, {
      value: 100,
      title: "100"
    }, {
      value: -1,
      title: "$vuetify.dataFooter.itemsPerPageAll"
    }]
  },
  showCurrentPage: Boolean
}, "VDataTableFooter"), Pa = Y()({
  name: "VDataTableFooter",
  props: po(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      t: a
    } = Ee(), {
      page: l,
      pageCount: i,
      startIndex: o,
      stopIndex: r,
      itemsLength: u,
      itemsPerPage: c,
      setItemsPerPage: s
    } = Ny(), d = C(() => e.itemsPerPageOptions.map((f) => typeof f == "number" ? {
      value: f,
      title: f === -1 ? a("$vuetify.dataFooter.itemsPerPageAll") : String(f)
    } : le(v({}, f), {
      title: isNaN(Number(f.title)) ? a(f.title) : f.title
    })));
    return Z(() => {
      var m;
      const f = Ti.filterProps(e);
      return w("div", {
        class: "v-data-table-footer"
      }, [(m = t.prepend) == null ? void 0 : m.call(t), w("div", {
        class: "v-data-table-footer__items-per-page"
      }, [w("span", {
        "aria-label": a(e.itemsPerPageText)
      }, [a(e.itemsPerPageText)]), k(Po, {
        items: d.value,
        modelValue: c.value,
        "onUpdate:modelValue": (h) => s(Number(h)),
        density: "compact",
        variant: "outlined",
        hideDetails: !0
      }, null)]), w("div", {
        class: "v-data-table-footer__info"
      }, [w("div", null, [a(e.pageText, u.value ? o.value + 1 : 0, r.value, u.value)])]), w("div", {
        class: "v-data-table-footer__pagination"
      }, [k(Ti, G({
        modelValue: l.value,
        "onUpdate:modelValue": (h) => l.value = h,
        density: "comfortable",
        firstAriaLabel: e.firstPageLabel,
        lastAriaLabel: e.lastPageLabel,
        length: i.value,
        nextAriaLabel: e.nextPageLabel,
        previousAriaLabel: e.prevPageLabel,
        rounded: !0,
        showFirstLastPage: !0,
        totalVisible: e.showCurrentPage ? 1 : 0,
        variant: "plain"
      }, f), null)])]);
    }), {};
  }
}), sl = pv({
  align: {
    type: String,
    default: "start"
  },
  fixed: {
    type: [Boolean, String],
    default: !1
  },
  fixedOffset: [Number, String],
  fixedEndOffset: [Number, String],
  height: [Number, String],
  lastFixed: Boolean,
  firstFixedEnd: Boolean,
  noPadding: Boolean,
  tag: String,
  width: [Number, String],
  maxWidth: [Number, String],
  nowrap: Boolean
}, (e, n) => {
  var i;
  let {
    slots: t
  } = n;
  const a = (i = e.tag) != null ? i : "td", l = typeof e.fixed == "string" ? e.fixed : e.fixed ? "start" : "none";
  return k(a, {
    class: X(["v-data-table__td", {
      "v-data-table-column--fixed": l === "start",
      "v-data-table-column--fixed-end": l === "end",
      "v-data-table-column--last-fixed": e.lastFixed,
      "v-data-table-column--first-fixed-end": e.firstFixedEnd,
      "v-data-table-column--no-padding": e.noPadding,
      "v-data-table-column--nowrap": e.nowrap
    }, `v-data-table-column--align-${e.align}`]),
    style: {
      height: ce(e.height),
      width: ce(e.width),
      maxWidth: ce(e.maxWidth),
      left: l === "start" ? ce(e.fixedOffset || null) : void 0,
      right: l === "end" ? ce(e.fixedEndOffset || null) : void 0
    }
  }, {
    default: () => {
      var o;
      return [(o = t.default) == null ? void 0 : o.call(t)];
    }
  });
}), Xy = N({
  headers: Array
}, "DataTable-header"), Bc = Symbol.for("vuetify:data-table-headers"), Dc = {
  title: "",
  sortable: !1
}, Zy = le(v({}, Dc), {
  width: 48
});
function Qy() {
  const n = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : []).map((t) => ({
    element: t,
    priority: 0
  }));
  return {
    enqueue: (t, a) => {
      let l = !1;
      for (let i = 0; i < n.length; i++)
        if (n[i].priority > a) {
          n.splice(i, 0, {
            element: t,
            priority: a
          }), l = !0;
          break;
        }
      l || n.push({
        element: t,
        priority: a
      });
    },
    size: () => n.length,
    count: () => {
      let t = 0;
      if (!n.length) return 0;
      const a = Math.floor(n[0].priority);
      for (let l = 0; l < n.length; l++)
        Math.floor(n[l].priority) === a && (t += 1);
      return t;
    },
    dequeue: () => n.shift()
  };
}
function Bi(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
  if (!e.children)
    n.push(e);
  else
    for (const t of e.children)
      Bi(t, n);
  return n;
}
function Mc(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : /* @__PURE__ */ new Set();
  for (const t of e)
    t.key && n.add(t.key), t.children && Mc(t.children, n);
  return n;
}
function Jy(e) {
  if (e.key) {
    if (e.key === "data-table-group") return Dc;
    if (["data-table-expand", "data-table-select"].includes(e.key)) return Zy;
  }
}
function Eo(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  return e.children ? Math.max(n, ...e.children.map((t) => Eo(t, n + 1))) : n;
}
function eb(e) {
  let n = !1;
  function t(i, o) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "none";
    if (i)
      if (r !== "none" && (i.fixed = r), i.fixed === !0 && (i.fixed = "start"), i.fixed === o)
        if (i.children)
          if (o === "start")
            for (let u = i.children.length - 1; u >= 0; u--)
              t(i.children[u], o, o);
          else
            for (let u = 0; u < i.children.length; u++)
              t(i.children[u], o, o);
        else
          !n && o === "start" ? i.lastFixed = !0 : !n && o === "end" ? i.firstFixedEnd = !0 : isNaN(Number(i.width)) ? fa(`Multiple fixed columns should have a static width (key: ${i.key})`) : i.minWidth = Math.max(Number(i.width) || 0, Number(i.minWidth) || 0), n = !0;
      else if (i.children)
        if (o === "start")
          for (let u = i.children.length - 1; u >= 0; u--)
            t(i.children[u], o);
        else
          for (let u = 0; u < i.children.length; u++)
            t(i.children[u], o);
      else
        n = !1;
  }
  for (let i = e.length - 1; i >= 0; i--)
    t(e[i], "start");
  for (let i = 0; i < e.length; i++)
    t(e[i], "end");
  let a = 0;
  for (let i = 0; i < e.length; i++)
    a = pc(e[i], a);
  let l = 0;
  for (let i = e.length - 1; i >= 0; i--)
    l = Ec(e[i], l);
}
function pc(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  if (!e) return n;
  if (e.children) {
    e.fixedOffset = n;
    for (const t of e.children)
      n = pc(t, n);
  } else e.fixed && e.fixed !== "end" && (e.fixedOffset = n, n += parseFloat(e.width || "0") || 0);
  return n;
}
function Ec(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  if (!e) return n;
  if (e.children) {
    e.fixedEndOffset = n;
    for (const t of e.children)
      n = Ec(t, n);
  } else e.fixed === "end" && (e.fixedEndOffset = n, n += parseFloat(e.width || "0") || 0);
  return n;
}
function tb(e, n) {
  const t = [];
  let a = 0;
  const l = Qy(e);
  for (; l.size() > 0; ) {
    let o = l.count();
    const r = [];
    let u = 1;
    for (; o > 0; ) {
      const {
        element: c,
        priority: s
      } = l.dequeue(), d = n - a - Eo(c);
      if (r.push(le(v({}, c), {
        rowspan: d != null ? d : 1,
        colspan: c.children ? Bi(c).length : 1
      })), c.children)
        for (const f of c.children) {
          const m = s % 1 + u / Math.pow(10, a + 2);
          l.enqueue(f, a + d + m);
        }
      u += 1, o -= 1;
    }
    a += 1, t.push(r);
  }
  return {
    columns: e.map((o) => Bi(o)).flat(),
    headers: t
  };
}
function $c(e) {
  var t, a, l, i;
  const n = [];
  for (const o of e) {
    const r = v(v({}, Jy(o)), o), u = (t = r.key) != null ? t : typeof r.value == "string" ? r.value : null, c = (l = (a = r.value) != null ? a : u) != null ? l : null, s = le(v({}, r), {
      key: u,
      value: c,
      sortable: (i = r.sortable) != null ? i : r.key != null || !!r.sort,
      children: r.children ? $c(r.children) : void 0
    });
    n.push(s);
  }
  return n;
}
function $o(e, n) {
  const t = Q([]), a = Q([]), l = Q({}), i = Q({}), o = Q({});
  We(() => {
    var b, g, S, y;
    const c = (e.headers || Object.keys((b = e.items[0]) != null ? b : {}).map((P) => ({
      key: P,
      title: qn(P)
    }))).slice(), s = Mc(c);
    (g = n == null ? void 0 : n.groupBy) != null && g.value.length && !s.has("data-table-group") && c.unshift({
      key: "data-table-group",
      title: "Group"
    }), (S = n == null ? void 0 : n.showSelect) != null && S.value && !s.has("data-table-select") && c.unshift({
      key: "data-table-select"
    }), (y = n == null ? void 0 : n.showExpand) != null && y.value && !s.has("data-table-expand") && c.push({
      key: "data-table-expand"
    });
    const d = $c(c);
    eb(d);
    const f = Math.max(...d.map((P) => Eo(P))) + 1, m = tb(d, f);
    t.value = m.headers, a.value = m.columns;
    const h = m.headers.flat(1);
    for (const P of h)
      P.key && (P.sortable && (P.sort && (l.value[P.key] = P.sort), P.sortRaw && (i.value[P.key] = P.sortRaw)), P.filter && (o.value[P.key] = P.filter));
  });
  const r = {
    headers: t,
    columns: a,
    sortFunctions: l,
    sortRawFunctions: i,
    filterFunctions: o
  };
  return Oe(Bc, r), r;
}
function Ol() {
  const e = Pe(Bc);
  if (!e) throw new Error("Missing headers!");
  return e;
}
const Fc = N(v(v({
  color: String,
  disableSort: Boolean,
  fixedHeader: Boolean,
  multiSort: Boolean,
  sortAscIcon: {
    type: me,
    default: "$sortAsc"
  },
  sortDescIcon: {
    type: me,
    default: "$sortDesc"
  },
  headerProps: {
    type: Object
  },
  /** @deprecated */
  sticky: Boolean
}, Pn()), Cl()), "VDataTableHeaders"), wn = Y()({
  name: "VDataTableHeaders",
  props: Fc(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      t: a
    } = Ee(), {
      toggleSort: l,
      sortBy: i,
      isSorted: o
    } = Tc(), {
      someSelected: r,
      allSelected: u,
      selectAll: c,
      showSelectAll: s
    } = El(), {
      columns: d,
      headers: f
    } = Ol(), {
      loaderClasses: m
    } = Ba(e);
    function h(p, L) {
      if (!(e.sticky || e.fixedHeader) && !p.fixed) return;
      const D = typeof p.fixed == "string" ? p.fixed : p.fixed ? "start" : "none";
      return {
        position: "sticky",
        left: D === "start" ? ce(p.fixedOffset) : void 0,
        right: D === "end" ? ce(p.fixedEndOffset) : void 0,
        top: e.sticky || e.fixedHeader ? `calc(var(--v-table-header-height) * ${L})` : void 0
      };
    }
    function b(p, L) {
      p.key === "Enter" && !e.disableSort && l(L);
    }
    function g(p) {
      const L = i.value.find((D) => D.key === p.key);
      return L ? L.order === "asc" ? e.sortAscIcon : e.sortDescIcon : e.sortAscIcon;
    }
    const {
      backgroundColorClasses: S,
      backgroundColorStyles: y
    } = pe(() => e.color), {
      displayClasses: P,
      mobile: V
    } = At(e), x = C(() => ({
      headers: f.value,
      columns: d.value,
      toggleSort: l,
      isSorted: o,
      sortBy: i.value,
      someSelected: r.value,
      allSelected: u.value,
      selectAll: c,
      getSortIcon: g
    })), I = C(() => ["v-data-table__th", {
      "v-data-table__th--sticky": e.sticky || e.fixedHeader
    }, P.value, m.value]), T = (p) => {
      var $, W;
      let {
        column: L,
        x: D,
        y: A
      } = p;
      const B = L.key === "data-table-select" || L.key === "data-table-expand", F = G(($ = e.headerProps) != null ? $ : {}, (W = L.headerProps) != null ? W : {});
      return k(sl, G({
        tag: "th",
        align: L.align,
        class: [{
          "v-data-table__th--sortable": L.sortable && !e.disableSort,
          "v-data-table__th--sorted": o(L),
          "v-data-table__th--fixed": L.fixed
        }, ...I.value],
        style: v({
          width: ce(L.width),
          minWidth: ce(L.minWidth),
          maxWidth: ce(L.maxWidth)
        }, h(L, A)),
        colspan: L.colspan,
        rowspan: L.rowspan,
        fixed: L.fixed,
        nowrap: L.nowrap,
        lastFixed: L.lastFixed,
        firstFixedEnd: L.firstFixedEnd,
        noPadding: B,
        tabindex: L.sortable ? 0 : void 0,
        onClick: L.sortable ? () => l(L) : void 0,
        onKeydown: L.sortable ? (J) => b(J, L) : void 0
      }, F), {
        default: () => {
          var H, E;
          const J = `header.${L.key}`, z = {
            column: L,
            selectAll: c,
            isSorted: o,
            toggleSort: l,
            sortBy: i.value,
            someSelected: r.value,
            allSelected: u.value,
            getSortIcon: g
          };
          return t[J] ? t[J](z) : L.key === "data-table-select" ? (E = (H = t["header.data-table-select"]) == null ? void 0 : H.call(t, z)) != null ? E : s.value && k(zt, {
            modelValue: u.value,
            indeterminate: r.value && !u.value,
            "onUpdate:modelValue": c
          }, null) : w("div", {
            class: "v-data-table-header__content"
          }, [w("span", null, [L.title]), L.sortable && !e.disableSort && k(Be, {
            key: "icon",
            class: "v-data-table-header__sort-icon",
            icon: g(L)
          }, null), e.multiSort && o(L) && w("div", {
            key: "badge",
            class: X(["v-data-table-header__sort-badge", ...S.value]),
            style: ie(y.value)
          }, [i.value.findIndex((O) => O.key === L.key) + 1])]);
        }
      });
    }, _ = () => {
      const p = C(() => d.value.filter((D) => (D == null ? void 0 : D.sortable) && !e.disableSort)), L = C(() => {
        if (d.value.find((A) => A.key === "data-table-select") != null)
          return u.value ? "$checkboxOn" : r.value ? "$checkboxIndeterminate" : "$checkboxOff";
      });
      return k(sl, G({
        tag: "th",
        class: [...I.value],
        colspan: f.value.length + 1
      }, e.headerProps), {
        default: () => [w("div", {
          class: "v-data-table-header__content"
        }, [k(Po, {
          chips: !0,
          class: "v-data-table__td-sort-select",
          clearable: !0,
          density: "default",
          items: p.value,
          label: a("$vuetify.dataTable.sortBy"),
          multiple: e.multiSort,
          variant: "underlined",
          "onClick:clear": () => i.value = [],
          appendIcon: L.value,
          "onClick:append": () => c(!u.value)
        }, {
          chip: (D) => {
            var A;
            return k(na, {
              onClick: (A = D.item.raw) != null && A.sortable ? () => l(D.item.raw) : void 0,
              onMousedown: (B) => {
                B.preventDefault(), B.stopPropagation();
              }
            }, {
              default: () => [D.item.title, k(Be, {
                class: X(["v-data-table__td-sort-icon", o(D.item.raw) && "v-data-table__td-sort-icon-active"]),
                icon: g(D.item.raw),
                size: "small"
              }, null)]
            });
          }
        })])]
      });
    };
    Z(() => V.value ? w("tr", null, [k(_, null, null)]) : w(he, null, [t.headers ? t.headers(x.value) : f.value.map((p, L) => w("tr", null, [p.map((D, A) => k(T, {
      column: D,
      x: A,
      y: L
    }, null))])), e.loading && w("tr", {
      class: "v-data-table-progress"
    }, [w("th", {
      colspan: d.value.length
    }, [k(Da, {
      name: "v-data-table-progress",
      absolute: !0,
      active: !0,
      color: typeof e.loading == "boolean" ? void 0 : e.loading,
      indeterminate: !0
    }, {
      default: t.loader
    })])])]));
  }
}), nb = N({
  item: {
    type: Object,
    required: !0
  }
}, "VDataTableGroupHeaderRow"), ab = Y()({
  name: "VDataTableGroupHeaderRow",
  props: nb(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      isGroupOpen: a,
      toggleGroup: l,
      extractRows: i
    } = Sc(), {
      isSelected: o,
      isSomeSelected: r,
      select: u
    } = El(), {
      columns: c
    } = Ol(), s = C(() => i([e.item]));
    return () => w("tr", {
      class: "v-data-table-group-header-row",
      style: {
        "--v-data-table-group-header-row-depth": e.item.depth
      }
    }, [c.value.map((d) => {
      var f, m, h, b;
      if (d.key === "data-table-group") {
        const g = a(e.item) ? "$expand" : "$next", S = () => l(e.item);
        return (m = (f = t["data-table-group"]) == null ? void 0 : f.call(t, {
          item: e.item,
          count: s.value.length,
          props: {
            icon: g,
            onClick: S
          }
        })) != null ? m : k(sl, {
          class: "v-data-table-group-header-row__column"
        }, {
          default: () => [k(xe, {
            size: "small",
            variant: "text",
            icon: g,
            onClick: S
          }, null), w("span", null, [e.item.value]), w("span", null, [Nt("("), s.value.length, Nt(")")])]
        });
      }
      if (d.key === "data-table-select") {
        const g = o(s.value), S = r(s.value) && !g, y = (P) => u(s.value, P);
        return (b = (h = t["data-table-select"]) == null ? void 0 : h.call(t, {
          props: {
            modelValue: g,
            indeterminate: S,
            "onUpdate:modelValue": y
          }
        })) != null ? b : w("td", null, [k(zt, {
          modelValue: g,
          indeterminate: S,
          "onUpdate:modelValue": y
        }, null)]);
      }
      return w("td", null, null);
    })]);
  }
}), lb = N(v({
  index: Number,
  item: Object,
  cellProps: [Object, Function],
  onClick: ot(),
  onContextmenu: ot(),
  onDblclick: ot()
}, Pn()), "VDataTableRow"), Fo = Y()({
  name: "VDataTableRow",
  props: lb(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      displayClasses: a,
      mobile: l
    } = At(e, "v-data-table__tr"), {
      isSelected: i,
      toggleSelect: o,
      someSelected: r,
      allSelected: u,
      selectAll: c
    } = El(), {
      isExpanded: s,
      toggleExpand: d
    } = yc(), {
      toggleSort: f,
      sortBy: m,
      isSorted: h
    } = Tc(), {
      columns: b
    } = Ol();
    Z(() => w("tr", {
      class: X(["v-data-table__tr", {
        "v-data-table__tr--clickable": !!(e.onClick || e.onContextmenu || e.onDblclick)
      }, a.value]),
      onClick: e.onClick,
      onContextmenu: e.onContextmenu,
      onDblclick: e.onDblclick
    }, [e.item && b.value.map((g, S) => {
      const y = e.item, P = `item.${g.key}`, V = `header.${g.key}`, x = {
        index: e.index,
        item: y.raw,
        internalItem: y,
        value: yn(y.columns, g.key),
        column: g,
        isSelected: i,
        toggleSelect: o,
        isExpanded: s,
        toggleExpand: d
      }, I = {
        column: g,
        selectAll: c,
        isSorted: h,
        toggleSort: f,
        sortBy: m.value,
        someSelected: r.value,
        allSelected: u.value,
        getSortIcon: () => ""
      }, T = typeof e.cellProps == "function" ? e.cellProps({
        index: x.index,
        item: x.item,
        internalItem: x.internalItem,
        value: x.value,
        column: g
      }) : e.cellProps, _ = typeof g.cellProps == "function" ? g.cellProps({
        index: x.index,
        item: x.item,
        internalItem: x.internalItem,
        value: x.value
      }) : g.cellProps;
      return k(sl, G({
        align: g.align,
        class: {
          "v-data-table__td--expanded-row": g.key === "data-table-expand",
          "v-data-table__td--select-row": g.key === "data-table-select"
        },
        fixed: g.fixed,
        fixedOffset: g.fixedOffset,
        fixedEndOffset: g.fixedEndOffset,
        lastFixed: g.lastFixed,
        firstFixedEnd: g.firstFixedEnd,
        maxWidth: l.value ? void 0 : g.maxWidth,
        noPadding: g.key === "data-table-select" || g.key === "data-table-expand",
        nowrap: g.nowrap,
        width: l.value ? void 0 : g.width
      }, T, _), {
        default: () => {
          var L, D, A, B, F, $, W, J;
          if (g.key === "data-table-select")
            return (D = (L = t["item.data-table-select"]) == null ? void 0 : L.call(t, le(v({}, x), {
              props: {
                disabled: !y.selectable,
                modelValue: i([y]),
                onClick: ja(() => o(y), ["stop"])
              }
            }))) != null ? D : k(zt, {
              disabled: !y.selectable,
              modelValue: i([y]),
              onClick: ja((z) => o(y, e.index, z), ["stop"])
            }, null);
          if (g.key === "data-table-expand")
            return (B = (A = t["item.data-table-expand"]) == null ? void 0 : A.call(t, le(v({}, x), {
              props: {
                icon: s(y) ? "$collapse" : "$expand",
                size: "small",
                variant: "text",
                onClick: ja(() => d(y), ["stop"])
              }
            }))) != null ? B : k(xe, {
              icon: s(y) ? "$collapse" : "$expand",
              size: "small",
              variant: "text",
              onClick: ja(() => d(y), ["stop"])
            }, null);
          if (t[P] && !l.value) return t[P](x);
          const p = hn(x.value);
          return l.value ? w(he, null, [w("div", {
            class: "v-data-table__td-title"
          }, [($ = (F = t[V]) == null ? void 0 : F.call(t, I)) != null ? $ : g.title]), w("div", {
            class: "v-data-table__td-value"
          }, [(J = (W = t[P]) == null ? void 0 : W.call(t, x)) != null ? J : p])]) : p;
        }
      });
    })]));
  }
}), Oc = N(v({
  loading: [Boolean, String],
  loadingText: {
    type: String,
    default: "$vuetify.dataIterator.loadingText"
  },
  hideNoData: Boolean,
  items: {
    type: Array,
    default: () => []
  },
  noDataText: {
    type: String,
    default: "$vuetify.noDataText"
  },
  rowProps: [Object, Function],
  cellProps: [Object, Function]
}, Pn()), "VDataTableRows"), Cn = Y()({
  name: "VDataTableRows",
  inheritAttrs: !1,
  props: Oc(),
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      columns: l
    } = Ol(), {
      expandOnClick: i,
      toggleExpand: o,
      isExpanded: r
    } = yc(), {
      isSelected: u,
      toggleSelect: c
    } = El(), {
      toggleGroup: s,
      isGroupOpen: d
    } = Sc(), {
      t: f
    } = Ee(), {
      mobile: m
    } = At(e);
    return Z(() => {
      var h, b, g, S;
      return e.loading && (!e.items.length || a.loading) ? w("tr", {
        class: "v-data-table-rows-loading",
        key: "loading"
      }, [w("td", {
        colspan: l.value.length
      }, [(b = (h = a.loading) == null ? void 0 : h.call(a)) != null ? b : f(e.loadingText)])]) : !e.loading && !e.items.length && !e.hideNoData ? w("tr", {
        class: "v-data-table-rows-no-data",
        key: "no-data"
      }, [w("td", {
        colspan: l.value.length
      }, [(S = (g = a["no-data"]) == null ? void 0 : g.call(a)) != null ? S : f(e.noDataText)])]) : w(he, null, [e.items.map((y, P) => {
        var I, T;
        if (y.type === "group") {
          const _ = {
            index: P,
            item: y,
            columns: l.value,
            isExpanded: r,
            toggleExpand: o,
            isSelected: u,
            toggleSelect: c,
            toggleGroup: s,
            isGroupOpen: d
          };
          return a["group-header"] ? a["group-header"](_) : k(ab, G({
            key: `group-header_${y.id}`,
            item: y
          }, hr(t, ":group-header", () => _)), a);
        }
        const V = {
          index: P,
          item: y.raw,
          internalItem: y,
          columns: l.value,
          isExpanded: r,
          toggleExpand: o,
          isSelected: u,
          toggleSelect: c
        }, x = le(v({}, V), {
          props: G({
            key: `item_${(I = y.key) != null ? I : y.index}`,
            onClick: i.value ? () => {
              o(y);
            } : void 0,
            index: P,
            item: y,
            cellProps: e.cellProps,
            mobile: m.value
          }, hr(t, ":row", () => V), typeof e.rowProps == "function" ? e.rowProps({
            item: V.item,
            index: V.index,
            internalItem: V.internalItem
          }) : e.rowProps)
        });
        return w(he, {
          key: x.props.key
        }, [a.item ? a.item(x) : k(Fo, x.props, a), r(y) && ((T = a["expanded-row"]) == null ? void 0 : T.call(a, V))]);
      })]);
    }), {};
  }
}), Nc = N(v(v(v(v({
  fixedHeader: Boolean,
  fixedFooter: Boolean,
  height: [Number, String],
  hover: Boolean,
  striped: {
    type: String,
    default: null,
    validator: (e) => ["even", "odd"].includes(e)
  }
}, de()), nt()), ke()), Ie()), "VTable"), xn = Y()({
  name: "VTable",
  props: Nc(),
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const {
      themeClasses: l
    } = De(e), {
      densityClasses: i
    } = ht(e);
    return Z(() => {
      const o = {
        VCheckboxBtn: {
          density: e.density
        }
      };
      return k(e.tag, {
        class: X(["v-table", {
          "v-table--fixed-height": !!e.height,
          "v-table--fixed-header": e.fixedHeader,
          "v-table--fixed-footer": e.fixedFooter,
          "v-table--has-top": !!t.top,
          "v-table--has-bottom": !!t.bottom,
          "v-table--hover": e.hover,
          "v-table--striped-even": e.striped === "even",
          "v-table--striped-odd": e.striped === "odd"
        }, l.value, i.value, e.class]),
        style: ie(e.style)
      }, {
        default: () => {
          var r, u;
          return [(r = t.top) == null ? void 0 : r.call(t), k(Ce, {
            defaults: o
          }, {
            default: () => {
              var c;
              return [t.default ? w("div", {
                class: "v-table__wrapper",
                style: {
                  height: ce(e.height)
                }
              }, [w("table", null, [t.default()])]) : (c = t.wrapper) == null ? void 0 : c.call(t)];
            }
          }), (u = t.bottom) == null ? void 0 : u.call(t)];
        }
      });
    }), {};
  }
}), ib = N({
  items: {
    type: Array,
    default: () => []
  },
  itemValue: {
    type: [String, Array, Function],
    default: "id"
  },
  itemSelectable: {
    type: [String, Array, Function],
    default: null
  },
  rowProps: [Object, Function],
  cellProps: [Object, Function],
  returnObject: Boolean
}, "DataTable-items");
function ob(e, n, t, a) {
  const l = e.returnObject ? n : qe(n, e.itemValue), i = qe(n, e.itemSelectable, !0), o = a.reduce((r, u) => (u.key != null && (r[u.key] = qe(n, u.value)), r), {});
  return {
    type: "item",
    key: e.returnObject ? qe(n, e.itemValue) : l,
    index: t,
    value: l,
    selectable: i,
    columns: o,
    raw: n
  };
}
function rb(e, n, t) {
  return n.map((a, l) => ob(e, a, l, t));
}
function Oo(e, n) {
  return {
    items: C(() => rb(e, e.items, n.value))
  };
}
const No = N(v(v(v(v(v(v(v(v(le(v({}, Oc()), {
  hideDefaultBody: Boolean,
  hideDefaultFooter: Boolean,
  hideDefaultHeader: Boolean,
  width: [String, Number],
  search: String
}), gc()), Ao()), Xy()), ib()), Ic()), Ac()), Fc()), Nc()), "DataTable"), ub = N(v(v(v(v({}, To()), No()), la()), po()), "VDataTable"), sb = Y()({
  name: "VDataTable",
  props: ub(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:page": (e) => !0,
    "update:itemsPerPage": (e) => !0,
    "update:sortBy": (e) => !0,
    "update:options": (e) => !0,
    "update:groupBy": (e) => !0,
    "update:expanded": (e) => !0,
    "update:currentItems": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      groupBy: l
    } = Lo(e), {
      sortBy: i,
      multiSort: o,
      mustSort: r
    } = $l(e), {
      page: u,
      itemsPerPage: c
    } = Bo(e), {
      disableSort: s
    } = Xn(e), {
      columns: d,
      headers: f,
      sortFunctions: m,
      sortRawFunctions: h,
      filterFunctions: b
    } = $o(e, {
      groupBy: l,
      showSelect: M(() => e.showSelect),
      showExpand: M(() => e.showExpand)
    }), {
      items: g
    } = Oo(e, d), S = M(() => e.search), {
      filteredItems: y
    } = ia(e, g, S, {
      transform: (j) => j.columns,
      customKeyFilter: b
    }), {
      toggleSort: P
    } = Fl({
      sortBy: i,
      multiSort: o,
      mustSort: r,
      page: u
    }), {
      sortByWithGroups: V,
      opened: x,
      extractRows: I,
      isGroupOpen: T,
      toggleGroup: _
    } = Bl({
      groupBy: l,
      sortBy: i,
      disableSort: s
    }), {
      sortedItems: p
    } = Mo(e, y, V, {
      transform: (j) => v(v({}, j.raw), j.columns),
      sortFunctions: m,
      sortRawFunctions: h
    }), {
      flatItems: L
    } = Dl(p, l, x), D = C(() => L.value.length), {
      startIndex: A,
      stopIndex: B,
      pageCount: F,
      setItemsPerPage: $
    } = Do({
      page: u,
      itemsPerPage: c,
      itemsLength: D
    }), {
      paginatedItems: W
    } = xc({
      items: L,
      startIndex: A,
      stopIndex: B,
      itemsPerPage: c
    }), J = C(() => I(W.value)), {
      isSelected: z,
      select: H,
      selectAll: E,
      toggleSelect: O,
      someSelected: R,
      allSelected: q
    } = pl(e, {
      allItems: g,
      currentPage: J
    }), {
      isExpanded: ae,
      toggleExpand: U
    } = Tl(e);
    Ml({
      page: u,
      itemsPerPage: c,
      sortBy: i,
      groupBy: l,
      search: S
    }), je({
      VDataTableRows: {
        hideNoData: M(() => e.hideNoData),
        noDataText: M(() => e.noDataText),
        loading: M(() => e.loading),
        loadingText: M(() => e.loadingText)
      }
    });
    const ne = C(() => ({
      page: u.value,
      itemsPerPage: c.value,
      sortBy: i.value,
      pageCount: F.value,
      toggleSort: P,
      setItemsPerPage: $,
      someSelected: R.value,
      allSelected: q.value,
      isSelected: z,
      select: H,
      selectAll: E,
      toggleSelect: O,
      isExpanded: ae,
      toggleExpand: U,
      isGroupOpen: T,
      toggleGroup: _,
      items: J.value.map((j) => j.raw),
      internalItems: J.value,
      groupedItems: W.value,
      columns: d.value,
      headers: f.value
    }));
    return Z(() => {
      const j = Pa.filterProps(e), ue = wn.filterProps(e), ge = Cn.filterProps(e), ee = xn.filterProps(e);
      return k(xn, G({
        class: ["v-data-table", {
          "v-data-table--show-select": e.showSelect,
          "v-data-table--loading": e.loading
        }, e.class],
        style: e.style
      }, ee, {
        fixedHeader: e.fixedHeader || e.sticky
      }), {
        top: () => {
          var re;
          return (re = a.top) == null ? void 0 : re.call(a, ne.value);
        },
        default: () => {
          var re, fe, K, se, ye, be;
          return a.default ? a.default(ne.value) : w(he, null, [(re = a.colgroup) == null ? void 0 : re.call(a, ne.value), !e.hideDefaultHeader && w("thead", {
            key: "thead"
          }, [k(wn, ue, a)]), (fe = a.thead) == null ? void 0 : fe.call(a, ne.value), !e.hideDefaultBody && w("tbody", null, [(K = a["body.prepend"]) == null ? void 0 : K.call(a, ne.value), a.body ? a.body(ne.value) : k(Cn, G(t, ge, {
            items: W.value
          }), a), (se = a["body.append"]) == null ? void 0 : se.call(a, ne.value)]), (ye = a.tbody) == null ? void 0 : ye.call(a, ne.value), (be = a.tfoot) == null ? void 0 : be.call(a, ne.value)]);
        },
        bottom: () => a.bottom ? a.bottom(ne.value) : !e.hideDefaultFooter && w(he, null, [k(It, null, null), k(Pa, j, {
          prepend: a["footer.prepend"]
        })])
      });
    }), {};
  }
}), cb = N(v(v(v(v({}, $e(No(), ["hideDefaultFooter"])), Ao()), qs()), la()), "VDataTableVirtual"), db = Y()({
  name: "VDataTableVirtual",
  props: cb(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:sortBy": (e) => !0,
    "update:options": (e) => !0,
    "update:groupBy": (e) => !0,
    "update:expanded": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      groupBy: l
    } = Lo(e), {
      sortBy: i,
      multiSort: o,
      mustSort: r
    } = $l(e), {
      disableSort: u
    } = Xn(e), {
      columns: c,
      headers: s,
      filterFunctions: d,
      sortFunctions: f,
      sortRawFunctions: m
    } = $o(e, {
      groupBy: l,
      showSelect: M(() => e.showSelect),
      showExpand: M(() => e.showExpand)
    }), {
      items: h
    } = Oo(e, c), b = M(() => e.search), {
      filteredItems: g
    } = ia(e, h, b, {
      transform: (ee) => ee.columns,
      customKeyFilter: d
    }), {
      toggleSort: S
    } = Fl({
      sortBy: i,
      multiSort: o,
      mustSort: r
    }), {
      sortByWithGroups: y,
      opened: P,
      extractRows: V,
      isGroupOpen: x,
      toggleGroup: I
    } = Bl({
      groupBy: l,
      sortBy: i,
      disableSort: u
    }), {
      sortedItems: T
    } = Mo(e, g, y, {
      transform: (ee) => v(v({}, ee.raw), ee.columns),
      sortFunctions: f,
      sortRawFunctions: m
    }), {
      flatItems: _
    } = Dl(T, l, P), p = C(() => V(_.value)), {
      isSelected: L,
      select: D,
      selectAll: A,
      toggleSelect: B,
      someSelected: F,
      allSelected: $
    } = pl(e, {
      allItems: p,
      currentPage: p
    }), {
      isExpanded: W,
      toggleExpand: J
    } = Tl(e), {
      containerRef: z,
      markerRef: H,
      paddingTop: E,
      paddingBottom: O,
      computedItems: R,
      handleItemResize: q,
      handleScroll: ae,
      handleScrollend: U,
      calculateVisibleItems: ne,
      scrollToIndex: j
    } = Xs(e, _), ue = C(() => R.value.map((ee) => ee.raw));
    Ml({
      sortBy: i,
      page: te(1),
      itemsPerPage: te(-1),
      groupBy: l,
      search: b
    }), je({
      VDataTableRows: {
        hideNoData: M(() => e.hideNoData),
        noDataText: M(() => e.noDataText),
        loading: M(() => e.loading),
        loadingText: M(() => e.loadingText)
      }
    });
    const ge = C(() => ({
      sortBy: i.value,
      toggleSort: S,
      someSelected: F.value,
      allSelected: $.value,
      isSelected: L,
      select: D,
      selectAll: A,
      toggleSelect: B,
      isExpanded: W,
      toggleExpand: J,
      isGroupOpen: x,
      toggleGroup: I,
      items: p.value.map((ee) => ee.raw),
      internalItems: p.value,
      groupedItems: _.value,
      columns: c.value,
      headers: s.value
    }));
    return Z(() => {
      const ee = wn.filterProps(e), re = Cn.filterProps(e), fe = xn.filterProps(e);
      return k(xn, G({
        class: ["v-data-table", {
          "v-data-table--loading": e.loading
        }, e.class],
        style: e.style
      }, fe, {
        fixedHeader: e.fixedHeader || e.sticky
      }), {
        top: () => {
          var K;
          return (K = a.top) == null ? void 0 : K.call(a, ge.value);
        },
        wrapper: () => {
          var K, se, ye, be, we, Me;
          return w("div", {
            ref: z,
            onScrollPassive: ae,
            onScrollend: U,
            class: "v-table__wrapper",
            style: {
              height: ce(e.height)
            }
          }, [w("table", null, [(K = a.colgroup) == null ? void 0 : K.call(a, ge.value), !e.hideDefaultHeader && w("thead", {
            key: "thead"
          }, [k(wn, ee, a)]), (se = a.thead) == null ? void 0 : se.call(a, ge.value), !e.hideDefaultBody && w("tbody", {
            key: "tbody"
          }, [w("tr", {
            ref: H,
            style: {
              height: ce(E.value),
              border: 0
            }
          }, [w("td", {
            colspan: c.value.length,
            style: {
              height: 0,
              border: 0
            }
          }, null)]), (ye = a["body.prepend"]) == null ? void 0 : ye.call(a, ge.value), k(Cn, G(t, re, {
            items: ue.value
          }), le(v({}, a), {
            item: (Se) => k(Ks, {
              key: Se.internalItem.index,
              renderless: !0,
              "onUpdate:height": (_e) => q(Se.internalItem.index, _e)
            }, {
              default: (_e) => {
                var Ae, wt;
                let {
                  itemRef: ut
                } = _e;
                return (wt = (Ae = a.item) == null ? void 0 : Ae.call(a, le(v({}, Se), {
                  itemRef: ut
                }))) != null ? wt : k(Fo, G(Se.props, {
                  ref: ut,
                  key: Se.internalItem.index,
                  index: Se.internalItem.index
                }), a);
              }
            })
          })), (be = a["body.append"]) == null ? void 0 : be.call(a, ge.value), w("tr", {
            style: {
              height: ce(O.value),
              border: 0
            }
          }, [w("td", {
            colspan: c.value.length,
            style: {
              height: 0,
              border: 0
            }
          }, null)])]), (we = a.tbody) == null ? void 0 : we.call(a, ge.value), (Me = a.tfoot) == null ? void 0 : Me.call(a, ge.value)])]);
        },
        bottom: () => {
          var K;
          return (K = a.bottom) == null ? void 0 : K.call(a, ge.value);
        }
      });
    }), {
      calculateVisibleItems: ne,
      scrollToIndex: j
    };
  }
}), vb = N(v(v(v({
  itemsLength: {
    type: [Number, String],
    required: !0
  }
}, To()), No()), po()), "VDataTableServer"), fb = Y()({
  name: "VDataTableServer",
  props: vb(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:page": (e) => !0,
    "update:itemsPerPage": (e) => !0,
    "update:sortBy": (e) => !0,
    "update:options": (e) => !0,
    "update:expanded": (e) => !0,
    "update:groupBy": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const {
      groupBy: l
    } = Lo(e), {
      sortBy: i,
      multiSort: o,
      mustSort: r
    } = $l(e), {
      page: u,
      itemsPerPage: c
    } = Bo(e), {
      disableSort: s
    } = Xn(e), d = C(() => parseInt(e.itemsLength, 10)), {
      columns: f,
      headers: m
    } = $o(e, {
      groupBy: l,
      showSelect: M(() => e.showSelect),
      showExpand: M(() => e.showExpand)
    }), {
      items: h
    } = Oo(e, f), {
      toggleSort: b
    } = Fl({
      sortBy: i,
      multiSort: o,
      mustSort: r,
      page: u
    }), {
      opened: g,
      isGroupOpen: S,
      toggleGroup: y,
      extractRows: P
    } = Bl({
      groupBy: l,
      sortBy: i,
      disableSort: s
    }), {
      pageCount: V,
      setItemsPerPage: x
    } = Do({
      page: u,
      itemsPerPage: c,
      itemsLength: d
    }), {
      flatItems: I
    } = Dl(h, l, g), {
      isSelected: T,
      select: _,
      selectAll: p,
      toggleSelect: L,
      someSelected: D,
      allSelected: A
    } = pl(e, {
      allItems: h,
      currentPage: h
    }), {
      isExpanded: B,
      toggleExpand: F
    } = Tl(e), $ = C(() => P(h.value));
    Ml({
      page: u,
      itemsPerPage: c,
      sortBy: i,
      groupBy: l,
      search: M(() => e.search)
    }), Oe("v-data-table", {
      toggleSort: b,
      sortBy: i
    }), je({
      VDataTableRows: {
        hideNoData: M(() => e.hideNoData),
        noDataText: M(() => e.noDataText),
        loading: M(() => e.loading),
        loadingText: M(() => e.loadingText)
      }
    });
    const W = C(() => ({
      page: u.value,
      itemsPerPage: c.value,
      sortBy: i.value,
      pageCount: V.value,
      toggleSort: b,
      setItemsPerPage: x,
      someSelected: D.value,
      allSelected: A.value,
      isSelected: T,
      select: _,
      selectAll: p,
      toggleSelect: L,
      isExpanded: B,
      toggleExpand: F,
      isGroupOpen: S,
      toggleGroup: y,
      items: $.value.map((J) => J.raw),
      internalItems: $.value,
      groupedItems: I.value,
      columns: f.value,
      headers: m.value
    }));
    Z(() => {
      const J = Pa.filterProps(e), z = wn.filterProps(e), H = Cn.filterProps(e), E = xn.filterProps(e);
      return k(xn, G({
        class: ["v-data-table", {
          "v-data-table--loading": e.loading
        }, e.class],
        style: e.style
      }, E, {
        fixedHeader: e.fixedHeader || e.sticky
      }), {
        top: () => {
          var O;
          return (O = a.top) == null ? void 0 : O.call(a, W.value);
        },
        default: () => {
          var O, R, q, ae, U, ne;
          return a.default ? a.default(W.value) : w(he, null, [(O = a.colgroup) == null ? void 0 : O.call(a, W.value), !e.hideDefaultHeader && w("thead", {
            key: "thead",
            class: "v-data-table__thead",
            role: "rowgroup"
          }, [k(wn, z, a)]), (R = a.thead) == null ? void 0 : R.call(a, W.value), !e.hideDefaultBody && w("tbody", {
            class: "v-data-table__tbody",
            role: "rowgroup"
          }, [(q = a["body.prepend"]) == null ? void 0 : q.call(a, W.value), a.body ? a.body(W.value) : k(Cn, G(t, H, {
            items: I.value
          }), a), (ae = a["body.append"]) == null ? void 0 : ae.call(a, W.value)]), (U = a.tbody) == null ? void 0 : U.call(a, W.value), (ne = a.tfoot) == null ? void 0 : ne.call(a, W.value)]);
        },
        bottom: () => a.bottom ? a.bottom(W.value) : !e.hideDefaultFooter && w(he, null, [k(It, null, null), k(Pa, J, {
          prepend: a["footer.prepend"]
        })])
      });
    });
  }
}), mb = N(v(v(v({
  fluid: {
    type: Boolean,
    default: !1
  }
}, de()), Ze()), ke()), "VContainer"), gb = Y()({
  name: "VContainer",
  props: mb(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      rtlClasses: a
    } = Xe(), {
      dimensionStyles: l
    } = Qe(e);
    return Z(() => k(e.tag, {
      class: X(["v-container", {
        "v-container--fluid": e.fluid
      }, a.value, e.class]),
      style: ie([l.value, e.style])
    }, t)), {};
  }
}), Rc = gl.reduce((e, n) => (e[n] = {
  type: [Boolean, String, Number],
  default: !1
}, e), {}), Hc = gl.reduce((e, n) => {
  const t = "offset" + qn(n);
  return e[t] = {
    type: [String, Number],
    default: null
  }, e;
}, {}), zc = gl.reduce((e, n) => {
  const t = "order" + qn(n);
  return e[t] = {
    type: [String, Number],
    default: null
  }, e;
}, {}), jr = {
  col: Object.keys(Rc),
  offset: Object.keys(Hc),
  order: Object.keys(zc)
};
function hb(e, n, t) {
  let a = e;
  if (!(t == null || t === !1)) {
    if (n) {
      const l = n.replace(e, "");
      a += `-${l}`;
    }
    return e === "col" && (a = "v-" + a), e === "col" && (t === "" || t === !0) || (a += `-${t}`), a.toLowerCase();
  }
}
const yb = ["auto", "start", "end", "center", "baseline", "stretch"], bb = N(v(v(le(v(le(v(le(v({
  cols: {
    type: [Boolean, String, Number],
    default: !1
  }
}, Rc), {
  offset: {
    type: [String, Number],
    default: null
  }
}), Hc), {
  order: {
    type: [String, Number],
    default: null
  }
}), zc), {
  alignSelf: {
    type: String,
    default: null,
    validator: (e) => yb.includes(e)
  }
}), de()), ke()), "VCol"), Sb = Y()({
  name: "VCol",
  props: bb(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = C(() => {
      const l = [];
      let i;
      for (i in jr)
        jr[i].forEach((r) => {
          const u = e[r], c = hb(i, r, u);
          c && l.push(c);
        });
      const o = l.some((r) => r.startsWith("v-col-"));
      return l.push({
        // Default to .v-col if no other col-{bp}-* classes generated nor `cols` specified.
        "v-col": !o || !e.cols,
        [`v-col-${e.cols}`]: e.cols,
        [`offset-${e.offset}`]: e.offset,
        [`order-${e.order}`]: e.order,
        [`align-self-${e.alignSelf}`]: e.alignSelf
      }), l;
    });
    return () => {
      var l;
      return Vn(e.tag, {
        class: [a.value, e.class],
        style: e.style
      }, (l = t.default) == null ? void 0 : l.call(t));
    };
  }
}), Ro = ["start", "end", "center"], Wc = ["space-between", "space-around", "space-evenly"];
function Ho(e, n) {
  return gl.reduce((t, a) => {
    const l = e + qn(a);
    return t[l] = n(), t;
  }, {});
}
const kb = [...Ro, "baseline", "stretch"], jc = (e) => kb.includes(e), Yc = Ho("align", () => ({
  type: String,
  default: null,
  validator: jc
})), wb = [...Ro, ...Wc], Gc = (e) => wb.includes(e), Uc = Ho("justify", () => ({
  type: String,
  default: null,
  validator: Gc
})), Cb = [...Ro, ...Wc, "stretch"], Kc = (e) => Cb.includes(e), qc = Ho("alignContent", () => ({
  type: String,
  default: null,
  validator: Kc
})), Yr = {
  align: Object.keys(Yc),
  justify: Object.keys(Uc),
  alignContent: Object.keys(qc)
}, xb = {
  align: "align",
  justify: "justify",
  alignContent: "align-content"
};
function Vb(e, n, t) {
  let a = xb[e];
  if (t != null) {
    if (n) {
      const l = n.replace(e, "");
      a += `-${l}`;
    }
    return a += `-${t}`, a.toLowerCase();
  }
}
const Pb = N(v(v(v(le(v(le(v({
  dense: Boolean,
  noGutters: Boolean,
  align: {
    type: String,
    default: null,
    validator: jc
  }
}, Yc), {
  justify: {
    type: String,
    default: null,
    validator: Gc
  }
}), Uc), {
  alignContent: {
    type: String,
    default: null,
    validator: Kc
  }
}), qc), de()), ke()), "VRow"), Ib = Y()({
  name: "VRow",
  props: Pb(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = C(() => {
      const l = [];
      let i;
      for (i in Yr)
        Yr[i].forEach((o) => {
          const r = e[o], u = Vb(i, o, r);
          u && l.push(u);
        });
      return l.push({
        "v-row--no-gutters": e.noGutters,
        "v-row--dense": e.dense,
        [`align-${e.align}`]: e.align,
        [`justify-${e.justify}`]: e.justify,
        [`align-content-${e.alignContent}`]: e.alignContent
      }), l;
    });
    return () => {
      var l;
      return Vn(e.tag, {
        class: ["v-row", a.value, e.class],
        style: e.style
      }, (l = t.default) == null ? void 0 : l.call(t));
    };
  }
}), Xc = Xt("v-spacer", "div", "VSpacer"), Zc = N({
  active: {
    type: [String, Array],
    default: void 0
  },
  controlHeight: [Number, String],
  disabled: {
    type: [Boolean, String, Array],
    default: null
  },
  nextIcon: {
    type: me,
    default: "$next"
  },
  prevIcon: {
    type: me,
    default: "$prev"
  },
  modeIcon: {
    type: me,
    default: "$subgroup"
  },
  text: String,
  viewMode: {
    type: String,
    default: "month"
  }
}, "VDatePickerControls"), Di = Y()({
  name: "VDatePickerControls",
  props: Zc(),
  emits: {
    "click:year": () => !0,
    "click:month": () => !0,
    "click:prev": () => !0,
    "click:next": () => !0,
    "click:text": () => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    const {
      t: a
    } = Ee(), l = C(() => Array.isArray(e.disabled) ? e.disabled.includes("text") : !!e.disabled), i = C(() => Array.isArray(e.disabled) ? e.disabled.includes("mode") : !!e.disabled), o = C(() => Array.isArray(e.disabled) ? e.disabled.includes("prev") : !!e.disabled), r = C(() => Array.isArray(e.disabled) ? e.disabled.includes("next") : !!e.disabled);
    function u() {
      t("click:prev");
    }
    function c() {
      t("click:next");
    }
    function s() {
      t("click:year");
    }
    function d() {
      t("click:month");
    }
    return Z(() => w("div", {
      class: X(["v-date-picker-controls"]),
      style: {
        "--v-date-picker-controls-height": ce(e.controlHeight)
      }
    }, [k(xe, {
      class: "v-date-picker-controls__month-btn",
      "data-testid": "month-btn",
      disabled: l.value,
      text: e.text,
      variant: "text",
      rounded: !0,
      onClick: d
    }, null), k(xe, {
      class: "v-date-picker-controls__mode-btn",
      "data-testid": "year-btn",
      disabled: i.value,
      density: "comfortable",
      icon: e.modeIcon,
      variant: "text",
      "aria-label": a("$vuetify.datePicker.ariaLabel.selectYear"),
      onClick: s
    }, null), k(Xc, null, null), w("div", {
      class: "v-date-picker-controls__month"
    }, [k(xe, {
      "data-testid": "prev-month",
      disabled: o.value,
      density: "comfortable",
      icon: e.prevIcon,
      variant: "text",
      "aria-label": a("$vuetify.datePicker.ariaLabel.previousMonth"),
      onClick: u
    }, null), k(xe, {
      "data-testid": "next-month",
      disabled: r.value,
      icon: e.nextIcon,
      density: "comfortable",
      variant: "text",
      "aria-label": a("$vuetify.datePicker.ariaLabel.nextMonth"),
      onClick: c
    }, null)])])), {};
  }
}), _b = N({
  appendIcon: me,
  color: String,
  header: String,
  transition: String,
  onClick: ot()
}, "VDatePickerHeader"), Mi = Y()({
  name: "VDatePickerHeader",
  props: _b(),
  emits: {
    click: () => !0,
    "click:append": () => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      backgroundColorClasses: l,
      backgroundColorStyles: i
    } = pe(() => e.color);
    function o() {
      t("click");
    }
    function r() {
      t("click:append");
    }
    return Z(() => {
      const u = !!(a.default || e.header), c = !!(a.append || e.appendIcon);
      return w("div", {
        class: X(["v-date-picker-header", {
          "v-date-picker-header--clickable": !!e.onClick
        }, l.value]),
        style: ie(i.value),
        onClick: o
      }, [a.prepend && w("div", {
        key: "prepend",
        class: "v-date-picker-header__prepend"
      }, [a.prepend()]), u && k(ft, {
        key: "content",
        name: e.transition
      }, {
        default: () => {
          var s, d;
          return [w("div", {
            key: e.header,
            class: "v-date-picker-header__content"
          }, [(d = (s = a.default) == null ? void 0 : s.call(a)) != null ? d : e.header])];
        }
      }), c && w("div", {
        class: "v-date-picker-header__append"
      }, [a.append ? k(Ce, {
        key: "append-defaults",
        disabled: !e.appendIcon,
        defaults: {
          VBtn: {
            icon: e.appendIcon,
            variant: "text"
          }
        }
      }, {
        default: () => {
          var s;
          return [(s = a.append) == null ? void 0 : s.call(a)];
        }
      }) : k(xe, {
        key: "append-btn",
        icon: e.appendIcon,
        variant: "text",
        onClick: r
      }, null)])]);
    }), {};
  }
}), Ab = N({
  allowedDates: [Array, Function],
  disabled: {
    type: Boolean,
    default: null
  },
  displayValue: null,
  modelValue: Array,
  month: [Number, String],
  max: null,
  min: null,
  showAdjacentMonths: Boolean,
  year: [Number, String],
  weekdays: {
    type: Array,
    default: () => [0, 1, 2, 3, 4, 5, 6]
  },
  weeksInMonth: {
    type: String,
    default: "dynamic"
  },
  firstDayOfWeek: {
    type: [Number, String],
    default: void 0
  },
  weekdayFormat: String
}, "calendar");
function Lb(e) {
  const n = Zn(), t = ve(e, "modelValue", [], (m) => ze(m).map((h) => n.date(h))), a = C(() => e.displayValue ? n.date(e.displayValue) : t.value.length > 0 ? n.date(t.value[0]) : e.min ? n.date(e.min) : Array.isArray(e.allowedDates) ? n.date(e.allowedDates[0]) : n.date()), l = ve(e, "year", void 0, (m) => {
    const h = m != null ? Number(m) : n.getYear(a.value);
    return n.startOfYear(n.setYear(n.date(), h));
  }, (m) => n.getYear(m)), i = ve(e, "month", void 0, (m) => {
    const h = m != null ? Number(m) : n.getMonth(a.value), b = n.setYear(n.startOfMonth(n.date()), n.getYear(l.value));
    return n.setMonth(b, h);
  }, (m) => n.getMonth(m)), o = C(() => {
    const m = n.toJsDate(n.startOfWeek(n.date(), e.firstDayOfWeek)).getDay();
    return n.getWeekdays(e.firstDayOfWeek, e.weekdayFormat).filter((h, b) => e.weekdays.includes((b + m) % 7));
  }), r = C(() => {
    const m = n.getWeekArray(i.value, e.firstDayOfWeek), h = m.flat(), b = 6 * 7;
    if (e.weeksInMonth === "static" && h.length < b) {
      const g = h[h.length - 1];
      let S = [];
      for (let y = 1; y <= b - h.length; y++)
        S.push(n.addDays(g, y)), y % 7 === 0 && (m.push(S), S = []);
    }
    return m;
  });
  function u(m, h) {
    return m.filter((b) => e.weekdays.includes(n.toJsDate(b).getDay())).map((b, g) => {
      const S = n.toISO(b), y = !n.isSameMonth(b, i.value), P = n.isSameDay(b, n.startOfMonth(i.value)), V = n.isSameDay(b, n.endOfMonth(i.value)), x = n.isSameDay(b, i.value), I = e.weekdays.length;
      return {
        date: b,
        formatted: n.format(b, "keyboardDate"),
        isAdjacent: y,
        isDisabled: f(b),
        isEnd: V,
        isHidden: y && !e.showAdjacentMonths,
        isSame: x,
        isSelected: t.value.some((T) => n.isSameDay(b, T)),
        isStart: P,
        isToday: n.isSameDay(b, h),
        isWeekEnd: g % I === I - 1,
        isWeekStart: g % I === 0,
        isoDate: S,
        localized: n.format(b, "dayOfMonth"),
        month: n.getMonth(b),
        year: n.getYear(b)
      };
    });
  }
  const c = C(() => {
    const m = n.startOfWeek(a.value, e.firstDayOfWeek), h = [];
    for (let g = 0; g <= 6; g++)
      h.push(n.addDays(m, g));
    const b = n.date();
    return u(h, b);
  }), s = C(() => {
    const m = r.value.flat(), h = n.date();
    return u(m, h);
  }), d = C(() => r.value.map((m) => m.length ? n.getWeek(m[0], e.firstDayOfWeek) : null));
  function f(m) {
    if (e.disabled) return !0;
    const h = n.date(m);
    return e.min && n.isBefore(n.endOfDay(h), n.date(e.min)) || e.max && n.isAfter(h, n.date(e.max)) ? !0 : Array.isArray(e.allowedDates) && e.allowedDates.length > 0 ? !e.allowedDates.some((b) => n.isSameDay(n.date(b), h)) : typeof e.allowedDates == "function" ? !e.allowedDates(h) : !1;
  }
  return {
    displayValue: a,
    daysInMonth: s,
    daysInWeek: c,
    genDays: u,
    model: t,
    weeksInMonth: r,
    weekdayLabels: o,
    weekNumbers: d
  };
}
const Qc = N(v({
  color: String,
  hideWeekdays: Boolean,
  multiple: [Boolean, Number, String],
  showWeek: Boolean,
  transition: {
    type: String,
    default: "picker-transition"
  },
  reverseTransition: {
    type: String,
    default: "picker-reverse-transition"
  }
}, $e(Ab(), ["displayValue"])), "VDatePickerMonth"), pi = Y()({
  name: "VDatePickerMonth",
  props: Qc(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:month": (e) => !0,
    "update:year": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = Q(), {
      t: i
    } = Ee(), {
      daysInMonth: o,
      model: r,
      weekNumbers: u,
      weekdayLabels: c
    } = Lb(e), s = Zn(), d = te(), f = te(), m = te(!1), h = M(() => m.value ? e.reverseTransition : e.transition);
    e.multiple === "range" && r.value.length > 0 && (d.value = r.value[0], r.value.length > 1 && (f.value = r.value[r.value.length - 1]));
    const b = C(() => {
      const V = ["number", "string"].includes(typeof e.multiple) ? Number(e.multiple) : 1 / 0;
      return r.value.length >= V;
    });
    oe(o, (V, x) => {
      x && (m.value = s.isBefore(V[0].date, x[0].date));
    });
    function g(V) {
      const x = s.startOfDay(V);
      if (r.value.length === 0 ? d.value = void 0 : r.value.length === 1 && (d.value = r.value[0], f.value = void 0), !d.value)
        d.value = x, r.value = [d.value];
      else if (f.value)
        d.value = V, f.value = void 0, r.value = [d.value];
      else {
        if (s.isSameDay(x, d.value)) {
          d.value = void 0, r.value = [];
          return;
        } else s.isBefore(x, d.value) ? (f.value = s.endOfDay(d.value), d.value = x) : f.value = s.endOfDay(x);
        r.value = Bf(s, d.value, f.value);
      }
    }
    function S(V) {
      const x = s.format(V.date, "fullDateWithWeekday"), I = V.isToday ? "currentDate" : "selectDate";
      return i(`$vuetify.datePicker.ariaLabel.${I}`, x);
    }
    function y(V) {
      const x = r.value.findIndex((I) => s.isSameDay(I, V));
      if (x === -1)
        r.value = [...r.value, V];
      else {
        const I = [...r.value];
        I.splice(x, 1), r.value = I;
      }
    }
    function P(V) {
      e.multiple === "range" ? g(V) : e.multiple ? y(V) : r.value = [V];
    }
    Z(() => w("div", {
      class: "v-date-picker-month",
      style: {
        "--v-date-picker-days-in-week": e.weekdays.length
      }
    }, [e.showWeek && w("div", {
      key: "weeks",
      class: "v-date-picker-month__weeks"
    }, [!e.hideWeekdays && w("div", {
      key: "hide-week-days",
      class: "v-date-picker-month__day"
    }, [Nt(" ")]), u.value.map((V) => w("div", {
      class: X(["v-date-picker-month__day", "v-date-picker-month__day--adjacent"])
    }, [V]))]), k(ft, {
      name: h.value
    }, {
      default: () => {
        var V;
        return [w("div", {
          ref: l,
          key: (V = o.value[0].date) == null ? void 0 : V.toString(),
          class: "v-date-picker-month__days"
        }, [!e.hideWeekdays && c.value.map((x) => w("div", {
          class: X(["v-date-picker-month__day", "v-date-picker-month__weekday"])
        }, [x])), o.value.map((x, I) => {
          var _, p;
          const T = {
            props: {
              class: "v-date-picker-month__day-btn",
              color: x.isSelected || x.isToday ? e.color : void 0,
              disabled: x.isDisabled,
              icon: !0,
              ripple: !1,
              text: x.localized,
              variant: x.isSelected ? "flat" : x.isToday ? "outlined" : "text",
              "aria-label": S(x),
              "aria-current": x.isToday ? "date" : void 0,
              onClick: () => P(x.date)
            },
            item: x,
            i: I
          };
          return b.value && !x.isSelected && (x.isDisabled = !0), w("div", {
            class: X(["v-date-picker-month__day", {
              "v-date-picker-month__day--adjacent": x.isAdjacent,
              "v-date-picker-month__day--hide-adjacent": x.isHidden,
              "v-date-picker-month__day--selected": x.isSelected,
              "v-date-picker-month__day--week-end": x.isWeekEnd,
              "v-date-picker-month__day--week-start": x.isWeekStart
            }]),
            "data-v-date": x.isDisabled ? void 0 : x.isoDate
          }, [(e.showAdjacentMonths || !x.isAdjacent) && ((p = (_ = a.day) == null ? void 0 : _.call(a, T)) != null ? p : k(xe, T.props, null))]);
        })])];
      }
    })]));
  }
}), Jc = N({
  color: String,
  height: [String, Number],
  min: null,
  max: null,
  modelValue: Number,
  year: Number,
  allowedMonths: [Array, Function]
}, "VDatePickerMonths"), Ei = Y()({
  name: "VDatePickerMonths",
  props: Jc(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = Zn(), i = ve(e, "modelValue"), o = C(() => {
      let u = l.startOfYear(l.date());
      return e.year && (u = l.setYear(u, e.year)), Vt(12).map((c) => {
        const s = l.format(u, "monthShort"), d = l.format(u, "month"), f = !!(!r(c) || e.min && l.isAfter(l.startOfMonth(l.date(e.min)), u) || e.max && l.isAfter(u, l.startOfMonth(l.date(e.max))));
        return u = l.getNextMonth(u), {
          isDisabled: f,
          text: s,
          label: d,
          value: c
        };
      });
    });
    We(() => {
      var u;
      i.value = (u = i.value) != null ? u : l.getMonth(l.date());
    });
    function r(u) {
      return Array.isArray(e.allowedMonths) && e.allowedMonths.length ? e.allowedMonths.includes(u) : typeof e.allowedMonths == "function" ? e.allowedMonths(u) : !0;
    }
    return Z(() => w("div", {
      class: "v-date-picker-months",
      style: {
        height: ce(e.height)
      }
    }, [w("div", {
      class: "v-date-picker-months__content"
    }, [o.value.map((u, c) => {
      var f, m;
      const s = {
        active: i.value === c,
        ariaLabel: u.label,
        color: i.value === c ? e.color : void 0,
        disabled: u.isDisabled,
        rounded: !0,
        text: u.text,
        variant: i.value === u.value ? "flat" : "text",
        onClick: () => d(c)
      };
      function d(h) {
        if (i.value === h) {
          t("update:modelValue", i.value);
          return;
        }
        i.value = h;
      }
      return (m = (f = a.month) == null ? void 0 : f.call(a, {
        month: u,
        i: c,
        props: s
      })) != null ? m : k(xe, G({
        key: "month"
      }, s), null);
    })])])), {};
  }
}), ed = N({
  color: String,
  height: [String, Number],
  min: null,
  max: null,
  modelValue: Number,
  allowedYears: [Array, Function]
}, "VDatePickerYears"), $i = Y()({
  name: "VDatePickerYears",
  props: ed(),
  directives: {
    vIntersect: Ht
  },
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = Zn(), i = ve(e, "modelValue"), o = C(() => {
      const s = l.getYear(l.date());
      let d = s - 100, f = s + 52;
      e.min && (d = l.getYear(l.date(e.min))), e.max && (f = l.getYear(l.date(e.max)));
      let m = l.startOfYear(l.date());
      return m = l.setYear(m, d), Vt(f - d + 1, d).map((h) => {
        const b = l.format(m, "year");
        return m = l.setYear(m, l.getYear(m) + 1), {
          text: b,
          value: h,
          isDisabled: !c(h)
        };
      });
    });
    We(() => {
      var s;
      i.value = (s = i.value) != null ? s : l.getYear(l.date());
    });
    const r = tl();
    function u() {
      var s, d;
      (s = r.el) == null || s.focus(), (d = r.el) == null || d.scrollIntoView({
        block: "center"
      });
    }
    function c(s) {
      return Array.isArray(e.allowedYears) && e.allowedYears.length ? e.allowedYears.includes(s) : typeof e.allowedYears == "function" ? e.allowedYears(s) : !0;
    }
    return Z(() => Re(w("div", {
      class: "v-date-picker-years",
      style: {
        height: ce(e.height)
      }
    }, [w("div", {
      class: "v-date-picker-years__content"
    }, [o.value.map((s, d) => {
      var m, h;
      const f = {
        ref: i.value === s.value ? r : void 0,
        active: i.value === s.value,
        color: i.value === s.value ? e.color : void 0,
        rounded: !0,
        text: s.text,
        disabled: s.isDisabled,
        variant: i.value === s.value ? "flat" : "text",
        onClick: () => {
          if (i.value === s.value) {
            t("update:modelValue", i.value);
            return;
          }
          i.value = s.value;
        }
      };
      return (h = (m = a.year) == null ? void 0 : m.call(a, {
        year: s,
        i: d,
        props: f
      })) != null ? h : k(xe, G({
        key: "month"
      }, f), null);
    })])]), [[Ht, {
      handler: u
    }, null, {
      once: !0
    }]])), {};
  }
}), Tb = N(le(v(v(v(v(v({
  // TODO: implement in v3.5
  // calendarIcon: {
  //   type: String,
  //   default: '$calendar',
  // },
  // keyboardIcon: {
  //   type: String,
  //   default: '$edit',
  // },
  // inputMode: {
  //   type: String as PropType<'calendar' | 'keyboard'>,
  //   default: 'calendar',
  // },
  // inputText: {
  //   type: String,
  //   default: '$vuetify.datePicker.input.placeholder',
  // },
  // inputPlaceholder: {
  //   type: String,
  //   default: 'dd/mm/yyyy',
  // },
  header: {
    type: String,
    default: "$vuetify.datePicker.header"
  },
  headerColor: String
}, Zc()), Qc({
  weeksInMonth: "static"
})), $e(Jc(), ["modelValue"])), $e(ed(), ["modelValue"])), Ll({
  title: "$vuetify.datePicker.title"
})), {
  modelValue: null
}), "VDatePicker"), Bb = Y()({
  name: "VDatePicker",
  props: Tb(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:month": (e) => !0,
    "update:year": (e) => !0,
    // 'update:inputMode': (date: any) => true,
    "update:viewMode": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const l = Zn(), {
      t: i
    } = Ee(), {
      rtlClasses: o
    } = Xe(), r = ve(e, "modelValue", void 0, (z) => ze(z).map((H) => l.date(H)), (z) => e.multiple ? z : z[0]), u = ve(e, "viewMode"), c = C(() => {
      const z = l.date(e.min);
      return e.min && l.isValid(z) ? z : null;
    }), s = C(() => {
      const z = l.date(e.max);
      return e.max && l.isValid(z) ? z : null;
    }), d = C(() => {
      var E;
      const z = l.date();
      let H = z;
      return (E = r.value) != null && E[0] ? H = l.date(r.value[0]) : c.value && l.isBefore(z, c.value) ? H = c.value : s.value && l.isAfter(z, s.value) && (H = s.value), H && l.isValid(H) ? H : z;
    }), f = M(() => {
      var z;
      return (z = e.headerColor) != null ? z : e.color;
    }), m = ve(e, "month"), h = C({
      get: () => {
        var z;
        return Number((z = m.value) != null ? z : l.getMonth(l.startOfMonth(d.value)));
      },
      set: (z) => m.value = z
    }), b = ve(e, "year"), g = C({
      get: () => {
        var z;
        return Number((z = b.value) != null ? z : l.getYear(l.startOfYear(l.setMonth(d.value, h.value))));
      },
      set: (z) => b.value = z
    }), S = te(!1), y = C(() => e.multiple && r.value.length > 1 ? i("$vuetify.datePicker.itemsSelected", r.value.length) : r.value[0] && l.isValid(r.value[0]) ? l.format(l.date(r.value[0]), "normalDateWithWeekday") : i(e.header)), P = C(() => {
      let z = l.date();
      return z = l.setDate(z, 1), z = l.setMonth(z, h.value), z = l.setYear(z, g.value), l.format(z, "monthAndYear");
    }), V = M(() => `date-picker-header${S.value ? "-reverse" : ""}-transition`), x = C(() => {
      if (e.disabled) return !0;
      const z = [];
      if (u.value !== "month")
        z.push("prev", "next");
      else {
        let H = l.date();
        if (H = l.startOfMonth(H), H = l.setMonth(H, h.value), H = l.setYear(H, g.value), c.value) {
          const E = l.addDays(l.startOfMonth(H), -1);
          l.isAfter(c.value, E) && z.push("prev");
        }
        if (s.value) {
          const E = l.addDays(l.endOfMonth(H), 1);
          l.isAfter(E, s.value) && z.push("next");
        }
      }
      return z;
    }), I = C(() => e.allowedYears || p), T = C(() => e.allowedMonths || L);
    function _(z, H) {
      const E = e.allowedDates;
      if (typeof E != "function") return !0;
      const O = l.getDiff(H, z, "days");
      for (let R = 0; R < O; R++)
        if (E(l.addDays(z, R))) return !0;
      return !1;
    }
    function p(z) {
      if (typeof e.allowedDates == "function") {
        const H = l.parseISO(`${z}-01-01`);
        return _(H, l.endOfYear(H));
      }
      if (Array.isArray(e.allowedDates) && e.allowedDates.length) {
        for (const H of e.allowedDates)
          if (l.getYear(l.date(H)) === z) return !0;
        return !1;
      }
      return !0;
    }
    function L(z) {
      if (typeof e.allowedDates == "function") {
        const H = String(z + 1).padStart(2, "0"), E = l.parseISO(`${g.value}-${H}-01`);
        return _(E, l.endOfMonth(E));
      }
      if (Array.isArray(e.allowedDates) && e.allowedDates.length) {
        for (const H of e.allowedDates)
          if (l.getYear(l.date(H)) === g.value && l.getMonth(l.date(H)) === z) return !0;
        return !1;
      }
      return !0;
    }
    function D() {
      h.value < 11 ? h.value++ : (g.value++, h.value = 0, J()), W();
    }
    function A() {
      h.value > 0 ? h.value-- : (g.value--, h.value = 11, J()), W();
    }
    function B() {
      u.value = "month";
    }
    function F() {
      u.value = u.value === "months" ? "month" : "months";
    }
    function $() {
      u.value = u.value === "year" ? "month" : "year";
    }
    function W() {
      u.value === "months" && F();
    }
    function J() {
      u.value === "year" && $();
    }
    return oe(r, (z, H) => {
      const E = ze(H), O = ze(z);
      if (!O.length) return;
      const R = l.date(E[E.length - 1]), q = l.date(O[O.length - 1]), ae = l.getMonth(q), U = l.getYear(q);
      ae !== h.value && (h.value = ae, W()), U !== g.value && (g.value = U, J()), S.value = l.isBefore(R, q);
    }), Z(() => {
      const z = Kn.filterProps(e), H = Di.filterProps(e), E = Mi.filterProps(e), O = pi.filterProps(e), R = $e(Ei.filterProps(e), ["modelValue"]), q = $e($i.filterProps(e), ["modelValue"]), ae = {
        color: f.value,
        header: y.value,
        transition: V.value
      };
      return k(Kn, G(z, {
        color: f.value,
        class: ["v-date-picker", `v-date-picker--${u.value}`, {
          "v-date-picker--show-week": e.showWeek
        }, o.value, e.class],
        style: e.style
      }), {
        title: () => {
          var U, ne;
          return (ne = (U = a.title) == null ? void 0 : U.call(a)) != null ? ne : w("div", {
            class: "v-date-picker__title"
          }, [i(e.title)]);
        },
        header: () => a.header ? k(Ce, {
          defaults: {
            VDatePickerHeader: v({}, ae)
          }
        }, {
          default: () => {
            var U;
            return [(U = a.header) == null ? void 0 : U.call(a, ae)];
          }
        }) : k(Mi, G({
          key: "header"
        }, E, ae, {
          onClick: u.value !== "month" ? B : void 0
        }), {
          prepend: a.prepend,
          append: a.append
        }),
        default: () => w(he, null, [k(Di, G(H, {
          disabled: x.value,
          text: P.value,
          "onClick:next": D,
          "onClick:prev": A,
          "onClick:month": F,
          "onClick:year": $
        }), null), k(ya, {
          hideOnLeave: !0
        }, {
          default: () => [u.value === "months" ? k(Ei, G({
            key: "date-picker-months"
          }, R, {
            modelValue: h.value,
            "onUpdate:modelValue": [(U) => h.value = U, W],
            min: c.value,
            max: s.value,
            year: g.value,
            allowedMonths: T.value
          }), {
            month: a.month
          }) : u.value === "year" ? k($i, G({
            key: "date-picker-years"
          }, q, {
            modelValue: g.value,
            "onUpdate:modelValue": [(U) => g.value = U, J],
            min: c.value,
            max: s.value,
            allowedYears: I.value
          }), {
            year: a.year
          }) : k(pi, G({
            key: "date-picker-month"
          }, O, {
            modelValue: r.value,
            "onUpdate:modelValue": (U) => r.value = U,
            month: h.value,
            "onUpdate:month": [(U) => h.value = U, W],
            year: g.value,
            "onUpdate:year": [(U) => g.value = U, J],
            min: c.value,
            max: s.value
          }), {
            day: a.day
          })]
        })]),
        actions: a.actions
      });
    }), {};
  }
}), Db = N(v(v(v(v({
  actionText: String,
  bgColor: String,
  color: String,
  icon: me,
  image: String,
  justify: {
    type: String,
    default: "center"
  },
  headline: String,
  title: String,
  text: String,
  textWidth: {
    type: [Number, String],
    default: 500
  },
  href: String,
  to: String
}, de()), Ze()), Yt({
  size: void 0
})), Ie()), "VEmptyState"), Mb = Y()({
  name: "VEmptyState",
  props: Db(),
  emits: {
    "click:action": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      themeClasses: l
    } = De(e), {
      backgroundColorClasses: i,
      backgroundColorStyles: o
    } = pe(() => e.bgColor), {
      dimensionStyles: r
    } = Qe(e), {
      displayClasses: u
    } = At();
    function c(s) {
      t("click:action", s);
    }
    return Z(() => {
      var g, S, y, P, V, x, I;
      const s = !!(a.actions || e.actionText), d = !!(a.headline || e.headline), f = !!(a.title || e.title), m = !!(a.text || e.text), h = !!(a.media || e.image || e.icon), b = e.size || (e.image ? 200 : 96);
      return w("div", {
        class: X(["v-empty-state", {
          [`v-empty-state--${e.justify}`]: !0
        }, l.value, i.value, u.value, e.class]),
        style: ie([o.value, r.value, e.style])
      }, [h && w("div", {
        key: "media",
        class: "v-empty-state__media"
      }, [a.media ? k(Ce, {
        key: "media-defaults",
        defaults: {
          VImg: {
            src: e.image,
            height: b
          },
          VIcon: {
            size: b,
            icon: e.icon
          }
        }
      }, {
        default: () => [a.media()]
      }) : w(he, null, [e.image ? k(Ut, {
        key: "image",
        src: e.image,
        height: b
      }, null) : e.icon ? k(Be, {
        key: "icon",
        color: e.color,
        size: b,
        icon: e.icon
      }, null) : void 0])]), d && w("div", {
        key: "headline",
        class: "v-empty-state__headline"
      }, [(S = (g = a.headline) == null ? void 0 : g.call(a)) != null ? S : e.headline]), f && w("div", {
        key: "title",
        class: "v-empty-state__title"
      }, [(P = (y = a.title) == null ? void 0 : y.call(a)) != null ? P : e.title]), m && w("div", {
        key: "text",
        class: "v-empty-state__text",
        style: {
          maxWidth: ce(e.textWidth)
        }
      }, [(x = (V = a.text) == null ? void 0 : V.call(a)) != null ? x : e.text]), a.default && w("div", {
        key: "content",
        class: "v-empty-state__content"
      }, [a.default()]), s && w("div", {
        key: "actions",
        class: "v-empty-state__actions"
      }, [k(Ce, {
        defaults: {
          VBtn: {
            class: "v-empty-state__action-btn",
            color: (I = e.color) != null ? I : "surface-variant",
            href: e.href,
            text: e.actionText,
            to: e.to
          }
        }
      }, {
        default: () => {
          var T, _;
          return [(_ = (T = a.actions) == null ? void 0 : T.call(a, {
            props: {
              onClick: c
            }
          })) != null ? _ : k(xe, {
            onClick: c
          }, null)];
        }
      })])]);
    }), {};
  }
}), Ia = Symbol.for("vuetify:v-expansion-panel"), td = N(v(v({}, de()), wo()), "VExpansionPanelText"), Fi = Y()({
  name: "VExpansionPanelText",
  props: td(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Pe(Ia);
    if (!a) throw new Error("[Vuetify] v-expansion-panel-text needs to be placed inside v-expansion-panel");
    const {
      hasContent: l,
      onAfterLeave: i
    } = Co(e, a.isSelected);
    return Z(() => k(kl, {
      onAfterLeave: i
    }, {
      default: () => {
        var o;
        return [Re(w("div", {
          class: X(["v-expansion-panel-text", e.class]),
          style: ie(e.style)
        }, [t.default && l.value && w("div", {
          class: "v-expansion-panel-text__wrapper"
        }, [(o = t.default) == null ? void 0 : o.call(t)])]), [[$t, a.isSelected.value]])];
      }
    })), {};
  }
}), nd = N(v(v({
  color: String,
  expandIcon: {
    type: me,
    default: "$expand"
  },
  collapseIcon: {
    type: me,
    default: "$collapse"
  },
  hideActions: Boolean,
  focusable: Boolean,
  static: Boolean,
  ripple: {
    type: [Boolean, Object],
    default: !1
  },
  readonly: Boolean
}, de()), Ze()), "VExpansionPanelTitle"), Oi = Y()({
  name: "VExpansionPanelTitle",
  directives: {
    vRipple: bt
  },
  props: nd(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Pe(Ia);
    if (!a) throw new Error("[Vuetify] v-expansion-panel-title needs to be placed inside v-expansion-panel");
    const {
      backgroundColorClasses: l,
      backgroundColorStyles: i
    } = pe(() => e.color), {
      dimensionStyles: o
    } = Qe(e), r = C(() => ({
      collapseIcon: e.collapseIcon,
      disabled: a.disabled.value,
      expanded: a.isSelected.value,
      expandIcon: e.expandIcon,
      readonly: e.readonly
    })), u = M(() => a.isSelected.value ? e.collapseIcon : e.expandIcon);
    return Z(() => {
      var c;
      return Re(w("button", {
        class: X(["v-expansion-panel-title", {
          "v-expansion-panel-title--active": a.isSelected.value,
          "v-expansion-panel-title--focusable": e.focusable,
          "v-expansion-panel-title--static": e.static
        }, l.value, e.class]),
        style: ie([i.value, o.value, e.style]),
        type: "button",
        tabindex: a.disabled.value ? -1 : void 0,
        disabled: a.disabled.value,
        "aria-expanded": a.isSelected.value,
        onClick: e.readonly ? void 0 : a.toggle
      }, [w("span", {
        class: "v-expansion-panel-title__overlay"
      }, null), (c = t.default) == null ? void 0 : c.call(t, r.value), !e.hideActions && k(Ce, {
        defaults: {
          VIcon: {
            icon: u.value
          }
        }
      }, {
        default: () => {
          var s, d;
          return [w("span", {
            class: "v-expansion-panel-title__icon"
          }, [(d = (s = t.actions) == null ? void 0 : s.call(t, r.value)) != null ? d : k(Be, null, null)])];
        }
      })]), [[bt, e.ripple]]);
    }), {};
  }
}), ad = N(v(v(v(v(v(v({
  title: String,
  text: String,
  bgColor: String
}, Je()), Bn()), Ne()), ke()), nd()), td()), "VExpansionPanel"), pb = Y()({
  name: "VExpansionPanel",
  props: ad(),
  emits: {
    "group:selected": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Dn(e, Ia), {
      backgroundColorClasses: l,
      backgroundColorStyles: i
    } = pe(() => e.bgColor), {
      elevationClasses: o
    } = lt(e), {
      roundedClasses: r
    } = Ye(e), u = M(() => (a == null ? void 0 : a.disabled.value) || e.disabled), c = C(() => a.group.items.value.reduce((f, m, h) => (a.group.selected.value.includes(m.id) && f.push(h), f), [])), s = C(() => {
      const f = a.group.items.value.findIndex((m) => m.id === a.id);
      return !a.isSelected.value && c.value.some((m) => m - f === 1);
    }), d = C(() => {
      const f = a.group.items.value.findIndex((m) => m.id === a.id);
      return !a.isSelected.value && c.value.some((m) => m - f === -1);
    });
    return Oe(Ia, a), Z(() => {
      const f = !!(t.text || e.text), m = !!(t.title || e.title), h = Oi.filterProps(e), b = Fi.filterProps(e);
      return k(e.tag, {
        class: X(["v-expansion-panel", {
          "v-expansion-panel--active": a.isSelected.value,
          "v-expansion-panel--before-active": s.value,
          "v-expansion-panel--after-active": d.value,
          "v-expansion-panel--disabled": u.value
        }, r.value, l.value, e.class]),
        style: ie([i.value, e.style])
      }, {
        default: () => [w("div", {
          class: X(["v-expansion-panel__shadow", ...o.value])
        }, null), k(Ce, {
          defaults: {
            VExpansionPanelTitle: v({}, h),
            VExpansionPanelText: v({}, b)
          }
        }, {
          default: () => {
            var g;
            return [m && k(Oi, {
              key: "title"
            }, {
              default: () => [t.title ? t.title() : e.title]
            }), f && k(Fi, {
              key: "text"
            }, {
              default: () => [t.text ? t.text() : e.text]
            }), (g = t.default) == null ? void 0 : g.call(t)];
          }
        })]
      });
    }), {
      groupItem: a
    };
  }
}), Eb = ["default", "accordion", "inset", "popout"], $b = N(le(v(v(v(v(v({
  flat: Boolean
}, Tn()), qt(ad(), ["bgColor", "collapseIcon", "color", "eager", "elevation", "expandIcon", "focusable", "hideActions", "readonly", "ripple", "rounded", "tile", "static"])), Ie()), de()), ke()), {
  variant: {
    type: String,
    default: "default",
    validator: (e) => Eb.includes(e)
  }
}), "VExpansionPanels"), Fb = Y()({
  name: "VExpansionPanels",
  props: $b(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      next: a,
      prev: l
    } = on(e, Ia), {
      themeClasses: i
    } = De(e), o = M(() => e.variant && `v-expansion-panels--variant-${e.variant}`);
    return je({
      VExpansionPanel: {
        bgColor: M(() => e.bgColor),
        collapseIcon: M(() => e.collapseIcon),
        color: M(() => e.color),
        eager: M(() => e.eager),
        elevation: M(() => e.elevation),
        expandIcon: M(() => e.expandIcon),
        focusable: M(() => e.focusable),
        hideActions: M(() => e.hideActions),
        readonly: M(() => e.readonly),
        ripple: M(() => e.ripple),
        rounded: M(() => e.rounded),
        static: M(() => e.static)
      }
    }), Z(() => k(e.tag, {
      class: X(["v-expansion-panels", {
        "v-expansion-panels--flat": e.flat,
        "v-expansion-panels--tile": e.tile
      }, i.value, o.value, e.class]),
      style: ie(e.style)
    }, {
      default: () => {
        var r;
        return [(r = t.default) == null ? void 0 : r.call(t, {
          prev: l,
          next: a
        })];
      }
    })), {
      next: a,
      prev: l
    };
  }
}), Ob = N(v(v(v(v({
  app: Boolean,
  appear: Boolean,
  extended: Boolean,
  layout: Boolean,
  offset: Boolean,
  modelValue: {
    type: Boolean,
    default: !0
  }
}, $e(xl({
  active: !0
}), ["location"])), In()), Zt()), Ft({
  transition: "fab-transition"
})), "VFab"), Nb = Y()({
  name: "VFab",
  props: Ob(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), l = te(56), i = Q(), {
      resizeRef: o
    } = pt((d) => {
      d.length && (l.value = d[0].target.clientHeight);
    }), r = M(() => e.app || e.absolute), u = C(() => {
      var d, f;
      return r.value ? (f = (d = e.location) == null ? void 0 : d.split(" ").shift()) != null ? f : "bottom" : !1;
    }), c = C(() => {
      var d, f;
      return r.value ? (f = (d = e.location) == null ? void 0 : d.split(" ")[1]) != null ? f : "end" : !1;
    });
    mt(() => e.app, () => {
      const d = _n({
        id: e.name,
        order: C(() => parseInt(e.order, 10)),
        position: u,
        layoutSize: C(() => e.layout ? l.value + 24 : 0),
        elementSize: C(() => l.value + 24),
        active: C(() => e.app && a.value),
        absolute: M(() => e.absolute)
      });
      We(() => {
        i.value = d.layoutItemStyles.value;
      });
    });
    const s = Q();
    return Z(() => {
      const d = xe.filterProps(e);
      return w("div", {
        ref: s,
        class: X(["v-fab", {
          "v-fab--absolute": e.absolute,
          "v-fab--app": !!e.app,
          "v-fab--extended": e.extended,
          "v-fab--offset": e.offset,
          [`v-fab--${u.value}`]: r.value,
          [`v-fab--${c.value}`]: r.value
        }, e.class]),
        style: ie([e.app ? v({}, i.value) : {
          height: e.absolute ? "100%" : "inherit"
        }, e.style])
      }, [w("div", {
        class: "v-fab__container"
      }, [k(ft, {
        appear: e.appear,
        transition: e.transition
      }, {
        default: () => [Re(k(xe, G({
          ref: o
        }, d, {
          active: void 0,
          location: void 0
        }), t), [[$t, e.active]])]
      })])]);
    }), {};
  }
});
function Rb() {
  function e(t) {
    var l, i, o, r;
    return [...(i = (l = t.dataTransfer) == null ? void 0 : l.items) != null ? i : []].filter((u) => u.kind === "file").map((u) => u.webkitGetAsEntry()).filter(Boolean).length > 0 || [...(r = (o = t.dataTransfer) == null ? void 0 : o.files) != null ? r : []].length > 0;
  }
  function n(t) {
    return He(this, null, function* () {
      var i, o, r, u;
      const a = [], l = [...(o = (i = t.dataTransfer) == null ? void 0 : i.items) != null ? o : []].filter((c) => c.kind === "file").map((c) => c.webkitGetAsEntry()).filter(Boolean);
      if (l.length)
        for (const c of l) {
          const s = yield ld(c, id(".", c));
          a.push(...s.map((d) => d.file));
        }
      else
        a.push(...(u = (r = t.dataTransfer) == null ? void 0 : r.files) != null ? u : []);
      return a;
    });
  }
  return {
    handleDrop: n,
    hasFilesOrFolders: e
  };
}
function ld(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
  return new Promise((t, a) => {
    e.isFile ? e.file((i) => t([{
      file: i,
      path: n
    }]), a) : e.isDirectory && e.createReader().readEntries((i) => He(this, null, function* () {
      const o = [];
      for (const r of i)
        o.push(...yield ld(r, id(n, r)));
      t(o);
    }));
  });
}
function id(e, n) {
  return n.isDirectory ? `${e}/${n.name}` : e;
}
const Hb = N(v(le(v({
  chips: Boolean,
  counter: Boolean,
  counterSizeString: {
    type: String,
    default: "$vuetify.fileInput.counterSize"
  },
  counterString: {
    type: String,
    default: "$vuetify.fileInput.counter"
  },
  hideInput: Boolean,
  multiple: Boolean,
  showSize: {
    type: [Boolean, Number, String],
    default: !1,
    validator: (e) => typeof e == "boolean" || [1e3, 1024].includes(Number(e))
  }
}, Jt({
  prependIcon: "$file"
})), {
  modelValue: {
    type: [Array, Object],
    default: (e) => e.multiple ? [] : null,
    validator: (e) => ze(e).every((n) => n != null && typeof n == "object")
  }
}), Oa({
  clearable: !0
})), "VFileInput"), zb = Y()({
  name: "VFileInput",
  inheritAttrs: !1,
  props: Hb(),
  emits: {
    "click:control": (e) => !0,
    "mousedown:control": (e) => !0,
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const {
      t: i
    } = Ee(), o = ve(e, "modelValue", e.modelValue, ($) => ze($), ($) => !e.multiple && Array.isArray($) ? $[0] : $), {
      isFocused: r,
      focus: u,
      blur: c
    } = Qt(e), s = C(() => typeof e.showSize != "boolean" ? e.showSize : void 0), d = C(() => {
      var $;
      return (($ = o.value) != null ? $ : []).reduce((W, J) => {
        let {
          size: z = 0
        } = J;
        return W + z;
      }, 0);
    }), f = C(() => tr(d.value, s.value)), m = C(() => {
      var $;
      return (($ = o.value) != null ? $ : []).map((W) => {
        const {
          name: J = "",
          size: z = 0
        } = W;
        return e.showSize ? `${J} (${tr(z, s.value)})` : J;
      });
    }), h = C(() => {
      var W, J;
      const $ = (J = (W = o.value) == null ? void 0 : W.length) != null ? J : 0;
      return e.showSize ? i(e.counterSizeString, $, f.value) : i(e.counterString, $);
    }), b = Q(), g = Q(), S = Q(), y = M(() => r.value || e.active), P = C(() => ["plain", "underlined"].includes(e.variant)), V = te(!1), {
      handleDrop: x,
      hasFilesOrFolders: I
    } = Rb();
    function T() {
      var $;
      S.value !== document.activeElement && (($ = S.value) == null || $.focus()), r.value || u();
    }
    function _($) {
      var W;
      (W = S.value) == null || W.click();
    }
    function p($) {
      a("mousedown:control", $);
    }
    function L($) {
      var W;
      (W = S.value) == null || W.click(), a("click:control", $);
    }
    function D($) {
      $.stopPropagation(), T(), Ve(() => {
        o.value = [], fl(e["onClick:clear"], $);
      });
    }
    function A($) {
      $.preventDefault(), $.stopImmediatePropagation(), V.value = !0;
    }
    function B($) {
      $.preventDefault(), V.value = !1;
    }
    function F($) {
      return He(this, null, function* () {
        if ($.preventDefault(), $.stopImmediatePropagation(), V.value = !1, !S.value || !I($)) return;
        const W = new DataTransfer();
        for (const J of yield x($))
          W.items.add(J);
        S.value.files = W.files, S.value.dispatchEvent(new Event("change", {
          bubbles: !0
        }));
      });
    }
    return oe(o, ($) => {
      (!Array.isArray($) || !$.length) && S.value && (S.value.value = "");
    }), Z(() => {
      const $ = !!(l.counter || e.counter), W = !!($ || l.details), [J, z] = an(t), R = ct.filterProps(e), {
        modelValue: H
      } = R, E = Ge(R, [
        "modelValue"
      ]), O = le(v({}, nn.filterProps(e)), {
        "onClick:clear": D
      });
      return k(ct, G({
        ref: b,
        modelValue: e.multiple ? o.value : o.value[0],
        class: ["v-file-input", {
          "v-file-input--chips": !!e.chips,
          "v-file-input--dragging": V.value,
          "v-file-input--hide": e.hideInput,
          "v-input--plain-underlined": P.value
        }, e.class],
        style: e.style,
        "onClick:prepend": _
      }, J, E, {
        centerAffix: !P.value,
        focused: r.value
      }), le(v({}, l), {
        default: (q) => {
          let {
            id: ae,
            isDisabled: U,
            isDirty: ne,
            isReadonly: j,
            isValid: ue,
            hasDetails: ge
          } = q;
          return k(nn, G({
            ref: g,
            prependIcon: e.prependIcon,
            onMousedown: p,
            onClick: L,
            "onClick:prependInner": e["onClick:prependInner"],
            "onClick:appendInner": e["onClick:appendInner"]
          }, O, {
            id: ae.value,
            active: y.value || ne.value,
            dirty: ne.value || e.dirty,
            disabled: U.value,
            focused: r.value,
            details: ge.value,
            error: ue.value === !1,
            onDragover: A,
            onDrop: F
          }), le(v({}, l), {
            default: (ee) => {
              var ye;
              let {
                props: K
              } = ee, se = K, {
                class: re
              } = se, fe = Ge(se, [
                "class"
              ]);
              return w(he, null, [w("input", G({
                ref: S,
                type: "file",
                readonly: j.value,
                disabled: U.value,
                multiple: e.multiple,
                name: e.name,
                onClick: (be) => {
                  be.stopPropagation(), j.value && be.preventDefault(), T();
                },
                onChange: (be) => {
                  var Me;
                  if (!be.target) return;
                  const we = be.target;
                  o.value = [...(Me = we.files) != null ? Me : []];
                },
                onDragleave: B,
                onFocus: T,
                onBlur: c
              }, fe, z), null), w("div", {
                class: X(re)
              }, [!!((ye = o.value) != null && ye.length) && !e.hideInput && (l.selection ? l.selection({
                fileNames: m.value,
                totalBytes: d.value,
                totalBytesReadable: f.value
              }) : e.chips ? m.value.map((be) => k(na, {
                key: be,
                size: "small",
                text: be
              }, null)) : m.value.join(", "))])]);
            }
          }));
        },
        details: W ? (q) => {
          var ae, U;
          return w(he, null, [(ae = l.details) == null ? void 0 : ae.call(l, q), $ && w(he, null, [w("span", null, null), k(Pl, {
            active: !!((U = o.value) != null && U.length),
            value: h.value,
            disabled: e.disabled
          }, l.counter)])]);
        } : void 0
      }));
    }), it({}, b, g, S);
  }
}), Wb = N(v(v(v(v(v(v(v({
  app: Boolean,
  color: String,
  height: {
    type: [Number, String],
    default: "auto"
  }
}, kt()), de()), Je()), In()), Ne()), ke({
  tag: "footer"
})), Ie()), "VFooter"), jb = Y()({
  name: "VFooter",
  props: Wb(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Q(), {
      themeClasses: l
    } = De(e), {
      backgroundColorClasses: i,
      backgroundColorStyles: o
    } = pe(() => e.color), {
      borderClasses: r
    } = Ct(e), {
      elevationClasses: u
    } = lt(e), {
      roundedClasses: c
    } = Ye(e), s = te(32), {
      resizeRef: d
    } = pt((m) => {
      m.length && (s.value = m[0].target.clientHeight);
    }), f = C(() => e.height === "auto" ? s.value : parseInt(e.height, 10));
    return mt(() => e.app, () => {
      const m = _n({
        id: e.name,
        order: C(() => parseInt(e.order, 10)),
        position: M(() => "bottom"),
        layoutSize: f,
        elementSize: C(() => e.height === "auto" ? void 0 : f.value),
        active: M(() => e.app),
        absolute: M(() => e.absolute)
      });
      We(() => {
        a.value = m.layoutItemStyles.value;
      });
    }), Z(() => k(e.tag, {
      ref: d,
      class: X(["v-footer", l.value, i.value, r.value, u.value, c.value, e.class]),
      style: ie([o.value, e.app ? a.value : {
        height: ce(e.height)
      }, e.style])
    }, t)), {};
  }
}), Yb = N(v(v({}, de()), tg()), "VForm"), Gb = Y()({
  name: "VForm",
  props: Yb(),
  emits: {
    "update:modelValue": (e) => !0,
    submit: (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = ng(e), i = Q();
    function o(u) {
      u.preventDefault(), l.reset();
    }
    function r(u) {
      const c = u, s = l.validate();
      c.then = s.then.bind(s), c.catch = s.catch.bind(s), c.finally = s.finally.bind(s), a("submit", c), c.defaultPrevented || s.then((d) => {
        var m;
        let {
          valid: f
        } = d;
        f && ((m = i.value) == null || m.submit());
      }), c.preventDefault();
    }
    return Z(() => {
      var u;
      return w("form", {
        ref: i,
        class: X(["v-form", e.class]),
        style: ie(e.style),
        novalidate: !0,
        onReset: o,
        onSubmit: r
      }, [(u = t.default) == null ? void 0 : u.call(t, l)]);
    }), it(l, i);
  }
}), Ub = N(v({
  disabled: Boolean,
  modelValue: {
    type: Boolean,
    default: null
  }
}, So()), "VHover"), Kb = Y()({
  name: "VHover",
  props: Ub(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), {
      runOpenDelay: l,
      runCloseDelay: i
    } = ko(e, (o) => !e.disabled && (a.value = o));
    return () => {
      var o;
      return (o = t.default) == null ? void 0 : o.call(t, {
        isHovering: a.value,
        props: {
          onMouseenter: l,
          onMouseleave: i
        }
      });
    };
  }
}), qb = N(v(v({
  color: String,
  direction: {
    type: String,
    default: "vertical",
    validator: (e) => ["vertical", "horizontal"].includes(e)
  },
  side: {
    type: String,
    default: "end",
    validator: (e) => ["start", "end", "both"].includes(e)
  },
  mode: {
    type: String,
    default: "intersect",
    validator: (e) => ["intersect", "manual"].includes(e)
  },
  margin: [Number, String],
  loadMoreText: {
    type: String,
    default: "$vuetify.infiniteScroll.loadMore"
  },
  emptyText: {
    type: String,
    default: "$vuetify.infiniteScroll.empty"
  }
}, Ze()), ke()), "VInfiniteScroll"), Gr = _t({
  name: "VInfiniteScrollIntersect",
  props: {
    side: {
      type: String,
      required: !0
    },
    rootMargin: String
  },
  emits: {
    intersect: (e, n) => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    const {
      intersectionRef: a,
      isIntersecting: l
    } = Ta();
    return oe(l, (i) => He(this, null, function* () {
      t("intersect", e.side, i);
    })), Z(() => w("div", {
      class: "v-infinite-scroll-intersect",
      style: {
        "--v-infinite-margin-size": e.rootMargin
      },
      ref: a
    }, [Nt(" ")])), {};
  }
}), Xb = Y()({
  name: "VInfiniteScroll",
  props: qb(),
  emits: {
    load: (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = Q(), i = te("ok"), o = te("ok"), r = C(() => ce(e.margin)), u = te(!1);
    function c(I) {
      if (!l.value) return;
      const T = e.direction === "vertical" ? "scrollTop" : "scrollLeft";
      l.value[T] = I;
    }
    function s() {
      if (!l.value) return 0;
      const I = e.direction === "vertical" ? "scrollTop" : "scrollLeft";
      return l.value[I];
    }
    function d() {
      if (!l.value) return 0;
      const I = e.direction === "vertical" ? "scrollHeight" : "scrollWidth";
      return l.value[I];
    }
    function f() {
      if (!l.value) return 0;
      const I = e.direction === "vertical" ? "clientHeight" : "clientWidth";
      return l.value[I];
    }
    gt(() => {
      l.value && (e.side === "start" ? c(d()) : e.side === "both" && c(d() / 2 - f() / 2));
    });
    function m(I, T) {
      I === "start" ? i.value = T : I === "end" ? o.value = T : I === "both" && (i.value = T, o.value = T);
    }
    function h(I) {
      return I === "start" ? i.value : o.value;
    }
    let b = 0;
    function g(I, T) {
      u.value = T, u.value && S(I);
    }
    function S(I) {
      if (e.mode !== "manual" && !u.value) return;
      const T = h(I);
      if (!l.value || ["empty", "loading"].includes(T)) return;
      b = d(), m(I, "loading");
      function _(p) {
        m(I, p), Ve(() => {
          p === "empty" || p === "error" || (p === "ok" && I === "start" && c(d() - b + s()), e.mode !== "manual" && Ve(() => {
            window.requestAnimationFrame(() => {
              window.requestAnimationFrame(() => {
                window.requestAnimationFrame(() => {
                  S(I);
                });
              });
            });
          }));
        });
      }
      a("load", {
        side: I,
        done: _
      });
    }
    const {
      t: y
    } = Ee();
    function P(I, T) {
      var L, D, A, B, F, $, W, J, z;
      if (e.side !== I && e.side !== "both") return;
      const _ = () => S(I), p = {
        side: I,
        props: {
          onClick: _,
          color: e.color
        }
      };
      return T === "error" ? (L = t.error) == null ? void 0 : L.call(t, p) : T === "empty" ? (A = (D = t.empty) == null ? void 0 : D.call(t, p)) != null ? A : w("div", null, [y(e.emptyText)]) : e.mode === "manual" ? T === "loading" ? (F = (B = t.loading) == null ? void 0 : B.call(t, p)) != null ? F : k(bn, {
        indeterminate: !0,
        color: e.color
      }, null) : (W = ($ = t["load-more"]) == null ? void 0 : $.call(t, p)) != null ? W : k(xe, {
        variant: "outlined",
        color: e.color,
        onClick: _
      }, {
        default: () => [y(e.loadMoreText)]
      }) : (z = (J = t.loading) == null ? void 0 : J.call(t, p)) != null ? z : k(bn, {
        indeterminate: !0,
        color: e.color
      }, null);
    }
    const {
      dimensionStyles: V
    } = Qe(e);
    Z(() => {
      const I = e.tag, T = e.side === "start" || e.side === "both", _ = e.side === "end" || e.side === "both", p = e.mode === "intersect";
      return k(I, {
        ref: l,
        class: X(["v-infinite-scroll", `v-infinite-scroll--${e.direction}`, {
          "v-infinite-scroll--start": T,
          "v-infinite-scroll--end": _
        }]),
        style: ie(V.value)
      }, {
        default: () => {
          var L;
          return [w("div", {
            class: "v-infinite-scroll__side"
          }, [P("start", i.value)]), T && p && k(Gr, {
            key: "start",
            side: "start",
            onIntersect: g,
            rootMargin: r.value
          }, null), (L = t.default) == null ? void 0 : L.call(t), _ && p && k(Gr, {
            key: "end",
            side: "end",
            onIntersect: g,
            rootMargin: r.value
          }, null), w("div", {
            class: "v-infinite-scroll__side"
          }, [P("end", o.value)])];
        }
      });
    });
    function x(I) {
      const T = I != null ? I : e.side;
      m(T, "ok"), Ve(() => {
        c(d() - b + s()), e.mode !== "manual" && Ve(() => {
          window.requestAnimationFrame(() => {
            window.requestAnimationFrame(() => {
              window.requestAnimationFrame(() => {
                T === "both" ? (S("start"), S("end")) : S(T);
              });
            });
          });
        });
      });
    }
    return {
      reset: x
    };
  }
}), od = Symbol.for("vuetify:v-item-group"), Zb = N(v(v(v(v({}, de()), Tn({
  selectedClass: "v-item--selected"
})), ke()), Ie()), "VItemGroup"), Qb = Y()({
  name: "VItemGroup",
  props: Zb(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      isSelected: l,
      select: i,
      next: o,
      prev: r,
      selected: u
    } = on(e, od);
    return () => k(e.tag, {
      class: X(["v-item-group", a.value, e.class]),
      style: ie(e.style)
    }, {
      default: () => {
        var c;
        return [(c = t.default) == null ? void 0 : c.call(t, {
          isSelected: l,
          select: i,
          next: o,
          prev: r,
          selected: u.value
        })];
      }
    });
  }
}), Jb = Y()({
  name: "VItem",
  props: Bn(),
  emits: {
    "group:selected": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      isSelected: a,
      select: l,
      toggle: i,
      selectedClass: o,
      value: r,
      disabled: u
    } = Dn(e, od);
    return () => {
      var c;
      return (c = t.default) == null ? void 0 : c.call(t, {
        isSelected: a.value,
        selectedClass: o.value,
        select: l,
        toggle: i,
        value: r.value,
        disabled: u.value
      });
    };
  }
}), e1 = N(v(v(v(v(v(v({
  color: String
}, kt()), de()), Ne()), ke({
  tag: "kbd"
})), Ie()), Je()), "VKbd"), t1 = Y()({
  name: "VKbd",
  props: e1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      borderClasses: l
    } = Ct(e), {
      roundedClasses: i
    } = Ye(e), {
      backgroundColorClasses: o,
      backgroundColorStyles: r
    } = pe(() => e.color), {
      elevationClasses: u
    } = lt(e);
    return Z(() => k(e.tag, {
      class: X(["v-kbd", a.value, o.value, l.value, u.value, i.value, e.class]),
      style: ie([r.value, e.style])
    }, t)), {};
  }
}), n1 = N(v(v(v({}, de()), Ze()), Ru()), "VLayout"), a1 = Y()({
  name: "VLayout",
  props: n1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      layoutClasses: a,
      layoutStyles: l,
      getLayoutItem: i,
      items: o,
      layoutRef: r
    } = Hu(e), {
      dimensionStyles: u
    } = Qe(e);
    return Z(() => {
      var c;
      return w("div", {
        ref: r,
        class: X([a.value, e.class]),
        style: ie([u.value, l.value, e.style])
      }, [(c = t.default) == null ? void 0 : c.call(t)]);
    }), {
      getLayoutItem: i,
      items: o
    };
  }
}), l1 = N(v(v({
  position: {
    type: String,
    required: !0
  },
  size: {
    type: [Number, String],
    default: 300
  },
  modelValue: Boolean
}, de()), In()), "VLayoutItem"), i1 = Y()({
  name: "VLayoutItem",
  props: l1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      layoutItemStyles: a
    } = _n({
      id: e.name,
      order: C(() => parseInt(e.order, 10)),
      position: M(() => e.position),
      elementSize: M(() => e.size),
      layoutSize: M(() => e.size),
      active: M(() => e.modelValue),
      absolute: M(() => e.absolute)
    });
    return () => {
      var l;
      return w("div", {
        class: X(["v-layout-item", e.class]),
        style: ie([a.value, e.style])
      }, [(l = t.default) == null ? void 0 : l.call(t)]);
    };
  }
}), o1 = N(v(v(v(v({
  modelValue: Boolean,
  options: {
    type: Object,
    // For more information on types, navigate to:
    // https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
    default: () => ({
      root: void 0,
      rootMargin: void 0,
      threshold: void 0
    })
  }
}, de()), Ze()), ke()), Ft({
  transition: "fade-transition"
})), "VLazy"), r1 = Y()({
  name: "VLazy",
  directives: {
    vIntersect: Ht
  },
  props: o1(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      dimensionStyles: a
    } = Qe(e), l = ve(e, "modelValue");
    function i(o) {
      l.value || (l.value = o);
    }
    return Z(() => Re(k(e.tag, {
      class: X(["v-lazy", e.class]),
      style: ie([a.value, e.style])
    }, {
      default: () => [l.value && k(ft, {
        transition: e.transition,
        appear: !0
      }, {
        default: () => {
          var o;
          return [(o = t.default) == null ? void 0 : o.call(t)];
        }
      })]
    }), [[Ht, {
      handler: i,
      options: e.options
    }, null]])), {};
  }
}), u1 = N(v({
  locale: String,
  fallbackLocale: String,
  messages: Object,
  rtl: {
    type: Boolean,
    default: void 0
  }
}, de()), "VLocaleProvider"), s1 = Y()({
  name: "VLocaleProvider",
  props: u1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      rtlClasses: a
    } = Yv(e);
    return Z(() => {
      var l;
      return w("div", {
        class: X(["v-locale-provider", a.value, e.class]),
        style: ie(e.style)
      }, [(l = t.default) == null ? void 0 : l.call(t)]);
    }), {};
  }
}), c1 = N(v(v(v({
  scrollable: Boolean
}, de()), Ze()), ke({
  tag: "main"
})), "VMain"), d1 = Y()({
  name: "VMain",
  props: c1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      dimensionStyles: a
    } = Qe(e), {
      mainStyles: l
    } = io(), {
      ssrBootStyles: i
    } = An();
    return Z(() => k(e.tag, {
      class: X(["v-main", {
        "v-main--scrollable": e.scrollable
      }, e.class]),
      style: ie([l.value, i.value, a.value, e.style])
    }, {
      default: () => {
        var o, r;
        return [e.scrollable ? w("div", {
          class: "v-main__scroller"
        }, [(o = t.default) == null ? void 0 : o.call(t)]) : (r = t.default) == null ? void 0 : r.call(t)];
      }
    })), {};
  }
});
function v1(e) {
  let {
    rootEl: n,
    isSticky: t,
    layoutItemStyles: a
  } = e;
  const l = te(!1), i = te(0), o = C(() => {
    const c = typeof l.value == "boolean" ? "top" : l.value;
    return [t.value ? {
      top: "auto",
      bottom: "auto",
      height: void 0
    } : void 0, l.value ? {
      [c]: ce(i.value)
    } : {
      top: a.value.top
    }];
  });
  gt(() => {
    oe(t, (c) => {
      c ? window.addEventListener("scroll", u, {
        passive: !0
      }) : window.removeEventListener("scroll", u);
    }, {
      immediate: !0
    });
  }), dt(() => {
    window.removeEventListener("scroll", u);
  });
  let r = 0;
  function u() {
    var b;
    const c = r > window.scrollY ? "up" : "down", s = n.value.getBoundingClientRect(), d = parseFloat((b = a.value.top) != null ? b : 0), f = window.scrollY - Math.max(0, i.value - d), m = s.height + Math.max(i.value, d) - window.scrollY - window.innerHeight, h = parseFloat(getComputedStyle(n.value).getPropertyValue("--v-body-scroll-y")) || 0;
    s.height < window.innerHeight - d ? (l.value = "top", i.value = d) : c === "up" && l.value === "bottom" || c === "down" && l.value === "top" ? (i.value = window.scrollY + s.top - h, l.value = !0) : c === "down" && m <= 0 ? (i.value = 0, l.value = "bottom") : c === "up" && f <= 0 && (h ? l.value !== "top" && (i.value = -f + h + d, l.value = "top") : (i.value = s.top + f, l.value = "top")), r = window.scrollY;
  }
  return {
    isStuck: l,
    stickyStyles: o
  };
}
const f1 = 100, m1 = 20;
function Ur(e) {
  return (e < 0 ? -1 : 1) * Math.sqrt(Math.abs(e)) * 1.41421356237;
}
function Kr(e) {
  if (e.length < 2)
    return 0;
  if (e.length === 2)
    return e[1].t === e[0].t ? 0 : (e[1].d - e[0].d) / (e[1].t - e[0].t);
  let n = 0;
  for (let t = e.length - 1; t > 0; t--) {
    if (e[t].t === e[t - 1].t)
      continue;
    const a = Ur(n), l = (e[t].d - e[t - 1].d) / (e[t].t - e[t - 1].t);
    n += (l - a) * Math.abs(l), t === e.length - 1 && (n *= 0.5);
  }
  return Ur(n) * 1e3;
}
function g1() {
  const e = {};
  function n(l) {
    Array.from(l.changedTouches).forEach((i) => {
      var r;
      ((r = e[i.identifier]) != null ? r : e[i.identifier] = new su(m1)).push([l.timeStamp, i]);
    });
  }
  function t(l) {
    Array.from(l.changedTouches).forEach((i) => {
      delete e[i.identifier];
    });
  }
  function a(l) {
    var c;
    const i = (c = e[l]) == null ? void 0 : c.values().reverse();
    if (!i)
      throw new Error(`No samples for touch id ${l}`);
    const o = i[0], r = [], u = [];
    for (const s of i) {
      if (o[0] - s[0] > f1) break;
      r.push({
        t: s[0],
        d: s[1].clientX
      }), u.push({
        t: s[0],
        d: s[1].clientY
      });
    }
    return {
      x: Kr(r),
      y: Kr(u),
      get direction() {
        const {
          x: s,
          y: d
        } = this, [f, m] = [Math.abs(s), Math.abs(d)];
        return f > m && s >= 0 ? "right" : f > m && s <= 0 ? "left" : m > f && d >= 0 ? "down" : m > f && d <= 0 ? "up" : h1();
      }
    };
  }
  return {
    addMovement: n,
    endTouch: t,
    getVelocity: a
  };
}
function h1() {
  throw new Error();
}
function y1(e) {
  let {
    el: n,
    isActive: t,
    isTemporary: a,
    width: l,
    touchless: i,
    position: o
  } = e;
  gt(() => {
    window.addEventListener("touchstart", y, {
      passive: !0
    }), window.addEventListener("touchmove", P, {
      passive: !1
    }), window.addEventListener("touchend", V, {
      passive: !0
    });
  }), dt(() => {
    window.removeEventListener("touchstart", y), window.removeEventListener("touchmove", P), window.removeEventListener("touchend", V);
  });
  const r = C(() => ["left", "right"].includes(o.value)), {
    addMovement: u,
    endTouch: c,
    getVelocity: s
  } = g1();
  let d = !1;
  const f = te(!1), m = te(0), h = te(0);
  let b;
  function g(I, T) {
    return (o.value === "left" ? I : o.value === "right" ? document.documentElement.clientWidth - I : o.value === "top" ? I : o.value === "bottom" ? document.documentElement.clientHeight - I : On()) - (T ? l.value : 0);
  }
  function S(I) {
    let T = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    const _ = o.value === "left" ? (I - h.value) / l.value : o.value === "right" ? (document.documentElement.clientWidth - I - h.value) / l.value : o.value === "top" ? (I - h.value) / l.value : o.value === "bottom" ? (document.documentElement.clientHeight - I - h.value) / l.value : On();
    return T ? Fe(_) : _;
  }
  function y(I) {
    if (i.value) return;
    const T = I.changedTouches[0].clientX, _ = I.changedTouches[0].clientY, p = 25, L = o.value === "left" ? T < p : o.value === "right" ? T > document.documentElement.clientWidth - p : o.value === "top" ? _ < p : o.value === "bottom" ? _ > document.documentElement.clientHeight - p : On(), D = t.value && (o.value === "left" ? T < l.value : o.value === "right" ? T > document.documentElement.clientWidth - l.value : o.value === "top" ? _ < l.value : o.value === "bottom" ? _ > document.documentElement.clientHeight - l.value : On());
    (L || D || t.value && a.value) && (b = [T, _], h.value = g(r.value ? T : _, t.value), m.value = S(r.value ? T : _), d = h.value > -20 && h.value < 80, c(I), u(I));
  }
  function P(I) {
    const T = I.changedTouches[0].clientX, _ = I.changedTouches[0].clientY;
    if (d) {
      if (!I.cancelable) {
        d = !1;
        return;
      }
      const L = Math.abs(T - b[0]), D = Math.abs(_ - b[1]);
      (r.value ? L > D && L > 3 : D > L && D > 3) ? (f.value = !0, d = !1) : (r.value ? D : L) > 3 && (d = !1);
    }
    if (!f.value) return;
    I.preventDefault(), u(I);
    const p = S(r.value ? T : _, !1);
    m.value = Math.max(0, Math.min(1, p)), p > 1 ? h.value = g(r.value ? T : _, !0) : p < 0 && (h.value = g(r.value ? T : _, !1));
  }
  function V(I) {
    if (d = !1, !f.value) return;
    u(I), f.value = !1;
    const T = s(I.changedTouches[0].identifier), _ = Math.abs(T.x), p = Math.abs(T.y);
    (r.value ? _ > p && _ > 400 : p > _ && p > 3) ? t.value = T.direction === ({
      left: "right",
      right: "left",
      top: "down",
      bottom: "up"
    }[o.value] || On()) : t.value = m.value > 0.5;
  }
  const x = C(() => f.value ? {
    transform: o.value === "left" ? `translateX(calc(-100% + ${m.value * l.value}px))` : o.value === "right" ? `translateX(calc(100% - ${m.value * l.value}px))` : o.value === "top" ? `translateY(calc(-100% + ${m.value * l.value}px))` : o.value === "bottom" ? `translateY(calc(100% - ${m.value * l.value}px))` : On(),
    transition: "none"
  } : void 0);
  return mt(f, () => {
    var _, p, L, D;
    const I = (p = (_ = n.value) == null ? void 0 : _.style.transform) != null ? p : null, T = (D = (L = n.value) == null ? void 0 : L.style.transition) != null ? D : null;
    We(() => {
      var A, B, F, $;
      (B = n.value) == null || B.style.setProperty("transform", ((A = x.value) == null ? void 0 : A.transform) || "none"), ($ = n.value) == null || $.style.setProperty("transition", ((F = x.value) == null ? void 0 : F.transition) || null);
    }), tt(() => {
      var A, B;
      (A = n.value) == null || A.style.setProperty("transform", I), (B = n.value) == null || B.style.setProperty("transition", T);
    });
  }), {
    isDragging: f,
    dragProgress: m,
    dragStyles: x
  };
}
function On() {
  throw new Error();
}
const b1 = ["start", "end", "left", "right", "top", "bottom"], S1 = N(v(v(v(v(v(v(v(v(v({
  color: String,
  disableResizeWatcher: Boolean,
  disableRouteWatcher: Boolean,
  expandOnHover: Boolean,
  floating: Boolean,
  modelValue: {
    type: Boolean,
    default: null
  },
  permanent: Boolean,
  rail: {
    type: Boolean,
    default: null
  },
  railWidth: {
    type: [Number, String],
    default: 56
  },
  scrim: {
    type: [Boolean, String],
    default: !0
  },
  image: String,
  temporary: Boolean,
  persistent: Boolean,
  touchless: Boolean,
  width: {
    type: [Number, String],
    default: 256
  },
  location: {
    type: String,
    default: "start",
    validator: (e) => b1.includes(e)
  },
  sticky: Boolean
}, kt()), de()), So()), Pn({
  mobile: null
})), Je()), In()), Ne()), ke({
  tag: "nav"
})), Ie()), "VNavigationDrawer"), k1 = Y()({
  name: "VNavigationDrawer",
  props: S1(),
  emits: {
    "update:modelValue": (e) => !0,
    "update:rail": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const {
      isRtl: i
    } = Xe(), {
      themeClasses: o
    } = De(e), {
      borderClasses: r
    } = Ct(e), {
      backgroundColorClasses: u,
      backgroundColorStyles: c
    } = pe(() => e.color), {
      elevationClasses: s
    } = lt(e), {
      displayClasses: d,
      mobile: f
    } = At(e), {
      roundedClasses: m
    } = Ye(e), h = es(), b = ve(e, "modelValue", null, (E) => !!E), {
      ssrBootStyles: g
    } = An(), {
      scopeId: S
    } = pn(), y = Q(), P = te(!1), {
      runOpenDelay: V,
      runCloseDelay: x
    } = ko(e, (E) => {
      P.value = E;
    }), I = C(() => e.rail && e.expandOnHover && P.value ? Number(e.width) : Number(e.rail ? e.railWidth : e.width)), T = C(() => li(e.location, i.value)), _ = M(() => e.persistent), p = C(() => !e.permanent && (f.value || e.temporary)), L = C(() => e.sticky && !p.value && T.value !== "bottom");
    mt(() => e.expandOnHover && e.rail != null, () => {
      oe(P, (E) => a("update:rail", !E));
    }), mt(() => !e.disableResizeWatcher, () => {
      oe(p, (E) => !e.permanent && Ve(() => b.value = !E));
    }), mt(() => !e.disableRouteWatcher && !!h, () => {
      oe(h.currentRoute, () => p.value && (b.value = !1));
    }), oe(() => e.permanent, (E) => {
      E && (b.value = !0);
    }), e.modelValue == null && !p.value && (b.value = e.permanent || !f.value);
    const {
      isDragging: D,
      dragProgress: A
    } = y1({
      el: y,
      isActive: b,
      isTemporary: p,
      width: I,
      touchless: M(() => e.touchless),
      position: T
    }), B = C(() => {
      const E = p.value ? 0 : e.rail && e.expandOnHover ? Number(e.railWidth) : I.value;
      return D.value ? E * A.value : E;
    }), {
      layoutItemStyles: F,
      layoutItemScrimStyles: $
    } = _n({
      id: e.name,
      order: C(() => parseInt(e.order, 10)),
      position: T,
      layoutSize: B,
      elementSize: I,
      active: vl(b),
      disableTransitions: M(() => D.value),
      absolute: C(() => (
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        e.absolute || L.value && typeof W.value != "string"
      ))
    }), {
      isStuck: W,
      stickyStyles: J
    } = v1({
      rootEl: y,
      isSticky: L,
      layoutItemStyles: F
    }), z = pe(() => typeof e.scrim == "string" ? e.scrim : null), H = C(() => v(v({}, D.value ? {
      opacity: A.value * 0.2,
      transition: "none"
    } : void 0), $.value));
    return je({
      VList: {
        bgColor: "transparent"
      }
    }), Z(() => {
      const E = l.image || e.image;
      return w(he, null, [k(e.tag, G({
        ref: y,
        onMouseenter: V,
        onMouseleave: x,
        class: ["v-navigation-drawer", `v-navigation-drawer--${T.value}`, {
          "v-navigation-drawer--expand-on-hover": e.expandOnHover,
          "v-navigation-drawer--floating": e.floating,
          "v-navigation-drawer--is-hovering": P.value,
          "v-navigation-drawer--rail": e.rail,
          "v-navigation-drawer--temporary": p.value,
          "v-navigation-drawer--persistent": _.value,
          "v-navigation-drawer--active": b.value,
          "v-navigation-drawer--sticky": L.value
        }, o.value, u.value, r.value, d.value, s.value, m.value, e.class],
        style: [c.value, F.value, g.value, J.value, e.style]
      }, S, t), {
        default: () => {
          var O, R, q;
          return [E && w("div", {
            key: "image",
            class: "v-navigation-drawer__img"
          }, [l.image ? k(Ce, {
            key: "image-defaults",
            disabled: !e.image,
            defaults: {
              VImg: {
                alt: "",
                cover: !0,
                height: "inherit",
                src: e.image
              }
            }
          }, l.image) : k(Ut, {
            key: "image-img",
            alt: "",
            cover: !0,
            height: "inherit",
            src: e.image
          }, null)]), l.prepend && w("div", {
            class: "v-navigation-drawer__prepend"
          }, [(O = l.prepend) == null ? void 0 : O.call(l)]), w("div", {
            class: "v-navigation-drawer__content"
          }, [(R = l.default) == null ? void 0 : R.call(l)]), l.append && w("div", {
            class: "v-navigation-drawer__append"
          }, [(q = l.append) == null ? void 0 : q.call(l)])];
        }
      }), k(en, {
        name: "fade-transition"
      }, {
        default: () => [p.value && (D.value || b.value) && !!e.scrim && w("div", G({
          class: ["v-navigation-drawer__scrim", z.backgroundColorClasses.value],
          style: [H.value, z.backgroundColorStyles.value],
          onClick: () => {
            _.value || (b.value = !1);
          }
        }, S), null)]
      })]);
    }), {
      isStuck: W
    };
  }
}), w1 = _t({
  name: "VNoSsr",
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Ws();
    return () => {
      var l;
      return a.value && ((l = t.default) == null ? void 0 : l.call(t));
    };
  }
}), C1 = 50, x1 = 500;
function V1(e) {
  let {
    toggleUpDown: n
  } = e, t = -1, a = -1;
  tt(i);
  function l(r) {
    i(), o(r), window.addEventListener("pointerup", i), document.addEventListener("blur", i), t = window.setTimeout(() => {
      a = window.setInterval(() => o(r), C1);
    }, x1);
  }
  function i() {
    window.clearTimeout(t), window.clearInterval(a), window.removeEventListener("pointerup", i), document.removeEventListener("blur", i);
  }
  function o(r) {
    n(r === "up");
  }
  return {
    holdStart: l,
    holdStop: i
  };
}
const P1 = N(v({
  controlVariant: {
    type: String,
    default: "default"
  },
  inset: Boolean,
  hideInput: Boolean,
  modelValue: {
    type: Number,
    default: null
  },
  min: {
    type: Number,
    default: Number.MIN_SAFE_INTEGER
  },
  max: {
    type: Number,
    default: Number.MAX_SAFE_INTEGER
  },
  step: {
    type: Number,
    default: 1
  },
  precision: {
    type: Number,
    default: 0
  },
  minFractionDigits: {
    type: Number,
    default: null
  },
  decimalSeparator: {
    type: String,
    validator: (e) => !e || e.length === 1
  }
}, $e(Na(), ["modelValue", "validationValue"])), "VNumberInput"), I1 = Y()({
  name: "VNumberInput",
  props: v({}, P1()),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Q(), {
      holdStart: l,
      holdStop: i
    } = V1({
      toggleUpDown: p
    }), o = $a(e), r = C(() => o.isDisabled.value || o.isReadonly.value), u = te(e.focused), {
      decimalSeparator: c
    } = Ee(), s = C(() => {
      var O;
      return ((O = e.decimalSeparator) == null ? void 0 : O[0]) || c.value;
    });
    function d(O) {
      let R = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e.precision, q = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
      const ae = R == null ? String(O) : O.toFixed(R);
      if (u.value && q)
        return Number(ae).toString().replace(".", s.value);
      if (e.minFractionDigits === null || R !== null && R < e.minFractionDigits)
        return ae.replace(".", s.value);
      let [U, ne] = ae.split(".");
      return ne = (ne != null ? ne : "").padEnd(e.minFractionDigits, "0").replace(new RegExp(`(?<=\\d{${e.minFractionDigits}})0+$`, "g"), ""), [U, ne].filter(Boolean).join(s.value);
    }
    const f = ve(e, "modelValue", null, (O) => O != null ? O : null, (O) => O == null ? O != null ? O : null : Fe(Number(O), e.min, e.max)), m = te(null);
    We(() => {
      u.value && !r.value || (f.value == null ? m.value = null : isNaN(f.value) || (m.value = d(f.value)));
    });
    const h = C({
      get: () => m.value,
      set(O) {
        if (O === null || O === "") {
          f.value = null, m.value = null;
          return;
        }
        const R = Number(O.replace(s.value, "."));
        !isNaN(R) && R <= e.max && R >= e.min && (f.value = R, m.value = O);
      }
    }), b = C(() => {
      var O;
      return r.value ? !1 : ((O = f.value) != null ? O : 0) + e.step <= e.max;
    }), g = C(() => {
      var O;
      return r.value ? !1 : ((O = f.value) != null ? O : 0) - e.step >= e.min;
    }), S = C(() => e.hideInput ? "stacked" : e.controlVariant), y = M(() => S.value === "split" ? "$plus" : "$collapse"), P = M(() => S.value === "split" ? "$minus" : "$expand"), V = M(() => S.value === "split" ? "default" : "small"), x = M(() => S.value === "stacked" ? "auto" : "100%"), I = {
      props: {
        onClick: A,
        onPointerup: B,
        onPointerdown: F,
        onPointercancel: B
      }
    }, T = {
      props: {
        onClick: A,
        onPointerup: B,
        onPointerdown: $,
        onPointercancel: B
      }
    };
    oe(() => e.precision, () => J()), oe(() => e.minFractionDigits, () => J()), gt(() => {
      W();
    });
    function _(O) {
      if (O == null) return 0;
      const R = O.toString(), q = R.indexOf(".");
      return ~q ? R.length - q : 0;
    }
    function p() {
      let O = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
      if (r.value) return;
      if (f.value == null) {
        h.value = d(Fe(0, e.min, e.max));
        return;
      }
      let R = Math.max(_(f.value), _(e.step));
      e.precision != null && (R = Math.max(R, e.precision)), O ? b.value && (h.value = d(f.value + e.step, R)) : g.value && (h.value = d(f.value - e.step, R));
    }
    function L(O) {
      var ue;
      if (!O.data) return;
      const R = O.target, {
        value: q,
        selectionStart: ae,
        selectionEnd: U
      } = R != null ? R : {}, ne = q ? q.slice(0, ae) + O.data + q.slice(U) : O.data, j = av(ne, e.precision, s.value);
      if (new RegExp(`^-?\\d*${nl(s.value)}?\\d*$`).test(ne) || (O.preventDefault(), R.value = j), e.precision != null) {
        if (((ue = ne.split(s.value)[1]) == null ? void 0 : ue.length) > e.precision) {
          O.preventDefault(), R.value = j;
          const ge = (ae != null ? ae : 0) + O.data.length;
          R.setSelectionRange(ge, ge);
        }
        e.precision === 0 && ne.includes(s.value) && (O.preventDefault(), R.value = j);
      }
    }
    function D(O) {
      return He(this, null, function* () {
        ["Enter", "ArrowLeft", "ArrowRight", "Backspace", "Delete", "Tab"].includes(O.key) || O.ctrlKey || ["ArrowDown", "ArrowUp"].includes(O.key) && (O.preventDefault(), O.stopPropagation(), W(), yield Ve(), O.key === "ArrowDown" ? p(!1) : p());
      });
    }
    function A(O) {
      O.stopPropagation();
    }
    function B(O) {
      const R = O.currentTarget;
      R == null || R.releasePointerCapture(O.pointerId), O.preventDefault(), i();
    }
    function F(O) {
      const R = O.currentTarget;
      R == null || R.setPointerCapture(O.pointerId), O.preventDefault(), O.stopPropagation(), l("up");
    }
    function $(O) {
      const R = O.currentTarget;
      R == null || R.setPointerCapture(O.pointerId), O.preventDefault(), O.stopPropagation(), l("down");
    }
    function W() {
      if (r.value || !a.value) return;
      const O = a.value.value, R = Number(O.replace(s.value, "."));
      O && !isNaN(R) ? h.value = d(Fe(R, e.min, e.max)) : h.value = null;
    }
    function J() {
      r.value || (h.value = f.value !== null && !isNaN(f.value) ? d(f.value, e.precision, !1) : null);
    }
    function z() {
      if (!r.value) {
        if (f.value === null || isNaN(f.value)) {
          h.value = null;
          return;
        }
        h.value = f.value.toString().replace(".", s.value);
      }
    }
    function H() {
      z();
    }
    function E() {
      W();
    }
    return Z(() => {
      const re = Kt.filterProps(e), {
        modelValue: O
      } = re, R = Ge(re, [
        "modelValue"
      ]);
      function q() {
        return t.increment ? k(Ce, {
          key: "increment-defaults",
          defaults: {
            VBtn: {
              disabled: !b.value,
              height: x.value,
              size: V.value,
              icon: y.value,
              variant: "text"
            }
          }
        }, {
          default: () => [t.increment(I)]
        }) : k(xe, {
          "aria-hidden": "true",
          "data-testid": "increment",
          disabled: !b.value,
          height: x.value,
          icon: y.value,
          key: "increment-btn",
          onClick: A,
          onPointerdown: F,
          onPointerup: B,
          onPointercancel: B,
          size: V.value,
          variant: "text",
          tabindex: "-1"
        }, null);
      }
      function ae() {
        return t.decrement ? k(Ce, {
          key: "decrement-defaults",
          defaults: {
            VBtn: {
              disabled: !g.value,
              height: x.value,
              size: V.value,
              icon: P.value,
              variant: "text"
            }
          }
        }, {
          default: () => [t.decrement(T)]
        }) : k(xe, {
          "aria-hidden": "true",
          "data-testid": "decrement",
          disabled: !g.value,
          height: x.value,
          icon: P.value,
          key: "decrement-btn",
          onClick: A,
          onPointerdown: $,
          onPointerup: B,
          onPointercancel: B,
          size: V.value,
          variant: "text",
          tabindex: "-1"
        }, null);
      }
      function U() {
        return w("div", {
          class: "v-number-input__control"
        }, [ae(), k(It, {
          vertical: S.value !== "stacked"
        }, null), q()]);
      }
      function ne() {
        return !e.hideInput && !e.inset ? k(It, {
          vertical: !0
        }, null) : void 0;
      }
      const j = S.value === "split" ? w("div", {
        class: "v-number-input__control"
      }, [k(It, {
        vertical: !0
      }, null), q()]) : e.reverse || S.value === "hidden" ? void 0 : w(he, null, [ne(), U()]), ue = t["append-inner"] || j, ge = S.value === "split" ? w("div", {
        class: "v-number-input__control"
      }, [ae(), k(It, {
        vertical: !0
      }, null)]) : e.reverse && S.value !== "hidden" ? w(he, null, [U(), ne()]) : void 0, ee = t["prepend-inner"] || ge;
      return k(Kt, G({
        ref: a
      }, R, {
        modelValue: h.value,
        "onUpdate:modelValue": (fe) => h.value = fe,
        focused: u.value,
        "onUpdate:focused": (fe) => u.value = fe,
        validationValue: f.value,
        onBeforeinput: L,
        onFocus: H,
        onBlur: E,
        onKeydown: D,
        class: ["v-number-input", {
          "v-number-input--default": S.value === "default",
          "v-number-input--hide-input": e.hideInput,
          "v-number-input--inset": e.inset,
          "v-number-input--reverse": e.reverse,
          "v-number-input--split": S.value === "split",
          "v-number-input--stacked": S.value === "stacked"
        }, e.class],
        style: e.style,
        inputmode: "decimal"
      }), le(v({}, t), {
        "append-inner": ue ? function() {
          var ye;
          for (var fe = arguments.length, K = new Array(fe), se = 0; se < fe; se++)
            K[se] = arguments[se];
          return w(he, null, [(ye = t["append-inner"]) == null ? void 0 : ye.call(t, ...K), j]);
        } : void 0,
        "prepend-inner": ee ? function() {
          var ye;
          for (var fe = arguments.length, K = new Array(fe), se = 0; se < fe; se++)
            K[se] = arguments[se];
          return w(he, null, [ge, (ye = t["prepend-inner"]) == null ? void 0 : ye.call(t, ...K)]);
        } : void 0
      }));
    }), it({}, a);
  }
}), _1 = N(v(v(v({
  autofocus: Boolean,
  divider: String,
  focusAll: Boolean,
  label: {
    type: String,
    default: "$vuetify.input.otp"
  },
  length: {
    type: [Number, String],
    default: 6
  },
  modelValue: {
    type: [Number, String],
    default: void 0
  },
  placeholder: String,
  type: {
    type: String,
    default: "number"
  }
}, Ze()), Ea()), qt(Oa({
  variant: "outlined"
}), ["baseColor", "bgColor", "class", "color", "disabled", "error", "loading", "rounded", "style", "theme", "variant"])), "VOtpInput"), A1 = Y()({
  name: "VOtpInput",
  props: _1(),
  emits: {
    finish: (e) => !0,
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const {
      dimensionStyles: i
    } = Qe(e), {
      isFocused: o,
      focus: r,
      blur: u
    } = Qt(e), c = ve(e, "modelValue", "", (L) => L == null ? [] : String(L).split(""), (L) => L.join("")), {
      t: s
    } = Ee(), d = C(() => Number(e.length)), f = C(() => Array(d.value).fill(0)), m = Q(-1), h = Q(), b = Q([]), g = C(() => b.value[m.value]);
    let S = !1;
    mt(() => e.autofocus, () => {
      const L = Hn();
      L.run(() => {
        const {
          intersectionRef: D,
          isIntersecting: A
        } = Ta();
        We(() => {
          D.value = b.value[0];
        }), oe(A, (B) => {
          var F;
          B && ((F = D.value) == null || F.focus(), L.stop());
        });
      });
    });
    function y() {
      if (p(g.value.value)) {
        g.value.value = "";
        return;
      }
      if (S) return;
      const L = c.value.slice(), D = g.value.value;
      L[m.value] = D;
      let A = null;
      m.value > c.value.length ? A = c.value.length + 1 : m.value + 1 !== d.value && (A = "next"), c.value = L, A && mn(h.value, A);
    }
    function P() {
      S = !1, y();
    }
    function V(L) {
      const D = c.value.slice(), A = m.value;
      let B = null;
      ["ArrowLeft", "ArrowRight", "Backspace", "Delete"].includes(L.key) && (L.preventDefault(), L.key === "ArrowLeft" ? B = "prev" : L.key === "ArrowRight" ? B = "next" : ["Backspace", "Delete"].includes(L.key) && (D[m.value] = "", c.value = D, m.value > 0 && L.key === "Backspace" ? B = "prev" : requestAnimationFrame(() => {
        var F;
        (F = b.value[A]) == null || F.select();
      })), requestAnimationFrame(() => {
        B != null && mn(h.value, B);
      }));
    }
    function x(L, D) {
      var F, $;
      D.preventDefault(), D.stopPropagation();
      const A = ($ = (F = D == null ? void 0 : D.clipboardData) == null ? void 0 : F.getData("Text").trim().slice(0, d.value)) != null ? $ : "", B = A.length - 1 === -1 ? L : A.length - 1;
      p(A) || (c.value = A.split(""), m.value = B);
    }
    function I() {
      c.value = [];
    }
    function T(L, D) {
      r(), m.value = D;
    }
    function _() {
      u(), m.value = -1;
    }
    function p(L) {
      return e.type === "number" && /[^0-9]/g.test(L);
    }
    return je({
      VField: {
        color: M(() => e.color),
        bgColor: M(() => e.color),
        baseColor: M(() => e.baseColor),
        disabled: M(() => e.disabled),
        error: M(() => e.error),
        variant: M(() => e.variant)
      }
    }, {
      scoped: !0
    }), oe(c, (L) => {
      L.length === d.value && a("finish", L.join(""));
    }, {
      deep: !0
    }), oe(m, (L) => {
      L < 0 || Ve(() => {
        var D;
        (D = b.value[L]) == null || D.select();
      });
    }), Z(() => {
      var A;
      const [L, D] = an(t);
      return w("div", G({
        class: ["v-otp-input", {
          "v-otp-input--divided": !!e.divider
        }, e.class],
        style: [e.style]
      }, L), [w("div", {
        ref: h,
        class: "v-otp-input__content",
        style: ie([i.value])
      }, [f.value.map((B, F) => w(he, null, [e.divider && F !== 0 && w("span", {
        class: "v-otp-input__divider"
      }, [e.divider]), k(nn, {
        focused: o.value && e.focusAll || m.value === F,
        key: F
      }, le(v({}, l), {
        loader: void 0,
        default: () => w("input", {
          ref: ($) => b.value[F] = $,
          "aria-label": s(e.label, F + 1),
          autofocus: F === 0 && e.autofocus,
          autocomplete: "one-time-code",
          class: X(["v-otp-input__field"]),
          disabled: e.disabled,
          inputmode: e.type === "number" ? "numeric" : "text",
          min: e.type === "number" ? 0 : void 0,
          maxlength: F === 0 ? d.value : "1",
          placeholder: e.placeholder,
          type: e.type === "number" ? "text" : e.type,
          value: c.value[F],
          onInput: y,
          onFocus: ($) => T($, F),
          onBlur: _,
          onKeydown: V,
          onCompositionstart: () => S = !0,
          onCompositionend: P,
          onPaste: ($) => x(F, $)
        }, null)
      }))])), w("input", G({
        class: "v-otp-input-input",
        type: "hidden"
      }, D, {
        value: c.value.join("")
      }), null), k(Wt, {
        contained: !0,
        contentClass: "v-otp-input__loader",
        modelValue: !!e.loading,
        persistent: !0
      }, {
        default: () => {
          var B, F;
          return [(F = (B = l.loader) == null ? void 0 : B.call(l)) != null ? F : k(bn, {
            color: typeof e.loading == "boolean" ? void 0 : e.loading,
            indeterminate: !0,
            size: "24",
            width: "2"
          }, null)];
        }
      }), (A = l.default) == null ? void 0 : A.call(l)])]);
    }), {
      blur: () => {
        var L;
        (L = b.value) == null || L.some((D) => D.blur());
      },
      focus: () => {
        var L;
        (L = b.value) == null || L[0].focus();
      },
      reset: I,
      isFocused: o
    };
  }
});
function L1(e) {
  return Math.floor(Math.abs(e)) * Math.sign(e);
}
const T1 = N(v({
  scale: {
    type: [Number, String],
    default: 0.5
  }
}, de()), "VParallax"), B1 = Y()({
  name: "VParallax",
  props: T1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      intersectionRef: a,
      isIntersecting: l
    } = Ta(), {
      resizeRef: i,
      contentRect: o
    } = pt(), {
      height: r
    } = At(), u = Q();
    We(() => {
      var m;
      a.value = i.value = (m = u.value) == null ? void 0 : m.$el;
    });
    let c;
    oe(l, (m) => {
      m ? (c = eo(a.value), c = c === document.scrollingElement ? document : c, c.addEventListener("scroll", f, {
        passive: !0
      }), f()) : c.removeEventListener("scroll", f);
    }), dt(() => {
      c == null || c.removeEventListener("scroll", f);
    }), oe(r, f), oe(() => {
      var m;
      return (m = o.value) == null ? void 0 : m.height;
    }, f);
    const s = C(() => 1 - Fe(Number(e.scale)));
    let d = -1;
    function f() {
      l.value && (cancelAnimationFrame(d), d = requestAnimationFrame(() => {
        var x;
        const m = ((x = u.value) == null ? void 0 : x.$el).querySelector(".v-img__img");
        if (!m) return;
        const h = c instanceof Document ? document.documentElement.clientHeight : c.clientHeight, b = c instanceof Document ? window.scrollY : c.scrollTop, g = a.value.getBoundingClientRect().top + b, S = o.value.height, y = g + (S - h) / 2, P = L1((b - y) * s.value), V = Math.max(1, (s.value * (h - S) + S) / S);
        m.style.setProperty("transform", `translateY(${P}px) scale(${V})`);
      }));
    }
    return Z(() => k(Ut, {
      class: X(["v-parallax", {
        "v-parallax--active": l.value
      }, e.class]),
      style: ie(e.style),
      ref: u,
      cover: !0,
      onLoadstart: f,
      onLoad: f
    }, t)), {};
  }
}), D1 = N(v({}, Vl({
  falseIcon: "$radioOff",
  trueIcon: "$radioOn"
})), "VRadio"), M1 = Y()({
  name: "VRadio",
  props: D1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      const a = tn.filterProps(e);
      return k(tn, G(a, {
        class: ["v-radio", e.class],
        style: e.style,
        type: "radio"
      }), t);
    }), {};
  }
}), p1 = N(le(v(v({
  height: {
    type: [Number, String],
    default: "auto"
  }
}, Jt()), $e(fo(), ["multiple"])), {
  trueIcon: {
    type: me,
    default: "$radioOn"
  },
  falseIcon: {
    type: me,
    default: "$radioOff"
  },
  type: {
    type: String,
    default: "radio"
  }
}), "VRadioGroup"), E1 = Y()({
  name: "VRadioGroup",
  inheritAttrs: !1,
  props: p1(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const l = St(), i = C(() => e.id || `radio-group-${l}`), o = ve(e, "modelValue"), r = Q();
    return Z(() => {
      const [u, c] = an(t), s = ct.filterProps(e), d = tn.filterProps(e), f = a.label ? a.label({
        label: e.label,
        props: {
          for: i.value
        }
      }) : e.label;
      return k(ct, G({
        ref: r,
        class: ["v-radio-group", e.class],
        style: e.style
      }, u, s, {
        modelValue: o.value,
        "onUpdate:modelValue": (m) => o.value = m,
        id: i.value
      }), le(v({}, a), {
        default: (m) => {
          let {
            id: h,
            messagesId: b,
            isDisabled: g,
            isReadonly: S
          } = m;
          return w(he, null, [f && k(ta, {
            id: h.value
          }, {
            default: () => [f]
          }), k(cs, G(d, {
            id: h.value,
            "aria-describedby": b.value,
            defaultsTarget: "VRadio",
            trueIcon: e.trueIcon,
            falseIcon: e.falseIcon,
            type: e.type,
            disabled: g.value,
            readonly: S.value,
            "aria-labelledby": f ? h.value : void 0,
            multiple: !1
          }, c, {
            modelValue: o.value,
            "onUpdate:modelValue": (y) => o.value = y
          }), a)]);
        }
      }));
    }), it({}, r);
  }
}), $1 = N(le(v(v(v({}, Ea()), Jt()), dc()), {
  strict: Boolean,
  modelValue: {
    type: Array,
    default: () => [0, 0]
  }
}), "VRangeSlider"), F1 = Y()({
  name: "VRangeSlider",
  props: $1(),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0,
    end: (e) => !0,
    start: (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = Q(), i = Q(), o = Q(), {
      rtlClasses: r
    } = Xe();
    function u(L) {
      if (!l.value || !i.value) return;
      const D = _i(L, l.value.$el, e.direction), A = _i(L, i.value.$el, e.direction), B = Math.abs(D), F = Math.abs(A);
      return B < F || B === F && D < 0 ? l.value.$el : i.value.$el;
    }
    const c = vc(e), s = ve(e, "modelValue", void 0, (L) => L != null && L.length ? L.map((D) => c.roundValue(D)) : [0, 0]), {
      activeThumbRef: d,
      hasLabels: f,
      max: m,
      min: h,
      mousePressed: b,
      onSliderMousedown: g,
      onSliderTouchstart: S,
      position: y,
      trackContainerRef: P,
      readonly: V
    } = fc({
      props: e,
      steps: c,
      onSliderStart: () => {
        a("start", s.value);
      },
      onSliderEnd: (L) => {
        var B;
        let {
          value: D
        } = L;
        const A = d.value === ((B = l.value) == null ? void 0 : B.$el) ? [D, s.value[1]] : [s.value[0], D];
        !e.strict && A[0] < A[1] && (s.value = A), a("end", s.value);
      },
      onSliderMove: (L) => {
        var F, $, W, J;
        let {
          value: D
        } = L;
        const [A, B] = s.value;
        !e.strict && A === B && A !== h.value && (d.value = D > A ? (F = i.value) == null ? void 0 : F.$el : ($ = l.value) == null ? void 0 : $.$el, (W = d.value) == null || W.focus()), d.value === ((J = l.value) == null ? void 0 : J.$el) ? s.value = [Math.min(D, B), B] : s.value = [A, Math.max(A, D)];
      },
      getActiveThumb: u
    }), {
      isFocused: x,
      focus: I,
      blur: T
    } = Qt(e), _ = C(() => y(s.value[0])), p = C(() => y(s.value[1]));
    return Z(() => {
      const L = ct.filterProps(e), D = !!(e.label || t.label || t.prepend);
      return k(ct, G({
        class: ["v-slider", "v-range-slider", {
          "v-slider--has-labels": !!t["tick-label"] || f.value,
          "v-slider--focused": x.value,
          "v-slider--pressed": b.value,
          "v-slider--disabled": e.disabled
        }, r.value, e.class],
        style: e.style,
        ref: o
      }, L, {
        focused: x.value
      }), le(v({}, t), {
        prepend: D ? (A) => {
          var B, F, $;
          return w(he, null, [(F = (B = t.label) == null ? void 0 : B.call(t, A)) != null ? F : e.label ? k(ta, {
            class: "v-slider__label",
            text: e.label
          }, null) : void 0, ($ = t.prepend) == null ? void 0 : $.call(t, A)]);
        } : void 0,
        default: (A) => {
          var $, W;
          let {
            id: B,
            messagesId: F
          } = A;
          return w("div", {
            class: "v-slider__container",
            onMousedown: V.value ? void 0 : g,
            onTouchstartPassive: V.value ? void 0 : S
          }, [w("input", {
            id: `${B.value}_start`,
            name: e.name || B.value,
            disabled: !!e.disabled,
            readonly: !!e.readonly,
            tabindex: "-1",
            value: s.value[0]
          }, null), w("input", {
            id: `${B.value}_stop`,
            name: e.name || B.value,
            disabled: !!e.disabled,
            readonly: !!e.readonly,
            tabindex: "-1",
            value: s.value[1]
          }, null), k(mc, {
            ref: P,
            start: _.value,
            stop: p.value
          }, {
            "tick-label": t["tick-label"]
          }), k(Ai, {
            ref: l,
            "aria-describedby": F.value,
            focused: x && d.value === (($ = l.value) == null ? void 0 : $.$el),
            modelValue: s.value[0],
            "onUpdate:modelValue": (J) => s.value = [J, s.value[1]],
            onFocus: (J) => {
              var z, H, E, O;
              I(), d.value = (z = l.value) == null ? void 0 : z.$el, m.value !== h.value && s.value[0] === s.value[1] && s.value[1] === h.value && J.relatedTarget !== ((H = i.value) == null ? void 0 : H.$el) && ((E = l.value) == null || E.$el.blur(), (O = i.value) == null || O.$el.focus());
            },
            onBlur: () => {
              T(), d.value = void 0;
            },
            min: h.value,
            max: s.value[1],
            position: _.value,
            ripple: e.ripple
          }, {
            "thumb-label": t["thumb-label"]
          }), k(Ai, {
            ref: i,
            "aria-describedby": F.value,
            focused: x && d.value === ((W = i.value) == null ? void 0 : W.$el),
            modelValue: s.value[1],
            "onUpdate:modelValue": (J) => s.value = [s.value[0], J],
            onFocus: (J) => {
              var z, H, E, O;
              I(), d.value = (z = i.value) == null ? void 0 : z.$el, m.value !== h.value && s.value[0] === s.value[1] && s.value[0] === m.value && J.relatedTarget !== ((H = l.value) == null ? void 0 : H.$el) && ((E = i.value) == null || E.$el.blur(), (O = l.value) == null || O.$el.focus());
            },
            onBlur: () => {
              T(), d.value = void 0;
            },
            min: s.value[0],
            max: m.value,
            position: p.value,
            ripple: e.ripple
          }, {
            "thumb-label": t["thumb-label"]
          })]);
        }
      }));
    }), it({
      focus: () => {
        var L;
        return (L = l.value) == null ? void 0 : L.$el.focus();
      }
    }, o);
  }
}), O1 = N(v(v(v(v(v({
  name: String,
  itemAriaLabel: {
    type: String,
    default: "$vuetify.rating.ariaLabel.item"
  },
  activeColor: String,
  color: String,
  clearable: Boolean,
  disabled: Boolean,
  emptyIcon: {
    type: me,
    default: "$ratingEmpty"
  },
  fullIcon: {
    type: me,
    default: "$ratingFull"
  },
  halfIncrements: Boolean,
  hover: Boolean,
  length: {
    type: [Number, String],
    default: 5
  },
  readonly: Boolean,
  modelValue: {
    type: [Number, String],
    default: 0
  },
  itemLabels: Array,
  itemLabelPosition: {
    type: String,
    default: "top",
    validator: (e) => ["top", "bottom"].includes(e)
  },
  ripple: Boolean
}, de()), nt()), Yt()), ke()), Ie()), "VRating"), N1 = Y()({
  name: "VRating",
  props: O1(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      t: a
    } = Ee(), {
      themeClasses: l
    } = De(e), i = ve(e, "modelValue"), o = C(() => Fe(parseFloat(i.value), 0, Number(e.length))), r = C(() => Vt(Number(e.length), 1)), u = C(() => r.value.flatMap((g) => e.halfIncrements ? [g - 0.5, g] : [g])), c = te(-1), s = C(() => u.value.map((g) => {
      var _;
      const S = e.hover && c.value > -1, y = o.value >= g, P = c.value >= g, x = (S ? P : y) ? e.fullIcon : e.emptyIcon, I = (_ = e.activeColor) != null ? _ : e.color, T = y || P ? I : e.color;
      return {
        isFilled: y,
        isHovered: P,
        icon: x,
        color: T
      };
    })), d = C(() => [0, ...u.value].map((g) => {
      function S() {
        c.value = g;
      }
      function y() {
        c.value = -1;
      }
      function P() {
        e.disabled || e.readonly || (i.value = o.value === g && e.clearable ? 0 : g);
      }
      return {
        onMouseenter: e.hover ? S : void 0,
        onMouseleave: e.hover ? y : void 0,
        onClick: P
      };
    })), f = St(), m = C(() => {
      var g;
      return (g = e.name) != null ? g : `v-rating-${f}`;
    });
    function h(g) {
      var p, L;
      let {
        value: S,
        index: y,
        showStar: P = !0
      } = g;
      const {
        onMouseenter: V,
        onMouseleave: x,
        onClick: I
      } = d.value[y + 1], T = `${m.value}-${String(S).replace(".", "-")}`, _ = {
        color: (p = s.value[y]) == null ? void 0 : p.color,
        density: e.density,
        disabled: e.disabled,
        icon: (L = s.value[y]) == null ? void 0 : L.icon,
        ripple: e.ripple,
        size: e.size,
        variant: "plain"
      };
      return w(he, null, [w("label", {
        for: T,
        class: X({
          "v-rating__item--half": e.halfIncrements && S % 1 > 0,
          "v-rating__item--full": e.halfIncrements && S % 1 === 0
        }),
        onMouseenter: V,
        onMouseleave: x,
        onClick: I
      }, [w("span", {
        class: "v-rating__hidden"
      }, [a(e.itemAriaLabel, S, e.length)]), P ? t.item ? t.item(le(v({}, s.value[y]), {
        props: _,
        value: S,
        index: y,
        rating: o.value
      })) : k(xe, G({
        "aria-label": a(e.itemAriaLabel, S, e.length)
      }, _), null) : void 0]), w("input", {
        class: "v-rating__hidden",
        name: m.value,
        id: T,
        type: "radio",
        value: S,
        checked: o.value === S,
        tabindex: -1,
        readonly: e.readonly,
        disabled: e.disabled
      }, null)]);
    }
    function b(g) {
      return t["item-label"] ? t["item-label"](g) : g.label ? w("span", null, [g.label]) : w("span", null, [Nt(" ")]);
    }
    return Z(() => {
      var S;
      const g = !!((S = e.itemLabels) != null && S.length) || t["item-label"];
      return k(e.tag, {
        class: X(["v-rating", {
          "v-rating--hover": e.hover,
          "v-rating--readonly": e.readonly
        }, l.value, e.class]),
        style: ie(e.style)
      }, {
        default: () => [k(h, {
          value: 0,
          index: -1,
          showStar: !1
        }, null), r.value.map((y, P) => {
          var V, x;
          return w("div", {
            class: "v-rating__wrapper"
          }, [g && e.itemLabelPosition === "top" ? b({
            value: y,
            index: P,
            label: (V = e.itemLabels) == null ? void 0 : V[P]
          }) : void 0, w("div", {
            class: "v-rating__item"
          }, [e.halfIncrements ? w(he, null, [k(h, {
            value: y - 0.5,
            index: P * 2
          }, null), k(h, {
            value: y,
            index: P * 2 + 1
          }, null)]) : k(h, {
            value: y,
            index: P
          }, null)]), g && e.itemLabelPosition === "bottom" ? b({
            value: y,
            index: P,
            label: (x = e.itemLabels) == null ? void 0 : x[P]
          }) : void 0]);
        })]
      });
    }), {};
  }
}), R1 = {
  actions: "button@2",
  article: "heading, paragraph",
  avatar: "avatar",
  button: "button",
  card: "image, heading",
  "card-avatar": "image, list-item-avatar",
  chip: "chip",
  "date-picker": "list-item, heading, divider, date-picker-options, date-picker-days, actions",
  "date-picker-options": "text, avatar@2",
  "date-picker-days": "avatar@28",
  divider: "divider",
  heading: "heading",
  image: "image",
  "list-item": "text",
  "list-item-avatar": "avatar, text",
  "list-item-two-line": "sentences",
  "list-item-avatar-two-line": "avatar, sentences",
  "list-item-three-line": "paragraph",
  "list-item-avatar-three-line": "avatar, paragraph",
  ossein: "ossein",
  paragraph: "text@3",
  sentences: "text@2",
  subtitle: "text",
  table: "table-heading, table-thead, table-tbody, table-tfoot",
  "table-heading": "chip, text",
  "table-thead": "heading@6",
  "table-tbody": "table-row-divider@6",
  "table-row-divider": "table-row, divider",
  "table-row": "text@6",
  "table-tfoot": "text@2, avatar@2",
  text: "text"
};
function H1(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
  return w("div", {
    class: X(["v-skeleton-loader__bone", `v-skeleton-loader__${e}`])
  }, [n]);
}
function qr(e) {
  const [n, t] = e.split("@");
  return Array.from({
    length: t
  }).map(() => Nl(n));
}
function Nl(e) {
  let n = [];
  if (!e) return n;
  const t = R1[e];
  if (e !== t) {
    if (e.includes(",")) return Xr(e);
    if (e.includes("@")) return qr(e);
    t.includes(",") ? n = Xr(t) : t.includes("@") ? n = qr(t) : t && n.push(Nl(t));
  }
  return [H1(e, n)];
}
function Xr(e) {
  return e.replace(/\s/g, "").split(",").map(Nl);
}
const z1 = N(v(v(v({
  boilerplate: Boolean,
  color: String,
  loading: Boolean,
  loadingText: {
    type: String,
    default: "$vuetify.loading"
  },
  type: {
    type: [String, Array],
    default: "ossein"
  }
}, Ze()), Je()), Ie()), "VSkeletonLoader"), W1 = Y()({
  name: "VSkeletonLoader",
  props: z1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      backgroundColorClasses: a,
      backgroundColorStyles: l
    } = pe(() => e.color), {
      dimensionStyles: i
    } = Qe(e), {
      elevationClasses: o
    } = lt(e), {
      themeClasses: r
    } = De(e), {
      t: u
    } = Ee(), c = C(() => Nl(ze(e.type).join(",")));
    return Z(() => {
      var f;
      const s = !t.default || e.loading, d = e.boilerplate || !s ? {} : {
        ariaLive: "polite",
        ariaLabel: u(e.loadingText),
        role: "alert"
      };
      return w("div", G({
        class: ["v-skeleton-loader", {
          "v-skeleton-loader--boilerplate": e.boilerplate
        }, r.value, a.value, o.value],
        style: [l.value, s ? i.value : {}]
      }, d), [s ? c.value : (f = t.default) == null ? void 0 : f.call(t)]);
    }), {};
  }
}), j1 = Y()({
  name: "VSlideGroupItem",
  props: Bn(),
  emits: {
    "group:selected": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Dn(e, Ss);
    return () => {
      var l;
      return (l = t.default) == null ? void 0 : l.call(t, {
        isSelected: a.isSelected.value,
        select: a.select,
        toggle: a.toggle,
        selectedClass: a.selectedClass.value
      });
    };
  }
});
function Y1(e) {
  const n = te(e());
  let t = -1;
  function a() {
    clearInterval(t);
  }
  function l() {
    a(), Ve(() => n.value = e());
  }
  function i(o) {
    const r = o ? getComputedStyle(o) : {
      transitionDuration: 0.2
    }, u = parseFloat(r.transitionDuration) * 1e3 || 200;
    if (a(), n.value <= 0) return;
    const c = performance.now();
    t = window.setInterval(() => {
      const s = performance.now() - c + u;
      n.value = Math.max(e() - s, 0), n.value <= 0 && a();
    }, u);
  }
  return tt(a), {
    clear: a,
    time: n,
    start: i,
    reset: l
  };
}
const rd = N(v(v(v(v(v(v({
  multiLine: Boolean,
  text: String,
  timer: [Boolean, String],
  timeout: {
    type: [Number, String],
    default: 5e3
  },
  vertical: Boolean
}, Zt({
  location: "bottom"
})), Jn()), Ne()), Dt()), Ie()), $e(Fa({
  transition: "v-snackbar-transition"
}), ["persistent", "noClickAnimation", "scrim", "scrollStrategy"])), "VSnackbar"), Ni = Y()({
  name: "VSnackbar",
  props: rd(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), {
      positionClasses: l
    } = ea(e), {
      scopeId: i
    } = pn(), {
      themeClasses: o
    } = De(e), {
      colorClasses: r,
      colorStyles: u,
      variantClasses: c
    } = Ln(e), {
      roundedClasses: s
    } = Ye(e), d = Y1(() => Number(e.timeout)), f = Q(), m = Q(), h = te(!1), b = te(0), g = Q(), S = Pe(ha, void 0);
    mt(() => !!S, () => {
      const D = io();
      We(() => {
        g.value = D.mainStyles.value;
      });
    }), oe(a, P), oe(() => e.timeout, P), gt(() => {
      a.value && P();
    });
    let y = -1;
    function P() {
      d.reset(), window.clearTimeout(y);
      const D = Number(e.timeout);
      if (!a.value || D === -1) return;
      const A = Ui(m.value);
      d.start(A), y = window.setTimeout(() => {
        a.value = !1;
      }, D);
    }
    function V() {
      d.reset(), window.clearTimeout(y);
    }
    function x() {
      h.value = !0, V();
    }
    function I() {
      h.value = !1, P();
    }
    function T(D) {
      b.value = D.touches[0].clientY;
    }
    function _(D) {
      Math.abs(b.value - D.changedTouches[0].clientY) > 50 && (a.value = !1);
    }
    function p() {
      h.value && I();
    }
    const L = C(() => e.location.split(" ").reduce((D, A) => (D[`v-snackbar--${A}`] = !0, D), {}));
    return Z(() => {
      const D = Wt.filterProps(e), A = !!(t.default || t.text || e.text);
      return k(Wt, G({
        ref: f,
        class: ["v-snackbar", {
          "v-snackbar--active": a.value,
          "v-snackbar--multi-line": e.multiLine && !e.vertical,
          "v-snackbar--timer": !!e.timer,
          "v-snackbar--vertical": e.vertical
        }, L.value, l.value, e.class],
        style: [g.value, e.style]
      }, D, {
        modelValue: a.value,
        "onUpdate:modelValue": (B) => a.value = B,
        contentProps: G({
          class: ["v-snackbar__wrapper", o.value, r.value, s.value, c.value],
          style: [u.value],
          onPointerenter: x,
          onPointerleave: I
        }, D.contentProps),
        persistent: !0,
        noClickAnimation: !0,
        scrim: !1,
        scrollStrategy: "none",
        _disableGlobalStack: !0,
        onTouchstartPassive: T,
        onTouchend: _,
        onAfterLeave: p
      }, i), {
        default: () => {
          var B, F, $;
          return [ln(!1, "v-snackbar"), e.timer && !h.value && w("div", {
            key: "timer",
            class: "v-snackbar__timer"
          }, [k(wl, {
            ref: m,
            color: typeof e.timer == "string" ? e.timer : "info",
            max: e.timeout,
            modelValue: d.time.value
          }, null)]), A && w("div", {
            key: "content",
            class: "v-snackbar__content",
            role: "status",
            "aria-live": "polite"
          }, [(F = (B = t.text) == null ? void 0 : B.call(t)) != null ? F : e.text, ($ = t.default) == null ? void 0 : $.call(t)]), t.actions && k(Ce, {
            defaults: {
              VBtn: {
                variant: "text",
                ripple: !1,
                slim: !0
              }
            }
          }, {
            default: () => [w("div", {
              class: "v-snackbar__actions"
            }, [t.actions({
              isActive: a
            })])]
          })];
        },
        activator: t.activator
      });
    }), it({}, f);
  }
}), G1 = N(v({
  // TODO: Port this to Snackbar on dev
  closable: [Boolean, String],
  closeText: {
    type: String,
    default: "$vuetify.dismiss"
  },
  modelValue: {
    type: Array,
    default: () => []
  }
}, $e(rd(), ["modelValue"])), "VSnackbarQueue"), U1 = Y()({
  name: "VSnackbarQueue",
  props: G1(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      t: l
    } = Ee(), i = te(!1), o = te(!1), r = te();
    oe(() => e.modelValue.length, (f, m) => {
      !o.value && f > m && c();
    }), oe(i, (f) => {
      f && (o.value = !0);
    });
    function u() {
      e.modelValue.length ? c() : (r.value = void 0, o.value = !1);
    }
    function c() {
      const [f, ...m] = e.modelValue;
      t("update:modelValue", m), r.value = typeof f == "string" ? {
        text: f
      } : f, Ve(() => {
        i.value = !0;
      });
    }
    function s() {
      i.value = !1;
    }
    const d = C(() => ({
      color: typeof e.closable == "string" ? e.closable : void 0,
      text: l(e.closeText)
    }));
    Z(() => {
      const f = !!(e.closable || a.actions), b = Ni.filterProps(e), {
        modelValue: m
      } = b, h = Ge(b, [
        "modelValue"
      ]);
      return w(he, null, [o.value && !!r.value && (a.default ? k(Ce, {
        defaults: {
          VSnackbar: r.value
        }
      }, {
        default: () => [a.default({
          item: r.value
        })]
      }) : k(Ni, G(h, r.value, {
        modelValue: i.value,
        "onUpdate:modelValue": (g) => i.value = g,
        onAfterLeave: u
      }), {
        text: a.text ? () => {
          var g;
          return (g = a.text) == null ? void 0 : g.call(a, {
            item: r.value
          });
        } : void 0,
        actions: f ? () => w(he, null, [a.actions ? k(Ce, {
          defaults: {
            VBtn: d.value
          }
        }, {
          default: () => [a.actions({
            item: r.value,
            props: {
              onClick: s
            }
          })]
        }) : k(xe, G(d.value, {
          onClick: s
        }), null)]) : void 0
      }))]);
    });
  }
}), ud = N({
  autoDraw: Boolean,
  autoDrawDuration: [Number, String],
  autoDrawEasing: {
    type: String,
    default: "ease"
  },
  color: String,
  gradient: {
    type: Array,
    default: () => []
  },
  gradientDirection: {
    type: String,
    validator: (e) => ["top", "bottom", "left", "right"].includes(e),
    default: "top"
  },
  height: {
    type: [String, Number],
    default: 75
  },
  labels: {
    type: Array,
    default: () => []
  },
  labelSize: {
    type: [Number, String],
    default: 7
  },
  lineWidth: {
    type: [String, Number],
    default: 4
  },
  id: String,
  itemValue: {
    type: String,
    default: "value"
  },
  modelValue: {
    type: Array,
    default: () => []
  },
  min: [String, Number],
  max: [String, Number],
  padding: {
    type: [String, Number],
    default: 8
  },
  showLabels: Boolean,
  smooth: [Boolean, String, Number],
  width: {
    type: [Number, String],
    default: 300
  }
}, "Line"), sd = N(v({
  autoLineWidth: Boolean
}, ud()), "VBarline"), Zr = Y()({
  name: "VBarline",
  props: sd(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = St(), l = C(() => e.id || `barline-${a}`), i = C(() => Number(e.autoDrawDuration) || 500), o = C(() => !!(e.showLabels || e.labels.length > 0 || t != null && t.label)), r = C(() => parseFloat(e.lineWidth) || 4), u = C(() => Math.max(e.modelValue.length * r.value, Number(e.width))), c = C(() => ({
      minX: 0,
      maxX: u.value,
      minY: 0,
      maxY: parseInt(e.height, 10)
    })), s = C(() => e.modelValue.map((g) => qe(g, e.itemValue, g)));
    function d(g, S) {
      const {
        minX: y,
        maxX: P,
        minY: V,
        maxY: x
      } = S, I = g.length;
      let T = e.max != null ? Number(e.max) : Math.max(...g), _ = e.min != null ? Number(e.min) : Math.min(...g);
      _ > 0 && e.min == null && (_ = 0), T < 0 && e.max == null && (T = 0);
      const p = P / (I === 1 ? 2 : I), L = (x - V) / (T - _ || 1), D = x - Math.abs(_ * L);
      return g.map((A, B) => {
        const F = Math.abs(L * A);
        return {
          x: y + B * p,
          y: D - F + +(A < 0) * F,
          height: F,
          value: A
        };
      });
    }
    const f = C(() => {
      const g = [], S = d(s.value, c.value), y = S.length;
      for (let P = 0; g.length < y; P++) {
        const V = S[P];
        let x = e.labels[P];
        x || (x = typeof V == "object" ? V.value : V), g.push({
          x: V.x,
          value: String(x)
        });
      }
      return g;
    }), m = C(() => d(s.value, c.value)), h = C(() => m.value.length === 1 ? (c.value.maxX - r.value) / 2 : (Math.abs(m.value[0].x - m.value[1].x) - r.value) / 2), b = C(() => typeof e.smooth == "boolean" ? e.smooth ? 2 : 0 : Number(e.smooth));
    Z(() => {
      const g = e.gradient.slice().length ? e.gradient.slice().reverse() : [""];
      return w("svg", {
        display: "block"
      }, [w("defs", null, [w("linearGradient", {
        id: l.value,
        gradientUnits: "userSpaceOnUse",
        x1: e.gradientDirection === "left" ? "100%" : "0",
        y1: e.gradientDirection === "top" ? "100%" : "0",
        x2: e.gradientDirection === "right" ? "100%" : "0",
        y2: e.gradientDirection === "bottom" ? "100%" : "0"
      }, [g.map((S, y) => w("stop", {
        offset: y / Math.max(g.length - 1, 1),
        "stop-color": S || "currentColor"
      }, null))])]), w("clipPath", {
        id: `${l.value}-clip`
      }, [m.value.map((S) => w("rect", {
        x: S.x + h.value,
        y: S.y,
        width: r.value,
        height: S.height,
        rx: b.value,
        ry: b.value
      }, [e.autoDraw && w(he, null, [w("animate", {
        attributeName: "y",
        from: S.y + S.height,
        to: S.y,
        dur: `${i.value}ms`,
        fill: "freeze"
      }, null), w("animate", {
        attributeName: "height",
        from: "0",
        to: S.height,
        dur: `${i.value}ms`,
        fill: "freeze"
      }, null)])]))]), o.value && w("g", {
        key: "labels",
        style: {
          textAnchor: "middle",
          dominantBaseline: "mathematical",
          fill: "currentColor"
        }
      }, [f.value.map((S, y) => {
        var P, V;
        return w("text", {
          x: S.x + h.value + r.value / 2,
          y: parseInt(e.height, 10) - 2 + (parseInt(e.labelSize, 10) || 7 * 0.75),
          "font-size": Number(e.labelSize) || 7
        }, [(V = (P = t.label) == null ? void 0 : P.call(t, {
          index: y,
          value: S.value
        })) != null ? V : S.value]);
      })]), w("g", {
        "clip-path": `url(#${l.value}-clip)`,
        fill: `url(#${l.value})`
      }, [w("rect", {
        x: 0,
        y: 0,
        width: Math.max(e.modelValue.length * r.value, Number(e.width)),
        height: e.height
      }, null)])]);
    });
  }
});
function K1(e, n) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 75;
  if (e.length === 0) return "";
  const l = e.shift(), i = e[e.length - 1];
  return (t ? `M${l.x} ${a - l.x + 2} L${l.x} ${l.y}` : `M${l.x} ${l.y}`) + e.map((o, r) => {
    const u = e[r + 1], c = e[r - 1] || l, s = u && q1(u, o, c);
    if (!u || s)
      return `L${o.x} ${o.y}`;
    const d = Math.min(Qr(c, o), Qr(u, o)), m = d / 2 < n ? d / 2 : n, h = Jr(c, o, m), b = Jr(u, o, m);
    return `L${h.x} ${h.y}S${o.x} ${o.y} ${b.x} ${b.y}`;
  }).join("") + (t ? `L${i.x} ${a - l.x + 2} Z` : "");
}
function qa(e) {
  return parseInt(e, 10);
}
function q1(e, n, t) {
  return qa(e.x + t.x) === qa(2 * n.x) && qa(e.y + t.y) === qa(2 * n.y);
}
function Qr(e, n) {
  return Math.sqrt(Math.pow(n.x - e.x, 2) + Math.pow(n.y - e.y, 2));
}
function Jr(e, n, t) {
  const a = {
    x: e.x - n.x,
    y: e.y - n.y
  }, l = Math.sqrt(a.x * a.x + a.y * a.y), i = {
    x: a.x / l,
    y: a.y / l
  };
  return {
    x: n.x + i.x * t,
    y: n.y + i.y * t
  };
}
const cd = N(v({
  fill: Boolean
}, ud()), "VTrendline"), eu = Y()({
  name: "VTrendline",
  props: cd(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = St(), l = C(() => e.id || `trendline-${a}`), i = C(() => Number(e.autoDrawDuration) || (e.fill ? 500 : 2e3)), o = Q(0), r = Q(null);
    function u(g, S) {
      const {
        minX: y,
        maxX: P,
        minY: V,
        maxY: x
      } = S;
      g.length === 1 && (g = [g[0], g[0]]);
      const I = g.length, T = e.max != null ? Number(e.max) : Math.max(...g), _ = e.min != null ? Number(e.min) : Math.min(...g), p = (P - y) / (I - 1), L = (x - V) / (T - _ || 1);
      return g.map((D, A) => ({
        x: y + A * p,
        y: x - (D - _) * L,
        value: D
      }));
    }
    const c = C(() => !!(e.showLabels || e.labels.length > 0 || t != null && t.label)), s = C(() => parseFloat(e.lineWidth) || 4), d = C(() => Number(e.width)), f = C(() => {
      const g = Number(e.padding);
      return {
        minX: g,
        maxX: d.value - g,
        minY: g,
        maxY: parseInt(e.height, 10) - g
      };
    }), m = C(() => e.modelValue.map((g) => qe(g, e.itemValue, g))), h = C(() => {
      const g = [], S = u(m.value, f.value), y = S.length;
      for (let P = 0; g.length < y; P++) {
        const V = S[P];
        let x = e.labels[P];
        x || (x = typeof V == "object" ? V.value : V), g.push({
          x: V.x,
          value: String(x)
        });
      }
      return g;
    });
    oe(() => e.modelValue, () => He(this, null, function* () {
      if (yield Ve(), !e.autoDraw || !r.value) return;
      const g = r.value, S = g.getTotalLength();
      e.fill ? (g.style.transformOrigin = "bottom center", g.style.transition = "none", g.style.transform = "scaleY(0)", g.getBoundingClientRect(), g.style.transition = `transform ${i.value}ms ${e.autoDrawEasing}`, g.style.transform = "scaleY(1)") : (g.style.strokeDasharray = `${S}`, g.style.strokeDashoffset = `${S}`, g.getBoundingClientRect(), g.style.transition = `stroke-dashoffset ${i.value}ms ${e.autoDrawEasing}`, g.style.strokeDashoffset = "0"), o.value = S;
    }), {
      immediate: !0
    });
    function b(g) {
      const S = typeof e.smooth == "boolean" ? e.smooth ? 8 : 0 : Number(e.smooth);
      return K1(u(m.value, f.value), S, g, parseInt(e.height, 10));
    }
    Z(() => {
      var S, y, P;
      const g = e.gradient.slice().length ? e.gradient.slice().reverse() : [""];
      return w("svg", {
        display: "block",
        "stroke-width": (S = parseFloat(e.lineWidth)) != null ? S : 4
      }, [w("defs", null, [w("linearGradient", {
        id: l.value,
        gradientUnits: "userSpaceOnUse",
        x1: e.gradientDirection === "left" ? "100%" : "0",
        y1: e.gradientDirection === "top" ? "100%" : "0",
        x2: e.gradientDirection === "right" ? "100%" : "0",
        y2: e.gradientDirection === "bottom" ? "100%" : "0"
      }, [g.map((V, x) => w("stop", {
        offset: x / Math.max(g.length - 1, 1),
        "stop-color": V || "currentColor"
      }, null))])]), c.value && w("g", {
        key: "labels",
        style: {
          textAnchor: "middle",
          dominantBaseline: "mathematical",
          fill: "currentColor"
        }
      }, [h.value.map((V, x) => {
        var I, T;
        return w("text", {
          x: V.x + s.value / 2 + s.value / 2,
          y: parseInt(e.height, 10) - 4 + (parseInt(e.labelSize, 10) || 7 * 0.75),
          "font-size": Number(e.labelSize) || 7
        }, [(T = (I = t.label) == null ? void 0 : I.call(t, {
          index: x,
          value: V.value
        })) != null ? T : V.value]);
      })]), w("path", {
        ref: r,
        d: b(e.fill),
        fill: e.fill ? `url(#${l.value})` : "none",
        stroke: e.fill ? "none" : `url(#${l.value})`
      }, null), e.fill && w("path", {
        d: b(!1),
        fill: "none",
        stroke: (P = e.color) != null ? P : (y = e.gradient) == null ? void 0 : y[0]
      }, null)]);
    });
  }
}), X1 = N(v(v({
  type: {
    type: String,
    default: "trend"
  }
}, sd()), cd()), "VSparkline"), Z1 = Y()({
  name: "VSparkline",
  props: X1(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      textColorClasses: a,
      textColorStyles: l
    } = rt(() => e.color), i = C(() => !!(e.showLabels || e.labels.length > 0 || t != null && t.label)), o = C(() => {
      let r = parseInt(e.height, 10);
      return i.value && (r += parseInt(e.labelSize, 10) * 1.5), r;
    });
    Z(() => {
      const r = e.type === "trend" ? eu : Zr, u = e.type === "trend" ? eu.filterProps(e) : Zr.filterProps(e);
      return k(r, G({
        key: e.type,
        class: a.value,
        style: l.value,
        viewBox: `0 0 ${e.width} ${parseInt(o.value, 10)}`
      }, u), t);
    });
  }
}), Q1 = N(v(v({}, de()), Gs({
  offset: 8,
  minWidth: 0,
  openDelay: 0,
  closeDelay: 100,
  location: "top center",
  transition: "scale-transition"
})), "VSpeedDial"), J1 = Y()({
  name: "VSpeedDial",
  props: Q1(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), l = Q(), i = C(() => {
      var c, s;
      const [r, u = "center"] = (s = (c = e.location) == null ? void 0 : c.split(" ")) != null ? s : [];
      return `${r} ${u}`;
    }), o = C(() => ({
      [`v-speed-dial__content--${i.value.replace(" ", "-")}`]: !0
    }));
    return Z(() => {
      const r = Un.filterProps(e);
      return k(Un, G(r, {
        modelValue: a.value,
        "onUpdate:modelValue": (u) => a.value = u,
        class: e.class,
        style: e.style,
        contentClass: ["v-speed-dial__content", o.value, e.contentClass],
        location: i.value,
        ref: l,
        transition: "fade-transition"
      }), le(v({}, t), {
        default: (u) => k(Ce, {
          defaults: {
            VBtn: {
              size: "small"
            }
          }
        }, {
          default: () => [k(ft, {
            appear: !0,
            group: !0,
            transition: e.transition
          }, {
            default: () => {
              var c;
              return [(c = t.default) == null ? void 0 : c.call(t, u)];
            }
          })]
        })
      }));
    }), {};
  }
}), zo = Symbol.for("vuetify:v-stepper"), dd = N({
  color: String,
  disabled: {
    type: [Boolean, String],
    default: !1
  },
  prevText: {
    type: String,
    default: "$vuetify.stepper.prev"
  },
  nextText: {
    type: String,
    default: "$vuetify.stepper.next"
  }
}, "VStepperActions"), vd = Y()({
  name: "VStepperActions",
  props: dd(),
  emits: {
    "click:prev": () => !0,
    "click:next": () => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      t: l
    } = Ee();
    function i() {
      t("click:prev");
    }
    function o() {
      t("click:next");
    }
    return Z(() => {
      const r = {
        onClick: i
      }, u = {
        onClick: o
      };
      return w("div", {
        class: "v-stepper-actions"
      }, [k(Ce, {
        defaults: {
          VBtn: {
            disabled: ["prev", !0].includes(e.disabled),
            text: l(e.prevText),
            variant: "text"
          }
        }
      }, {
        default: () => {
          var c, s;
          return [(s = (c = a.prev) == null ? void 0 : c.call(a, {
            props: r
          })) != null ? s : k(xe, r, null)];
        }
      }), k(Ce, {
        defaults: {
          VBtn: {
            color: e.color,
            disabled: ["next", !0].includes(e.disabled),
            text: l(e.nextText),
            variant: "tonal"
          }
        }
      }, {
        default: () => {
          var c, s;
          return [(s = (c = a.next) == null ? void 0 : c.call(a, {
            props: u
          })) != null ? s : k(xe, u, null)];
        }
      })]);
    }), {};
  }
}), fd = Xt("v-stepper-header"), e0 = N({
  color: String,
  title: String,
  subtitle: String,
  complete: Boolean,
  completeIcon: {
    type: me,
    default: "$complete"
  },
  editable: Boolean,
  editIcon: {
    type: me,
    default: "$edit"
  },
  error: Boolean,
  errorIcon: {
    type: me,
    default: "$error"
  },
  icon: me,
  ripple: {
    type: [Boolean, Object],
    default: !0
  },
  rules: {
    type: Array,
    default: () => []
  }
}, "StepperItem"), t0 = N(v(v({}, e0()), Bn()), "VStepperItem"), md = Y()({
  name: "VStepperItem",
  directives: {
    vRipple: bt
  },
  props: t0(),
  emits: {
    "group:selected": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Dn(e, zo, !0), l = C(() => {
      var f;
      return (f = a == null ? void 0 : a.value.value) != null ? f : e.value;
    }), i = C(() => e.rules.every((f) => f() === !0)), o = C(() => !e.disabled && e.editable), r = C(() => !e.disabled && e.editable), u = C(() => e.error || !i.value), c = C(() => e.complete || e.rules.length > 0 && i.value), s = C(() => u.value ? e.errorIcon : c.value ? e.completeIcon : a.isSelected.value && e.editable ? e.editIcon : e.icon), d = C(() => ({
      canEdit: r.value,
      hasError: u.value,
      hasCompleted: c.value,
      title: e.title,
      subtitle: e.subtitle,
      step: l.value,
      value: e.value
    }));
    return Z(() => {
      var g, S, y, P, V;
      const f = (!a || a.isSelected.value || c.value || r.value) && !u.value && !e.disabled, m = !!(e.title != null || t.title), h = !!(e.subtitle != null || t.subtitle);
      function b() {
        a == null || a.toggle();
      }
      return Re(w("button", {
        class: X(["v-stepper-item", {
          "v-stepper-item--complete": c.value,
          "v-stepper-item--disabled": e.disabled,
          "v-stepper-item--error": u.value
        }, a == null ? void 0 : a.selectedClass.value]),
        disabled: !e.editable,
        type: "button",
        onClick: b
      }, [o.value && ln(!0, "v-stepper-item"), k(Bt, {
        key: "stepper-avatar",
        class: "v-stepper-item__avatar",
        color: f ? e.color : void 0,
        size: 24
      }, {
        default: () => {
          var x, I;
          return [(I = (x = t.icon) == null ? void 0 : x.call(t, d.value)) != null ? I : s.value ? k(Be, {
            icon: s.value
          }, null) : l.value];
        }
      }), w("div", {
        class: "v-stepper-item__content"
      }, [m && w("div", {
        key: "title",
        class: "v-stepper-item__title"
      }, [(S = (g = t.title) == null ? void 0 : g.call(t, d.value)) != null ? S : e.title]), h && w("div", {
        key: "subtitle",
        class: "v-stepper-item__subtitle"
      }, [(P = (y = t.subtitle) == null ? void 0 : y.call(t, d.value)) != null ? P : e.subtitle]), (V = t.default) == null ? void 0 : V.call(t, d.value)])]), [[bt, e.editable && e.ripple, null]]);
    }), {};
  }
}), n0 = N(v({}, $e(_l(), ["continuous", "nextIcon", "prevIcon", "showArrows", "touch", "mandatory"])), "VStepperWindow"), gd = Y()({
  name: "VStepperWindow",
  props: n0(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Pe(zo, null), l = ve(e, "modelValue"), i = C({
      get() {
        var o;
        return l.value != null || !a ? l.value : (o = a.items.value.find((r) => a.selected.value.includes(r.id))) == null ? void 0 : o.value;
      },
      set(o) {
        l.value = o;
      }
    });
    return Z(() => {
      const o = Sn.filterProps(e);
      return k(Sn, G({
        _as: "VStepperWindow"
      }, o, {
        modelValue: i.value,
        "onUpdate:modelValue": (r) => i.value = r,
        class: ["v-stepper-window", e.class],
        style: e.style,
        mandatory: !1,
        touch: !1
      }), t);
    }), {};
  }
}), a0 = N(v({}, Al()), "VStepperWindowItem"), hd = Y()({
  name: "VStepperWindowItem",
  props: a0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      const a = kn.filterProps(e);
      return k(kn, G({
        _as: "VStepperWindowItem"
      }, a, {
        class: ["v-stepper-window-item", e.class],
        style: e.style
      }), t);
    }), {};
  }
}), l0 = N(v({
  altLabels: Boolean,
  bgColor: String,
  completeIcon: me,
  editIcon: me,
  editable: Boolean,
  errorIcon: me,
  hideActions: Boolean,
  items: {
    type: Array,
    default: () => []
  },
  itemTitle: {
    type: String,
    default: "title"
  },
  itemValue: {
    type: String,
    default: "value"
  },
  nonLinear: Boolean,
  flat: Boolean
}, Pn()), "Stepper"), i0 = N(v(v(v(v({}, l0()), Tn({
  mandatory: "force",
  selectedClass: "v-stepper-item--selected"
})), _o()), qt(dd(), ["prevText", "nextText"])), "VStepper"), o0 = Y()({
  name: "VStepper",
  props: i0(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      items: a,
      next: l,
      prev: i,
      selected: o
    } = on(e, zo), {
      displayClasses: r,
      mobile: u
    } = At(e), {
      completeIcon: c,
      editIcon: s,
      errorIcon: d,
      color: f,
      editable: m,
      prevText: h,
      nextText: b
    } = Xn(e), g = C(() => e.items.map((P, V) => {
      const x = qe(P, e.itemTitle, P), I = qe(P, e.itemValue, V + 1);
      return {
        title: x,
        value: I,
        raw: P
      };
    })), S = C(() => a.value.findIndex((P) => o.value.includes(P.id))), y = C(() => e.disabled ? e.disabled : S.value === 0 ? "prev" : S.value === a.value.length - 1 ? "next" : !1);
    return je({
      VStepperItem: {
        editable: m,
        errorIcon: d,
        completeIcon: c,
        editIcon: s,
        prevText: h,
        nextText: b
      },
      VStepperActions: {
        color: f,
        disabled: y,
        prevText: h,
        nextText: b
      }
    }), Z(() => {
      const P = Va.filterProps(e), V = !!(t.header || e.items.length), x = e.items.length > 0, I = !e.hideActions && !!(x || t.actions);
      return k(Va, G(P, {
        color: e.bgColor,
        class: ["v-stepper", {
          "v-stepper--alt-labels": e.altLabels,
          "v-stepper--flat": e.flat,
          "v-stepper--non-linear": e.nonLinear,
          "v-stepper--mobile": u.value
        }, r.value, e.class],
        style: e.style
      }), {
        default: () => {
          var T, _, p;
          return [V && k(fd, {
            key: "stepper-header"
          }, {
            default: () => [g.value.map((L, D) => {
              var $;
              let F = L, {
                raw: A
              } = F, B = Ge(F, [
                "raw"
              ]);
              return w(he, null, [!!D && k(It, null, null), k(md, B, {
                default: ($ = t[`header-item.${B.value}`]) != null ? $ : t.header,
                icon: t.icon,
                title: t.title,
                subtitle: t.subtitle
              })]);
            })]
          }), x && k(gd, {
            key: "stepper-window"
          }, {
            default: () => [g.value.map((L) => k(hd, {
              value: L.value
            }, {
              default: () => {
                var D, A, B;
                return (B = (D = t[`item.${L.value}`]) == null ? void 0 : D.call(t, L)) != null ? B : (A = t.item) == null ? void 0 : A.call(t, L);
              }
            }))]
          }), (T = t.default) == null ? void 0 : T.call(t, {
            prev: i,
            next: l
          }), I && ((p = (_ = t.actions) == null ? void 0 : _.call(t, {
            next: l,
            prev: i
          })) != null ? p : k(vd, {
            key: "stepper-actions",
            "onClick:prev": i,
            "onClick:next": l
          }, t))];
        }
      });
    }), {
      prev: i,
      next: l
    };
  }
}), r0 = N(v(v({
  indeterminate: Boolean,
  inset: Boolean,
  flat: Boolean,
  loading: {
    type: [Boolean, String],
    default: !1
  }
}, Jt()), Vl()), "VSwitch"), u0 = Y()({
  name: "VSwitch",
  inheritAttrs: !1,
  props: r0(),
  emits: {
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0,
    "update:indeterminate": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const l = ve(e, "indeterminate"), i = ve(e, "modelValue"), {
      loaderClasses: o
    } = Ba(e), {
      isFocused: r,
      focus: u,
      blur: c
    } = Qt(e), s = Q(), d = Q(), f = Te && window.matchMedia("(forced-colors: active)").matches, m = M(() => typeof e.loading == "string" && e.loading !== "" ? e.loading : e.color), h = St(), b = M(() => e.id || `switch-${h}`);
    function g() {
      l.value && (l.value = !1);
    }
    function S(y) {
      var P, V;
      y.stopPropagation(), y.preventDefault(), (V = (P = s.value) == null ? void 0 : P.input) == null || V.click();
    }
    return Z(() => {
      const [y, P] = an(t), V = ct.filterProps(e), x = tn.filterProps(e);
      return k(ct, G({
        ref: d,
        class: ["v-switch", {
          "v-switch--flat": e.flat
        }, {
          "v-switch--inset": e.inset
        }, {
          "v-switch--indeterminate": l.value
        }, o.value, e.class]
      }, y, V, {
        modelValue: i.value,
        "onUpdate:modelValue": (I) => i.value = I,
        id: b.value,
        focused: r.value,
        style: e.style
      }), le(v({}, a), {
        default: (I) => {
          let {
            id: T,
            messagesId: _,
            isDisabled: p,
            isReadonly: L,
            isValid: D
          } = I;
          const A = {
            model: i,
            isValid: D
          };
          return k(tn, G({
            ref: s
          }, x, {
            modelValue: i.value,
            "onUpdate:modelValue": [(B) => i.value = B, g],
            id: T.value,
            "aria-describedby": _.value,
            type: "checkbox",
            "aria-checked": l.value ? "mixed" : void 0,
            disabled: p.value,
            readonly: L.value,
            onFocus: u,
            onBlur: c
          }, P), le(v({}, a), {
            default: (B) => {
              let {
                backgroundColorClasses: F,
                backgroundColorStyles: $
              } = B;
              return w("div", {
                class: X(["v-switch__track", f ? void 0 : F.value]),
                style: ie($.value),
                onClick: S
              }, [a["track-true"] && w("div", {
                key: "prepend",
                class: "v-switch__track-true"
              }, [a["track-true"](A)]), a["track-false"] && w("div", {
                key: "append",
                class: "v-switch__track-false"
              }, [a["track-false"](A)])]);
            },
            input: (B) => {
              let {
                inputNode: F,
                icon: $,
                backgroundColorClasses: W,
                backgroundColorStyles: J
              } = B;
              return w(he, null, [F, w("div", {
                class: X(["v-switch__thumb", {
                  "v-switch__thumb--filled": $ || e.loading
                }, e.inset || f ? void 0 : W.value]),
                style: ie(e.inset ? void 0 : J.value)
              }, [a.thumb ? k(Ce, {
                defaults: {
                  VIcon: {
                    icon: $,
                    size: "x-small"
                  }
                }
              }, {
                default: () => [a.thumb(le(v({}, A), {
                  icon: $
                }))]
              }) : k(ro, null, {
                default: () => [e.loading ? k(Da, {
                  name: "v-switch",
                  active: !0,
                  color: D.value === !1 ? void 0 : m.value
                }, {
                  default: (z) => a.loader ? a.loader(z) : k(bn, {
                    active: z.isActive,
                    color: z.color,
                    indeterminate: !0,
                    size: "16",
                    width: "2"
                  }, null)
                }) : $ && k(Be, {
                  key: String($),
                  icon: $,
                  size: "x-small"
                }, null)]
              })])]);
            }
          }));
        }
      }));
    }), it({}, d);
  }
}), s0 = N(v(v(v(v(v(v({
  color: String,
  height: [Number, String],
  window: Boolean
}, de()), Je()), In()), Ne()), ke()), Ie()), "VSystemBar"), c0 = Y()({
  name: "VSystemBar",
  props: s0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      backgroundColorClasses: l,
      backgroundColorStyles: i
    } = pe(() => e.color), {
      elevationClasses: o
    } = lt(e), {
      roundedClasses: r
    } = Ye(e), {
      ssrBootStyles: u
    } = An(), c = C(() => {
      var d;
      return (d = e.height) != null ? d : e.window ? 32 : 24;
    }), {
      layoutItemStyles: s
    } = _n({
      id: e.name,
      order: C(() => parseInt(e.order, 10)),
      position: te("top"),
      layoutSize: c,
      elementSize: c,
      active: C(() => !0),
      absolute: M(() => e.absolute)
    });
    return Z(() => k(e.tag, {
      class: X(["v-system-bar", {
        "v-system-bar--window": e.window
      }, a.value, l.value, o.value, r.value, e.class]),
      style: ie([i.value, s.value, u.value, e.style])
    }, t)), {};
  }
}), Wo = Symbol.for("vuetify:v-tabs"), d0 = N(v({
  fixed: Boolean,
  sliderColor: String,
  hideSlider: Boolean,
  direction: {
    type: String,
    default: "horizontal"
  }
}, $e(xl({
  selectedClass: "v-tab--selected",
  variant: "text"
}), ["active", "block", "flat", "location", "position", "symbol"])), "VTab"), yd = Y()({
  name: "VTab",
  props: d0(),
  setup(e, n) {
    let {
      slots: t,
      attrs: a
    } = n;
    const {
      textColorClasses: l,
      textColorStyles: i
    } = rt(() => e.sliderColor), o = Q(), r = Q(), u = C(() => e.direction === "horizontal"), c = C(() => {
      var d, f, m;
      return (m = (f = (d = o.value) == null ? void 0 : d.group) == null ? void 0 : f.isSelected.value) != null ? m : !1;
    });
    function s(d) {
      var m, h;
      let {
        value: f
      } = d;
      if (f) {
        const b = (h = (m = o.value) == null ? void 0 : m.$el.parentElement) == null ? void 0 : h.querySelector(".v-tab--selected .v-tab__slider"), g = r.value;
        if (!b || !g) return;
        const S = getComputedStyle(b).color, y = b.getBoundingClientRect(), P = g.getBoundingClientRect(), V = u.value ? "x" : "y", x = u.value ? "X" : "Y", I = u.value ? "right" : "bottom", T = u.value ? "width" : "height", _ = y[V], p = P[V], L = _ > p ? y[I] - P[I] : y[V] - P[V], D = Math.sign(L) > 0 ? u.value ? "right" : "bottom" : Math.sign(L) < 0 ? u.value ? "left" : "top" : "center", B = (Math.abs(L) + (Math.sign(L) < 0 ? y[T] : P[T])) / Math.max(y[T], P[T]) || 0, F = y[T] / P[T] || 0, $ = 1.5;
        dn(g, {
          backgroundColor: [S, "currentcolor"],
          transform: [`translate${x}(${L}px) scale${x}(${F})`, `translate${x}(${L / $}px) scale${x}(${(B - 1) / $ + 1})`, "none"],
          transformOrigin: Array(3).fill(D)
        }, {
          duration: 225,
          easing: ma
        });
      }
    }
    return Z(() => {
      const d = xe.filterProps(e);
      return k(xe, G({
        symbol: Wo,
        ref: o,
        class: ["v-tab", e.class],
        style: e.style,
        tabindex: c.value ? 0 : -1,
        role: "tab",
        "aria-selected": String(c.value),
        active: !1
      }, d, a, {
        block: e.fixed,
        maxWidth: e.fixed ? 300 : void 0,
        "onGroup:selected": s
      }), le(v({}, t), {
        default: () => {
          var f, m;
          return w(he, null, [(m = (f = t.default) == null ? void 0 : f.call(t)) != null ? m : e.text, !e.hideSlider && w("div", {
            ref: r,
            class: X(["v-tab__slider", l.value]),
            style: ie(i.value)
          }, null)]);
        }
      }));
    }), it({}, o);
  }
}), v0 = N(v({}, $e(_l(), ["continuous", "nextIcon", "prevIcon", "showArrows", "touch", "mandatory"])), "VTabsWindow"), bd = Y()({
  name: "VTabsWindow",
  props: v0(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Pe(Wo, null), l = ve(e, "modelValue"), i = C({
      get() {
        var o;
        return l.value != null || !a ? l.value : (o = a.items.value.find((r) => a.selected.value.includes(r.id))) == null ? void 0 : o.value;
      },
      set(o) {
        l.value = o;
      }
    });
    return Z(() => {
      const o = Sn.filterProps(e);
      return k(Sn, G({
        _as: "VTabsWindow"
      }, o, {
        modelValue: i.value,
        "onUpdate:modelValue": (r) => i.value = r,
        class: ["v-tabs-window", e.class],
        style: e.style,
        mandatory: !1,
        touch: !1
      }), t);
    }), {};
  }
}), f0 = N(v({}, Al()), "VTabsWindowItem"), Sd = Y()({
  name: "VTabsWindowItem",
  props: f0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return Z(() => {
      const a = kn.filterProps(e);
      return k(kn, G({
        _as: "VTabsWindowItem"
      }, a, {
        class: ["v-tabs-window-item", e.class],
        style: e.style
      }), t);
    }), {};
  }
});
function m0(e) {
  return e ? e.map((n) => Ja(n) ? n : {
    text: n,
    value: n
  }) : [];
}
const g0 = N(v(v(v({
  alignTabs: {
    type: String,
    default: "start"
  },
  color: String,
  fixedTabs: Boolean,
  items: {
    type: Array,
    default: () => []
  },
  stacked: Boolean,
  bgColor: String,
  grow: Boolean,
  height: {
    type: [Number, String],
    default: void 0
  },
  hideSlider: Boolean,
  sliderColor: String
}, mo({
  mandatory: "force",
  selectedClass: "v-tab-item--selected"
})), nt()), ke()), "VTabs"), h0 = Y()({
  name: "VTabs",
  props: g0(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      slots: a
    } = n;
    const l = ve(e, "modelValue"), i = C(() => m0(e.items)), {
      densityClasses: o
    } = ht(e), {
      backgroundColorClasses: r,
      backgroundColorStyles: u
    } = pe(() => e.bgColor), {
      scopeId: c
    } = pn();
    return je({
      VTab: {
        color: M(() => e.color),
        direction: M(() => e.direction),
        stacked: M(() => e.stacked),
        fixed: M(() => e.fixedTabs),
        sliderColor: M(() => e.sliderColor),
        hideSlider: M(() => e.hideSlider)
      }
    }), Z(() => {
      const s = wa.filterProps(e), d = !!(a.window || e.items.length > 0);
      return w(he, null, [k(wa, G(s, {
        modelValue: l.value,
        "onUpdate:modelValue": (f) => l.value = f,
        class: ["v-tabs", `v-tabs--${e.direction}`, `v-tabs--align-tabs-${e.alignTabs}`, {
          "v-tabs--fixed-tabs": e.fixedTabs,
          "v-tabs--grow": e.grow,
          "v-tabs--stacked": e.stacked
        }, o.value, r.value, e.class],
        style: [{
          "--v-tabs-height": ce(e.height)
        }, u.value, e.style],
        role: "tablist",
        symbol: Wo
      }, c, t), {
        default: () => {
          var f, m;
          return [(m = (f = a.default) == null ? void 0 : f.call(a)) != null ? m : i.value.map((h) => {
            var b, g;
            return (g = (b = a.tab) == null ? void 0 : b.call(a, {
              item: h
            })) != null ? g : k(yd, G(h, {
              key: h.text,
              value: h.value
            }), {
              default: a[`tab.${h.value}`] ? () => {
                var S;
                return (S = a[`tab.${h.value}`]) == null ? void 0 : S.call(a, {
                  item: h
                });
              } : void 0
            });
          })];
        }
      }), d && k(bd, G({
        modelValue: l.value,
        "onUpdate:modelValue": (f) => l.value = f,
        key: "tabs-window"
      }, c), {
        default: () => {
          var f;
          return [i.value.map((m) => {
            var h, b;
            return (b = (h = a.item) == null ? void 0 : h.call(a, {
              item: m
            })) != null ? b : k(Sd, {
              value: m.value
            }, {
              default: () => {
                var g;
                return (g = a[`item.${m.value}`]) == null ? void 0 : g.call(a, {
                  item: m
                });
              }
            });
          }), (f = a.window) == null ? void 0 : f.call(a)];
        }
      })]);
    }), {};
  }
}), y0 = N(v(v({
  autoGrow: Boolean,
  autofocus: Boolean,
  counter: [Boolean, Number, String],
  counterValue: Function,
  prefix: String,
  placeholder: String,
  persistentPlaceholder: Boolean,
  persistentCounter: Boolean,
  noResize: Boolean,
  rows: {
    type: [Number, String],
    default: 5,
    validator: (e) => !isNaN(parseFloat(e))
  },
  maxRows: {
    type: [Number, String],
    validator: (e) => !isNaN(parseFloat(e))
  },
  suffix: String,
  modelModifiers: Object
}, Jt()), Oa()), "VTextarea"), b0 = Y()({
  name: "VTextarea",
  directives: {
    vIntersect: Ht
  },
  inheritAttrs: !1,
  props: y0(),
  emits: {
    "click:control": (e) => !0,
    "mousedown:control": (e) => !0,
    "update:focused": (e) => !0,
    "update:modelValue": (e) => !0,
    "update:rows": (e) => !0
  },
  setup(e, n) {
    let {
      attrs: t,
      emit: a,
      slots: l
    } = n;
    const i = ve(e, "modelValue"), {
      isFocused: o,
      focus: r,
      blur: u
    } = Qt(e), {
      onIntersect: c
    } = Us(e), s = C(() => typeof e.counterValue == "function" ? e.counterValue(i.value) : (i.value || "").toString().length), d = C(() => {
      if (t.maxlength) return t.maxlength;
      if (!(!e.counter || typeof e.counter != "number" && typeof e.counter != "string"))
        return e.counter;
    }), f = Q(), m = Q(), h = te(""), b = Q(), g = C(() => e.persistentPlaceholder || o.value || e.active);
    function S() {
      var D;
      b.value !== document.activeElement && ((D = b.value) == null || D.focus()), o.value || r();
    }
    function y(D) {
      S(), a("click:control", D);
    }
    function P(D) {
      a("mousedown:control", D);
    }
    function V(D) {
      D.stopPropagation(), S(), Ve(() => {
        i.value = "", fl(e["onClick:clear"], D);
      });
    }
    function x(D) {
      var B;
      const A = D.target;
      if (i.value = A.value, (B = e.modelModifiers) != null && B.trim) {
        const F = [A.selectionStart, A.selectionEnd];
        Ve(() => {
          A.selectionStart = F[0], A.selectionEnd = F[1];
        });
      }
    }
    const I = Q(), T = Q(Number(e.rows)), _ = C(() => ["plain", "underlined"].includes(e.variant));
    We(() => {
      e.autoGrow || (T.value = Number(e.rows));
    });
    function p() {
      e.autoGrow && Ve(() => {
        if (!I.value || !m.value) return;
        const D = getComputedStyle(I.value), A = getComputedStyle(m.value.$el), B = parseFloat(D.getPropertyValue("--v-field-padding-top")) + parseFloat(D.getPropertyValue("--v-input-padding-top")) + parseFloat(D.getPropertyValue("--v-field-padding-bottom")), F = I.value.scrollHeight, $ = parseFloat(D.lineHeight), W = Math.max(parseFloat(e.rows) * $ + B, parseFloat(A.getPropertyValue("--v-input-control-height"))), J = parseFloat(e.maxRows) * $ + B || 1 / 0, z = Fe(F != null ? F : 0, W, J);
        T.value = Math.floor((z - B) / $), h.value = ce(z);
      });
    }
    gt(p), oe(i, p), oe(() => e.rows, p), oe(() => e.maxRows, p), oe(() => e.density, p), oe(T, (D) => {
      a("update:rows", D);
    });
    let L;
    return oe(I, (D) => {
      D ? (L = new ResizeObserver(p), L.observe(I.value)) : L == null || L.disconnect();
    }), dt(() => {
      L == null || L.disconnect();
    }), Z(() => {
      const D = !!(l.counter || e.counter || e.counterValue), A = !!(D || l.details), [B, F] = an(t), z = ct.filterProps(e), {
        modelValue: $
      } = z, W = Ge(z, [
        "modelValue"
      ]), J = le(v({}, nn.filterProps(e)), {
        "onClick:clear": V
      });
      return k(ct, G({
        ref: f,
        modelValue: i.value,
        "onUpdate:modelValue": (H) => i.value = H,
        class: ["v-textarea v-text-field", {
          "v-textarea--prefixed": e.prefix,
          "v-textarea--suffixed": e.suffix,
          "v-text-field--prefixed": e.prefix,
          "v-text-field--suffixed": e.suffix,
          "v-textarea--auto-grow": e.autoGrow,
          "v-textarea--no-resize": e.noResize || e.autoGrow,
          "v-input--plain-underlined": _.value
        }, e.class],
        style: e.style
      }, B, W, {
        centerAffix: T.value === 1 && !_.value,
        focused: o.value
      }), le(v({}, l), {
        default: (H) => {
          let {
            id: E,
            isDisabled: O,
            isDirty: R,
            isReadonly: q,
            isValid: ae,
            hasDetails: U
          } = H;
          return k(nn, G({
            ref: m,
            style: {
              "--v-textarea-control-height": h.value
            },
            onClick: y,
            onMousedown: P,
            "onClick:prependInner": e["onClick:prependInner"],
            "onClick:appendInner": e["onClick:appendInner"]
          }, J, {
            id: E.value,
            active: g.value || R.value,
            centerAffix: T.value === 1 && !_.value,
            dirty: R.value || e.dirty,
            disabled: O.value,
            focused: o.value,
            details: U.value,
            error: ae.value === !1
          }), le(v({}, l), {
            default: (ne) => {
              let {
                props: ge
              } = ne, ee = ge, {
                class: j
              } = ee, ue = Ge(ee, [
                "class"
              ]);
              return w(he, null, [e.prefix && w("span", {
                class: "v-text-field__prefix"
              }, [e.prefix]), Re(w("textarea", G({
                ref: b,
                class: j,
                value: i.value,
                onInput: x,
                autofocus: e.autofocus,
                readonly: q.value,
                disabled: O.value,
                placeholder: e.placeholder,
                rows: e.rows,
                name: e.name,
                onFocus: S,
                onBlur: u
              }, ue, F), null), [[Ht, {
                handler: c
              }, null, {
                once: !0
              }]]), e.autoGrow && Re(w("textarea", {
                class: X([j, "v-textarea__sizer"]),
                id: `${ue.id}-sizer`,
                "onUpdate:modelValue": (re) => i.value = re,
                ref: I,
                readonly: !0,
                "aria-hidden": "true"
              }, null), [[Gd, i.value]]), e.suffix && w("span", {
                class: "v-text-field__suffix"
              }, [e.suffix])]);
            }
          }));
        },
        details: A ? (H) => {
          var E;
          return w(he, null, [(E = l.details) == null ? void 0 : E.call(l, H), D && w(he, null, [w("span", null, null), k(Pl, {
            active: e.persistentCounter || o.value,
            value: s.value,
            max: d.value,
            disabled: e.disabled
          }, l.counter)])]);
        } : void 0
      }));
    }), it({}, f, m, b);
  }
}), S0 = N(v(v(v({
  withBackground: Boolean
}, de()), Ie()), ke()), "VThemeProvider"), k0 = Y()({
  name: "VThemeProvider",
  props: S0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e);
    return () => {
      var l;
      return e.withBackground ? k(e.tag, {
        class: X(["v-theme-provider", a.value, e.class]),
        style: ie(e.style)
      }, {
        default: () => {
          var i;
          return [(i = t.default) == null ? void 0 : i.call(t)];
        }
      }) : (l = t.default) == null ? void 0 : l.call(t);
    };
  }
}), w0 = N(v(v(v(v({
  dotColor: String,
  fillDot: Boolean,
  hideDot: Boolean,
  icon: me,
  iconColor: String,
  lineColor: String
}, de()), Ne()), Yt()), Je()), "VTimelineDivider"), C0 = Y()({
  name: "VTimelineDivider",
  props: w0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      sizeClasses: a,
      sizeStyles: l
    } = Qn(e, "v-timeline-divider__dot"), {
      backgroundColorStyles: i,
      backgroundColorClasses: o
    } = pe(() => e.dotColor), {
      roundedClasses: r
    } = Ye(e, "v-timeline-divider__dot"), {
      elevationClasses: u
    } = lt(e), {
      backgroundColorClasses: c,
      backgroundColorStyles: s
    } = pe(() => e.lineColor);
    return Z(() => w("div", {
      class: X(["v-timeline-divider", {
        "v-timeline-divider--fill-dot": e.fillDot
      }, e.class]),
      style: ie(e.style)
    }, [w("div", {
      class: X(["v-timeline-divider__before", c.value]),
      style: ie(s.value)
    }, null), !e.hideDot && w("div", {
      key: "dot",
      class: X(["v-timeline-divider__dot", u.value, r.value, a.value]),
      style: ie(l.value)
    }, [w("div", {
      class: X(["v-timeline-divider__inner-dot", o.value, r.value]),
      style: ie(i.value)
    }, [t.default ? k(Ce, {
      key: "icon-defaults",
      disabled: !e.icon,
      defaults: {
        VIcon: {
          color: e.iconColor,
          icon: e.icon,
          size: e.size
        }
      }
    }, t.default) : k(Be, {
      key: "icon",
      color: e.iconColor,
      icon: e.icon,
      size: e.size
    }, null)])]), w("div", {
      class: X(["v-timeline-divider__after", c.value]),
      style: ie(s.value)
    }, null)])), {};
  }
}), kd = N(v(v(v(v(v(v({
  density: String,
  dotColor: String,
  fillDot: Boolean,
  hideDot: Boolean,
  hideOpposite: {
    type: Boolean,
    default: void 0
  },
  icon: me,
  iconColor: String,
  lineInset: [Number, String],
  side: {
    type: String,
    validator: (e) => e == null || ["start", "end"].includes(e)
  }
}, de()), Ze()), Je()), Ne()), Yt()), ke()), "VTimelineItem"), x0 = Y()({
  name: "VTimelineItem",
  props: kd(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      dimensionStyles: a
    } = Qe(e), l = te(0), i = Q();
    return oe(i, (o) => {
      var r, u;
      o && (l.value = (u = (r = o.$el.querySelector(".v-timeline-divider__dot")) == null ? void 0 : r.getBoundingClientRect().width) != null ? u : 0);
    }, {
      flush: "post"
    }), Z(() => {
      var o, r;
      return w("div", {
        class: X(["v-timeline-item", {
          "v-timeline-item--fill-dot": e.fillDot,
          "v-timeline-item--side-start": e.side === "start",
          "v-timeline-item--side-end": e.side === "end"
        }, e.class]),
        style: ie([{
          "--v-timeline-dot-size": ce(l.value),
          "--v-timeline-line-inset": e.lineInset ? `calc(var(--v-timeline-dot-size) / 2 + ${ce(e.lineInset)})` : ce(0)
        }, e.style])
      }, [w("div", {
        class: "v-timeline-item__body",
        style: ie(a.value)
      }, [(o = t.default) == null ? void 0 : o.call(t)]), k(C0, {
        ref: i,
        hideDot: e.hideDot,
        icon: e.icon,
        iconColor: e.iconColor,
        size: e.size,
        elevation: e.elevation,
        dotColor: e.dotColor,
        fillDot: e.fillDot,
        rounded: e.rounded
      }, {
        default: t.icon
      }), e.density !== "compact" && w("div", {
        class: "v-timeline-item__opposite"
      }, [!e.hideOpposite && ((r = t.opposite) == null ? void 0 : r.call(t))])]);
    }), {};
  }
}), V0 = N(v(v(v(v(v({
  align: {
    type: String,
    default: "center",
    validator: (e) => ["center", "start"].includes(e)
  },
  direction: {
    type: String,
    default: "vertical",
    validator: (e) => ["vertical", "horizontal"].includes(e)
  },
  justify: {
    type: String,
    default: "auto",
    validator: (e) => ["auto", "center"].includes(e)
  },
  side: {
    type: String,
    validator: (e) => e == null || ["start", "end"].includes(e)
  },
  lineThickness: {
    type: [String, Number],
    default: 2
  },
  lineColor: String,
  truncateLine: {
    type: String,
    validator: (e) => ["start", "end", "both"].includes(e)
  }
}, qt(kd({
  lineInset: 0
}), ["dotColor", "fillDot", "hideOpposite", "iconColor", "lineInset", "size"])), de()), nt()), ke()), Ie()), "VTimeline"), P0 = Y()({
  name: "VTimeline",
  props: V0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const {
      themeClasses: a
    } = De(e), {
      densityClasses: l
    } = ht(e), {
      rtlClasses: i
    } = Xe();
    je({
      VTimelineDivider: {
        lineColor: M(() => e.lineColor)
      },
      VTimelineItem: {
        density: M(() => e.density),
        dotColor: M(() => e.dotColor),
        fillDot: M(() => e.fillDot),
        hideOpposite: M(() => e.hideOpposite),
        iconColor: M(() => e.iconColor),
        lineColor: M(() => e.lineColor),
        lineInset: M(() => e.lineInset),
        size: M(() => e.size)
      }
    });
    const o = C(() => {
      const u = e.side ? e.side : e.density !== "default" ? "end" : null;
      return u && `v-timeline--side-${u}`;
    }), r = C(() => {
      const u = ["v-timeline--truncate-line-start", "v-timeline--truncate-line-end"];
      switch (e.truncateLine) {
        case "both":
          return u;
        case "start":
          return u[0];
        case "end":
          return u[1];
        default:
          return null;
      }
    });
    return Z(() => k(e.tag, {
      class: X(["v-timeline", `v-timeline--${e.direction}`, `v-timeline--align-${e.align}`, `v-timeline--justify-${e.justify}`, r.value, {
        "v-timeline--inset-line": !!e.lineInset
      }, a.value, l.value, o.value, i.value, e.class]),
      style: ie([{
        "--v-timeline-line-thickness": ce(e.lineThickness)
      }, e.style])
    }, t)), {};
  }
});
function vn(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 2;
  return String(e).padStart(n, "0");
}
const I0 = N({
  allowedValues: Function,
  ampm: Boolean,
  color: String,
  disabled: Boolean,
  displayedValue: null,
  double: Boolean,
  format: {
    type: Function,
    default: (e) => e
  },
  max: {
    type: Number,
    required: !0
  },
  min: {
    type: Number,
    required: !0
  },
  scrollable: Boolean,
  readonly: Boolean,
  rotate: {
    type: Number,
    default: 0
  },
  step: {
    type: Number,
    default: 1
  },
  modelValue: {
    type: Number
  }
}, "VTimePickerClock"), Ri = Y()({
  name: "VTimePickerClock",
  props: I0(),
  emits: {
    change: (e) => !0,
    input: (e) => !0
  },
  setup(e, n) {
    let {
      emit: t
    } = n;
    const a = Q(null), l = Q(null), i = Q(void 0), o = Q(!1), r = Q(null), u = Q(null), c = ru((H) => t("change", H), 750), {
      textColorClasses: s,
      textColorStyles: d
    } = rt(() => e.color), {
      backgroundColorClasses: f,
      backgroundColorStyles: m
    } = pe(() => e.color), h = C(() => e.max - e.min + 1), b = C(() => e.double ? h.value / 2 : h.value), g = C(() => 360 / b.value), S = C(() => g.value * Math.PI / 180), y = C(() => e.modelValue == null ? e.min : e.modelValue), P = C(() => 0.62), V = C(() => {
      const H = [];
      for (let E = e.min; E <= e.max; E = E + e.step)
        H.push(E);
      return H;
    });
    oe(() => e.modelValue, (H) => {
      i.value = H;
    });
    function x(H) {
      i.value !== H && (i.value = H), t("input", H);
    }
    function I(H) {
      return !e.allowedValues || e.allowedValues(H);
    }
    function T(H) {
      if (!e.scrollable || e.disabled) return;
      H.preventDefault();
      const E = Math.sign(-H.deltaY || 1);
      let O = y.value;
      do
        O = O + E, O = (O - e.min + h.value) % h.value + e.min;
      while (!I(O) && O !== y.value);
      O !== e.displayedValue && x(O), c(O);
    }
    function _(H) {
      return e.double && H - e.min >= b.value;
    }
    function p(H) {
      return _(H) ? P.value : 1;
    }
    function L(H) {
      const E = e.rotate * Math.PI / 180;
      return {
        x: Math.sin((H - e.min) * S.value + E) * p(H),
        y: -Math.cos((H - e.min) * S.value + E) * p(H)
      };
    }
    function D(H, E) {
      const O = (Math.round(H / g.value) + (E ? b.value : 0)) % h.value + e.min;
      return H < 360 - g.value / 2 ? O : E ? e.max - b.value + 1 : e.min;
    }
    function A(H) {
      const {
        x: E,
        y: O
      } = L(H);
      return {
        left: `${Math.round(50 + E * 50)}%`,
        top: `${Math.round(50 + O * 50)}%`
      };
    }
    function B(H, E) {
      const O = E.x - H.x, R = E.y - H.y;
      return Math.sqrt(O * O + R * R);
    }
    function F(H, E) {
      const O = 2 * Math.atan2(E.y - H.y - B(H, E), E.x - H.x);
      return Math.abs(O * 180 / Math.PI);
    }
    function $(H) {
      r.value === null && (r.value = H), u.value = H, x(H);
    }
    function W(H) {
      var fe, K, se;
      if (H.preventDefault(), !o.value && H.type !== "click" || !a.value) return;
      const {
        width: E,
        top: O,
        left: R
      } = (fe = a.value) == null ? void 0 : fe.getBoundingClientRect(), {
        width: q
      } = (se = (K = l.value) == null ? void 0 : K.getBoundingClientRect()) != null ? se : {
        width: 0
      }, {
        clientX: ae,
        clientY: U
      } = "touches" in H ? H.touches[0] : H, ne = {
        x: E / 2,
        y: -E / 2
      }, j = {
        x: ae - R,
        y: O - U
      }, ue = Math.round(F(ne, j) - e.rotate + 360) % 360, ge = e.double && B(ne, j) < (q + q * P.value) / 4, ee = Math.ceil(15 / g.value);
      let re;
      for (let ye = 0; ye < ee; ye++)
        if (re = D(ue + ye * g.value, ge), I(re) || (re = D(ue - ye * g.value, ge), I(re))) return $(re);
    }
    function J(H) {
      e.disabled || (H.preventDefault(), window.addEventListener("mousemove", W), window.addEventListener("touchmove", W), window.addEventListener("mouseup", z), window.addEventListener("touchend", z), r.value = null, u.value = null, o.value = !0, W(H));
    }
    function z(H) {
      H.stopPropagation(), window.removeEventListener("mousemove", W), window.removeEventListener("touchmove", W), window.removeEventListener("mouseup", z), window.removeEventListener("touchend", z), o.value = !1, u.value !== null && I(u.value) && t("change", u.value);
    }
    Z(() => w("div", {
      class: X([{
        "v-time-picker-clock": !0,
        "v-time-picker-clock--indeterminate": e.modelValue == null,
        "v-time-picker-clock--readonly": e.readonly
      }]),
      onMousedown: J,
      onTouchstart: J,
      onWheel: T,
      ref: a
    }, [w("div", {
      class: "v-time-picker-clock__inner",
      ref: l
    }, [w("div", {
      class: X([{
        "v-time-picker-clock__hand": !0,
        "v-time-picker-clock__hand--inner": _(e.modelValue)
      }, s.value]),
      style: ie([{
        transform: `rotate(${e.rotate + g.value * (y.value - e.min)}deg) scaleY(${p(y.value)})`
      }, d.value])
    }, null), V.value.map((H) => {
      const E = H === y.value;
      return w("div", {
        class: X([{
          "v-time-picker-clock__item": !0,
          "v-time-picker-clock__item--active": E,
          "v-time-picker-clock__item--disabled": e.disabled || !I(H)
        }, E && f.value]),
        style: ie([A(H), E && m.value])
      }, [w("span", null, [e.format(H)])]);
    })])]));
  }
}), _0 = N({
  ampm: Boolean,
  color: String,
  disabled: Boolean,
  hour: Number,
  minute: Number,
  second: Number,
  period: String,
  readonly: Boolean,
  useSeconds: Boolean,
  value: Number,
  viewMode: String
}, "VTimePickerControls"), Hi = Y()({
  name: "VTimePickerControls",
  props: _0(),
  emits: {
    "update:period": (e) => !0,
    "update:viewMode": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      t: l
    } = Ee();
    return Z(() => {
      let i = e.hour;
      return e.ampm && (i = i ? (i - 1) % 12 + 1 : 12), w("div", {
        class: "v-time-picker-controls"
      }, [w("div", {
        class: X({
          "v-time-picker-controls__time": !0,
          "v-time-picker-controls__time--with-seconds": e.useSeconds
        })
      }, [k(xe, {
        active: e.viewMode === "hour",
        color: e.viewMode === "hour" ? e.color : void 0,
        disabled: e.disabled,
        variant: "tonal",
        class: X({
          "v-time-picker-controls__time__btn": !0,
          "v-time-picker-controls__time--with-ampm__btn": e.ampm,
          "v-time-picker-controls__time--with-seconds__btn": e.useSeconds
        }),
        text: e.hour == null ? "--" : vn(`${i}`),
        onClick: () => t("update:viewMode", "hour")
      }, null), w("span", {
        class: X(["v-time-picker-controls__time__separator", {
          "v-time-picker-controls--with-seconds__time__separator": e.useSeconds
        }])
      }, [Nt(":")]), k(xe, {
        active: e.viewMode === "minute",
        color: e.viewMode === "minute" ? e.color : void 0,
        class: X({
          "v-time-picker-controls__time__btn": !0,
          "v-time-picker-controls__time__btn__active": e.viewMode === "minute",
          "v-time-picker-controls__time--with-ampm__btn": e.ampm,
          "v-time-picker-controls__time--with-seconds__btn": e.useSeconds
        }),
        disabled: e.disabled,
        variant: "tonal",
        text: e.minute == null ? "--" : vn(e.minute),
        onClick: () => t("update:viewMode", "minute")
      }, null), e.useSeconds && w("span", {
        class: X(["v-time-picker-controls__time__separator", {
          "v-time-picker-controls--with-seconds__time__separator": e.useSeconds
        }]),
        key: "secondsDivider"
      }, [Nt(":")]), e.useSeconds && k(xe, {
        key: "secondsVal",
        active: e.viewMode === "second",
        color: e.viewMode === "second" ? e.color : void 0,
        variant: "tonal",
        onClick: () => t("update:viewMode", "second"),
        class: X({
          "v-time-picker-controls__time__btn": !0,
          "v-time-picker-controls__time__btn__active": e.viewMode === "second",
          "v-time-picker-controls__time--with-seconds__btn": e.useSeconds
        }),
        disabled: e.disabled,
        text: e.second == null ? "--" : vn(e.second)
      }, null), e.ampm && w("div", {
        class: "v-time-picker-controls__ampm"
      }, [k(xe, {
        active: e.period === "am",
        color: e.period === "am" ? e.color : void 0,
        class: X({
          "v-time-picker-controls__ampm__am": !0,
          "v-time-picker-controls__ampm__btn": !0,
          "v-time-picker-controls__ampm__btn__active": e.period === "am"
        }),
        disabled: e.disabled,
        text: l("$vuetify.timePicker.am"),
        variant: e.disabled && e.period === "am" ? "elevated" : "tonal",
        onClick: () => e.period !== "am" ? t("update:period", "am") : null
      }, null), k(xe, {
        active: e.period === "pm",
        color: e.period === "pm" ? e.color : void 0,
        class: X({
          "v-time-picker-controls__ampm__pm": !0,
          "v-time-picker-controls__ampm__btn": !0,
          "v-time-picker-controls__ampm__btn__active": e.period === "pm"
        }),
        disabled: e.disabled,
        text: l("$vuetify.timePicker.pm"),
        variant: e.disabled && e.period === "pm" ? "elevated" : "tonal",
        onClick: () => e.period !== "pm" ? t("update:period", "pm") : null
      }, null)])])]);
    }), {};
  }
}), A0 = Vt(24), wd = Vt(12), L0 = wd.map((e) => e + 12);
Vt(60);
const T0 = N(v({
  allowedHours: [Function, Array],
  allowedMinutes: [Function, Array],
  allowedSeconds: [Function, Array],
  disabled: Boolean,
  format: {
    type: String,
    default: "ampm"
  },
  max: String,
  min: String,
  viewMode: {
    type: String,
    default: "hour"
  },
  modelValue: null,
  readonly: Boolean,
  scrollable: Boolean,
  useSeconds: Boolean
}, $e(Ll({
  title: "$vuetify.timePicker.title"
}), ["landscape"])), "VTimePicker"), B0 = Y()({
  name: "VTimePicker",
  props: T0(),
  emits: {
    "update:hour": (e) => !0,
    "update:minute": (e) => !0,
    "update:period": (e) => !0,
    "update:second": (e) => !0,
    "update:modelValue": (e) => !0,
    "update:viewMode": (e) => !0
  },
  setup(e, n) {
    let {
      emit: t,
      slots: a
    } = n;
    const {
      t: l
    } = Ee(), i = Q(null), o = Q(null), r = Q(null), u = Q(null), c = Q(null), s = Q(null), d = Q("am"), f = ve(e, "viewMode", "hour"), m = Q(null), h = Q(null), b = C(() => {
      let A;
      if (e.allowedHours instanceof Array ? A = ($) => e.allowedHours.includes($) : A = e.allowedHours, !e.min && !e.max) return A;
      const B = e.min ? Number(e.min.split(":")[0]) : 0, F = e.max ? Number(e.max.split(":")[0]) : 23;
      return ($) => $ >= Number(B) && $ <= Number(F) && (!A || A($));
    }), g = C(() => {
      let A;
      const B = !b.value || i.value === null || b.value(i.value);
      if (e.allowedMinutes instanceof Array ? A = (E) => e.allowedMinutes.includes(E) : A = e.allowedMinutes, !e.min && !e.max)
        return B ? A : () => !1;
      const [F, $] = e.min ? e.min.split(":").map(Number) : [0, 0], [W, J] = e.max ? e.max.split(":").map(Number) : [23, 59], z = F * 60 + Number($), H = W * 60 + Number(J);
      return (E) => {
        const O = 60 * i.value + E;
        return O >= z && O <= H && B && (!A || A(E));
      };
    }), S = C(() => {
      let A;
      const F = (!b.value || i.value === null || b.value(i.value)) && (!g.value || o.value === null || g.value(o.value));
      if (e.allowedSeconds instanceof Array ? A = (q) => e.allowedSeconds.includes(q) : A = e.allowedSeconds, !e.min && !e.max)
        return F ? A : () => !1;
      const [$, W, J] = e.min ? e.min.split(":").map(Number) : [0, 0, 0], [z, H, E] = e.max ? e.max.split(":").map(Number) : [23, 59, 59], O = $ * 3600 + W * 60 + Number(J || 0), R = z * 3600 + H * 60 + Number(E || 0);
      return (q) => {
        const ae = 3600 * i.value + 60 * o.value + q;
        return ae >= O && ae <= R && F && (!A || A(q));
      };
    }), y = C(() => e.format === "ampm");
    oe(() => e.modelValue, (A) => T(A)), gt(() => {
      T(e.modelValue);
    });
    function P() {
      return i.value != null && o.value != null && (!e.useSeconds || r.value != null) ? `${vn(i.value)}:${vn(o.value)}` + (e.useSeconds ? `:${vn(r.value)}` : "") : null;
    }
    function V() {
      const A = P();
      A !== null && t("update:modelValue", A);
    }
    function x(A) {
      return A ? (A - 1) % 12 + 1 : 12;
    }
    function I(A, B) {
      return A % 12 + (B === "pm" ? 12 : 0);
    }
    function T(A) {
      if (A == null || A === "")
        i.value = null, o.value = null, r.value = null;
      else if (A instanceof Date)
        i.value = A.getHours(), o.value = A.getMinutes(), r.value = A.getSeconds();
      else {
        const [B, , F, , $, W] = A.trim().toLowerCase().match(/^(\d+):(\d+)(:(\d+))?([ap]m)?$/) || new Array(6);
        i.value = W ? I(parseInt(B, 10), W) : parseInt(B, 10), o.value = parseInt(F, 10), r.value = parseInt($ || 0, 10);
      }
      d.value = i.value == null || i.value < 12 ? "am" : "pm";
    }
    function _(A, B) {
      const F = b.value;
      if (!F) return B;
      const $ = y.value ? B < 12 ? wd : L0 : A0;
      return (($.find((J) => F((J + B) % $.length + $[0])) || 0) + B) % $.length + $[0];
    }
    function p(A) {
      if (d.value = A, i.value != null) {
        const B = i.value + (d.value === "am" ? -12 : 12);
        i.value = _("hour", B);
      }
      return t("update:period", A), V(), !0;
    }
    function L(A) {
      f.value === "hour" ? i.value = y.value ? I(A, d.value) : A : f.value === "minute" ? o.value = A : r.value = A;
    }
    function D(A) {
      switch (f.value || "hour") {
        case "hour":
          t("update:hour", A);
          break;
        case "minute":
          t("update:minute", A);
          break;
        case "second":
          t("update:second", A);
          break;
      }
      const B = i.value !== null && o.value !== null && (e.useSeconds ? r.value !== null : !0);
      f.value === "hour" ? f.value = "minute" : e.useSeconds && f.value === "minute" && (f.value = "second"), !(i.value === u.value && o.value === c.value && (!e.useSeconds || r.value === s.value) || P() === null) && (u.value = i.value, c.value = o.value, e.useSeconds && (s.value = r.value), B && V());
    }
    Z(() => {
      const A = Kn.filterProps(e), B = Hi.filterProps(e), F = Ri.filterProps($e(e, ["format", "modelValue", "min", "max"]));
      return k(Kn, G(A, {
        color: void 0,
        class: ["v-time-picker", e.class],
        style: e.style
      }), {
        title: () => {
          var $, W;
          return (W = ($ = a.title) == null ? void 0 : $.call(a)) != null ? W : w("div", {
            class: "v-time-picker__title"
          }, [l(e.title)]);
        },
        header: () => k(Hi, G(B, {
          ampm: y.value,
          hour: i.value,
          minute: o.value,
          period: d.value,
          second: r.value,
          viewMode: f.value,
          "onUpdate:period": ($) => p($),
          "onUpdate:viewMode": ($) => f.value = $,
          ref: m
        }), null),
        default: () => k(Ri, G(F, {
          allowedValues: f.value === "hour" ? b.value : f.value === "minute" ? g.value : S.value,
          double: f.value === "hour" && !y.value,
          format: f.value === "hour" ? y.value ? x : ($) => $ : ($) => vn($, 2),
          max: f.value === "hour" ? y.value && d.value === "am" ? 11 : 23 : 59,
          min: f.value === "hour" && y.value && d.value === "pm" ? 12 : 0,
          size: 20,
          step: f.value === "hour" ? 1 : 5,
          modelValue: f.value === "hour" ? i.value : f.value === "minute" ? o.value : r.value,
          onChange: D,
          onInput: L,
          ref: h
        }), null),
        actions: a.actions
      });
    });
  }
}), D0 = N(v(v({}, de()), Dt({
  variant: "text"
})), "VToolbarItems"), M0 = Y()({
  name: "VToolbarItems",
  props: D0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    return je({
      VBtn: {
        color: M(() => e.color),
        height: "inherit",
        variant: M(() => e.variant)
      }
    }), Z(() => {
      var a;
      return w("div", {
        class: X(["v-toolbar-items", e.class]),
        style: ie(e.style)
      }, [(a = t.default) == null ? void 0 : a.call(t)]);
    }), {};
  }
}), p0 = N(v({
  id: String,
  interactive: Boolean,
  text: String
}, $e(Fa({
  closeOnBack: !1,
  location: "end",
  locationStrategy: "connected",
  eager: !0,
  minWidth: 0,
  offset: 10,
  openOnClick: !1,
  openOnHover: !0,
  origin: "auto",
  scrim: !1,
  scrollStrategy: "reposition",
  transition: null
}), ["absolute", "persistent"])), "VTooltip"), E0 = Y()({
  name: "VTooltip",
  props: p0(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = ve(e, "modelValue"), {
      scopeId: l
    } = pn(), i = St(), o = M(() => e.id || `v-tooltip-${i}`), r = Q(), u = C(() => e.location.split(" ").length > 1 ? e.location : e.location + " center"), c = C(() => e.origin === "auto" || e.origin === "overlap" || e.origin.split(" ").length > 1 || e.location.split(" ").length > 1 ? e.origin : e.origin + " center"), s = M(() => e.transition != null ? e.transition : a.value ? "scale-transition" : "fade-transition"), d = C(() => G({
      "aria-describedby": o.value
    }, e.activatorProps));
    return Z(() => {
      const f = Wt.filterProps(e);
      return k(Wt, G({
        ref: r,
        class: ["v-tooltip", {
          "v-tooltip--interactive": e.interactive
        }, e.class],
        style: e.style,
        id: o.value
      }, f, {
        modelValue: a.value,
        "onUpdate:modelValue": (m) => a.value = m,
        transition: s.value,
        absolute: !0,
        location: u.value,
        origin: c.value,
        persistent: !0,
        role: "tooltip",
        activatorProps: d.value,
        _disableGlobalStack: !0
      }, l), {
        activator: t.activator,
        default: function() {
          var g, S;
          for (var m = arguments.length, h = new Array(m), b = 0; b < m; b++)
            h[b] = arguments[b];
          return (S = (g = t.default) == null ? void 0 : g.call(t, ...h)) != null ? S : e.text;
        }
      });
    }), it({}, r);
  }
}), $0 = N(v({}, $e(Ls({
  collapseIcon: "$treeviewCollapse",
  expandIcon: "$treeviewExpand"
}), ["subgroup"])), "VTreeviewGroup"), zi = Y()({
  name: "VTreeviewGroup",
  props: $0(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = Q(), l = C(() => {
      var o;
      return (o = a.value) != null && o.isOpen ? e.collapseIcon : e.expandIcon;
    }), i = C(() => ({
      VTreeviewItem: {
        prependIcon: void 0,
        appendIcon: void 0,
        toggleIcon: l.value
      }
    }));
    return Z(() => {
      const o = xa.filterProps(e);
      return k(xa, G(o, {
        ref: a,
        class: ["v-treeview-group", e.class],
        subgroup: !0
      }), le(v({}, t), {
        activator: t.activator ? (r) => w(he, null, [k(Ce, {
          defaults: i.value
        }, {
          default: () => {
            var u;
            return [(u = t.activator) == null ? void 0 : u.call(t, r)];
          }
        })]) : void 0
      }));
    }), {};
  }
}), Cd = Symbol.for("vuetify:v-treeview"), xd = N(v({
  loading: Boolean,
  hideActions: Boolean,
  indentLines: Array,
  toggleIcon: me
}, Ds({
  slim: !0
})), "VTreeviewItem"), Wi = Y()({
  name: "VTreeviewItem",
  props: xd(),
  emits: {
    toggleExpand: (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const l = Pe(Cd, {
      visibleIds: Q()
    }).visibleIds, i = Q(), o = C(() => {
      var f, m;
      return ((f = i.value) == null ? void 0 : f.root.activatable.value) && ((m = i.value) == null ? void 0 : m.isGroupActivator);
    }), r = C(() => {
      var f, m;
      return ((f = i.value) == null ? void 0 : f.link.isClickable.value) || e.value != null && !!((m = i.value) != null && m.list);
    }), u = C(() => !e.disabled && e.link !== !1 && (e.link || r.value || o.value)), c = C(() => {
      var f;
      return l.value && !l.value.has(Ue((f = i.value) == null ? void 0 : f.id));
    });
    function s(f) {
      var m, h;
      u.value && o.value && ((h = i.value) == null || h.activate(!((m = i.value) != null && m.isActivated), f));
    }
    function d(f) {
      f.preventDefault(), f.stopPropagation(), a("toggleExpand", f);
    }
    return Z(() => {
      var h;
      const f = Et.filterProps(e), m = t.prepend || e.toggleIcon || e.indentLines;
      return k(Et, G({
        ref: i
      }, f, {
        active: ((h = i.value) == null ? void 0 : h.isActivated) || void 0,
        class: ["v-treeview-item", {
          "v-treeview-item--activatable-group-activator": o.value,
          "v-treeview-item--filtered": c.value
        }, e.class],
        ripple: !1,
        onClick: s
      }), le(v({}, t), {
        prepend: m ? (b) => {
          var g;
          return w(he, null, [e.indentLines && e.indentLines.length > 0 ? w("div", {
            key: "indent-lines",
            class: "v-treeview-indent-lines",
            style: {
              "--v-indent-parts": e.indentLines.length
            }
          }, [e.indentLines.map((S) => w("div", {
            class: X(`v-treeview-indent-line v-treeview-indent-line--${S}`)
          }, null))]) : "", !e.hideActions && k(Ns, {
            start: !0
          }, {
            default: () => [e.toggleIcon ? k(xe, {
              density: "compact",
              icon: e.toggleIcon,
              loading: e.loading,
              variant: "text",
              onClick: d
            }, {
              loader: () => k(bn, {
                indeterminate: "disable-shrink",
                size: "20",
                width: "2"
              }, null)
            }) : w("div", {
              class: "v-treeview-item__level"
            }, null)]
          }), (g = t.prepend) == null ? void 0 : g.call(t, b)]);
        } : void 0
      }));
    }), it({}, i);
  }
}), Vd = N(v(v({
  fluid: Boolean,
  disabled: Boolean,
  loadChildren: Function,
  loadingIcon: {
    type: String,
    default: "$loading"
  },
  items: Array,
  openOnClick: {
    type: Boolean,
    default: void 0
  },
  indeterminateIcon: {
    type: me,
    default: "$checkboxIndeterminate"
  },
  falseIcon: me,
  trueIcon: me,
  returnObject: Boolean,
  activatable: Boolean,
  selectable: Boolean,
  selectedColor: String,
  selectStrategy: [String, Function, Object],
  index: Number,
  isLastGroup: Boolean,
  separateRoots: Boolean,
  parentIndentLines: Array,
  indentLinesVariant: String,
  path: {
    type: Array,
    default: () => []
  }
}, qt(xd(), ["hideActions"])), nt()), "VTreeviewChildren"), cl = Y()({
  name: "VTreeviewChildren",
  props: Vd(),
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = yt(/* @__PURE__ */ new Set()), l = Q([]), i = C(() => !e.disabled && (e.openOnClick != null ? e.openOnClick : e.selectable && !e.activatable));
    function o(u) {
      return He(this, null, function* () {
        var c, s;
        try {
          if (!((c = e.items) != null && c.length) || !e.loadChildren) return;
          ((s = u == null ? void 0 : u.children) == null ? void 0 : s.length) === 0 && (a.add(u.value), yield e.loadChildren(u.raw));
        } finally {
          a.delete(u.value);
        }
      });
    }
    function r(u, c) {
      e.selectable && u(c);
    }
    return () => {
      var u, c, s;
      return (s = (u = t.default) == null ? void 0 : u.call(t)) != null ? s : (c = e.items) == null ? void 0 : c.map((d, f, m) => {
        var p, L, D;
        const {
          children: h,
          props: b
        } = d, g = a.has(d.value), S = !!((p = m.at(f + 1)) != null && p.children), y = (D = (L = e.path) == null ? void 0 : L.length) != null ? D : 0, P = m.length - 1 === f, V = {
          index: f,
          depth: y,
          isFirst: f === 0,
          isLast: P,
          path: [...e.path, f],
          hideAction: e.hideActions
        }, x = Nv({
          depth: y,
          isLast: P,
          isLastGroup: e.isLastGroup,
          leafLinks: !e.hideActions && !e.fluid,
          separateRoots: e.separateRoots,
          parentIndentLines: e.parentIndentLines,
          variant: e.indentLinesVariant
        }), I = {
          prepend: (A) => {
            var B;
            return w(he, null, [e.selectable && (!h || h && !["leaf", "single-leaf"].includes(e.selectStrategy)) && w("div", null, [k(zt, {
              key: d.value,
              modelValue: A.isSelected,
              disabled: e.disabled,
              loading: g,
              color: e.selectedColor,
              density: e.density,
              indeterminate: A.isIndeterminate,
              indeterminateIcon: e.indeterminateIcon,
              falseIcon: e.falseIcon,
              trueIcon: e.trueIcon,
              "onUpdate:modelValue": (F) => r(A.select, F),
              onClick: (F) => F.stopPropagation(),
              onKeydown: (F) => {
                ["Enter", "Space"].includes(F.key) && (F.stopPropagation(), r(A.select, A.isSelected));
              }
            }, null)]), (B = t.prepend) == null ? void 0 : B.call(t, le(v(v({}, A), V), {
              item: d.raw,
              internalItem: d
            }))]);
          },
          append: t.append ? (A) => {
            var B;
            return (B = t.append) == null ? void 0 : B.call(t, le(v(v({}, A), V), {
              item: d.raw,
              internalItem: d
            }));
          } : void 0,
          title: t.title ? (A) => {
            var B;
            return (B = t.title) == null ? void 0 : B.call(t, le(v({}, A), {
              item: d.raw,
              internalItem: d
            }));
          } : void 0,
          subtitle: t.subtitle ? (A) => {
            var B;
            return (B = t.subtitle) == null ? void 0 : B.call(t, le(v({}, A), {
              item: d.raw,
              internalItem: d
            }));
          } : void 0
        }, T = zi.filterProps(b), _ = cl.filterProps(v(v({}, e), V));
        return h ? k(zi, G(T, {
          value: e.returnObject ? d.raw : T == null ? void 0 : T.value,
          rawId: T == null ? void 0 : T.value
        }), {
          activator: (A) => {
            let {
              props: B
            } = A;
            const F = le(v(v({}, b), B), {
              value: b == null ? void 0 : b.value,
              onToggleExpand: [() => o(d), B.onClick],
              onClick: i.value ? [() => o(d), B.onClick] : () => {
                var $, W;
                return r(($ = l.value[f]) == null ? void 0 : $.select, !((W = l.value[f]) != null && W.isSelected));
              }
            });
            return k(Wi, G({
              ref: ($) => l.value[f] = $
            }, F, {
              hideActions: e.hideActions,
              indentLines: x.node,
              value: e.returnObject ? d.raw : b.value,
              loading: g
            }), I);
          },
          default: () => k(cl, G(_, {
            items: h,
            indentLinesVariant: e.indentLinesVariant,
            parentIndentLines: x.children,
            isLastGroup: S,
            returnObject: e.returnObject
          }), t)
        }) : Rl(t.item, {
          props: b,
          item: d.raw,
          internalItem: d
        }, () => d.type === "divider" ? Rl(t.divider, {
          props: d.raw
        }, () => k(It, d.props, null)) : d.type === "subheader" ? Rl(t.subheader, {
          props: d.raw
        }, () => k(aa, d.props, null)) : k(Wi, G(b, {
          hideActions: e.hideActions,
          indentLines: x.leaf,
          value: e.returnObject ? Ue(d.raw) : b.value
        }), I));
      });
    };
  }
});
function Pd(e) {
  let n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
  for (const t of e)
    n.push(t), t.children && Pd(t.children, n);
  return n;
}
const F0 = N(le(v(v(v({
  openAll: Boolean,
  indentLines: [Boolean, String],
  search: String
}, la({
  filterKeys: ["title"]
})), $e(Vd(), ["index", "path", "indentLinesVariant", "parentIndentLines", "isLastGroup"])), $e(Os({
  collapseIcon: "$treeviewCollapse",
  expandIcon: "$treeviewExpand",
  slim: !0
}), ["nav", "openStrategy"])), {
  modelValue: Array
}), "VTreeview"), O0 = Y()({
  name: "VTreeview",
  props: F0(),
  emits: {
    "update:opened": (e) => !0,
    "update:activated": (e) => !0,
    "update:selected": (e) => !0,
    "update:modelValue": (e) => !0,
    "click:open": (e) => !0,
    "click:select": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t,
      emit: a
    } = n;
    const {
      items: l
    } = Fs(e), i = M(() => e.activeColor), o = M(() => e.baseColor), r = M(() => e.color), u = ve(e, "activated"), c = ve(e, "selected"), s = C({
      get: () => {
        var P;
        return (P = e.modelValue) != null ? P : c.value;
      },
      set(P) {
        c.value = P, a("update:modelValue", P);
      }
    }), d = Q(), f = C(() => e.openAll ? y(l.value) : e.opened), m = C(() => Pd(l.value)), h = M(() => e.search), {
      filteredItems: b
    } = ia(e, m, h), g = C(() => {
      var V;
      if (!h.value) return null;
      const P = (V = d.value) == null ? void 0 : V.getPath;
      return P ? new Set(b.value.flatMap((x) => {
        const I = e.returnObject ? x.raw : x.props.value;
        return [...P(I), ...S(I)].map(Ue);
      })) : null;
    });
    function S(P) {
      var I, T, _, p;
      const V = [], x = ((T = (I = d.value) == null ? void 0 : I.children.get(P)) != null ? T : []).slice();
      for (; x.length; ) {
        const L = x.shift();
        L && (V.push(L), x.push(...((p = (_ = d.value) == null ? void 0 : _.children.get(L)) != null ? p : []).slice()));
      }
      return V;
    }
    function y(P) {
      let V = [];
      for (const x of P)
        x.children && (V.push(e.returnObject ? Ue(x.raw) : x.value), x.children && (V = V.concat(y(x.children))));
      return V;
    }
    return Oe(Cd, {
      visibleIds: g
    }), je({
      VTreeviewGroup: {
        activeColor: i,
        baseColor: o,
        color: r,
        collapseIcon: M(() => e.collapseIcon),
        expandIcon: M(() => e.expandIcon)
      },
      VTreeviewItem: {
        activeClass: M(() => e.activeClass),
        activeColor: i,
        baseColor: o,
        color: r,
        density: M(() => e.density),
        disabled: M(() => e.disabled),
        lines: M(() => e.lines),
        variant: M(() => e.variant)
      }
    }), Z(() => {
      const P = Gn.filterProps(e), V = cl.filterProps(e), x = typeof e.indentLines == "boolean" ? "default" : e.indentLines;
      return k(Gn, G({
        ref: d
      }, P, {
        class: ["v-treeview", {
          "v-treeview--fluid": e.fluid
        }, e.class],
        openStrategy: "multiple",
        style: e.style,
        opened: f.value,
        activated: u.value,
        "onUpdate:activated": (I) => u.value = I,
        selected: s.value,
        "onUpdate:selected": (I) => s.value = I
      }), {
        default: () => [k(cl, G(V, {
          density: e.density,
          returnObject: e.returnObject,
          items: l.value,
          parentIndentLines: e.indentLines ? [] : void 0,
          indentLinesVariant: x
        }), t)]
      });
    }), {};
  }
}), N0 = Y()({
  name: "VValidation",
  props: gs(),
  emits: {
    "update:modelValue": (e) => !0
  },
  setup(e, n) {
    let {
      slots: t
    } = n;
    const a = hs(e, "validation");
    return () => {
      var l;
      return (l = t.default) == null ? void 0 : l.call(t, a);
    };
  }
}), W0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  VAlert: qm,
  VAlertTitle: us,
  VApp: nm,
  VAppBar: Cm,
  VAppBarNavIcon: Wm,
  VAppBarTitle: jm,
  VAutocomplete: mh,
  VAvatar: Bt,
  VBadge: hh,
  VBanner: Sh,
  VBannerActions: Qs,
  VBannerText: Js,
  VBottomNavigation: wh,
  VBottomSheet: xh,
  VBreadcrumbs: _h,
  VBreadcrumbsDivider: tc,
  VBreadcrumbsItem: nc,
  VBtn: xe,
  VBtnGroup: hi,
  VBtnToggle: Am,
  VCard: Dh,
  VCardActions: ac,
  VCardItem: oc,
  VCardSubtitle: lc,
  VCardText: rc,
  VCardTitle: ic,
  VCarousel: Hh,
  VCarouselItem: Wh,
  VCheckbox: og,
  VCheckboxBtn: zt,
  VChip: na,
  VChipGroup: dg,
  VClassIcon: lo,
  VCode: jh,
  VCol: Sb,
  VColorPicker: My,
  VCombobox: Ey,
  VComponentIcon: fi,
  VConfirmEdit: Fy,
  VContainer: gb,
  VCounter: Pl,
  VDataIterator: Uy,
  VDataTable: sb,
  VDataTableFooter: Pa,
  VDataTableHeaders: wn,
  VDataTableRow: Fo,
  VDataTableRows: Cn,
  VDataTableServer: fb,
  VDataTableVirtual: db,
  VDatePicker: Bb,
  VDatePickerControls: Di,
  VDatePickerHeader: Mi,
  VDatePickerMonth: pi,
  VDatePickerMonths: Ei,
  VDatePickerYears: $i,
  VDefaultsProvider: Ce,
  VDialog: xi,
  VDialogBottomTransition: om,
  VDialogTopTransition: rm,
  VDialogTransition: Sl,
  VDivider: It,
  VEmptyState: Mb,
  VExpandTransition: kl,
  VExpandXTransition: so,
  VExpansionPanel: pb,
  VExpansionPanelText: Fi,
  VExpansionPanelTitle: Oi,
  VExpansionPanels: Fb,
  VFab: Nb,
  VFabTransition: im,
  VFadeTransition: ya,
  VField: nn,
  VFieldLabel: da,
  VFileInput: zb,
  VFooter: jb,
  VForm: Gb,
  VHover: Kb,
  VIcon: Be,
  VImg: Ut,
  VInfiniteScroll: Xb,
  VInput: ct,
  VItem: Jb,
  VItemGroup: Qb,
  VKbd: t1,
  VLabel: ta,
  VLayout: a1,
  VLayoutItem: i1,
  VLazy: r1,
  VLigatureIcon: Nf,
  VList: Gn,
  VListGroup: xa,
  VListImg: Bg,
  VListItem: Et,
  VListItemAction: Ns,
  VListItemMedia: pg,
  VListItemSubtitle: Ts,
  VListItemTitle: Bs,
  VListSubheader: aa,
  VLocaleProvider: s1,
  VMain: d1,
  VMenu: Un,
  VMessages: fs,
  VNavigationDrawer: k1,
  VNoSsr: w1,
  VNumberInput: I1,
  VOtpInput: A1,
  VOverlay: Wt,
  VPagination: Ti,
  VParallax: B1,
  VProgressCircular: bn,
  VProgressLinear: wl,
  VRadio: M1,
  VRadioGroup: E1,
  VRangeSlider: F1,
  VRating: N1,
  VResponsive: mi,
  VRow: Ib,
  VScaleTransition: ro,
  VScrollXReverseTransition: sm,
  VScrollXTransition: um,
  VScrollYReverseTransition: dm,
  VScrollYTransition: cm,
  VSelect: Po,
  VSelectionControl: tn,
  VSelectionControlGroup: cs,
  VSheet: Va,
  VSkeletonLoader: W1,
  VSlideGroup: wa,
  VSlideGroupItem: j1,
  VSlideXReverseTransition: fm,
  VSlideXTransition: vm,
  VSlideYReverseTransition: mm,
  VSlideYTransition: uo,
  VSlider: Li,
  VSnackbar: Ni,
  VSnackbarQueue: U1,
  VSpacer: Xc,
  VSparkline: Z1,
  VSpeedDial: J1,
  VStepper: o0,
  VStepperActions: vd,
  VStepperHeader: fd,
  VStepperItem: md,
  VStepperWindow: gd,
  VStepperWindowItem: hd,
  VSvgIcon: yl,
  VSwitch: u0,
  VSystemBar: c0,
  VTab: yd,
  VTable: xn,
  VTabs: h0,
  VTabsWindow: bd,
  VTabsWindowItem: Sd,
  VTextField: Kt,
  VTextarea: b0,
  VThemeProvider: k0,
  VTimePicker: B0,
  VTimePickerClock: Ri,
  VTimePickerControls: Hi,
  VTimeline: P0,
  VTimelineItem: x0,
  VToolbar: gi,
  VToolbarItems: M0,
  VToolbarTitle: oo,
  VTooltip: E0,
  VTreeview: O0,
  VTreeviewGroup: zi,
  VTreeviewItem: Wi,
  VValidation: N0,
  VVirtualScroll: Il,
  VWindow: Sn,
  VWindowItem: kn
}, Symbol.toStringTag, { value: "Module" })), j0 = {
  collapse: "svg:M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z",
  complete: "svg:M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z",
  cancel: "svg:M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",
  close: "svg:M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",
  delete: "svg:M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",
  // delete (e.g. v-chip close)
  clear: "svg:M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",
  success: "svg:M12,2C17.52,2 22,6.48 22,12C22,17.52 17.52,22 12,22C6.48,22 2,17.52 2,12C2,6.48 6.48,2 12,2M11,16.5L18,9.5L16.59,8.09L11,13.67L7.91,10.59L6.5,12L11,16.5Z",
  info: "svg:M13,9H11V7H13M13,17H11V11H13M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2Z",
  warning: "svg:M13,13H11V7H13M13,17H11V15H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",
  error: "svg:M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",
  prev: "svg:M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z",
  next: "svg:M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z",
  checkboxOn: "svg:M10,17L5,12L6.41,10.58L10,14.17L17.59,6.58L19,8M19,3H5C3.89,3 3,3.89 3,5V19C3,20.1 3.9,21 5,21H19C20.1,21 21,20.1 21,19V5C21,3.89 20.1,3 19,3Z",
  checkboxOff: "svg:M19,3H5C3.89,3 3,3.89 3,5V19C3,20.1 3.9,21 5,21H19C20.1,21 21,20.1 21,19V5C21,3.89 20.1,3 19,3M19,5V19H5V5H19Z",
  checkboxIndeterminate: "svg:M17,13H7V11H17M19,3H5C3.89,3 3,3.89 3,5V19C3,20.1 3.9,21 5,21H19C20.1,21 21,20.1 21,19V5C21,3.89 20.1,3 19,3Z",
  delimiter: "svg:M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2Z",
  // for carousel
  sortAsc: "svg:M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z",
  sortDesc: "svg:M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z",
  expand: "svg:M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z",
  menu: "svg:M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z",
  subgroup: "svg:M7,10L12,15L17,10H7Z",
  dropdown: "svg:M7,10L12,15L17,10H7Z",
  radioOn: "svg:M12,20C7.58,20 4,16.42 4,12C4,7.58 7.58,4 12,4C16.42,4 20,7.58 20,12C20,16.42 16.42,20 12,20M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2M12,7C9.24,7 7,9.24 7,12C7,14.76 9.24,17 12,17C14.76,17 17,14.76 17,12C17,9.24 14.76,7 12,7Z",
  radioOff: "svg:M12,20C7.58,20 4,16.42 4,12C4,7.58 7.58,4 12,4C16.42,4 20,7.58 20,12C20,16.42 16.42,20 12,20M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2Z",
  edit: "svg:M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z",
  ratingEmpty: "svg:M12,15.39L8.24,17.66L9.23,13.38L5.91,10.5L10.29,10.13L12,6.09L13.71,10.13L18.09,10.5L14.77,13.38L15.76,17.66M22,9.24L14.81,8.63L12,2L9.19,8.63L2,9.24L7.45,13.97L5.82,21L12,17.27L18.18,21L16.54,13.97L22,9.24Z",
  ratingFull: "svg:M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z",
  ratingHalf: "svg:M12,15.4V6.1L13.71,10.13L18.09,10.5L14.77,13.39L15.76,17.67M22,9.24L14.81,8.63L12,2L9.19,8.63L2,9.24L7.45,13.97L5.82,21L12,17.27L18.18,21L16.54,13.97L22,9.24Z",
  loading: "svg:M19,8L15,12H18C18,15.31 15.31,18 12,18C11,18 10.03,17.75 9.2,17.3L7.74,18.76C8.97,19.54 10.43,20 12,20C16.42,20 20,16.42 20,12H23M6,12C6,8.69 8.69,6 12,6C13,6 13.97,6.25 14.8,6.7L16.26,5.24C15.03,4.46 13.57,4 12,4C7.58,4 4,7.58 4,12H1L5,16L9,12",
  first: "svg:M18.41,16.59L13.82,12L18.41,7.41L17,6L11,12L17,18L18.41,16.59M6,6H8V18H6V6Z",
  last: "svg:M5.59,7.41L10.18,12L5.59,16.59L7,18L13,12L7,6L5.59,7.41M16,6H18V18H16V6Z",
  unfold: "svg:M12,18.17L8.83,15L7.42,16.41L12,21L16.59,16.41L15.17,15M12,5.83L15.17,9L16.58,7.59L12,3L7.41,7.59L8.83,9L12,5.83Z",
  file: "svg:M16.5,6V17.5C16.5,19.71 14.71,21.5 12.5,21.5C10.29,21.5 8.5,19.71 8.5,17.5V5C8.5,3.62 9.62,2.5 11,2.5C12.38,2.5 13.5,3.62 13.5,5V15.5C13.5,16.05 13.05,16.5 12.5,16.5C11.95,16.5 11.5,16.05 11.5,15.5V6H10V15.5C10,16.88 11.12,18 12.5,18C13.88,18 15,16.88 15,15.5V5C15,2.79 13.21,1 11,1C8.79,1 7,2.79 7,5V17.5C7,20.54 9.46,23 12.5,23C15.54,23 18,20.54 18,17.5V6H16.5Z",
  plus: "svg:M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",
  minus: "svg:M19,13H5V11H19V13Z",
  calendar: "svg:M19,19H5V8H19M16,1V3H8V1H6V3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C21,3.89 20.1,3 19,3H18V1M17,12H12V17H17V12Z",
  treeviewCollapse: "svg:M7,10L12,15L17,10H7Z",
  treeviewExpand: "svg:M10,17L15,12L10,7V17Z",
  eyeDropper: "svg:M19.35,11.72L17.22,13.85L15.81,12.43L8.1,20.14L3.5,22L2,20.5L3.86,15.9L11.57,8.19L10.15,6.78L12.28,4.65L19.35,11.72M16.76,3C17.93,1.83 19.83,1.83 21,3C22.17,4.17 22.17,6.07 21,7.24L19.08,9.16L14.84,4.92L16.76,3M5.56,17.03L4.5,19.5L6.97,18.44L14.4,11L13,9.6L5.56,17.03Z",
  upload: "svg:M11 20H6.5q-2.28 0-3.89-1.57Q1 16.85 1 14.58q0-1.95 1.17-3.48q1.18-1.53 3.08-1.95q.63-2.3 2.5-3.72Q9.63 4 12 4q2.93 0 4.96 2.04Q19 8.07 19 11q1.73.2 2.86 1.5q1.14 1.28 1.14 3q0 1.88-1.31 3.19T18.5 20H13v-7.15l1.6 1.55L16 13l-4-4l-4 4l1.4 1.4l1.6-1.55Z",
  color: "svg:M17.5 12a1.5 1.5 0 0 1-1.5-1.5A1.5 1.5 0 0 1 17.5 9a1.5 1.5 0 0 1 1.5 1.5a1.5 1.5 0 0 1-1.5 1.5m-3-4A1.5 1.5 0 0 1 13 6.5A1.5 1.5 0 0 1 14.5 5A1.5 1.5 0 0 1 16 6.5A1.5 1.5 0 0 1 14.5 8m-5 0A1.5 1.5 0 0 1 8 6.5A1.5 1.5 0 0 1 9.5 5A1.5 1.5 0 0 1 11 6.5A1.5 1.5 0 0 1 9.5 8m-3 4A1.5 1.5 0 0 1 5 10.5A1.5 1.5 0 0 1 6.5 9A1.5 1.5 0 0 1 8 10.5A1.5 1.5 0 0 1 6.5 12M12 3a9 9 0 0 0-9 9a9 9 0 0 0 9 9a1.5 1.5 0 0 0 1.5-1.5c0-.39-.15-.74-.39-1c-.23-.27-.38-.62-.38-1a1.5 1.5 0 0 1 1.5-1.5H16a5 5 0 0 0 5-5c0-4.42-4.03-8-9-8",
  command: "svg:M6,2A4,4 0 0,1 10,6V8H14V6A4,4 0 0,1 18,2A4,4 0 0,1 22,6A4,4 0 0,1 18,10H16V14H18A4,4 0 0,1 22,18A4,4 0 0,1 18,22A4,4 0 0,1 14,18V16H10V18A4,4 0 0,1 6,22A4,4 0 0,1 2,18A4,4 0 0,1 6,14H8V10H6A4,4 0 0,1 2,6A4,4 0 0,1 6,2M16,18A2,2 0 0,0 18,20A2,2 0 0,0 20,18A2,2 0 0,0 18,16H16V18M14,10H10V14H14V10M6,16A2,2 0 0,0 4,18A2,2 0 0,0 6,20A2,2 0 0,0 8,18V16H6M8,6A2,2 0 0,0 6,4A2,2 0 0,0 4,6A2,2 0 0,0 6,8H8V6M18,8A2,2 0 0,0 20,6A2,2 0 0,0 18,4A2,2 0 0,0 16,6V8H18Z",
  ctrl: "svg:M19.78,11.78L18.36,13.19L12,6.83L5.64,13.19L4.22,11.78L12,4L19.78,11.78Z",
  space: "svg:M3 15H5V19H19V15H21V19C21 20.1 20.1 21 19 21H5C3.9 21 3 20.1 3 19V15Z",
  shift: "svg:M15 18v-6h2.17L12 6.83L6.83 12H9v6zM12 4l10 10h-5v6H7v-6H2z",
  alt: "svg:M3 4h6.11l7.04 14H21v2h-6.12L7.84 6H3zm11 0h7v2h-7z",
  enter: "svg:M19 7v4H5.83l3.58-3.59L8 6l-6 6l6 6l1.41-1.42L5.83 13H21V7z",
  arrowup: "svg:M13 20h-2V8l-5.5 5.5l-1.42-1.42L12 4.16l7.92 7.92l-1.42 1.42L13 8z",
  arrowdown: "svg:M11 4h2v12l5.5-5.5l1.42 1.42L12 19.84l-7.92-7.92L5.5 10.5L11 16z",
  arrowleft: "svg:M20 11v2H8l5.5 5.5l-1.42 1.42L4.16 12l7.92-7.92L13.5 5.5L8 11z",
  arrowright: "svg:M4 11v2h12l-5.5 5.5l1.42 1.42L19.84 12l-7.92-7.92L10.5 5.5L16 11z",
  backspace: "svg:M19 15.59L17.59 17L14 13.41L10.41 17L9 15.59L12.59 12L9 8.41L10.41 7L14 10.59L17.59 7L19 8.41L15.41 12zM22 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H7c-.69 0-1.23-.36-1.59-.89L0 12l5.41-8.12C5.77 3.35 6.31 3 7 3zm0 2H7l-4.72 7L7 19h15z",
  play: "svg:M8,5.14V19.14L19,12.14L8,5.14Z",
  pause: "svg:M14,19H18V5H14M6,19H10V5H6V19Z",
  fullscreen: "svg:M5,5H10V7H7V10H5V5M14,5H19V10H17V7H14V5M17,14H19V19H14V17H17V14M10,17V19H5V14H7V17H10Z",
  fullscreenExit: "svg:M14,14H19V16H16V19H14V14M5,14H10V19H8V16H5V14M8,5H10V10H5V8H8V5M19,8V10H14V5H16V8H19Z",
  volumeHigh: "svg:M14,3.23V5.29C16.89,6.15 19,8.83 19,12C19,15.17 16.89,17.84 14,18.7V20.77C18,19.86 21,16.28 21,12C21,7.72 18,4.14 14,3.23M16.5,12C16.5,10.23 15.5,8.71 14,7.97V16C15.5,15.29 16.5,13.76 16.5,12M3,9V15H7L12,20V4L7,9H3Z",
  volumeMedium: "svg:M5,9V15H9L14,20V4L9,9M18.5,12C18.5,10.23 17.5,8.71 16,7.97V16C17.5,15.29 18.5,13.76 18.5,12Z",
  volumeLow: "svg:M7,9V15H11L16,20V4L11,9H7Z",
  volumeOff: "svg:M5.64,3.64L21.36,19.36L19.95,20.78L16,16.83V20L11,15H7V9H8.17L4.22,5.05L5.64,3.64M16,4V11.17L12.41,7.58L16,4Z"
}, Y0 = {
  component: yl
};
export {
  xn as $,
  d1 as A,
  k1 as B,
  Sb as C,
  Ib as D,
  My as E,
  Li as F,
  Wt as G,
  bn as H,
  Ts as I,
  nm as J,
  Wu as K,
  j0 as L,
  Y0 as M,
  pb as N,
  Oi as O,
  Fi as P,
  Fb as Q,
  bt as R,
  E1 as S,
  M1 as T,
  Il as U,
  xe as V,
  dg as W,
  Va as X,
  Xb as Y,
  Ti as Z,
  Xc as _,
  E0 as a,
  xi as a0,
  ic as a1,
  rc as a2,
  ac as a3,
  Sn as a4,
  kn as a5,
  W0 as a6,
  z0 as a7,
  Gb as a8,
  Bt as a9,
  u0 as aa,
  mh as ab,
  b0 as ac,
  aa as ad,
  Qb as ae,
  Jb as af,
  Be as b,
  Po as c,
  Et as d,
  Dh as e,
  It as f,
  Un as g,
  Ut as h,
  Kt as i,
  og as j,
  Gn as k,
  Bs as l,
  na as m,
  bl as n,
  h0 as o,
  yd as p,
  bd as q,
  Sd as r,
  Cm as s,
  W1 as t,
  io as u,
  Ey as v,
  jb as w,
  Am as x,
  wl as y,
  qm as z
};
